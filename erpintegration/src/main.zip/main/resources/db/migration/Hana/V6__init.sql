CREATE column TABLE EncryptedColumnModel
(
    encryptedModelID bigint not null,
    columnTypes integer,
    dbColumnName varchar(255),
    searchable boolean not null,
    value varchar(255),
    taskObj_taskID bigint,
    primary key (encryptedModelID)
);

CREATE column TABLE JobSubmitTable
(
    jobID bigint not null,
    jobType integer,
    startDate timestamp,
    status integer,
    tableName varchar(255),
    tenantID varchar(255),
    updatedDate timestamp,
    primary key (jobID)
);

CREATE column TABLE TaskRunningStatus
(
    taskID bigint not null,
    batchDone integer not null,
    columnType integer,
    jobID bigint,
    numberOfColumns integer not null,
    orderBy varchar(255),
    startDate timestamp,
    status integer,
    tableName varchar(255),
    tenantID varchar(255),
    updatedDate timestamp,
    whereClause varchar(255),
    primary key (taskID)
);

CREATE column TABLE FileJobSubmitTable
(
    jobID bigint not null,
    folderName varchar(255),
    jobType integer,
    numberOfFiles integer not null,
    startDate timestamp,
    status integer,
    supportedSourceTypes integer,
    tenantID varchar(255),
    updatedDate timestamp,
    primary key (jobID)
);

CREATE column TABLE FileTaskRunningStatus
(
    taskID bigint not null,
    fileName varchar(255),
    jobID bigint,
    startDate timestamp,
    status integer,
    tenantID varchar(255),
    updatedDate timestamp,
    primary key (taskID)
);