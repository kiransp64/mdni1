-- ID generator sequence for JobSubmitTable
DO()
BEGIN
DECLARE maxJobId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
SEQ_EXISTS := 1;
SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'JOBSUBMITTABLE_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
	-- ID generator sequence for JobSubmitTable
    SELECT MAX(jobID) + 1 INTO maxJobId FROM JobSubmitTable;
        IF maxJobId IS null
        THEN
        maxJobId = 1;
        END IF;
    execute immediate 'CREATE SEQUENCE JobSubmitTable_SEQ START WITH ' || maxJobId || ' INCREMENT BY 1';
END IF;

END;



-- ID generator sequence for TaskRunningStatus
DO()
BEGIN
DECLARE maxTaskId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
SEQ_EXISTS := 1;
SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'TASKRUNNINGSTATUS_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
	-- ID generator sequence for TaskRunningStatus
    SELECT MAX(taskID) + 1 INTO maxTaskId FROM TaskRunningStatus;
        IF maxTaskId IS null
        THEN
        maxTaskId = 1;
        END IF;
    execute immediate 'CREATE SEQUENCE TaskRunningStatus_SEQ START WITH ' || maxTaskId || ' INCREMENT BY 1';
END IF;

END;

-- ID generator sequence for EncryptedColumnModel
DO()
BEGIN
DECLARE maxColId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
SEQ_EXISTS := 1;
SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'ENCRYPTEDCOLUMNMODEL_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
	-- ID generator sequence for EncryptedColumnModel
    SELECT MAX(encryptedModelID) + 1 INTO maxColId FROM EncryptedColumnModel;
        IF maxColId IS null
        THEN
        maxColId = 1;
        END IF;
    execute immediate 'CREATE SEQUENCE EncryptedColumnModel_SEQ START WITH ' || maxColId || ' INCREMENT BY 1';
END IF;

END;

-- ID generator sequence for FileJobSubmitTable
DO()
BEGIN
DECLARE maxFileJobId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
SEQ_EXISTS := 1;
SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'FILEJOBSUBMITTABLE_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
	-- ID generator sequence for FileJobSubmitTable
    SELECT MAX(jobID) + 1 INTO maxFileJobId FROM FileJobSubmitTable;
        IF maxFileJobId IS null
        THEN
        maxFileJobId = 1;
        END IF;
    execute immediate 'CREATE SEQUENCE FileJobSubmitTable_SEQ START WITH ' || maxFileJobId || ' INCREMENT BY 1';
END IF;

END;

-- ID generator sequence for FileTaskRunningStatus
DO()
BEGIN
DECLARE maxFileTaskId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
SEQ_EXISTS := 1;
SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'FILETASKRUNNINGSTATUS_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
	-- ID generator sequence for FileTaskRunningStatus
    SELECT MAX(taskID) + 1 INTO maxFileTaskId FROM FileTaskRunningStatus;
        IF maxFileTaskId IS null
        THEN
        maxFileTaskId = 1;
        END IF;
    execute immediate 'CREATE SEQUENCE FileTaskRunningStatus_SEQ START WITH ' || maxFileTaskId || ' INCREMENT BY 1';
END IF;

END;


-- with underscore sequence

-- ID generator sequence for JobSubmitTable
DO()
BEGIN
	DECLARE maxJobId BIGINT DEFAULT 1;
	DECLARE SEQ_EXISTS int;
	DECLARE TABLE_EXISTS int;
	SEQ_EXISTS := 1;
	
	TABLE_EXISTS := 0;
	SELECT COUNT(*) INTO TABLE_EXISTS FROM TABLES WHERE TABLE_NAME = 'JOB_SUBMIT_TABLE' AND SCHEMA_NAME = CURRENT_USER ;
	IF(TABLE_EXISTS = 1) THEN
		-- ID generator sequence for JobSubmitTable
	    execute immediate ' SELECT MAX(jobID) + 1 FROM JOB_SUBMIT_TABLE' INTO maxJobId;
	        IF maxJobId IS null
	        THEN
	        maxJobId = 1;
	        END IF;
	END IF;
	
	
	SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'JOB_SUBMIT_TABLE_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
	IF(SEQ_EXISTS = 0) THEN
	    execute immediate 'CREATE SEQUENCE JOB_SUBMIT_TABLE_SEQ START WITH ' || maxJobId || ' INCREMENT BY 1';
	END IF;
	
END;




-- ID generator sequence for TaskRunningStatus
DO()
BEGIN
DECLARE maxTaskId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
DECLARE TABLE_EXISTS int;
SEQ_EXISTS := 1;
TABLE_EXISTS := 0;


	SELECT COUNT(*) INTO TABLE_EXISTS FROM TABLES WHERE TABLE_NAME = 'TASK_RUNNING_STATUS' AND SCHEMA_NAME = CURRENT_USER ;
	IF(TABLE_EXISTS = 1) THEN
		-- ID generator sequence for JobSubmitTable
	    execute immediate ' SELECT MAX(taskID) + 1 FROM TASK_RUNNING_STATUS ' INTO maxTaskId;
        IF maxTaskId IS null
        THEN
        maxTaskId = 1;
        END IF;
	END IF;


SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'TASK_RUNNING_STATUS_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
    execute immediate 'CREATE SEQUENCE TASK_RUNNING_STATUS_SEQ START WITH ' || maxTaskId || ' INCREMENT BY 1';
END IF;

END;

-- ID generator sequence for EncryptedColumnModel
DO()
BEGIN
DECLARE maxColId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
DECLARE TABLE_EXISTS int;
SEQ_EXISTS := 1;
TABLE_EXISTS := 0;


	SELECT COUNT(*) INTO TABLE_EXISTS FROM TABLES WHERE TABLE_NAME = 'ENCRYPTED_COLUMN_MODEL' AND SCHEMA_NAME = CURRENT_USER ;
	IF(TABLE_EXISTS = 1) THEN
		-- ID generator sequence for JobSubmitTable
	    execute immediate ' SELECT MAX(ENCRYPTED_MODELID) + 1 FROM ENCRYPTED_COLUMN_MODEL' INTO maxColId;
        IF maxColId IS null
        THEN
        maxColId = 1;
        END IF;
	END IF;

SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'ENCRYPTED_COLUMN_MODEL_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
    execute immediate 'CREATE SEQUENCE ENCRYPTED_COLUMN_MODEL_SEQ START WITH ' || maxColId || ' INCREMENT BY 1';
END IF;

END;

-- ID generator sequence for FileJobSubmitTable
DO()
BEGIN
DECLARE maxFileJobId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
DECLARE TABLE_EXISTS int;
SEQ_EXISTS := 1;
TABLE_EXISTS := 0;

	SELECT COUNT(*) INTO TABLE_EXISTS FROM TABLES WHERE TABLE_NAME = 'FILE_JOB_SUBMIT_TABLE' AND SCHEMA_NAME = CURRENT_USER ;
	IF(TABLE_EXISTS = 1) THEN
		-- ID generator sequence for JobSubmitTable
	    execute immediate ' SELECT MAX(jobID) + 1 FROM FILE_JOB_SUBMIT_TABLE' INTO maxFileJobId;
        IF maxFileJobId IS null
        THEN
        maxFileJobId = 1;
        END IF;
	END IF;

SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'FILE_JOB_SUBMIT_TABLE_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
    execute immediate 'CREATE SEQUENCE FILE_JOB_SUBMIT_TABLE_SEQ START WITH ' || maxFileJobId || ' INCREMENT BY 1';
END IF;

END;

-- ID generator sequence for FileTaskRunningStatus
DO()
BEGIN
DECLARE maxFileTaskId BIGINT DEFAULT 1;
DECLARE SEQ_EXISTS int;
DECLARE TABLE_EXISTS int;
SEQ_EXISTS := 1;
TABLE_EXISTS := 0;


	SELECT COUNT(*) INTO TABLE_EXISTS FROM TABLES WHERE TABLE_NAME = 'FILE_TASK_RUNNING_STATUS' AND SCHEMA_NAME = CURRENT_USER ;
	IF(TABLE_EXISTS = 1) THEN
		-- ID generator sequence for JobSubmitTable
	    execute immediate ' SELECT MAX(taskID) + 1  FROM FILE_TASK_RUNNING_STATUS' INTO maxFileTaskId;
        IF maxFileTaskId IS null
        THEN
        maxFileTaskId = 1;
        END IF;
	END IF;

SELECT COUNT(*) INTO SEQ_EXISTS FROM SEQUENCES WHERE SEQUENCE_NAME = 'FILE_TASK_RUNNING_STATUS_SEQ' AND SCHEMA_NAME = CURRENT_USER ;
IF(SEQ_EXISTS = 0) THEN
    execute immediate 'CREATE SEQUENCE FILE_TASK_RUNNING_STATUS_SEQ START WITH ' || maxFileTaskId || ' INCREMENT BY 1';
END IF;

END;
