/*To be executed only when HANA schema is creted independently, not necessary incase of migration from
Oracle as it is already present in it */
insert into type_map_tab values('101','1','XmlPayload','1');	
insert into type_map_tab values('102','1','PurchaseOrg','1');	
insert into type_map_tab values('103','1','PurchaseGroup','1');	
insert into type_map_tab values('104','1','SequenceNumberGetter','1');	
insert into type_map_tab values('105','1','IntegrationConfig','1');	
insert into type_map_tab values('106','1','IncoTerms','1');	
insert into type_map_tab values('107','1','InternalOrder','1');	
insert into type_map_tab values('108','1','CurrencyMapping','1');	
insert into type_map_tab values('109','1','ItemCategory','1');	
insert into type_map_tab values('110','1','TaxCode','1');	
insert into type_map_tab values('111','1','WBSElement','1');	
insert into type_map_tab values('112','1','CompanyCode','1');	
insert into type_map_tab values('113','1','CurrencyConversionRate','1');	
insert into type_map_tab values('114','1','Tenant','1');	
insert into type_map_tab values('115','1','SenderBusinessSystem','1');	
insert into type_map_tab values('116','1','Region','1');	
insert into type_map_tab values('117','1','GeneralLedger','1');	
insert into type_map_tab values('118','1','PartitionedCommodityCode','1');	
insert into type_map_tab values('119','1','PlantPurchaseOrgCombo','1');	
insert into type_map_tab values('120','1','CostCenter','1');	
insert into type_map_tab values('121','1','Audit','1');	
insert into type_map_tab values('122','1','CountryCode','1');	
insert into type_map_tab values('123','1','CurrencyCode','1');	
insert into type_map_tab values('124','1','LocaleCode','1');	
insert into type_map_tab values('125','1','UOMCode','1');	
insert into type_map_tab values('126','1','Address','1');	
insert into type_map_tab values('127','1','PaymentMethodType','1');	
insert into type_map_tab values('128','1','Schema','1');	
insert into type_map_tab values('129','1','AccountCategory','1');	
insert into type_map_tab values('130','1','User','1');	
insert into type_map_tab values('131','1','IntegrationJobLog','1');	
insert into type_map_tab values('132','1','EntityVersion','1');	
insert into type_map_tab values('133','1','Currency','1');

Insert into HANA_TENANT_TAB (AN_ID,REALM,HANA_TENANT_ID,HANA_POD,DATE_CREATED,DATE_UPDATED,IS_ACTIVE,STATUS) values ('System','System',0,1,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,1,2);

CREATE SEQUENCE HIBERNATE_SEQUENCE  START WITH 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20 NO CYCLE;
CREATE SEQUENCE tenant_id_sequence  START WITH 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20 NO CYCLE;
 