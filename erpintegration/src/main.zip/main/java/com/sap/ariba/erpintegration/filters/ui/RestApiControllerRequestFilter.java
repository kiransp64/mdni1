package com.sap.ariba.erpintegration.filters.ui;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.common.utility.OAuth2UserInfo;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.handlers.CredentialAuthenticatorFactory;
import com.sap.ariba.erpintegration.handlers.CredentialBasedAuthenticator;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.Constants;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import jakarta.servlet.Filter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.HttpHeaders;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
@Order(1)
public class RestApiControllerRequestFilter implements Filter
{

    private static String oauthValidationFailureMessage = "Invalid token, validation failed";
    private static String missingAuthHeaderMessage = "Missing authorization header";

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.filters.UIApiControllerRequestFilter";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    private static final String Basic = "basic";

    @Autowired
    private OAuthTokenManager oAuthTokenManager;

    @Autowired
    private CredentialAuthenticatorFactory credentialAuthenticatorFactory;

    @Override
    public void init (FilterConfig filterConfig) throws ServletException
    {

    }

    @Override
    public void doFilter (ServletRequest req,
                          ServletResponse res,
                          FilterChain chain)
        throws IOException,
        ServletException
    {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String requestUri = request.getRequestURI();
        // Condition added for Basic authentication for /uploadWSDLFile resource for i.e Credential based authentication
        if (StringUtils.isNotBlank(requestUri) && requestUri.contains("/uploadWSDLFile")) {
            final String authorization = request.getHeader(HttpHeaders.AUTHORIZATION);
            String tenantId = request.getParameter(Constants.KeyTenantId);
            if (StringUtils.isBlank(authorization)) {
                logger.error("Missing Authorization Header");
                writeErrorResponse(missingAuthHeaderMessage, HttpStatus.SC_UNAUTHORIZED, response, requestUri);
                return;
            }
            if (StringUtils.isBlank(tenantId)) {
                logger.error("Tenant not passed");
                writeErrorResponse(missingAuthHeaderMessage, HttpStatus.SC_BAD_REQUEST, response, requestUri);
                return;
            }
            // if tenantId doesn't exist or is not registered
            if (!(Utility.isTenantExists(tenantId))) {
                logger.error("Not a valid incoming request. Tenant {} not recognized", tenantId);
                writeErrorResponse("Not a valid incoming request ,Tenant : " + tenantId + " not recognized",
                        HttpStatus.SC_BAD_REQUEST, response, requestUri);
                return;
            }
            if (StringUtils.isNotBlank(authorization) && authorization.toLowerCase().startsWith(Basic)) {

                // Authorization: Basic base64credentials
                String base64Credentials = authorization.substring("Basic".length()).trim();
                byte[] credentialDecoded = Base64.getDecoder().decode(base64Credentials);
                String credentials = new String(credentialDecoded, StandardCharsets.UTF_8);
                // credentials = username:password
                final String[] credValues = credentials.split(":", 2);
                try {
                    if (getCredentialBasedAuthenticator().validateCredentials(tenantId, "", credValues[0], credValues[1])) {
                        logger.info("Verification of Basic OAuth token is successful for /uploadWSDLFile");
                    } else {
                        logger.error("Basic OAuth verification failed");
                        writeErrorResponse("Basic Auth incorrect",
                                HttpStatus.SC_UNAUTHORIZED, response, requestUri);
                        return;
                    }
                } catch (Exception e) {
                    logger.error("Authentication issue : CredentialBasedAuthentication verification failed for /UploadWsdlFile : {}", e.getMessage(), e);
                     if (e instanceof IntegrationServiceException) {
                        logger.warn("Authentication issue " + e.getMessage());
                    }
                    //TODo, if it is required to audit the authentication failure
                    //auditClientDataService.auditAuthentication(message," CredentialBasedAuthentication verification failed, For /uploadWSDL " + ex.getMessage());
                    //auditClientDataService.auditWsdlUpload(request,  e.getMessage(), null, false);
                    writeErrorResponse("Internal server Error, Please reach out to Internal System",
                            HttpStatus.SC_INTERNAL_SERVER_ERROR, response, requestUri);
                    return;
                }


            } else {
                logger.debug("Basic OAuth verification is failed");
                writeErrorResponse("Basic Auth incorrect",
                        HttpStatus.SC_UNAUTHORIZED, response, requestUri);
                return;
            }
            chain.doFilter(request, response);
        }
        else if (!request.getRequestURI().contains("/inspectorapi/")) {
            chain.doFilter(req, res);
        }
        else {
            oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(OAuthTokenManager.class);
            String authHeader = request.getHeader("Authorization");
            if(authHeader == null) {
                writeErrorResponse(missingAuthHeaderMessage, HttpStatus.SC_UNAUTHORIZED, response, requestUri);
                return;
            }
            OAuth2UserInfo userInfo = oAuthTokenManager.getUserInfo(authHeader);
            if(userInfo == null) {
                writeErrorResponse(oauthValidationFailureMessage, HttpStatus.SC_UNAUTHORIZED, response, requestUri);
                return;
            }
            chain.doFilter(request, response);
        }

    }

    private void writeErrorResponse(String errResponse,
                                    int status,
                                    HttpServletResponse response,
                                    String url)
                                        throws IOException {

        response.setContentType("application/json");
        ObjectMapper mapper = new ObjectMapper();
        String errorResponse =  mapper.writeValueAsString(errResponse);
        response.setStatus(status);
        logger.error("Request to the api "+ url + " failed due to the reason: "+errorResponse);
		ServletOutputStream out = response.getOutputStream();
		out.write(errResponse.getBytes());
		out.flush();
		out.close();
    }

    private CredentialBasedAuthenticator getCredentialBasedAuthenticator ()
    {
        return credentialAuthenticatorFactory.getCredentialBasedAuthenticator();
    }

    @Override
    public void destroy ()
    {

    }
}
