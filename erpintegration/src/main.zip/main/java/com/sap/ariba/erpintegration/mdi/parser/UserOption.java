package com.sap.ariba.erpintegration.mdi.parser;

import com.sap.ariba.erpintegration.mdi.exception.AttributeParserErrorListener;
import com.sap.ariba.erpintegration.mdi.exception.ResourceParseException;
import com.sap.ariba.erpintegration.mdi.parser.model.Attribute;
import com.sap.ariba.erpintegration.mdi.parser.model.Attributes;
import com.sap.ariba.erpintegration.mdi.parser.model.PaginatedAttributesOptions;
import com.sap.ariba.erpintegration.mdi.parser.user.grammar.UserLexer;
import com.sap.ariba.erpintegration.mdi.parser.user.grammar.UserParser;
import com.sap.ariba.erpintegration.mdi.parser.visitor.UserOptionVisitor;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.TokenStream;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Arrays;

/**
 * UserOption class is root class to take SCIM GET apis attribute parameter and , using ANTLR grammar
 * it will parse and filter out the pagination
 * option and other attribute parts like attribute list filter options
 *
 * <p>
 * * for more information and test cases checkout GroupOptionVisitorTest and UserOptionVisitorTest.java files
 */
public class UserOption
{

    private static final Logger logger = LoggerFactory.getLogger(UserOption.class);

    /**
     * This method : getPaginationOptions() will receive attribute string pagination option from SCIM API i.e. User /Group
     * and using User.g4 grammar it will parse the attribute String
     * and determine the pagination options and list of attributes
     *
     * @param attribute param will be passed here as big string that will contain pagination option and attribute list
     * @param parentTop  count option of pagination
     * @param parentSkip startIndex option of Pagination
     * @return Attribute Object contain Pagination option, type and attribute list
     */
    public Attribute getPaginationOptions (String attribute,
                                           int parentTop,
                                           int parentSkip)
    {
        if (null != attribute) {
            try {
                UserOptionVisitor paginationVisitor = (parentTop == -1 && parentSkip == -1) ?
                                new UserOptionVisitor() :
                                new UserOptionVisitor(parentTop,
                                                      parentSkip);
                AttributeParserErrorListener errorListener = new AttributeParserErrorListener();
                CharStream charStream = CharStreams.fromString(attribute);
                UserLexer lexer = new UserLexer(charStream);
                lexer.addErrorListener(errorListener);
                TokenStream tokens = new CommonTokenStream(lexer);
                UserParser parser = new UserParser(tokens);
                parser.addErrorListener(errorListener);
                UserParser.UserContext context = parser.user();
                return context.accept(paginationVisitor);
            }
            catch (Exception e) {
                logger.error("Error while trying to parse attribute , Error Message : {}",
                             e.getMessage());
                throw new ResourceParseException(
                                "Error while trying to parse attribute - " + attribute + " - "
                                                + e.getMessage(),
                                e);
            }
        }
        else {
            logger.error("Mandatory input attribute string not provided.");
            throw new ResourceParseException("attribute input is mandatory.");
        }
    }

    public Attributes getPaginationOptions (String attribute)
    {
        Attribute att;
        Attributes attributes = new Attributes();
        PaginatedAttributesOptions options = new PaginatedAttributesOptions();

        if (StringUtils.equalsIgnoreCase(attribute,
                                         "*")) {
            attributes.setMembers(Arrays.asList(attribute));
            attributes.setPaginatedAttributesOptions(null);
            return attributes;
        }
        att = getPaginationOptions(attribute,
                                   -1,
                                   -1);

        options.setCount(att.getCount());
        options.setStartIndex(att.getStartIndex());
        attributes.setMembers(att.getAttributes());
        attributes.setPaginatedAttributesOptions(options);
        return attributes;
    }

}
