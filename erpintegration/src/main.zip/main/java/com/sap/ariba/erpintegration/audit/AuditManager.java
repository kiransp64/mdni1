package com.sap.ariba.erpintegration.audit;

/**
 * This interface gives you access to interact with Audit Service
 * 
 * @author i339952
 */
public interface AuditManager
{
    /**
     * This method will log an audit.
     * @param tenantId
     * @param operation
     * @param comment
     */
    public void logAudit (String tenantId, Operation operation, String comment);
}
