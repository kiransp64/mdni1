package com.sap.ariba.erpintegration.service.exception;

public class DataCompressionException extends Exception {

    public DataCompressionException(Exception e) {
        super(e);
    }

    public DataCompressionException(String errorMessage, Exception e) {
        super(errorMessage, e);
    }

    public DataCompressionException (String errorMessage)
    {
        super(errorMessage);
    }
}
