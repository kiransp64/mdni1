package com.sap.ariba.erpintegration.onemds.tenant;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import com.sap.ariba.erpintegration.onemds.destination.DestinationFetcherService;
import com.sap.ariba.erpintegration.onemds.destination.DestinationFetcherServiceImpl;
import com.sap.ariba.erpintegration.onemds.exception.TenantServiceException;
import com.sap.ariba.erpintegration.persistence.model.Tenant;
import com.sap.ariba.erpintegration.util.ErrorUtil;

@Component 
@Primary 
@ConditionalOnExpression("${environment.mdcs:false}==true") 
@Qualifier("mdcsMdiDestinationTenantService")
public class MDCSMdiDestinationTenantServiceImpl extends TenantServiceImpl
{

    private static final Logger logger = LoggerFactory.getLogger(
        MDCSMdiDestinationTenantServiceImpl.class);

    @Value("${onemds.fetch.using.destination}")
    private boolean fetchUsingDestination;

    @Autowired
    protected DestinationFetcherService destinationFetcherServiceImpl;

    @Autowired @Qualifier("mdcsMdiTenantService")
    private TenantService mdcsMdiTenantService;

    @Override
    public String getAppURL (String tenantID) throws TenantServiceException
    {
        String appUrl = null;

        if (fetchUsingDestination) {
            boolean isFallBackToMDI = isFallBackToMDI(tenantID);

            Map<String, Object> destination = null;
            try {
                destination = destinationFetcherServiceImpl.getDestination(tenantID);
            }
            catch (Exception e) {
                handleDestinationFetchFail(tenantID, isFallBackToMDI, e);
            }
            if (destination != null) {
                appUrl = (String)destination.get(
                    DestinationFetcherServiceImpl.DESTINATION_URL_KEY);
                return appUrl;
            }
            else if (!isFallBackToMDI) {
                handleDestinationNotFound(tenantID);
            }
        }
        appUrl = mdcsMdiTenantService.getAppURL(tenantID);

        return appUrl;
    }

    @Override
    public String getClientID (String tenantID) throws TenantServiceException
    {
        String clientID = null;

        if (fetchUsingDestination) {
            boolean isFallBackToMDI = isFallBackToMDI(tenantID);
            Map<String, Object> destination = null;
            try {
                destination = destinationFetcherServiceImpl.getDestination(tenantID);
            }
            catch (Exception e) {
                handleDestinationFetchFail(tenantID, isFallBackToMDI, e);
            }
            if (destination != null) {
                clientID = (String)destination.get(
                    DestinationFetcherServiceImpl.DESTINATION_CLIENT_ID);
                return clientID;
            }
            else if (!isFallBackToMDI) {
                handleDestinationNotFound(tenantID);
            }
        }
        clientID = mdcsMdiTenantService.getClientID(tenantID);
        return clientID;

    }

    @Override
    public String getClientSecret (String tenantID) throws TenantServiceException
    {
        String clientSecret = null;

        if (fetchUsingDestination) {
            boolean isFallBackToMDI = isFallBackToMDI(tenantID);
            Map<String, Object> destination = null;
            try {
                destination = destinationFetcherServiceImpl.getDestination(tenantID);
            }
            catch (Exception e) {
                handleDestinationFetchFail(tenantID, isFallBackToMDI, e);
            }
            if (destination != null) {
                clientSecret = (String)destination.get(
                    DestinationFetcherServiceImpl.DESTINATION_CLIENT_SECRET);
                return clientSecret;
            }
            else if (!isFallBackToMDI) {
                handleDestinationNotFound(tenantID);
            }
        }
        clientSecret = mdcsMdiTenantService.getClientSecret(tenantID);
        return clientSecret;

    }

    @Override
    public String getAuthURL (String tenantID) throws TenantServiceException
    {
        String authURL = null;

        if (fetchUsingDestination) {
            boolean isFallBackToMDI = isFallBackToMDI(tenantID);
            Map<String, Object> destination = null;
            try {
                destination = destinationFetcherServiceImpl.getDestination(tenantID);
            }
            catch (Exception e) {
                handleDestinationFetchFail(tenantID, isFallBackToMDI, e);
            }
            if (destination != null) {
                authURL = (String)destination.get(
                    DestinationFetcherServiceImpl.DESTINATION_URL_TOKEN_SERVICE_URL);
                return authURL;
            }
            else if (!isFallBackToMDI) {
                handleDestinationNotFound(tenantID);
            }
        }
        authURL = mdcsMdiTenantService.getAuthURL(tenantID);
        return authURL;
    }

    @Override
    public boolean isTenantValid (String tenantID) throws TenantServiceException
    {
        return true;
    }

    public boolean isFallBackToMDI (String tenantID) throws TenantServiceException
    {
        boolean isFallBackToMDI = true;
        try {

            Tenant tenant = mdcsMdiTenantService.getTenant(tenantID);
            boolean destinationEnabled = tenant.isDestinationEnabled();
            if (destinationEnabled) {
                /*
                 * Destination of type sap.mdi.mdcs.hub is previously configured .
                 */
                isFallBackToMDI = false;
            }

        }
        catch (TenantServiceException e) {
            logger.error(
                "Error - {}, while fetching tenant for tenantID : {}",
                ErrorUtil.getCompleteCausedByErrors(e),
                tenantID);
            throw new TenantServiceException(
                "Error while fetching tenant for tenantID " + tenantID,
                e);
        }
        return isFallBackToMDI;
    }

    public void handleDestinationFetchFail (String tenantID,
                                             boolean isFallBackToMDI,
                                             Exception e)
        throws TenantServiceException
    {

        logger.error(
            "Error - {}, while fetching destination for tenant : {}",
            ErrorUtil.getCompleteCausedByErrors(e),
            tenantID);
        if (!isFallBackToMDI) {
            logger.error(
                "Error - {}, while fetching destination for tenant : {}.An Destination of type sap.mdi.mdcs.hub was configured for this Tenant .",
                tenantID);
            throw new TenantServiceException(
                "Error while fetching destination for tenant :  " + tenantID
                    + ".An Destination of type sap.mdi.mdcs.hub was configured for this Tenant .",
                e);
        }

    }

    public void handleDestinationNotFound (String tenantID) throws TenantServiceException
    {

        logger.error(
            "Destination of type sap.mdi.mdcs.hub was configured for tenant : {} .But now there is no Destination of type sap.mdi.mdcs.hub found.",
            tenantID);
        throw new TenantServiceException(
            "Could not find Destination of type sap.mdi.mdcs.hub for tenant :" + tenantID);
    }
}
