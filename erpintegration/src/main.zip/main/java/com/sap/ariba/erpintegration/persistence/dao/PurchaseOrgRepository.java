package com.sap.ariba.erpintegration.persistence.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.annotations.BatchSize;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import com.sap.ariba.erpintegration.persistence.model.PurchaseOrg;

@Component("PurchaseOrgRepositoryComponent")
public interface PurchaseOrgRepository<T,D> extends GenericDAO<PurchaseOrg, Long> {

    @Query("select s from PurchaseOrg s where s.tenantId = :tenantId and s.purchasingOrgID = :purchasingOrgId")
    GenericEntity findOne(@Param("tenantId") long tenantId, @Param("purchasingOrgId") String purchasingOrgId);

    @Query("select s from PurchaseOrg s where s.tenantId = :tenantId and s.purchasingOrgID = :purchasingOrgId and  s.purchasingOrgID = :companyCode")
    GenericEntity findOne(@Param("tenantId") long tenantId, @Param("purchasingOrgId") String purchasingOrgId,@Param("companyCode") String companyCode);

    @Query("select s from PurchaseOrg s where s.purchasingOrgID = :purchasingOrgID")
    List<GenericEntity> findAllReferences(@Param("purchasingOrgID") String purchasingOrgID);

    @Query("select s from PurchaseOrg s where dateUpdated > :timeUpdated and tenantId = :tenantId order by id")
    @BatchSize(size = 1000)
    public List<GenericEntity> findAll(@Param("timeUpdated") Date timeUpdated, @Param("tenantId") long tenantId);

    @Query("select s from PurchaseOrg s where tenantId = :tenantId order by id")
    @BatchSize(size = 1000)
    public List<GenericEntity> findAll(@Param("tenantId") long tenantId);

    @Query("select data from PurchaseOrg where dateUpdated > :timeUpdated and id > :lastRecordId and tenantId = :tenantId order by id")
    @BatchSize(size = 1000)
    public List<GenericEntity> findAll(@Param("timeUpdated") Date timeUpdated, @Param("lastRecordId") String lastRecordId,@Param("tenantId") long tenantId);

    @Query("select s from PurchaseOrg s where s.dateUpdated >= :minTimeUpdated and s.dateUpdated <= :maxTimeUpdated and s.tenantId = :tenantId order by s.id asc")
    public Page<GenericEntity> findAll (@Param("tenantId") long tenantId,
                                        @Param("minTimeUpdated") Date minTimeUpdated,
                                        @Param("maxTimeUpdated") Date maxTimeUpdated,
                                                           Pageable pageable);

    @Query("select s from PurchaseOrg s where s.dateUpdated >= :minTimeUpdated and s.dateUpdated <= :maxTimeUpdated and s.id > :lastRecordId and s.tenantId = :tenantId order by s.id asc")
    public Page<GenericEntity> findAll (@Param("tenantId") long tenantId,
                                        @Param("minTimeUpdated") Date minTimeUpdated,
                                        @Param("maxTimeUpdated") Date maxTimeUpdated,
                                        @Param("lastRecordId") String lastRecordId,
                                                        Pageable pageable);
}
