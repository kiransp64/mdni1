/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.filters;

import com.sap.ariba.erpintegration.monitor.passport.context.ContextHandler;
import com.sap.ariba.erpintegration.monitor.passport.context.ContextHolder;
import com.sap.ariba.erpintegration.monitor.passport.context.EventContext;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;

import static com.sap.ariba.erpintegration.filters.ScimUtils.getRequestOperation;
import static com.sap.ariba.erpintegration.filters.ScimUtils.isScimCall;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INTEGRATION_MONITORING_ENABLE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI_CRITICAL_MONITORING_FILTER;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.SCIM_IM_INTEGRATION;
import static com.sap.ariba.erpintegration.util.EventNameToObjectMap.getObjectName;

/**
 * This filter introduced for scim integration monitoring related activity.
 */
@Slf4j
@Order(0)
@Component
@ConditionalOnExpression(INTEGRATION_MONITORING_ENABLE)
public class ScimMonitoringFilter extends MonitoringFilter
{

    @Autowired
    private ContextHandler contextHandler;

    @Override
    public void doFilter (ServletRequest req,
                          ServletResponse res,
                          FilterChain chain) throws IOException, ServletException
    {
        log.info("{} , From SCIM Monitoring filter.",
                 SCIM_IM_INTEGRATION);
        HttpServletRequest request = (HttpServletRequest)req;
        try {
            if (isScimCall(request)) {
                super.setRequestContextToCurrentThread(request);
                setRequiredSCIMParamToThreadContext(request);
                super.logCurrentContextDetail(request.getRequestURI());
            }
        }
        catch (Exception e) {
            log.error("{} , RequestUri - {} , Exception - {} , while processing the request from SCIM Monitoring Filter .",
                      MDNI_CRITICAL_MONITORING_FILTER,
                      request.getRequestURI(),
                      ErrorUtil.getCompleteCausedByErrors(e));
        }
        finally {
            chain.doFilter(request,
                           res);
            ContextHolder.removeContext();
        }
    }

    @Override
    public void destroy ()
    {
        super.destroy();
    }


    /**
     * Setting required Scim related IM Data to Thread context
     *
     * @param request
     */
    private void setRequiredSCIMParamToThreadContext (HttpServletRequest request)
    {
        EventContext eventContext = contextHandler.fetchCurrentEventContextThreadDetails();
        if (ObjectUtils.isNotEmpty(eventContext)) {
            eventContext.setObjectName(getObjectName(request.getRequestURI()));
            eventContext.setOperation(getRequestOperation(request.getMethod()));
            contextHandler.setContextInThread(eventContext);
        }
    }
}
