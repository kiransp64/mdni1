package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.interceptor.Fault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by i318483 on 02/05/17.
 */
@Component
public class CredentialBasedAuthenticator
{
    public static final String KeyHttpAuthUserName = "HttpAuthUniqueName";
    public static final String KeyHttpAuthPassword = "HttpAuthPassword";
    private static final String SOAPAction_ANID = "SOAPAction";

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.CredentialBasedAuthenticator";
    private static final Logger logger = LoggerFactory.getLogger(
        nameOfLogger);

    public CredentialBasedAuthenticator ()
    {
        
    }

    /**
     * Extract the user credentials provided from Message Object and validate it based on oAuth server.
     * @param message
     * @throws Fault
     */
    public boolean authenticate (SoapMessage message) throws IntegrationServiceException
    {
        String anId = getANId(message);
        if(anId == null){
            logger.error("Tenant not passed");
            throw new IntegrationServiceException("Tenant not passed");
        }

        boolean isValidRequest = false;
        String authorizationToken = null;
        String userName = null, password = null;
        try {
            authorizationToken = HandlerUtil.getAuthorizationToken(message);
            AuthorizationPolicy policy = message.get(AuthorizationPolicy.class);
            if (policy != null) {
                userName = policy.getUserName();
                password = policy.getPassword();
            }
            isValidRequest = validateCredentials(anId, authorizationToken, userName, password);
        } 
        catch (IntegrationServiceException e) {
            logger.warn("Authentication issue " + e.getMessage());
            throw e;
        }
        return isValidRequest;
    }

    /**
     * Validate the credentials with oAuth Server.
     * @param password 
     * @param userName 
     * @param authorizationToken 
     * @param anId 
     * @return
     * @throws IntegrationServiceException
     */
    public boolean validateCredentials (String anId,
                                         String authorizationToken,
                                         String userName,
                                         String password)
        throws IntegrationServiceException
    {
        OAuthTokenManager oAuthTokenManager;
        if (userName != null && password != null) {
            String[] credentials = getConfiguredCredentials(anId);
            if (!ArrayUtils.isEmpty(credentials) && credentials.length == 2) {
                String configuredUserName = credentials[0];
                String configuredPassword = credentials[1];
                if (userName.equals(configuredUserName)
                    && password.equals(configuredPassword))
                {
                    return true;
                }
            }
            else {
                return false;
            }
        }
        else if (authorizationToken != null) {
            oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(
                OAuthTokenManager.class);
            return oAuthTokenManager.getUserInfo(authorizationToken) != null;
        }

        return false;
    }

    protected String[] getConfiguredCredentials (String anID)
    throws IntegrationServiceException
    {
        String[] credentials = null;
        Map responseAsMap = null;
        if (HandlerUtil.isMDCS()) {
            responseAsMap = HandlerUtil.getMdcsAuthCredentials(anID);
        }
        else {
            responseAsMap = HandlerUtil.getConfiguredCredentials(anID);
        }
        if (responseAsMap != null) {
            String configuredUserName = (String)responseAsMap.get(KeyHttpAuthUserName);
            String configuredPassword = (String)responseAsMap.get(KeyHttpAuthPassword);

            if (!StringUtils.isEmpty(configuredUserName) && !StringUtils.isEmpty(
                configuredPassword))
            {
                credentials = new String[] { configuredUserName, configuredPassword };
            }
        }
        else {
            logger.warn("Configured Credentials received are blank for customer - {}",
                        anID);
        }
        return credentials;
    }

    private String getANId (SoapMessage message)
    {
        String anId = HandlerUtil.getANId(message);
        if (anId == null) {
            anId = (String) message.get(SOAPAction_ANID);
        }
        return anId;
    }
}
