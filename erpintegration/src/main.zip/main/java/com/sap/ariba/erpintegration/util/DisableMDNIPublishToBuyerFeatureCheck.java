package com.sap.ariba.erpintegration.util;

import com.sap.ariba.erpintegration.mdi.common.oauth.OAuthProvider;
import com.sap.ariba.erpintegration.mdi.common.util.URLUtil;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.TransientWebClientResponseException;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;
import jakarta.annotation.PostConstruct;
import java.net.ConnectException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
@ConditionalOnProperty(value = "environment.mdcs", matchIfMissing = false, havingValue = "false")
public class DisableMDNIPublishToBuyerFeatureCheck
{
    @Value("${mdni.disablePublishToBuyer.featureCheckURL}")
    private String disablePublishToBuyerFeatureCheckUrl;
    
    @Value("${server.proxy.isProduction}")
    private boolean isProduction;

    @Value("${server.proxy.proxyHost}")
    private String proxyHost;

    @Value("${server.proxy.proxyPort}")
    private String proxyPort;

    @Value("${server.proxy.nonProxyHosts}")
    private String nonProxyHosts;
    
    @Value("${mdni.disablePublishToBuyer.connectTimeout}")
    private Integer connectionTimeOut;
    
    @Value("${mdni.disablePublishToBuyer.readTimeout}")
    private long readTimeout;
    
    private static final Logger logger = LoggerFactory.getLogger(DisableMDNIPublishToBuyerFeatureCheck.class);
    
    private static final String REALM_KEY = "realm";
    private static final String PUBLISH_FEATURE_NAME = "DisableMDNIPublishToBuyerFeature";
    private static final String FEATURE_KEY = "Feature";
    private static final String STATUS_KEY = "Status";
    private static final String ENABLED_KEY = "Enabled";
    
    /**
     *  Cache for getting realm name given AN ID
     *  Key = ANID
     *  Value = Realm Name
     */
    private static final Map<String, String> REALM_ANID_CACHE = new HashMap<>();
    
    @Autowired
    private OAuthProvider oAuthProvider;
    
    private WebClient webClient;

    private ClientHttpConnector connector;
    
    @PostConstruct
    private void initialize ()
    {
        if (!StringUtils.isBlank(disablePublishToBuyerFeatureCheckUrl)) {
            // create reactor netty HTTP client
            HttpClient httpClient = HttpClient.create().tcpConfiguration(tcpClient -> {
                tcpClient = tcpClient.option(
                    ChannelOption.CONNECT_TIMEOUT_MILLIS,
                    getConnectTimeout());
                tcpClient = tcpClient.doOnConnected(
                    conn -> conn.addHandlerLast(
                        new ReadTimeoutHandler(getReadTimeout(),
                            TimeUnit.MILLISECONDS)));
                if (isProduction && proxyHost != null
                    && !proxyHost.isEmpty()
                    && !proxyPort.isEmpty())
                {
                    tcpClient = tcpClient.proxy(
                        ops -> ops.type(ProxyProvider.Proxy.HTTP).host(
                            proxyHost).port(
                                Integer.valueOf(proxyPort)));
                    logger.info(
                        "Setting proxy for reactor HttpClient with proxyHost:"
                            + proxyHost + " and proxyPort:"
                            + proxyPort);
                }
                return tcpClient;
            });
            // create a client http connector using above http client
            connector = new ReactorClientHttpConnector(httpClient);
            // use this configured http connector to build the web client
            logger.info(
                "Start : Connecting to URL {} ", disablePublishToBuyerFeatureCheckUrl);
            webClient = WebClient.builder().baseUrl(
                disablePublishToBuyerFeatureCheckUrl).clientConnector(
                    connector).build();
        }
    }
    
    public boolean isDisableMDNIPublishToBuyerFeatureEnabled (String anId)
    {
        boolean isFeatureEnabled = false;
        if (webClient != null) {
            String realmName = getRealmName(anId);
            WebClient newWebClient = webClient;
            if (!StringUtils.isBlank(realmName)) {
                // Make REST API call
                try {

                    String newUrl = URLUtil.changeUrl(anId,
                                            disablePublishToBuyerFeatureCheckUrl);
                    if (!newUrl.equals(disablePublishToBuyerFeatureCheckUrl)) {
                        newWebClient = WebClient.builder().baseUrl(newUrl).clientConnector(connector)
                                        .build();
                    }

                    Map<String, String> response = newWebClient.get()
                                    .uri(uriBuilder -> uriBuilder.queryParam(REALM_KEY,
                                                                             realmName).build())
                                    .header(HttpHeaders.AUTHORIZATION,
                                            oAuthProvider.getToken(anId)).retrieve()
                                    .bodyToMono(Map.class).block();
                    if (!MapUtils.isEmpty(response)) {
                        if (PUBLISH_FEATURE_NAME.equalsIgnoreCase(response.get(FEATURE_KEY))) {
                            if (ENABLED_KEY.equalsIgnoreCase(response.get(STATUS_KEY))) {
                                isFeatureEnabled = true;
                                logger.info("Disable Publish to Buyer Feature is enable for tenant with ANID: '{}' and realm: '{}'",
                                            anId,
                                            realmName);
                            }
                        }
                    }
                }
                catch (Exception ex) {
                    // Check if we have a 404 error, it indicates that the realm
                    // corresponding to
                    // the specified ANID was not found in the application
                    if (ex instanceof WebClientResponseException wcex) {
                        if (wcex.getRawStatusCode() == HttpStatus.SC_NOT_FOUND) {
                            // Realm not present indicates either an invalid realm
                            // or a realm which is S4 only (i.e. no corresponding 
                            // Buyer realm is present)
                            isFeatureEnabled = false;
                        }
                        else {
                            // In case the caught exception is a transient
                            // exception (i.e HTTP status 503 or 504 or "Connection Refused" errors),
                            // it is wrapped in a TransientWebClientResponseException and thrown which
                            // becomes eligible for retry.
                            // If it is any other exception, it is thrown back without retrying
                            logAppropriateException(anId, ex);
                        }
                    }
                    else {
                        // Any other type of Exception
                        logAppropriateException(anId, ex);
                    }
                }
            }
            if (!isFeatureEnabled) {
                logger.info(
                    "Disable Publish to Buyer Feature is disabled for tenant with ANID: '{}' and realm: '{}'",
                    anId,
                    realmName);
            }
        }
        else {
            logger.error(
                "Failed to check enablement status for '{}' as '{}' property is null/blank",
                PUBLISH_FEATURE_NAME,
                "mdni.disablePublishToBuyer.featureCheckURL"); // TODO add appropriate feature check
        }
        return isFeatureEnabled;
    }
    
    private Integer getConnectTimeout ()
    {
        // TODO Auto-generated method stub
        return connectionTimeOut;
    }
    
    public long getReadTimeout ()
    {
        return readTimeout;
    }
    
    private static String getRealmName (String anId)
    {
        String realmName = REALM_ANID_CACHE.get(anId);
        if (StringUtils.isBlank(realmName)) {
            realmName = Utility.getRealmName(anId);
            REALM_ANID_CACHE.put(anId, realmName);
        }
        return realmName;
    }
    
    private void logAppropriateException (String anId, Exception e)
    {
        Exception exception = e;
        if (e instanceof WebClientResponseException wcex) {
            if (wcex.getRawStatusCode() == HttpStatus.SC_GATEWAY_TIMEOUT
                || wcex.getRawStatusCode() == HttpStatus.SC_SERVICE_UNAVAILABLE)
            {
                // We have a transient exception which can be retried
                exception = new TransientWebClientResponseException(wcex);
            }
        }
        else {
            Throwable throwable = ExceptionUtils.getRootCause(e);
            if (ExceptionUtils.indexOfType(throwable, ConnectException.class) != -1) {
                // We have a transient exception which can be retried
                exception = new TransientWebClientResponseException(
                    HttpStatus.SC_SERVICE_UNAVAILABLE,
                    "Connection refused");
            }
        }
        logger.error("Error occurred while checking if disable publish to buyer is enabled for ANID:'{}' : {}",
            anId,
            ExceptionUtils.getRootCauseMessage(exception));
    }    

}
