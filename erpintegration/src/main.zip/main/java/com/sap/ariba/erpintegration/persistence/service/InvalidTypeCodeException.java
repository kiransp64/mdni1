package com.sap.ariba.erpintegration.persistence.service;

/**
 * Created by i318483 on 02/06/17.
 */
public class InvalidTypeCodeException extends Exception
{
    private static final long serialVersionUID = 1L;

    public InvalidTypeCodeException (Exception e)
    {
        super(e);
    }

    public InvalidTypeCodeException (String message)
    {
        super(message);
    }

    public InvalidTypeCodeException (String message, Exception e)
    {
        super(message, e);
    }
}
