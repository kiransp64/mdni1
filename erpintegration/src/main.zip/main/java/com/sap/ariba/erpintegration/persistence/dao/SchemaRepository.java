package com.sap.ariba.erpintegration.persistence.dao;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.sap.ariba.erpintegration.persistence.model.Schema;
import com.sap.ariba.erpintegration.persistence.service.BaseIdServiceImpl;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import org.springframework.transaction.annotation.Transactional;

/**
 * This Repository Class is responsible for interacting with SCHEMA_TAB table.
 * 
 * @author i339952
 */
@Component("SchemaRepositoryComponent")
public interface SchemaRepository extends GenericDataDao<Schema>
{
    public static String nameOfLogger = "com.sap.ariba.erpintegration.persistence.dao.SchemaRepository";
    public static Logger logger = LoggerFactory.getLogger(nameOfLogger);

    @Query("select s from Schema s where s.tenantId = :tenantId and s.objectName = :objectName and s.senderBusinessSystemId = :senderBusinessSystemId")
    Schema findOne (@Param("tenantId") long tenantId,
                    @Param("objectName") String objectName,
                    @Param("senderBusinessSystemId") String senderBusinessSystemId);
    
    @Query("select s from Schema s where s.tenantId = :tenantId and s.objectName = :objectName and s.senderBusinessSystemId is NULL")
    Schema findOne (@Param("tenantId") long tenantId,
                    @Param("objectName") String objectName);

    @Query("select s from Schema s where s.tenantId = :tenantId")
    List<Schema> find (@Param("tenantId") long tenantId);

    @Query("select s from Schema s where s.tenantId = :tenantId and s.senderBusinessSystemId = :senderBusinessSystemId")
    List<Schema> find (@Param("tenantId") long tenantId,
                       @Param("senderBusinessSystemId") String senderBusinessSystemId);

    @Query("select s from Schema s where s.tenantId = :tenantId and s.senderBusinessSystemId is NULL")
    List<Schema> findBySenderBusinessSystemIdNull (@Param("tenantId") long tenantId);

    @Query("select id,dateCreated,dateUpdated from Schema s where tenantId = :tenantId order by id desc")
    public Page<Schema> findKeyFieldsOfAllRecords(@Param("tenantId") long tenantId, Pageable pageable);

    @Transactional
    long deleteByTenantId(long tenantId);

    default void save (String tenantId,
                       String senderBusinessSystemId,
                       String objectName,
                       boolean isFMD,
                       String path)
    {
        if (logger.isDebugEnabled()) {
            logger.debug(
                "Merging data [tenantId: {}, senderBusinessSystemId: {}, path: {}, isFMD: {}, objectName: {}]",
                tenantId,
                senderBusinessSystemId,
                path,
                isFMD,
                objectName);
        }

        long systemTenantId = -1;
        if (Utility.isTenantExists(tenantId)) {
            systemTenantId = Utility.getTenantId(tenantId);
        }

        Date date = new Date();

        Schema schema = null;

        if (senderBusinessSystemId == null) {
            schema = findOne(systemTenantId, objectName);
        }
        else {
            schema = findOne(systemTenantId, objectName, senderBusinessSystemId);
        }

        if (schema == null) {
            schema = new Schema();
            String baseId = null;
            try {
                baseId = this.getBaseId(systemTenantId, schema.getObjectType());
            }
            catch (InvalidTypeCodeException e) {
                logger.error("Exception: ", e);
            }
            schema.setDateCreated(date);
            schema.setId(baseId);

        }

        schema.setDateUpdated(date);
        schema.setSenderBusinessSystemId(senderBusinessSystemId);
        schema.setObjectName(objectName);
        schema.setFMD(isFMD);
        schema.setTenantId(systemTenantId);
        schema.setPath(path);

        save(schema);

        if (logger.isDebugEnabled()) {
            logger.debug(
                "Schema details for tenantId: {}, senderBusinessSystemId: {}, path: {}, isFMD: {}, objectName: {} got saved",
                tenantId,
                senderBusinessSystemId,
                path,
                isFMD,
                objectName);

        }
    }

    default String getBaseId (long variantId, String objectName)
        throws InvalidTypeCodeException
    {
        BaseIdServiceImpl service = BaseIdServiceImpl.getInstance();
        return service.allocateBaseId(objectName, variantId);
    }

}
