package com.sap.ariba.erpintegration.monitor.application;

import com.sap.ariba.erpintegration.monitor.application.logentry.LogEntryBuilderException;
import com.sap.ariba.erpintegration.monitor.application.logentry.LogEntryUtil;
import com.sap.ariba.erpintegration.monitor.application.logentry.MDIIDsLogEntryBuilder;
import com.sap.ariba.erpintegration.monitor.application.model.ApplicationData;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.model.MDIIntegrationMonitoringContext;
import com.sap.ariba.erpintegration.monitor.im.util.IMConstants;
import com.sap.ariba.erpintegration.monitor.im.util.IMEvents;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.integrationmonitoring.bean.ApplicationMonitoringBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@ConditionalOnExpression(IMConstants.INTEGRATION_MONITORING_ENABLE)
@Component(value = "mdiApplicationContextDataHandler")
public class MDIApplicationContextDataHandler
    extends XMLPayloadApplicationContextDataHandler
{
    private static final Logger logger = LoggerFactory.getLogger(
        MDIApplicationContextDataHandler.class);

    @Autowired
    private MDIIDsLogEntryBuilder logEntryBuilder;

    @Value("${integration.monitoring.mdi.deltatoken.send:false}")
    private boolean sendDeltaToken;

    @Override
    protected void setApplicationData (IntegrationContext integrationContext,
                                       List<ApplicationData> applicationDataList)
    {
        super.setApplicationData(integrationContext, applicationDataList);
        if (integrationContext instanceof MDIIntegrationMonitoringContext mdiIntegrationMonitoringContext) {
            if (sendDeltaToken && mdiIntegrationMonitoringContext.hasDeltaToken()) {
                ApplicationData stageAppData = new ApplicationData(
                    IMConstants.MDI_DELTA_TOKEN, IMConstants.MDI_DELTA_TOKEN_DISPLAY_NAME,
                    mdiIntegrationMonitoringContext.getDeltaToken(),
                    ApplicationMonitoringBean.Classification.MESSAGE,
                    ApplicationMonitoringBean.ValueType.SIMPLE);
                applicationDataList.add(stageAppData);
            }
        }

    }

    @Override
    public List<ApplicationMonitoringBean> buildLogEntries (IntegrationContext integrationContext)
    {
        if (integrationContext != null
            && integrationContext instanceof MDIIntegrationMonitoringContext mdiIntegrationMonitoringContext)
        {
            try {
                if (mdiIntegrationMonitoringContext.hasOptimisedLogEvents()) {
                    List<ApplicationData> appData = new ArrayList<>();
                    Set<String> createUUIDs = mdiIntegrationMonitoringContext.getCreateIDs();
                    if (createUUIDs != null && createUUIDs.size() > 0
                        && !LogEntryUtil.hasCrossedMaxAppDataLength(
                        integrationContext.getAppDataSize()))
                    {
                        List<ApplicationData> createAppData = logEntryBuilder.buildApplicationData(
                            createUUIDs, ApplicationMonitoringBean.Classification.MESSAGE,
                            ApplicationMonitoringBean.ValueType.JSON, LogEntryUtil.MDI_CREATE_OPERATION, integrationContext);
                        if(createAppData != null){
                            appData.addAll(createAppData);
                        }
                    }
                    Set<String> updateUUIDs = mdiIntegrationMonitoringContext.getUpdateIDs();
                    if (updateUUIDs != null && updateUUIDs.size() > 0
                        && !LogEntryUtil.hasCrossedMaxAppDataLength(
                        integrationContext.getAppDataSize()))
                    {
                        List<ApplicationData> updateAppData = logEntryBuilder.buildApplicationData(
                            updateUUIDs, ApplicationMonitoringBean.Classification.MESSAGE,
                            ApplicationMonitoringBean.ValueType.JSON,
                            LogEntryUtil.MDI_UPDATE_OPERATION, integrationContext);
                        if(updateAppData != null){
                            appData.addAll(updateAppData);
                        }
                    }

                    Set<String> deleteUUIds = mdiIntegrationMonitoringContext.getDeleteIDs();
                    if (deleteUUIds != null && deleteUUIds.size() > 0
                        && !LogEntryUtil.hasCrossedMaxAppDataLength(
                        integrationContext.getAppDataSize()))
                    {
                        List<ApplicationData> deleteAppData = logEntryBuilder.buildApplicationData(
                            deleteUUIds, ApplicationMonitoringBean.Classification.MESSAGE,
                            ApplicationMonitoringBean.ValueType.JSON,
                            LogEntryUtil.MDI_DELETE_OPERATION, integrationContext);
                        if(deleteAppData != null){
                            appData.addAll(deleteAppData);
                        }
                    }
                    return buildAppMonBeansFromAppDataWithSeq(appData, 0);
                }
            }
            catch (LogEntryBuilderException e) {
                logger.error(
                    "{} {} while trying to build Log Entries for MDI Instance IDs.",
                    IMConstants.MDNI_IM_CRITICAL, ErrorUtil.getCompleteCausedByErrors(e));
            }
        }
        return null;
    }

    @Override
    protected IMEvents getEventName ()
    {
        return IMEvents.MDI;
    }

    @Override
    protected String getIntegrationChannel ()
    {
        return IMConstants.INTEGRATION_CHANNEL_HTTP;
    }

}
