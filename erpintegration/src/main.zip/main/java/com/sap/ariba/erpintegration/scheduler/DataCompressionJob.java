package com.sap.ariba.erpintegration.scheduler;

import com.sap.ariba.erpintegration.SchedulerConfig;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.service.exception.DataCompressionException;
import com.sap.ariba.erpintegration.service.exception.DataDeletionException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.erpintegration.util.XMLUtil;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
@DisallowConcurrentExecution
@ConditionalOnExpression(
        "${remote.auditService.enable:true} and (${isInternal:false} == false)"
)
public class DataCompressionJob implements Job {

    private static final Logger logger = LoggerFactory.getLogger(DataCompressionJob.class);

    @Value("${dataCompressionJob.cronExpression}")
    private String dataCompressionCronExpression;

    @Value("${dataCompressionJob.retainNoOfDays}")
    private int retainNoOfDays;

    @Value("${remote.auditService.enable}")
    private boolean auditEnabled;


    /**
     * This job is used for compressing the xml data
     * @param jobExecutionContext
     * @throws JobExecutionException
     */
    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        if(auditEnabled) {
            logger.info("DataCompressionJob started");
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            StageXMLDataRepository dao = (StageXMLDataRepository) daoFactory.getGenericDAOStageData(ObjectTypes.XmlPayload.name());
            //Pull last x days data with datapurge not happened and compression not happened and status as processed.
            List<StageXMLData> stageXMLDataList = dao.findStageXmlDataForCompressing();
            logger.info("No. of records for compression "+ stageXMLDataList.size());
            if(stageXMLDataList.size() > 0) {
                if(!HandlerUtil.isAdvancedStorageOptionEnabled()) {
                    compressRecordsAndUpdate(stageXMLDataList);
                }else{
                    //Need to implement this once we have more clarity
                    // on audit for MDCS
                }
            };
        }
    }

    /**
     * This method calls the methods which does the compression of files and updating of DB.
     * @param stageXMLDataList
     */
    private void compressRecordsAndUpdate(List<StageXMLData> stageXMLDataList){
        List<StageXMLData> compressedXmlDataList = compressRecords(stageXMLDataList);
        updateFilePathCompressedRecords(compressedXmlDataList);
    }

    /**
     * This method loops through the records available for compression and compress the records.
     * @param stageXMLDataList
     * @return
     */
    private List<StageXMLData> compressRecords(List<StageXMLData> stageXMLDataList) {
        String filePath = null;
        //compressedXmlDataList contains the records which got successfully compressed.
        List<StageXMLData> compressedXmlDataList = new ArrayList<>();
        for(StageXMLData stageXMLData:stageXMLDataList) {
            filePath = stageXMLData.getDataPath();
            try {
                //Compress the record
                String compressedFilePath = XMLUtil.compressXMLData(filePath);
                //Delete the actual xml
                deleteXMLData(filePath);
                stageXMLData.setDataPath(compressedFilePath);
                stageXMLData.setDataCompressed(1);
                compressedXmlDataList.add(stageXMLData);
            } catch (DataCompressionException | DataDeletionException e) {
                logger.error(e.getMessage() + " file path "+ filePath);
            }
        }
        return compressedXmlDataList;
    }

    /**
     * Loops through all the successfully compressed records and update the status in DB.
     * @param compressedXmlDataList
     */
    private void updateFilePathCompressedRecords(List<StageXMLData> compressedXmlDataList) {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        GenericDAOStageData dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
        for (StageXMLData stageXMLData : compressedXmlDataList) {
            stageXMLData.setDateUpdated(new Date());
            dao.save(stageXMLData);
        }
    }

    /**
     * This method is used for deleting the actual files after compressing successfully
     * @param filePath
     * @throws DataDeletionException
     */
    private void deleteXMLData(String filePath) throws DataDeletionException {
        try {
            File file = new File(filePath);
            if(file.exists()) {
                Files.delete(file.toPath());
                return;
            }
            logger.info(filePath + " doesnot exist");
        }
        catch (IOException ex){
            throw new DataDeletionException("Exception while deleting file after compression "+filePath, ex);
        }
    }


    @Bean(name = "dataCompressionJobBean")
    public JobDetailFactoryBean dataCompressionJob() {
        return SchedulerConfig.createJobDetail(this.getClass());
    }

    @Bean(name = "dataCompressionJobBeanTrigger")
    public CronTriggerFactoryBean dataCompressionJobBeanTrigger(@Qualifier("dataCompressionJobBean") JobDetail jobDetail) {
        return SchedulerConfig.createCronTrigger(jobDetail, dataCompressionCronExpression);
    }


}
