package com.sap.ariba.erpintegration.onemds.tenant;

import com.sap.ariba.erpintegration.onemds.exception.TenantServiceException;
import com.sap.ariba.erpintegration.persistence.model.Tenant;

import java.util.List;
import java.util.Set;

public interface TenantService
{
    public Set<String> getAllTenants () throws TenantServiceException;

    public List<Tenant> dequeue () throws TenantServiceException;
    
    public void enqueue (String tenantID) throws TenantServiceException;

    public String getAppURL (String tenantID) throws TenantServiceException;

    public String getClientID (String tenantID) throws TenantServiceException;

    public String getClientSecret (String tenantID) throws TenantServiceException;

    public String getAuthURL (String tenantID) throws TenantServiceException;

    public boolean isTenantValid (String tenantID) throws TenantServiceException;

    public Tenant getTenant(String tenantIdentifier) throws TenantServiceException;

    public Tenant getTenant(long tenantId) throws TenantServiceException;

}
