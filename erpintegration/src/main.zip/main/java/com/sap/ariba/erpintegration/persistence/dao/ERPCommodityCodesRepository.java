package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.ERPCommodityCodes;
import org.springframework.data.repository.CrudRepository;

public interface ERPCommodityCodesRepository extends CrudRepository<ERPCommodityCodes, Long> {

}
