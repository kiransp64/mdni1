/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.exception;

public class IntegrationMonitoringException extends Exception
{
    public IntegrationMonitoringException (String message)
    {
        super(message);
    }

    public IntegrationMonitoringException (String message,
                                           Throwable cause)
    {
        super(message,
              cause);
    }

    public IntegrationMonitoringException (Throwable cause)
    {
        super(cause);
    }

    public IntegrationMonitoringException ()
    {
        super();
    }
}
