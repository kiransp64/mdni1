package com.sap.ariba.erpintegration.onemds.throttle;

import com.sap.ariba.erpintegration.onemds.exception.ThrottleServiceException;

public interface ThrottleService
{
    public int getTotalInProgress() throws ThrottleServiceException;

    public int getTotalInProgressInCurrentNode() throws ThrottleServiceException;

    public boolean canDistribute();

    public boolean canProcessInCurrentNode();
}
