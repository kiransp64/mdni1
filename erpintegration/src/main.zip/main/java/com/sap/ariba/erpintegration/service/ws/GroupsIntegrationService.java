package com.sap.ariba.erpintegration.service.ws;

import com.sap.ariba.erpintegration.persistence.model.GroupExport.Group;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;

import jakarta.jws.WebMethod;
import jakarta.jws.WebResult;
import jakarta.jws.WebService;
import jakarta.xml.ws.ResponseWrapper;
import java.util.List;

/**
 * Created by c5259108 on 04/12/17.
 */
@WebService(serviceName = "GroupsIntegrationService",targetNamespace = "http://groupsIntegrationService.com")
public interface GroupsIntegrationService {
    @WebMethod(operationName = "fetchGroups")
    @WebResult(name = "Group")
    @ResponseWrapper(localName = "GroupsResponse")
    List<Group> getGroups() throws IntegrationServiceException;
}
