/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.exception;

public class PassportDAOException extends Exception
{

    public PassportDAOException ()
    {
        super();
    }

    public PassportDAOException (String message)
    {
        super(message);
    }

    public PassportDAOException (String message,
                                 Throwable cause)
    {
        super(message,
              cause);
    }
}
