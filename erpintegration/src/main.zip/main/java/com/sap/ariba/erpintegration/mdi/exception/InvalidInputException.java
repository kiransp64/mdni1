package com.sap.ariba.erpintegration.mdi.exception;
import org.apache.http.HttpStatus;
public class InvalidInputException extends RuntimeException
{
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private int statusCode = HttpStatus.SC_BAD_REQUEST;

    public InvalidInputException (Exception e)
    {
        super(e);
    }

    public InvalidInputException (String message, int statusCode)
    {
        super(message);
        this.statusCode = statusCode;
    }

    public InvalidInputException (String message)
    {
        super(message);
    }

    public InvalidInputException (String message, Exception e)
    {
        super(message, e);
    }

    public int getStatusCode ()
    {
        return statusCode;
    }
}
