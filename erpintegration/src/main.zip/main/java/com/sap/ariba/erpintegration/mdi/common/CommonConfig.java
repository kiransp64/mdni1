package com.sap.ariba.erpintegration.mdi.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.mdi.common.util.JSONUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * added proxyBeanMethods=false for this configuration class , to not generate proxy object for underlying defined Bean's in this class,i.e
 * ObjectMapper,as while working with SB3 + JDK17 changes we observed failure of few JUnits with Proxy ,CGLib related error ,with the latest adoption of new Jar.
 * https://github.com/spring-projects/spring-framework/issues/29584
 * https://github.com/spring-projects/spring-framework/issues/30985
 */
@Configuration(proxyBeanMethods = false)
@ConfigurationProperties(prefix = "mdi.common")
public class CommonConfig
{

    private String baseURL;
    private String buyerAppURL;
    private String s4AppURL;
    private boolean usePreComputeRank;
    private String openApiBaseUrl;
    private boolean uniqueUUIDCheckEnabled;
    static final ObjectMapper simpleObjectMapper = JSONUtil.getObjectMapper();

    private boolean searchActiveGroupMembersEnabled;
    private boolean bindQueryForValidationEnabled;

    private boolean scimPatchOptimisationEnabled;

    private Integer scimPatchOptimisationChunkSize;
    @Value("${server.servlet.context-path}")
    private String contextPath;

    private int scimGroupPatchMembersBatchSize;

    public static final int DEFAULT_PATCHMEMBERSPERBATCH = 100;

    private int scimGroupPatchInvalidMembersShow;

    public static final int DEFAULT_PATCHINVALIDMEMBERSSHOW = 100;

    public String getContextPath ()
    {
        return contextPath;
    }

    public void setContextPath (String contextPath)
    {
        this.contextPath = contextPath;
    }

    public void setOpenApiBaseUrl (String openApiBaseUrl)
    {
        this.openApiBaseUrl = openApiBaseUrl;
    }

    public String getOpenApiBaseUrl ()
    {
        return openApiBaseUrl;
    }

    public String getBaseURL ()
    {
        return baseURL;
    }

    public void setBaseURL (String baseURL)
    {
        this.baseURL = baseURL;
    }
    public String getBuyerAppURL ()
    {
        return buyerAppURL;
    }

    public void setBuyerAppURL (String buyerAppURL)
    {
        this.buyerAppURL = buyerAppURL;
    }

    public String getS4AppURL ()
    {
        return s4AppURL;
    }

    public void setS4AppURL (String s4AppURL)
    {
        this.s4AppURL = s4AppURL;
    }

    public Boolean usePreComputeRank ()
    {
        return usePreComputeRank;
    }

    public void setUsePreComputeRank (boolean usePreComputeRank)
    {
        this.usePreComputeRank = usePreComputeRank;
    }

    public boolean isUniqueUUIDCheckEnabled() { return uniqueUUIDCheckEnabled;}

    public void setUniqueUUIDCheckEnabled(boolean uniqueUUIDCheckEnabled) {this.uniqueUUIDCheckEnabled = uniqueUUIDCheckEnabled; }
    public boolean isSearchActiveGroupMembersEnabled() { return searchActiveGroupMembersEnabled; }
    public void setSearchActiveGroupMembersEnabled(boolean searchActiveGroupMembersEnabled) { this.searchActiveGroupMembersEnabled = searchActiveGroupMembersEnabled; }
    @Bean
    public ObjectMapper simpleObjectMapper ()
    {
       return simpleObjectMapper;
    }

    public boolean isBindQueryForValidationEnabled() {
        return bindQueryForValidationEnabled;
    }

    public boolean isScimPatchOptimisationEnabled(){
        return scimPatchOptimisationEnabled;
    }

    public Integer getScimPatchOptimisationChunkSize(){
        return scimPatchOptimisationChunkSize;
    }

    public int getScimGroupPatchMembersBatchSize() {
        if(scimGroupPatchMembersBatchSize<=0){
            scimGroupPatchMembersBatchSize = DEFAULT_PATCHMEMBERSPERBATCH;
        }
        return scimGroupPatchMembersBatchSize;
    }
    public void setBindQueryForValidationEnabled(boolean bindQueryForValidationEnabled) {
        this.bindQueryForValidationEnabled = bindQueryForValidationEnabled;
    }
    public void setScimPatchOptimisationEnabled(boolean scimPatchOptimisationEnabled) {
        this.scimPatchOptimisationEnabled = scimPatchOptimisationEnabled;
    }

    public void setScimPatchOptimisationChunkSize(Integer scimPatchOptimisationChunkSize){
        this.scimPatchOptimisationChunkSize=scimPatchOptimisationChunkSize;
    }

    public void setScimGroupPatchMembersBatchSize(int scimGroupPatchMembersBatchSize){
        this.scimGroupPatchMembersBatchSize = scimGroupPatchMembersBatchSize;
    }

    public int getScimGroupPatchInvalidMembersShow() {
        if(scimGroupPatchInvalidMembersShow<=0){
            scimGroupPatchInvalidMembersShow = DEFAULT_PATCHINVALIDMEMBERSSHOW;
        }
        return scimGroupPatchInvalidMembersShow;
    }

    public void setScimGroupPatchInvalidMembersShow(int scimGroupPatchInvalidMembersShow) {
        this.scimGroupPatchInvalidMembersShow = scimGroupPatchInvalidMembersShow;
    }
}

