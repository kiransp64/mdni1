package com.sap.ariba.erpintegration.filters.ui;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OauthFilterRegistrationConfig {
    @Bean
    public FilterRegistrationBean<OauthRequestFilter> oauthFilter() {
        FilterRegistrationBean<OauthRequestFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new OauthRequestFilter());
        registrationBean.addUrlPatterns("/inspector","/main/inspector");        
        return registrationBean;
    }
    
}
