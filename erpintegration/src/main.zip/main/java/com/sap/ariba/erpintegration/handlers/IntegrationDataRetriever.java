package com.sap.ariba.erpintegration.handlers;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;

import org.json.simple.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.util.StringUtils;

import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAO;
import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;

/**
 * Created by i318483 on 01/06/17.
 */
//NOTE: THIS CLASS IS NO MORE USED. TO BE CLEANED UP.
public class IntegrationDataRetriever extends RequestHandler
{
    private long tenantId;
    private JSONArray dataArray;

    private String objectName;
    private String minTimeUpdated;
    private String maxTimeUpdated;
    private String lastRecordId;
    private String externalTenantId;
    private boolean moreData = Boolean.FALSE;

    private static final int pagesize = 1000;

    private static final String KeyTenantIdParam = "TenantId";
    private static final String KeyObjectNameParam = "ObjectName";
    private static final String KeyLastRecordIdHeader = "LastRecordId";
    private static final String KeyMinTimeUpdatedParam = "MinTimeUpdated";
    private static final String KeyMaxTimeUpdatedParam = "MaxTimeUpdated";
    private static final String KeyMoreDataHeader = "MoreData";

    SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy");

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.IntegrationDataRetriever";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    /**
     * This is called from Buyer side to get the data by passing tenantId,objectname and the
     * maxTImeUpdated and minTimeUpdated value in the request
     * @param request
     * @return
     * @throws IntegrationServiceException
     */
    @Override
    public Response execute (HttpServletRequest request)
        throws IntegrationServiceException
    {
        if (!super.isRequestAuthorized(request)) {
            return Response.status(HttpServletResponse.SC_UNAUTHORIZED).build();
        }

        externalTenantId = request.getParameter(KeyTenantIdParam);
        tenantId = Utility.getTenantId(externalTenantId);
        objectName = request.getParameter(KeyObjectNameParam);
        minTimeUpdated = request.getParameter(KeyMinTimeUpdatedParam);
        maxTimeUpdated = request.getParameter(KeyMaxTimeUpdatedParam);

        if (request.getHeader(KeyLastRecordIdHeader) != null) {
            lastRecordId = request.getHeader(KeyLastRecordIdHeader);
        }

        if (logger.isDebugEnabled())
            logger.debug(
                "Request :::: externalTenantId : {}, tenantId : {}, objectName : {}, minTimeUpdated : {}, maxTimeUpdated : {}, lastRecordId : {}",
                externalTenantId,
                tenantId,
                objectName,
                minTimeUpdated,
                maxTimeUpdated,
                lastRecordId);

        try {
            retrieveData();
        }
        catch (SQLException se) {
            logger.warn(
                "Exception while retrieving data for " + objectName + " "
                    + se.getMessage());

        }
        catch (ParseException pe) {
            logger.warn(
                "Exception while retrieving data for " + objectName + " "
                    + pe.getMessage());
        }

        final String payload = this.getDataArray().toJSONString();
        StreamingOutput stream = new StreamingOutput() {
            int chunkSize = 4000;

            @Override
            public void write (OutputStream os)
                throws IOException, WebApplicationException
            {
                Writer writer = new BufferedWriter(new OutputStreamWriter(os));
                if (payload.length() <= chunkSize) {
                    writer.write(payload);
                }
                else {
                    int startIndex = 0;
                    long charRem = payload.length();
                    while (charRem >= chunkSize) {
                        writer.write(
                            payload.substring(startIndex, startIndex + chunkSize));
                        startIndex = startIndex + chunkSize;
                        charRem = charRem - chunkSize;
                    }

                    if (charRem > 0) {
                        writer.write(payload.substring(startIndex, payload.length()));
                    }
                }

                writer.flush();
            }
        };

        if (logger.isDebugEnabled())
            logger.debug(
                "Response :: this.getLastRecordId() : {}, this.isMoreData() : {}, ObjectName : {}",
                this.getLastRecordId(),
                this.isMoreData(),
                this.objectName);

        return Response.status(HttpServletResponse.SC_OK).header(
            KeyLastRecordIdHeader,
            this.getLastRecordId()).header(KeyMoreDataHeader, this.isMoreData()).entity(
                stream).build();
    }

    public boolean retrieveData () throws SQLException, ParseException
    {
        Date minTimeUpdated = null;
        Date maxTimeUpdate = null;
        String jsonData = null;

        GenericDAO dao = null;
        DAOFactory daoFactory = null;
        Page<GenericEntity> pageData = null;

        daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        dao = daoFactory.getDAO(getObjectName());

        if (dao == null) {
            logger.warn("Object Not Supported Yet!! " + getObjectName());
            return false;
        }

        if (getMaxTimeUpdated() != null) {
            maxTimeUpdate = dateFormat.parse(getMaxTimeUpdated());
        }
        else {
            logger.warn("maxTimeUpdated not sent");
            return false;
        }

        if (getMinTimeUpdated() != null) {
            minTimeUpdated = dateFormat.parse(getMinTimeUpdated());
        }
        else {
            logger.warn("minTimeUpdated not sent");
            return false;
        }

        PageRequest pageRequest = PageRequest.of(0, pagesize);

        if (StringUtils.isEmpty(this.lastRecordId)) {
            pageData = dao.findAll(
                tenantId,
                minTimeUpdated,
                maxTimeUpdate,
                pageRequest);

            if (pageData != null && pageData.getContent().size() > 0)
                this.lastRecordId = pageData.getContent().get(
                    pageData.getContent().size() - 1).getId();
        }
        else {
            pageData = dao.findAll(
                tenantId,
                minTimeUpdated,
                maxTimeUpdate,
                this.lastRecordId,
                pageRequest);
            if (pageData != null && pageData.getContent().size() > 0)
                this.lastRecordId = pageData.getContent().get(
                    pageData.getContent().size() - 1).getId();

        }

        if (pageData != null && pageData.getTotalPages() > 1) {
            this.moreData = Boolean.TRUE;
        }

        dataArray = new JSONArray();

        if (pageData != null && pageData.getSize() > 0) {
            for (GenericEntity entity : pageData.getContent()) {
                Blob blob = entity.getData();
                jsonData = new String(blob.getBytes(1, (int)blob.length()));
                dataArray.add(jsonData);
            }
        }
        return true;
    }

    public String getLastRecordId ()
    {
        return lastRecordId;
    }

    public void setLastRecordId (String lastRecordId)
    {
        this.lastRecordId = lastRecordId;
    }

    public String getObjectName ()
    {
        return objectName;
    }

    public void setObjectName (String objectName)
    {
        this.objectName = objectName;
    }

    public String getExternalTenantId ()
    {
        return externalTenantId;
    }

    public void setExternalTenantId (String externalTenantId)
    {
        this.externalTenantId = externalTenantId;
    }

    public long getTenantId ()
    {
        return tenantId;
    }

    public void setTenantId (long tenantId)
    {
        this.tenantId = tenantId;
    }

    public JSONArray getDataArray ()
    {
        if (dataArray == null) {
            return new JSONArray();
        }
        return dataArray;
    }

    public void setDataArray (JSONArray dataArray)
    {
        this.dataArray = dataArray;
    }

    public String getMinTimeUpdated ()
    {
        return minTimeUpdated;
    }

    public void setMinTimeUpdated (String minTimeUpdated)
    {
        this.minTimeUpdated = minTimeUpdated;
    }

    public String getMaxTimeUpdated ()
    {
        return maxTimeUpdated;
    }

    public void setMaxTimeUpdated (String maxTimeUpdated)
    {
        this.maxTimeUpdated = maxTimeUpdated;
    }

    public boolean isMoreData ()
    {
        return moreData;
    }

    public void setMoreData (boolean moreData)
    {
        this.moreData = moreData;
    }

}
