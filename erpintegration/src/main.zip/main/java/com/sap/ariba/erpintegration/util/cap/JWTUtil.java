package com.sap.ariba.erpintegration.util.cap;

import com.auth0.jwk.InvalidPublicKeyException;
import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.mdi.cap.config.MDCSSecretsManager;
import com.sap.ariba.erpintegration.mdi.cap.util.MdcsConstants;
import com.sap.ariba.mdsclient.search.util.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.json.JsonObject;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.interfaces.RSAPublicKey;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * JWTUtil is having Utility methods to work with JWT with JWK
 */
public class JWTUtil {
    private static final Logger logger = LoggerFactory.getLogger(JWTUtil.class);
    public static final String DOT = ".";
    public static final String ZONE_UUID = "zone_uuid";
    public static final String ISS = "iss";
    public static final String IAS_ISS = "ias_iss";
    public static final String USER_UUID = "user_uuid";
    public static final String GIVEN_NAME = "given_name";
    public static final String FAMILY_NAME = "family_name";
    public static final String EMAIL = "email";
    public static final String CERT_PATH = "/oauth2/certs";
    private static final String AZP = "azp";
    private static final String NULL_CLAIM = "Null Claim";
    public static final String ZONE_ID_HEADER = "x-zone_uuid";
    public static final String HTTP = "http://";
    public static final String HTTPS = "https://";
    public static final String FILE = "file:///";
    public static final int expireTime = 60000;

    public static final ObjectMapper objectMapper = new ObjectMapper();

    private static ConcurrentHashMap<String, JwkProvider> iasKeyMap = new ConcurrentHashMap<>();

    public static boolean isJWT(String token) {
        DecodedJWT jwt = getJWT(token);
        return jwt != null;
    }

    public static boolean isJWT(DecodedJWT jwt) {
        return jwt != null;
    }

    public static DecodedJWT getJWT(String token) {
        DecodedJWT jwt = null;
        if(!StringUtils.isEmpty(token)) {
            try {
                jwt = JWT.decode(token);
                logger.debug("Successfully decoded the JWT");
            } catch (Throwable t) {
                logger.error("Exception while decoding the token. Must be an invalid JWT.", t);
            }
        }
        return jwt;
    }

    public static String getZoneId(DecodedJWT jwt) {
        return jwt != null && jwt.getClaim(ZONE_UUID) != null ? jwt.getClaim(ZONE_UUID).asString() : null;
    }

    public static String getZoneId(String token) {
        if (isJWT(token)) {
            DecodedJWT jwt = getJWT(token);
            return getZoneId(jwt);
        }
        return null;
    }

    public static boolean verify(DecodedJWT jwt) throws Exception {
        try {
            return verify(jwt, true);
        } catch (Exception e) {
            throw e;
        }
    }

    public static boolean verify(DecodedJWT jwt, boolean skipVerifyAudience) throws Exception {
        try {
            //Verify if the token is expired
            if (isExpired(jwt))
                throw new JWTVerificationException("Provided Token is expired");

            JsonObject iasSecrets = MDCSSecretsManager.getServiceBinding(MdcsConstants.IAS).getSecrets();
            String iasDomainsString = iasSecrets.getString(MdcsConstants.IAS_DOMAINS);
            String iasClientID = iasSecrets.getString(MdcsConstants.IAS_CLIENTID);
            String[] iasDomains;
            try {
                iasDomains = objectMapper.readValue(iasDomainsString, String[].class);
            } catch (JsonProcessingException e) {
                logger.error("Error while parsing ias domain from IAS Secrets", e);
                throw new JWTVerificationException("Error while parsing ias domain from IAS Secrets", e);
            }

            //Validate Issuer
            if(validateIssuer(jwt, iasDomains))
                logger.debug("[MDCS API Auth Filter] Validate Issuer Check Successful");
            else
                throw new JWTVerificationException("Validate Issuer Check failed");

            //Validate Audience
            if(!skipVerifyAudience) {
                if(verifyAudience(jwt, iasClientID))
                    logger.debug("[MDCS API Auth Filter] Validate Issuer Check Successful");
                else
                    throw new JWTVerificationException("Verify Audience Check failed");
            }
            else
                logger.debug("[MDCS API Auth Filter] Skipping JWT Verify Audience Check");
            //Zone UUID Verification
            String iasKeyPath = getIssClaim(jwt) + CERT_PATH;
            //Relax JWT issuer validation constraint
            if( (!iasKeyPath.startsWith(FILE)) && ((!iasKeyPath.startsWith(HTTP)) && (!iasKeyPath.startsWith(HTTPS))) ){
                iasKeyPath = HTTPS + iasKeyPath;
            }
            if(!iasKeyMap.containsKey(iasKeyPath)) {
                addJwkProviderToMap(getZoneId(jwt), iasKeyPath, jwt.getKeyId());
            }

            JwkProvider provider = iasKeyMap.get(iasKeyPath);
            Jwk jwk = provider.get(jwt.getKeyId());
            tryVerify(iasKeyPath, jwk, jwt);
            logger.info("JWT Verification successful");
            logger.debug("************** Requested User **************");
            logger.debug("User UUID : {}", jwt.getClaim(USER_UUID));
            logger.debug("User : {}, {}", jwt.getClaim(GIVEN_NAME), jwt.getClaim(FAMILY_NAME));
            logger.debug("Email : {}", jwt.getClaim(EMAIL));
            logger.debug("Subject : {}", jwt.getSubject());
            logger.debug("Audience : {}", jwt.getAudience());
            logger.debug("************** ************** **************");
            logger.info("JWT is still valid");

        } catch (Exception e) {
            logger.error("Exception occurred while verifying JWT", e);
            throw e;
        }
        return true;
    }

    public static void tryVerify(String iasKeyPath, Jwk jwk, DecodedJWT jwt) throws Exception {
        int count = 0;
        while(count < 2) {
            try {
                verifyAlgorithm(jwk, jwt);
                return;
            }
            catch (SignatureVerificationException e) {
                if(count < 1) {
                    logger.info("JWT Signature Verification Failed. Retrying by fetching new Jwk Provider", e);
                    jwk = addJwkProviderToMap(iasKeyPath, getZoneId(jwt), jwt.getKeyId());
                }
                else
                    throw e;
            }
            catch (Exception e) {
                throw e;
            }
            count ++;
        }
    }

    public static void verifyAlgorithm(Jwk jwk, DecodedJWT jwt) throws InvalidPublicKeyException, SignatureVerificationException {
        Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) jwk.getPublicKey(), null);
        algorithm.verify(jwt);
    }

    public static boolean verify(String token, boolean skipVerifyAudience) throws Throwable {
        if (isJWT(token)) {
            DecodedJWT jwt = getJWT(token);
            if (jwt == null) {
                throw new JWTDecodeException("Invalid JWT token. Unable to decode it.");
            }
            return verify(jwt, skipVerifyAudience);
        }else{
            throw new JWTDecodeException("Invalid JWT token. Unable to decode it.");
        }
    }

    public static boolean validateIssuer(DecodedJWT jwt, String[] iasDomains) throws JWTDecodeException{
        if(Objects.isNull(jwt)) {
            logger.error("Jwt Object is Null");
            return false;
        }
        logger.debug("Validating Issuer");
        String issuerUrl = jwt.getIssuer();
        String iasIssuerUrl = jwt.getClaim(IAS_ISS).asString();

        try {
            if(StringUtil.nullOrEmptyOrBlankString(issuerUrl)) {
                logger.error("Issuer validation failed. Token does not have iss claim");
                throw new JWTDecodeException("Issuer validation failed. Token does not have iss claim");
            }
            isUrlValid(issuerUrl, ISS);
            if(StringUtil.nullOrEmptyOrBlankString(iasIssuerUrl)) {
                matchTokenIssueUrl(issuerUrl, ISS, iasDomains);
            }
            else {
                isUrlValid(iasIssuerUrl, IAS_ISS);
                matchTokenIssueUrl(iasIssuerUrl, IAS_ISS, iasDomains);
            }
        }
        catch (JWTDecodeException e) {
            throw e;
        }
        logger.debug("Issuer Validation Successful");
        return true;
    }

    protected static boolean isUrlValid(String issUrl, String claim) throws JWTDecodeException {
        if(StringUtil.nullOrEmptyOrBlankString(issUrl) || StringUtil.nullOrEmptyOrBlankString(claim)) {
            logger.error("Invalid Issuer URL of jwt token or empty claim");
            throw new JWTDecodeException("Invalid Issuer URL of jwt token or empty claim");
        }
        /* As per recommendation from the CIM team, 
        the issuer URL https validation is commented temporarily.
        TODO: Uncomment the https validation code for issuer URL
        if(!issUrl.startsWith("https")) {
            logger.error("Issuer cannot be trusted because {} claim does not provide valid URL (missing http scheme)."
                    + " Please contact your Identity Provider Administrator.", claim);
            throw new JWTVerificationException("Issuer cannot be trusted because " + claim + " claim does not provide valid URL (missing http scheme)."
                    + " Please contact your Identity Provider Administrator.");
        }*/
        //Relax JWT issuer validation constraint
        if((!issUrl.startsWith(HTTP)) && (!issUrl.startsWith(HTTPS))){
            issUrl = HTTPS + issUrl;
        }
        try {
            URI url = new URI(issUrl);
            if(Objects.isNull(url.getQuery()) && Objects.isNull(url.getFragment()) && !Objects.isNull(url.getHost()))
                return true;
        } catch (URISyntaxException e) {
            logger.error("Invalid Issuer URL - {}", issUrl, e);
            throw new JWTDecodeException("Invalid Issuer URL in jwt token" + issUrl, e);
        }
        logger.error("Issuer validation failed. {} claim does not provide valid URL: {}", claim, issUrl);
        throw new JWTDecodeException("Issuer validation failed." + claim
                + " claim does not provide valid URL: " + issUrl);
    }

    protected static boolean matchTokenIssueUrl(String url, String claim, String[] iasDomains) throws JWTVerificationException {
        if(StringUtil.nullOrEmptyOrBlankString(url) || StringUtil.nullOrEmptyOrBlankString(claim) || Objects.isNull(iasDomains)) {
            throw new JWTDecodeException("Invalid IssuerURL or Claim or iasDomain Secret of IAS");
        }
        for(int i=0; i<iasDomains.length; i++) {
            if(url.endsWith(iasDomains[i]))
                return true;
        }
        logger.error("""
                Issuer cannot be trusted because {} of {} \
                does not match any of the domains of the identity provider.\
                """, claim, url);
        throw new JWTVerificationException("Issuer cannot be trusted because " + claim + " of " + url
                + "does not match any of the domains of the identity provider.");
    }

    /**
     * verifyAudience is to verify the audience in the request
     *
     * @param jwt
     * @return
     */
    protected static boolean verifyAudience(DecodedJWT jwt, String iasClientID) throws JWTVerificationException{
        logger.debug("[MDCS API Auth Filter] Starting JWT Verify Audience Check");
        if(Objects.isNull(jwt)) {
            logger.error("Jwt Object is Null");
            return false;
        }
        List<String> audienceList = jwt.getAudience();
        // Trusting the jwt token if it contains current application ias client ID
        if(audienceList.isEmpty() && jwt.getClaim(AZP).toString().equals(NULL_CLAIM)) {
            logger.error("[MDCS API Auth Filter] Verify Audience Check Failed as Aud or Azp Field of JWT token is null");
            throw new JWTDecodeException(" Verify Audience Check Failed as Aud or Azp Field of JWT token is null");
        }
        logger.debug("[MDCS API Auth Filter] Checking if audience field of JWT Token contains IAS client ID {}",iasClientID);
        if(!audienceList.contains(iasClientID) && !jwt.getClaim(AZP).toString().equals(iasClientID)) {
            logger.error("Audience Field of JWT Token does not contain IAS Client id");
            throw new JWTVerificationException("Audience Field of JWT Token does not contain IAS Client id");
        }
        else {
            logger.debug("Audience Verification Check Successful");
            return true;
        }
    }

    private static Jwk addJwkProviderToMap(String zoneId, String iasKeyPath, String keyId) throws Exception{
        Map<String, String> jwkProviderMap = new HashMap<>();
        jwkProviderMap.put(ZONE_ID_HEADER, zoneId);
        JwkProvider provider = new JwkProviderBuilder(new URL(iasKeyPath))
                .headers(jwkProviderMap)
                .build();
        iasKeyMap.put(iasKeyPath, provider);
        return provider.get(keyId);
    }

    private static boolean isExpired(DecodedJWT jwt) {
        return jwt != null && jwt.getExpiresAt() != null ? jwt.getExpiresAt().before(new Date(System.currentTimeMillis() - expireTime)) : Boolean.FALSE;
    }

    private static String getIssClaim(DecodedJWT jwt){
        return jwt != null && jwt.getClaim(ISS) != null ? jwt.getClaim(ISS).asString() : ISS;
    }

}
