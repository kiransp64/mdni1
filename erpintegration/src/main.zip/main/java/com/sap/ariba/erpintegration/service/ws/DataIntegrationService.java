package com.sap.ariba.erpintegration.service.ws;

import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;

import jakarta.jws.WebService;
import jakarta.ws.rs.core.Response;

/**
 * Created by i318483 on 28/04/17.
 */
@WebService
public interface DataIntegrationService
{
    public Response integrateData () throws IntegrationServiceException;
}
