package com.sap.ariba.erpintegration.storage;


import com.sap.ariba.erpintegration.storage.exception.CloudStorageException;

public interface CloudStorage {

    public void put(String path, String content) throws CloudStorageException;

    public String getContent(String path) throws CloudStorageException;
    public CloudStorageResponse getStream(String path) throws CloudStorageException;

    public void remove(String path) throws CloudStorageException;
    public void closeCloudObject (CloudStorageResponse cloudStorageResponse);

}
