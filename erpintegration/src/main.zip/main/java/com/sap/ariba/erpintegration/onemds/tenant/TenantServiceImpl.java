package com.sap.ariba.erpintegration.onemds.tenant;

import com.sap.ariba.erpintegration.mdi.api.APIUtil;
import com.sap.ariba.erpintegration.mdi.common.util.DateUtil;
import com.sap.ariba.erpintegration.onemds.common.MDIConfig;
import com.sap.ariba.erpintegration.onemds.exception.TenantConfigurationException;
import com.sap.ariba.erpintegration.onemds.exception.TenantServiceException;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.TenantRepository;
import com.sap.ariba.erpintegration.persistence.model.Tenant;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
@ConditionalOnExpression("${environment.mdcs:false}==false")
public class TenantServiceImpl implements TenantService
{
    private static final Logger logger = LoggerFactory.getLogger(TenantServiceImpl.class);

    @Autowired
    protected TenantConfigurationProvider tenantConfigurationProvider;

    @Autowired
    @Lazy
    private MDIConfig mdiConfig;

    @Override
    public Set<String> getAllTenants () throws TenantServiceException
    {
        try {
            return tenantConfigurationProvider.getAllTenants();
        }
        catch (TenantConfigurationException e) {
            logger.error(
                "Error - {}, while trying to get all tenants.",
                ErrorUtil.getCompleteCausedByErrors(e));
            throw new TenantServiceException("Error while trying to get all tenants.", e);
        }
    }

    @Override
    public List<Tenant> dequeue () throws TenantServiceException
    {
        try {
            TenantRepository tenantDao = getTenantRepository();

            Pageable pageReq = PageRequest.of(0, mdiConfig.getMaxTotalRuns());
            return tenantDao
                .findNexActivetMDITenantsToBeProcessed(Constants.MDI_ENABLED_VALUE,
                                                       Constants.MDI_ACTIVE_VALUE,
                                                       pageReq);
        }
        catch (Exception e) {
            logger.error(
                "{} while trying to get next set of tenants to process.",
                ErrorUtil.getCompleteCausedByErrors(e));
            throw new TenantServiceException(
                "Error while trying to get next set of tenants to process.",
                e);
        }
    }

    @Override
    public void enqueue (String tenantID) throws TenantServiceException
    {
        try {
            TenantRepository dao = getTenantRepository();
            Tenant tenant = dao.findOne(tenantID);
            tenant.setMDIProcessTime(DateUtil.getCurrentDate());
            dao.save(tenant);
        }
        catch (Exception e) {
            // Catching all exceptions to ensure application continues to enqueue remaining tenants
            logger.error(
                "{} while trying to enqueue tenant - {}",
                ErrorUtil.getCompleteCausedByErrors(e),
                tenantID);
        }
    }

    @Override
    public String getAppURL (String tenantID) throws TenantServiceException
    {

        try {
            return tenantConfigurationProvider.getAppURL(tenantID);
        }
        catch (TenantConfigurationException e) {
            logger.error(
                "Error - {}, while trying to get App URL for tenant - {}.",
                ErrorUtil.getCompleteCausedByErrors(e),
                tenantID);
            throw new TenantServiceException(
                "Error while trying to get App URL for tenant - " + tenantID,
                e);
        }

    }

    @Override
    public String getClientID (String tenantID) throws TenantServiceException
    {
        try {
            return tenantConfigurationProvider.getClientID(tenantID);
        }
        catch (TenantConfigurationException e) {
            logger.error(
                "Error - {}, while trying to get Client ID for tenant - {}.",
                ErrorUtil.getCompleteCausedByErrors(e),
                tenantID);
            throw new TenantServiceException(
                "Error while trying to get Client ID for tenant - " + tenantID,
                e);
        }
    }

    @Override
    public String getClientSecret (String tenantID) throws TenantServiceException
    {
        try {
            return tenantConfigurationProvider.getClientSecret(tenantID);
        }
        catch (TenantConfigurationException e) {
            logger.error(
                "Error - {}, while trying to get Client Secret for tenant - {}.",
                ErrorUtil.getCompleteCausedByErrors(e),
                tenantID);
            throw new TenantServiceException(
                "Error while trying to get Client Secret for tenant - " + tenantID,
                e);
        }
    }

    @Override
    public String getAuthURL (String tenantID) throws TenantServiceException
    {
        try {
            return tenantConfigurationProvider.getAuthURL(tenantID);
        }
        catch (TenantConfigurationException e) {
            logger.error(
                "Error - {}, while trying to get Auth URL for tenant - {}.",
                ErrorUtil.getCompleteCausedByErrors(e),
                tenantID);
            throw new TenantServiceException(
                "Error while trying to get Auth URL for tenant - " + tenantID,
                e);
        }
    }

    @Override
    public boolean isTenantValid (String tenantID) throws TenantServiceException
    {
        if (!StringUtils.isEmpty(tenantID)) {
            try {
                Tenant tenant = getTenant(tenantID);
                boolean isTenantActive = tenant != null && tenant.getIsActive() == 1;
                if (isTenantActive) {
                    return tenantConfigurationProvider.doesConfigurationExist(tenantID);
                }
            }
            catch (TenantConfigurationException e) {
                logger.error(
                    "Error - {} while trying to check if tenant configuration exists for tenant - {}",
                    ErrorUtil.getCompleteCausedByErrors(e),
                    tenantID);
                throw new TenantServiceException(
                    "Error while trying to check if tenant configuration exists for tenant - "
                        + tenantID,
                    e);
            }
        }
        return false;
    }

    @Override
    public Tenant getTenant (String tenantIdentifier) throws TenantServiceException
    {
        try {
            TenantRepository tenantRepository = getTenantRepository();
            return tenantRepository.findOne(tenantIdentifier);
        }
        catch (Exception e) {
            logger.error("{} while trying to find tenant for identifier - {}",
                         ErrorUtil.getCompleteCausedByErrors(e), APIUtil.sanitizeInput(tenantIdentifier));
            throw new TenantServiceException(
                "Error while trying to find tenant for identifier - " + tenantIdentifier,
                e);
        }
    }

    @Override
    public Tenant getTenant (long tenantId) throws TenantServiceException
    {
        try {
            TenantRepository tenantRepository = getTenantRepository();
            return tenantRepository.findOne(tenantId);
        }
        catch (Exception e) {
            logger.error("{} while trying to find tenant for identifier - {}",
                         ErrorUtil.getCompleteCausedByErrors(e), tenantId);
            throw new TenantServiceException(
                "Error while trying to find tenant for identifier - " + tenantId, e);
        }
    }

    private TenantRepository getTenantRepository ()
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        return (TenantRepository)factory.getMiscDAO(ObjectTypes.Tenant.getValue());
    }
}
