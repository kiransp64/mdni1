package com.sap.ariba.erpintegration.reencryption;

import com.sap.ariba.encryption.config.ReEncryptionType;
import com.sap.ariba.encryption.config.SupportedJobTypes;
import com.sap.ariba.encryption.config.SupportedSourceTypes;
import com.sap.ariba.encryption.scheduler.JobAlreadyPresentException;
import com.sap.ariba.encryption.scheduler.JobSchedulerException;
import com.sap.ariba.encryption.scheduler.service.JobStatus;
import com.sap.ariba.erpintegration.persistence.model.ReEncryptionRequest;
import com.sap.ariba.erpintegration.persistence.model.TenantLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service("reEncryptionService")
@ConditionalOnExpression("${environment.mdcs:false} == false && ${isInternal:false} == false && ${kmsEnabled:false} == true && ${reEncryption:false} == true")
public class MDNIReEncryptionService
{
    
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.encryption.MDNIReEncryptionService";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);
    
    @Value("${kmsEncryptedPath}")
    protected String folderPath;
   
   @Autowired
   MDNIReEncryptionLibProvider reEncryptionLib;
   
   public List<JobStatus> submitJob(ReEncryptionRequest request) throws JobSchedulerException,
   JobAlreadyPresentException,
   SQLException{
       List<TenantLevel> tenants = request.getTenantLevels();
       if(tenants.get(0).getName().equals("system")) {
           try {
               reEncryptionLib.getReEncryption().setSystemFileEncryptionJob(this.folderPath,
                   ReEncryptionType.SYSTEM_JOB,
                   SupportedSourceTypes.FILE_SOURCE);
           } catch(JobSchedulerException | JobAlreadyPresentException e) {
               logger.info("Exception while setting job {}", e.getMessage());
               throw e;
           }
       }
       return reEncryptionLib.getReEncryption().getSystemJobStatus(SupportedJobTypes.FileType);       
   }
   
   public List<JobStatus> getJobStatus(){
       return reEncryptionLib.getReEncryption().getSystemJobStatus(SupportedJobTypes.FileType);
   }
   
   public List<JobStatus> pauseJob() throws JobSchedulerException{
       reEncryptionLib.getReEncryption().pauseJob(SupportedJobTypes.FileType);
       return reEncryptionLib.getReEncryption().getSystemJobStatus(SupportedJobTypes.FileType);
   }
   
   public List<JobStatus> resumeJob () throws JobSchedulerException
   {
       reEncryptionLib.getReEncryption().resumeJob(SupportedJobTypes.FileType);
       return reEncryptionLib.getReEncryption().getSystemJobStatus(
           SupportedJobTypes.FileType);
   }
   
   public List<JobStatus> cancelJob () throws JobSchedulerException
   {
       reEncryptionLib.getReEncryption().cancelJob(SupportedJobTypes.FileType);
       return reEncryptionLib.getReEncryption().getSystemJobStatus(
           SupportedJobTypes.FileType);
   }
   
   
}