package com.sap.ariba.erpintegration.persistence.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Created by i318483 on 19/06/17.
 */
@Entity
@Table(name = "HANA_TENANT_TAB")

public class HanaTenant implements Serializable
{

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "AN_ID")
    private String anId;

    @Column(name = "PARENT_AN_ID")
    private String parentAnId;

    @Column(name = "WEIGHT")
    private Double weight;

    @Column(name = "REALM")
    private String realm;

    @Column(name = "HANA_TENANT_ID")
    private long hanaTenantId;

    @Column(name = "HANA_POD")
    private int hanaPod;

    @Column(name = "DATE_CREATED")
    private Date dateCreated;

    @Column(name = "DATE_UPDATED")
    private Date dateUpdated;

    @Column(name = "IS_ACTIVE")
    private int isActive;

    @Column(name = "STATUS")
    private int status;

    public String getAnId ()
    {
        return anId;
    }

    public void setAnId (String anId)
    {
        this.anId = anId;
    }

    public String getRealm ()
    {
        return realm;
    }

    public void setRealm (String realm)
    {
        this.realm = realm;
    }

    public long getHanaTenantId ()
    {
        return hanaTenantId;
    }

    public void setHanaTenantId (long hanaTenantId)
    {
        this.hanaTenantId = hanaTenantId;
    }

    public int getHanaPod ()
    {
        return hanaPod;
    }

    public void setHanaPod (int hanaPod)
    {
        this.hanaPod = hanaPod;
    }

    public Date getDateCreated ()
    {
        return dateCreated;
    }

    public void setDateCreated (Date dateCreated)
    {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated ()
    {
        return dateUpdated;
    }

    public void setDateUpdated (Date dateUpdated)
    {
        this.dateUpdated = dateUpdated;
    }

    public int getIsActive ()
    {
        return isActive;
    }

    public void setIsActive (int isActive)
    {
        this.isActive = isActive;
    }

    public int getStatus ()
    {
        return status;
    }

    public void setStatus (int status)
    {
        this.status = status;
    }

    public String getParentAnId ()
    {
        return parentAnId;
    }

    public void setParentAnId (String parentAnId)
    {
        this.parentAnId = parentAnId;
    }

    public Double getWeight ()
    {
        return weight;
    }

    public void setWeight (Double weight)
    {
        this.weight = weight;
    }

    @Override
    public String toString ()
    {
        return "HanaTenant [anId=" + anId + ", parentAnId=" + parentAnId + ", weight="
            + weight + ", realm=" + realm + ", hanaTenantId=" + hanaTenantId
            + ", hanaPod=" + hanaPod + ", dateCreated=" + dateCreated + ", dateUpdated="
            + dateUpdated + ", isActive=" + isActive + ", status=" + status + "]";
    }

}
