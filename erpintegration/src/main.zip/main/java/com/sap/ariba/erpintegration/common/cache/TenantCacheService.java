package com.sap.ariba.erpintegration.common.cache;

public interface TenantCacheService
{

    public void clearTenantCache();

}
