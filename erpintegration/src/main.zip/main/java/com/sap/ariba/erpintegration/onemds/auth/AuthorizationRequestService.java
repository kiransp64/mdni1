package com.sap.ariba.erpintegration.onemds.auth;

import com.sap.ariba.erpintegration.onemds.exception.AuthorizationRequestException;

public interface AuthorizationRequestService
{

    public AuthorizationRequestInfo getAuthorizationRequestInfo(AuthorizationRequestType type,String tenantId) throws AuthorizationRequestException;

}
