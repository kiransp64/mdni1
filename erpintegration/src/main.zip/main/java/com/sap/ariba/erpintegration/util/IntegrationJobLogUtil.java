package com.sap.ariba.erpintegration.util;

import com.sap.ariba.erpintegration.audit.AuditManagerImpl;
import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.handlers.IntegrationJobLogProvider;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.IntegrationJobLogRepository;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.persistence.model.AggregatedIntegrationJobLogResults;
import com.sap.ariba.erpintegration.persistence.model.IntegrationJobLog;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.service.BaseIdService;
import com.sap.ariba.erpintegration.persistence.service.BaseIdServiceImpl;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;
import com.sap.ariba.erpintegration.service.exception.IntegrationJobLogProviderException;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.rowset.serial.SerialBlob;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class IntegrationJobLogUtil
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.util.IntegrationJobLogUtil";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    private static boolean auditEnabled = Boolean.TRUE;

    public static IntegrationJobLog getIntegrationJobLog(String recordId)
    {
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        IntegrationJobLogRepository dao = (IntegrationJobLogRepository)daoFactory.getMiscDAO(ObjectTypes.IntegrationJobLog.name());
        IntegrationJobLog[] integrationJobLog = dao.findAll(recordId);
        return integrationJobLog != null && integrationJobLog.length > 0 ? integrationJobLog[0]: null;
    }

    public static List<Integer> getReprocessLinesList(String recordId)
    {
        IntegrationJobLog integrationJobLog = getIntegrationJobLog(recordId);
        if (integrationJobLog != null && integrationJobLog.getReprocessLines() != null) {
            List<Integer> reprocessLinesList = Arrays.asList(integrationJobLog.getReprocessLines().split(","))
                    .stream()
                    .map(String::trim)
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());

            return reprocessLinesList;
        }
        return null;
    }

    /**
     * create/update integration job log
     * for a processed job
     * @param anId
     * @param jobResponseProcessor
     * @param skippedRecords :applicable for incremental load
     * @param tenantId
     * @param integrationJobId
     * @param senderBusinessSystemId
     * @param integrationJobLogId
     * @param stagingJobStatus
     */
    public static void logIntegrationJobProcessingDetails (String anId,
                                                     IntegrationJobResponseProcessor jobResponseProcessor,
                                                     List<String> additionalWarnings,
                                                     long tenantId,
                                                     String integrationJobId,
                                                     String senderBusinessSystemId,
                                                     String integrationJobLogId,
                                                     int stagingJobStatus)
    {
        try {
            Date currentDate = new Date();
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            IntegrationJobLogRepository dao = (IntegrationJobLogRepository) daoFactory.getMiscDAO(ObjectTypes.IntegrationJobLog.name());
            IntegrationJobLog integrationJobLog = dao.findOne(integrationJobLogId);
            if (integrationJobLog == null) {
                logger.warn("Missing IntegrationJobLog Record for {}, so setting startDate and endDate to currentDate", integrationJobId );
                integrationJobLog = new IntegrationJobLog();
                integrationJobLog.setId(getBaseId(tenantId, ObjectTypes.IntegrationJobLog.getValue()));
                integrationJobLog.setDateCreated(new Date());
                integrationJobLog.setIsActive(0);
                integrationJobLog.setTenantId(tenantId);
                integrationJobLog.setSenderBusinessSytemId(senderBusinessSystemId);
                integrationJobLog.setJobId(integrationJobId);
                integrationJobLog.setStartDate(currentDate);
            }
            integrationJobLog.setEndDate(currentDate);
            integrationJobLog.setDateUpdated(new Date());
            integrationJobLog.setRecordsInserted(jobResponseProcessor.getRecordsCreated());
            integrationJobLog.setRecordsUpdated(jobResponseProcessor.getRecordsUpdated());
            integrationJobLog.setRecordsDeleted(jobResponseProcessor.getRecordsDeactivated());
            integrationJobLog.setReprocessLines(jobResponseProcessor.getReprocessLineNumbers());
            integrationJobLog.setStatus(stagingJobStatus);
            String existingWarnings = "";
            if(integrationJobLog.getWarningMessages() != null) {
                byte[] bytes = XMLUtil.convertBolbToByteArray(integrationJobLog.getWarningMessages());
                existingWarnings = new String(bytes);
            }
            String warningMessages = existingWarnings;
            for (String warning : additionalWarnings) {
                warningMessages += warning;                 		
            }
            warningMessages += jobResponseProcessor.getWarningMessages();
            if (warningMessages != null) {
                byte[] buff = warningMessages.getBytes();
                Blob blob = new SerialBlob(buff);
                integrationJobLog.setWarningMessages(blob);
            }

            String fatalErrorMessages = jobResponseProcessor.getFatalErrorMessages();
            if (fatalErrorMessages != null) {
                byte[] buff = fatalErrorMessages.getBytes();
                Blob blob = new SerialBlob(buff);
                integrationJobLog.setFatalErrors(blob);
            }

            String nonFatalExceptions = jobResponseProcessor.getNonFatalExceptions();
            if (nonFatalExceptions != null) {
                byte[] buff = nonFatalExceptions.getBytes();
                Blob blob = new SerialBlob(buff);
                integrationJobLog.setNonFatalExceptions(blob);
            }

            dao.save(integrationJobLog);
        } catch (SQLException se) {
            logger.warn(
                    "Exception while saving IntegrationJobLog data for {}, Exception {}", integrationJobId , se.getMessage());

            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(
                        anId,
                        Operation.PROCESS_INTEGRATION_DATA,
                        "Exception while updating IntegrationJobLog tenantId : " + tenantId + ", recordId:" + integrationJobId + ". Exception : "
                                + se.getMessage());
            }

        } catch (InvalidTypeCodeException se) {
            logger.warn(
                    "Exception while saving IntegrationJobLog data for {}, Exception {}", integrationJobId, se.getMessage());

            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(
                        anId,
                        Operation.PROCESS_INTEGRATION_DATA,
                        "Exception while updating IntegrationJobLog tenantId : " + tenantId + ", recordId:" + integrationJobId + ". Exception : "
                                + se.getMessage());
            }

        }
        finally {
            additionalWarnings.clear();
        }

    }

    public static String createIntegrationJobLogEntry (String anId,
                                                       long tenantId,
                                                       String integrationJobId,
                                                       String senderBusinessSystemId,
                                                       String objectName,
                                                       int status,
                                                       List<String> additionalWarnings)
    {
        String integrationJobLogId = null;
        IntegrationJobLog integrationJobLog = null;
        try {
            Date currentDate = new Date();
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            IntegrationJobLogRepository dao = (IntegrationJobLogRepository) daoFactory.getMiscDAO(ObjectTypes.IntegrationJobLog.name());
            integrationJobLog = new IntegrationJobLog();
            integrationJobLogId = getBaseId(tenantId, ObjectTypes.IntegrationJobLog.getValue());
            integrationJobLog.setId(integrationJobLogId);
            integrationJobLog.setDateCreated(currentDate);
            integrationJobLog.setIsActive(0);
            integrationJobLog.setTenantId(tenantId);
            integrationJobLog.setSenderBusinessSytemId(senderBusinessSystemId);
            integrationJobLog.setJobId(integrationJobId);
            integrationJobLog.setDateUpdated(currentDate);
            integrationJobLog.setStartDate(currentDate);
            integrationJobLog.setStatus(status);
            String warnings = "";
            for (String warning : additionalWarnings) {
            		warnings += warning;
            }
            if (warnings.length() > 0) {
                byte[] buff = warnings.getBytes();
                Blob blob = new SerialBlob(buff);
                integrationJobLog.setWarningMessages(blob);
            }
            dao.save(integrationJobLog);
        } catch (InvalidTypeCodeException | SQLException se) {
            logger.warn(
                    "Exception while creating a new IntegrationJobLog entry for {}, Exception {}", integrationJobId, se.getMessage());

            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(
                        anId,
                        Operation.PROCESS_INTEGRATION_DATA,
                        "Exception while creating a new IntegrationJobLog entry for tenantId : " + tenantId + ", recordId:" + integrationJobId + ". Exception : "
                                + se.getMessage());
            }

        }
        finally {
            additionalWarnings.clear();
        }

        return integrationJobLogId;

    }

    public static StageXMLData[] getIntegrationJobLogsForTenant(long tenantId)
    {
        StageXMLData[] jobs = null;

        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        StageXMLDataRepository dao = (StageXMLDataRepository) daoFactory.getGenericDAOStageData(ObjectTypes.XmlPayload.name());
        jobs = dao.findAll(tenantId);

        return jobs;
    }

    /**
     * Format of the BaseId
     * Total Length is 17 Characters
     * First 4 are for Variant
     * 2 Characters for the Service Code
     * 3 Characters for the Object Type Code
     * 8 Characters for the Sequence number
     *
     * @param variantId
     * @param objectName
     * @return
     * @throws InvalidTypeCodeException
     */
    private static String getBaseId(long variantId, String objectName) throws
            InvalidTypeCodeException {
        BaseIdService service = BaseIdServiceImpl.getInstance();
        return service.allocateBaseId(objectName, variantId);
    }

    public static JSONArray getIntegrationJobLogData(StageXMLData[] jobs)
    {
        JSONArray integrationJobLogsData = new JSONArray();
        final String KeyJobId = "JobId";
        final String KeyObject = "MasterDataObject";
        final String KeyStartDate = "StartDate";
        final String KeyEndDate = "EndDate";

        for (StageXMLData job: jobs) {
            JSONObject integrationJobLogObj = new JSONObject();
            integrationJobLogObj.put(KeyJobId, job.getId());
            integrationJobLogObj.put(KeyObject, job.getObjectName());
            integrationJobLogsData.add(integrationJobLogObj);
        }

        return integrationJobLogsData;
    }

    public static StageXMLData getLatestStageXmlDataForObject(String objectName, long tenantId){
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        StageXMLDataRepository dao = (StageXMLDataRepository) daoFactory.getGenericDAOStageData(ObjectTypes.XmlPayload.name());
        return dao.findLatest(objectName,tenantId);
    }

    public static AggregatedIntegrationJobLogResults getAggregatedRecordsData(String jobId){
        IntegrationJobLogRepository integrationJobLogRepositoryDao = getIntegrationJobLogRepository();
        AggregatedIntegrationJobLogResults aggregatedIntegrationJobLogResults =integrationJobLogRepositoryDao.findAggregatedRecordsData(jobId);
        return aggregatedIntegrationJobLogResults;
    }

    public static IntegrationJobLog getLatestIntegrationJobLogDateUpdated(String jobId){
        IntegrationJobLogRepository integrationJobLogRepositoryDao = getIntegrationJobLogRepository();
        return integrationJobLogRepositoryDao.findLatestDateUpdatedRecord(jobId);
    }

    private static IntegrationJobLogRepository getIntegrationJobLogRepository(){
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        IntegrationJobLogRepository integrationJobLogRepository = (IntegrationJobLogRepository)daoFactory.getMiscDAO(ObjectTypes.IntegrationJobLog.name());
        return integrationJobLogRepository;
    }

    public static boolean integrationJobLogExist(String jobId){
        boolean retVal = true;
        IntegrationJobLogRepository integrationJobLogRepositoryDao = getIntegrationJobLogRepository();
        IntegrationJobLog integrationJobLog = integrationJobLogRepositoryDao.findLatestDateUpdatedRecord(jobId);
        if(integrationJobLog == null){
            logger.debug("No entry exist in IntegrationJobLog Table for jobId {}",jobId);
            retVal = false;
        }
        return retVal;
    }
    public static StageXMLData getStageXmlDataForJobId(String jobId, Long tenantId){
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        StageXMLDataRepository dao = (StageXMLDataRepository) daoFactory.getGenericDAOStageData(ObjectTypes.XmlPayload.name());
        return dao.findStageXmlDataForJobId(jobId, tenantId);
    }

    public static String convertBlobToString (Blob blobData) throws
        IntegrationJobLogProviderException
    {
        if (blobData == null) {
            return "";
        }
        StringBuffer sb = new StringBuffer();
        InputStream inputStream = null;
        try {
            inputStream = blobData.getBinaryStream();
            int bytesRead;
            int chunkSize = 4096;
            do {
                byte[] bytes = new byte[chunkSize];
                bytesRead = inputStream.read(bytes);
                if (bytesRead > 0) {
                    String data = new String(bytes, 0, bytesRead, IntegrationJobLogProvider.characterEncoding);
                    sb.append(data);
                }
            }
            while (bytesRead == chunkSize);
        } catch (IOException | SQLException ex) {
            if (inputStream != null) {
                try {
                    inputStream.close();
                    throw new IntegrationJobLogProviderException("Error while closing stream");
                } catch (IOException e) {
                    IntegrationJobLogProvider.logger.warn("Exception {}", e);
                }
            }
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        return sb.toString();
    }
}
