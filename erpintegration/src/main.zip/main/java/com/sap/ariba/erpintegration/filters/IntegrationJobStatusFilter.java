/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.filters;

import com.sap.ariba.erpintegration.handlers.CredentialAuthenticatorFactory;
import com.sap.ariba.erpintegration.handlers.CredentialBasedAuthenticator;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.mdsclient.search.util.StringUtil;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import static org.springframework.http.HttpStatus.valueOf;

/**
 * This filter is used for new Integration Job status api , to validate and authenticate incoming request for Jobstatus call.
 */
@Component
public class IntegrationJobStatusFilter implements Filter
{

    private static final Logger logger = LoggerFactory.getLogger(IntegrationJobStatusFilter.class);

    private static String MDNI_CRITICAL_INTEGRATION_JOB = "[MDNI_CRITICAL][ARIBA][INTEGRATION_JOB_STATUS]";

    private static final String BASIC = "basic";

    private static final String INTEGRATION_JOB_STATUS_PATH = "integrationjob/status";

    private static final String ERROR_CODE = "errorCode";

    private static final String ERROR_MESSAGE = "message";

    private static final String NOT_VALID_REQUEST = "Not a valid incoming request.";

    @Autowired
    private CredentialAuthenticatorFactory credentialAuthenticatorFactory;

    /**
     * @param filterConfig
     * @throws ServletException
     */
    @Override
    public void init (FilterConfig filterConfig) throws ServletException
    {
        Filter.super.init(filterConfig);
    }

    /**
     * If incoming request is for Integration Job status api , then we are authenticating the request.
     *
     * @param servletRequest
     * @param servletResponse
     * @param filterChain
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void doFilter (ServletRequest servletRequest,
                          ServletResponse servletResponse,
                          FilterChain filterChain) throws IOException, ServletException
    {
        HttpServletRequest request = (HttpServletRequest)servletRequest;
        HttpServletResponse response = (HttpServletResponse)servletResponse;
        String requestUri = request.getRequestURI();
        if (isJobStatusCall(requestUri)) {
            logger.debug("From IntegrationJobStatusFilter , Integration JobStatus api Call.");
            String tenantId = request.getParameter(Constants.KeyTenantId);
            if (StringUtils.isBlank(tenantId)) {
                logger.error("{}, tenant id not passed as part of request.",
                             MDNI_CRITICAL_INTEGRATION_JOB);
                writeErrorResponse(NOT_VALID_REQUEST + "TenantId is Missing.",
                                   HttpStatus.SC_BAD_REQUEST,
                                   response,
                                   requestUri);
                return;
            }
            if (!Utility.isTenantExists(tenantId)) {
                logger.error("{},{} Tenant : {} not recognized.",
                             MDNI_CRITICAL_INTEGRATION_JOB,
                             NOT_VALID_REQUEST,
                             tenantId);
                writeErrorResponse(NOT_VALID_REQUEST + "Tenant Id" + tenantId + " not recognized.",
                                   HttpStatus.SC_BAD_REQUEST,
                                   response,
                                   requestUri);
                return;
            }
            if (!performBasicAuthentication(request,
                                            response)) {
                return;
            }
        }
        filterChain.doFilter(servletRequest,
                             servletResponse);
    }

    /**
     * Check if incoming request is for integration Job status
     *
     * @param requestUri for integration job status.
     * @return true of false
     */
    private boolean isJobStatusCall (String requestUri)
    {
        return StringUtils.isNotEmpty(requestUri) && requestUri.toLowerCase()
                        .contains(INTEGRATION_JOB_STATUS_PATH);
    }

    /**
     * This method will validate basic authentication for integration job status API.
     *
     * @param request incoming Http request
     */
    private boolean performBasicAuthentication (HttpServletRequest request,
                                                HttpServletResponse response)
    {
        boolean isValid = false;
        String requestUri = request.getRequestURI();
        String tenantId = request.getParameter(Constants.KeyTenantId);
        String jobId = request.getParameter(Constants.KeyJobId);
        final String authorizationToken = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (StringUtil.nullOrEmptyOrBlankString(authorizationToken)
                        || !authorizationToken.toLowerCase().startsWith(BASIC)) {
            logger.error("Authorization header/Basic Authentication passed as blank, for Tenant Id - {},Job Id - {}",
                         tenantId,
                         jobId);
            writeErrorResponse("Invalid request with Basic Auth, Authorization header should not be blank.",
                               HttpStatus.SC_UNAUTHORIZED,
                               response,
                               requestUri);
            return isValid;
        }
        try {
            String basicAuthPair = new String(Base64.decodeBase64(authorizationToken.substring(6)));
            String userName = basicAuthPair.split(":")[0];
            String password = basicAuthPair.split(":")[1];
            if (getCredentialBasedAuthenticator().validateCredentials(tenantId,
                                                                      "",
                                                                      userName,
                                                                      password)) {
                logger.debug("Integration Job status API ,verification of Basic Auth token is successful for Tenant Id - {},Job Id - {}.",
                             tenantId,
                             jobId);
                isValid = true;
            }
            else {
                logger.error("{},Basic Authentication verification failed for Tenant Id - {},Job Id - {}.",
                             MDNI_CRITICAL_INTEGRATION_JOB,
                             tenantId,
                             jobId);
                writeErrorResponse("Basic Authentication verification failed.",
                                   HttpStatus.SC_UNAUTHORIZED,
                                   response,
                                   requestUri);
            }
        }
        catch (IntegrationServiceException e) {
            logger.error("{}, Request Uri - {}, Tenant ID - {} ,Job Id-{}, Error - {} ,Basic Authentication verification failed for integration job status api.",
                         MDNI_CRITICAL_INTEGRATION_JOB,
                         requestUri,
                         tenantId,
                         jobId,
                         ErrorUtil.getCompleteCausedByErrors(e));
            writeErrorResponse("Invalid Authentication Credentials.",
                               HttpStatus.SC_UNAUTHORIZED,
                               response,
                               requestUri);
        }
        catch (Exception e) {
            logger.error("{}, Request Uri - {}, Tenant ID - {} ,Job Id-{}, Error - {} , while verifying basic authentication.",
                         MDNI_CRITICAL_INTEGRATION_JOB,
                         requestUri,
                         tenantId,
                         jobId,
                         ErrorUtil.getCompleteCausedByErrors(e));
            writeErrorResponse("Internal server Error, Please reach out to Internal System",
                               HttpStatus.SC_INTERNAL_SERVER_ERROR,
                               response,
                               requestUri);
        }
        return isValid;
    }

    /**
     * writing error response.
     *
     * @param errResponse
     * @param status
     * @param response
     * @param url
     */
    private void writeErrorResponse (String errResponse,
                                     int status,
                                     HttpServletResponse response,
                                     String url)
    {

        try {
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            response.setStatus(status);
            logger.error("{}, Status - {}, Request URL - {} failed due to the reason: {}.",
                         MDNI_CRITICAL_INTEGRATION_JOB,
                         status,
                         url,
                         errResponse);
            JSONObject errorMessage = new JSONObject();
            errorMessage.put(ERROR_CODE,
                             valueOf(status));
            errorMessage.put(ERROR_MESSAGE,
                             errResponse);
            response.getWriter().write(String.valueOf(errorMessage));
        }
        catch (IOException e) {
            logger.error("Error - {}, while convert errResponse to json.",
                         e.getMessage());
        }

    }

    private CredentialBasedAuthenticator getCredentialBasedAuthenticator ()
    {
        return credentialAuthenticatorFactory.getCredentialBasedAuthenticator();
    }

    /**
     *
     */
    @Override
    public void destroy ()
    {
        Filter.super.destroy();
    }
}
