package com.sap.ariba.erpintegration.storage;

import java.io.InputStream;

public class CloudStorageResponse
{
    private Object closeableObject = null;
    private InputStream inputStream = null;

    public CloudStorageResponse (Object closeableObject, InputStream inputStream)
    {
        this.closeableObject = closeableObject;
        this.inputStream = inputStream;
    }

    public Object getCloseableObject ()
    {
        return closeableObject;
    }

    public InputStream getInputStream ()
    {
        return inputStream;
    }

}
