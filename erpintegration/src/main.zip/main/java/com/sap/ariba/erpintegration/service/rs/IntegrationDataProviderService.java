package com.sap.ariba.erpintegration.service.rs;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sap.ariba.erpintegration.handlers.RequestHandler;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;

/**
 * Created by i318483 on 01/06/17.
 */
// @RestController
public class IntegrationDataProviderService
{

    private static final String KeyMinRecordIdHeader = "MinRecordId";
    private static final String KeyMaxRecordIdHeader = "MaxRecordId";
    private static final String KeyMaxBucketIdHeader = "MaxBucketId";
    private static final String KeyObjectNameHeader = "ObjectName";
    private static final String KeyRealmHeader = "realm";
    private static final String KeyPageNumber = "pageNumber";

    private static final String KeyAction = "RetrieveData";

    @GET @RequestMapping("/getIntegrationData") @Produces("application/json") public Response getData (
        @Context HttpServletRequest request) throws IntegrationServiceException,MissingServletRequestParameterException
    {
        RequestHandler requestHandler = RequestHandler.getHandler(KeyAction);
        return requestHandler.execute(request);
    }
}
