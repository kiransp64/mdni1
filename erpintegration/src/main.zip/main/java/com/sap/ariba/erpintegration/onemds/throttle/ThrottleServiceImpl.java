package com.sap.ariba.erpintegration.onemds.throttle;

import com.sap.ariba.erpintegration.onemds.common.MDIConfig;
import com.sap.ariba.erpintegration.onemds.exception.ThrottleDAOException;
import com.sap.ariba.erpintegration.onemds.exception.ThrottleServiceException;
import com.sap.ariba.erpintegration.onemds.throttle.dao.ThrottleDAO;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ThrottleServiceImpl implements ThrottleService
{
    private static final Logger logger = LoggerFactory.getLogger(ThrottleServiceImpl.class);

    @Autowired
    private MDIConfig mdiConfig;

    @Autowired
    private ThrottleDAO throttleDAO;

    @Override
    public int getTotalInProgress () throws ThrottleServiceException
    {
        try {
            return throttleDAO.getTotalRunning();
        }
        catch (ThrottleDAOException e) {
            logger.error("{} while trying to get total running MDI Integration events.",
                ErrorUtil.getCompleteCausedByErrors(e));
            throw new ThrottleServiceException("Error while trying to find total running MDI Integration processes.",
                e);
        }
    }

    @Override
    public int getTotalInProgressInCurrentNode () throws ThrottleServiceException
    {
        try {
            return throttleDAO.getTotalRunningInNode(mdiConfig.getNodeIndex());
        }
        catch (ThrottleDAOException e) {
            logger.error(
                "{} while trying to find total running MDI integration processes in node - {}.",
                ErrorUtil.getCompleteCausedByErrors(e),
                mdiConfig.getNodeIndex());
            throw new ThrottleServiceException(
                "Error while trying to find total running MDI integration processes in node - "
                    + mdiConfig.getNodeIndex(),
                e);
        }
    }

    @Override
    public boolean canDistribute ()
    {
        try {
            return getTotalInProgress() < mdiConfig.getMaxTotalRuns();
        }
        catch (ThrottleServiceException tse) {
            logger.error(
                "[MDI_Integration] [Throttle_Error] {}, while checking if processing can be distributed.",
                ErrorUtil.getCompleteCausedByErrors(tse));
            return true;
        }

    }

    @Override
    public boolean canProcessInCurrentNode ()
    {
        try {
            return getTotalInProgressInCurrentNode() < mdiConfig.getMaxPerNodeRuns();
        }
        catch (ThrottleServiceException tse) {
            logger.error(
                "[MDI_Integration] [Throttle_Error] {}, while checking if tenant can be processed in current node.",
                ErrorUtil.getCompleteCausedByErrors(tse));
            return true;
        }
    }
}
