package com.sap.ariba.erpintegration.service.exception;

/**
 * Created by i318483 on 31/05/17.
 */
public class IntegrationPayloadProcessorException extends Exception
{
    private static final long serialVersionUID = 1L;

    public IntegrationPayloadProcessorException (Exception e)
    {
        super(e);
    }

    public IntegrationPayloadProcessorException (String message)
    {
        super(message);
    }

    public IntegrationPayloadProcessorException (String message, Exception e)
    {
        super(message, e);
    }
}
