package com.sap.ariba.erpintegration.service.ws;

import com.sap.ariba.erpintegration.persistence.model.UserExport.UserExportData;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;

import jakarta.jws.WebMethod;
import jakarta.jws.WebResult;
import jakarta.jws.WebService;
import jakarta.xml.ws.ResponseWrapper;
import java.util.List;

/**
 * Created by c5259108 on 15/02/18.
 */

@WebService(serviceName = "UserIntegrationService",targetNamespace = "http://userIntegrationService.com")
public interface UserIntegrationService {
    @WebMethod(operationName = "fetchUsers")
    @WebResult(name = "User")
    @ResponseWrapper(localName = "UsersResponse") List<UserExportData> getUsers () throws
        IntegrationServiceException;
}
