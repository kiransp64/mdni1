package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;

import java.util.Date;

/**
 * Created by i318483 on 01/06/17.
 */
@NoRepositoryBean
public interface GenericJPADAO<T, D> extends JpaRepository<GenericEntity, Long>
{
    public String findMinId(@Param("timeUpdated") Date timeUpdated, @Param("tenantId") String tenantId);

    public String findMaxId(@Param("timeUpdated") Date timeUpdated, @Param("tenantId") String tenantId);
}
