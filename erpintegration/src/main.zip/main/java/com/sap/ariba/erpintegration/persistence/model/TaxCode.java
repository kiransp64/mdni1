package com.sap.ariba.erpintegration.persistence.model;

import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.util.CountryCodesMap;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.Serializable;
import java.util.Map;

public class TaxCode extends GenericEntity implements Serializable
{
    public static final String nameOfLogger = "com.sap.ariba.erpintegration.persistence.model.TaxCode";
    public static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private static final long serialVersionUID = 1L;
    private static final String objectType = "TaxCode";
    private static final String countryCodeNavigationTag = "TaxCodeKey.CountryCode";

    private String taxCode;

    private String countryCode;

    private static String[] lookupFields = { "TaxCode", "CountryCode" };

    @Override
    public void setLookupFields (Map<String, String> lookupDetails)
    {
        Object specialField1 = lookupDetails.get(lookupFields[0]);
        Object specialField2 = lookupDetails.get(lookupFields[1]);

        setTaxCode((String)specialField1);
        setCountryCode((String)specialField2);
    }

    @Override
    public String getObjectType ()
    {
        return objectType;
    }

    public String getTaxCode ()
    {
        return taxCode;
    }

    public void setTaxCode (String taxCode)
    {
        this.taxCode = taxCode;
    }

    public String getCountryCode ()
    {
        return countryCode;
    }

    public void setCountryCode (String countryCode)
    {
        this.countryCode = countryCode;
    }

    @Override
    public void processCountryCode (JSONObject jsonObject)
    {
        String countryCodeValue = (String)Utility.getNestedData(jsonObject,
                                                                countryCodeNavigationTag);
        if (!StringUtils.isEmpty(countryCodeValue)) {
            String aplha2CountryCode = CountryCodesMap.getAplha2CountryCode(countryCodeValue);
            if (!StringUtils.isEmpty(aplha2CountryCode)) {
                logger.debug("Replacing alpha3CountryCode {} with aplpha3CountryCode {} for objectName {}",
                             countryCodeValue,
                             aplha2CountryCode,
                             objectType);
                Utility.setNestedData(jsonObject,
                                      countryCodeNavigationTag,
                                      aplha2CountryCode);
            }
        }
    }
}
