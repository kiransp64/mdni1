package com.sap.ariba.erpintegration.common.utility;
/**
 * Created by i318483 on 24/04/17.
 */
import com.sap.ariba.erpintegration.MasterDataPublishServiceProxyConfiguration;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
@Primary
@Service @Component public class OAuthTokenManager
{
    @Value("${authServerURI}") private String oauthUrl;

    @Value("${authServerRefreshTokenURI}") private String authServerRefreshTokenURI;

    @Value("${mdniOauthClientId}") private String oauthClientId;

    @Value("${mdniOauthClientPrivateKey}") private String oauthClientPrivateKey;

    @Value("${mdniOauthClientPublicKey}") private String oauthClientPublicKey;

    @Value("${security.oauth2.resource.userInfoUri}") private String oauthUserInfoUrl;
    
    @Value("${oauthAccessTokenGrantType:#{null}}") private String accessTokenGrantType;

    @Value("${proxyURL}")
    public String proxyURL;

    @Autowired
    @Lazy
    private MasterDataPublishServiceProxyConfiguration httpsProxy;

    public static final String SCOPES_KEY = "scope";
    public static final String DEFAULT_SCOPES_VALUE = "erpnativeintgsvc:fetchdata";
    public static final String USER_NAME_KEY = "user_name";
    public static final String CUSTOM_ATTRIBUTES_KEY = "customAttributes";
    private static final String REALM_KEY = "uniq_attr2";

    public static final String AccessToken = "AccessToken";
    public static final String RefreshToken = "RefreshToken";
    public static final String ExpiresIn = "ExpiresIn";
    public static final String Scope = "Scope";
    public static final String TimeUpdated = "TimeUpdated";
    public static final String TokenType = "TokenType";

    public static final String grant_type = "grant_type";
    public static final String refresh_token = "refresh_token";

    private static final String USER_AGENT = "Mozilla/5.0";

    private static final Logger logger = LoggerFactory.getLogger(
        OAuthTokenManager.class);

    public Map<String, String> getTokens (String realmName,
                                          String customAttributes)
    {
        return getTokens(realmName,customAttributes,DEFAULT_SCOPES_VALUE);
    }

    public Map<String, String> getTokens (String realmName,
                                          String customAttributes, String scope)
    {
        HttpHeaders headers = null;
        RestTemplate restTemplate = null;
        Map<String, String> tokenMap = null;
        MultiValueMap<String, String> parameters = null;
        String grantType = null;

        grantType   = getGrantType();

        try {
            headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.add(
                "Authorization",
                "Basic " + getBase64EncodedValue(
                    oauthClientId,
                    oauthClientPrivateKey));

            parameters = new LinkedMultiValueMap<>();
            parameters.add(SCOPES_KEY, scope);
            parameters.add(USER_NAME_KEY, realmName);
            parameters.add(REALM_KEY, realmName);
            if (grantType != null && !grantType.isEmpty()) {
                parameters.add(grant_type, grantType);
            }
            if (customAttributes == null) {
                customAttributes = "{\"anId\", \"" + realmName +"\"}";
            }

            parameters.add(CUSTOM_ATTRIBUTES_KEY, customAttributes);

            final HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<MultiValueMap<String, String>>(
                parameters,
                headers);

            restTemplate = httpsProxy.getRestTemplate();
            logger.info("Start : Connecting to URL {} ",oauthUrl );
            final ResponseEntity<OAuth2TokenInfo> entity = (ResponseEntity) restTemplate.postForEntity(oauthUrl,
                requestEntity,
                OAuth2TokenInfo.class);
            OAuth2TokenInfo body = entity.getBody();

            tokenMap = getTokenMap(body);
        } 
        catch (IllegalStateException e) {
            logger.info("=== Error msg = " + e.getMessage());
        }
        catch(Exception e) {
            logger.info("=== Error msg = " + e.getMessage());
        }
        return tokenMap;
    }

    public OAuth2UserInfo getUserInfo (String token)
    {
        String responseData = null;
        OAuth2UserInfo userInfo = null;
        try {
            Map requestHeaders = new HashMap();
            requestHeaders.put("Authorization", "Bearer " + token);
            responseData = getTokenInfo(
                oauthUserInfoUrl,
                requestHeaders);
            return getOAuthUserInfo((responseData));
        }
        catch (IllegalStateException e) {
            logger.warn("=== Error msg = " + e.getMessage());
        }
        catch (Exception e) {
            logger.info("=== Error msg = " + e.getMessage());
        }
        return userInfo;
    }

    public String getUserInfoAsString (String token)
    {
        String responseData = null;
        OAuth2UserInfo userInfo = null;
        try {
            Map requestHeaders = new HashMap();
            requestHeaders.put("Authorization", "Bearer " + token);
            responseData = getTokenInfo(oauthUserInfoUrl, requestHeaders);
            return responseData;
        } catch (IllegalStateException e) {
            logger.warn("=== Error msg = " + e.getMessage());
        } catch(Exception e) {
            logger.info("=== Error msg = " + e.getMessage());
        }
        return null;
    }

    public String getTokenInfo (String urlToRead, Map<String, String> headers)
    {
        URL url = null;
        String line = null;
        BufferedReader rd = null;
        String responseValue = null;
        StringBuilder result = null;
        HttpURLConnection conn = null;
        JSONObject malformedURLException = null;
        JSONObject ioException = null;
        JSONObject protocolException = null;

        try {
            result = new StringBuilder();
            url = new URL(urlToRead);
            conn = httpsProxy.openConnection(url);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USER_AGENT);

            if (headers != null) {
                for (Map.Entry entry : headers.entrySet()) {
                    conn.addRequestProperty((String) entry.getKey(),
                        (String) entry.getValue());
                }
            }

            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                return null;
            }

            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);
            }
            rd.close();
            responseValue = result.toString();

        } catch (MalformedURLException ex) {
            if(malformedURLException!=null) {
                responseValue = malformedURLException.toString();
            }
        } catch (ProtocolException ex) {
            if(protocolException!=null) {
                responseValue = protocolException.toString();
            }
        } catch (IOException ex) {
            if(ioException!=null) {
                responseValue = ioException.toString();
            }
        }
        finally {
            try {
                if(rd != null) {
                    rd.close();
                }
            }
            catch (IOException e) {
                logger.error("Cannot close BufferedReader {}", e.getMessage());
            }
        }

        return responseValue;
    }

    private OAuth2UserInfo getOAuthUserInfo (String tokenInfo)
    {
        OAuth2UserInfo userInfo = null;
        try {
            if (tokenInfo != null) {
                JSONTokener tokener = new JSONTokener(tokenInfo);
                JSONObject json = new JSONObject(tokener);
                if (json != null) {
                    if (json.has("uniqAttr2") && json.has("attributes")) {
                        JSONObject attrObj = (JSONObject) json.get("attributes");
                        userInfo = new OAuth2UserInfo();
                        if (attrObj != null) {
                            if (attrObj.has("customAttributes")) {
                                tokener = new JSONTokener((String) attrObj.getString(
                                    "customAttributes"));
                                JSONObject custAttr = new JSONObject(tokener);
                                if (custAttr.has("anId")) {
                                    userInfo.setAnId(custAttr.getString("anId"));
                                }
                            }
                        }
                    }
                }
            }
        } catch (JSONException ex) {
            logger.warn("Exception while parsing json data {} " , ex);
        }

        return userInfo;
    }

    public static String getAccessTokenFromTokenMap (Map<String, String> tokenMap)
    {
        if (tokenMap == null)
            return null;

        return tokenMap.get(AccessToken);
    }

    public static String getRefreshTokenFromTokenMap (Map<String, String> tokenMap)
    {
        if (tokenMap == null)
            return null;

        return tokenMap.get(RefreshToken);
    }

    public static String getExpiresInFromTokenMap (Map<String, String> tokenMap)
    {
        if (tokenMap == null)
            return null;

        return tokenMap.get(ExpiresIn);
    }

    public static String getScopeFromTokenMap (Map<String, String> tokenMap)
    {
        if (tokenMap == null)
            return null;

        return tokenMap.get(Scope);
    }

    public static String getTimeUpdatedFromTokenMap (Map<String, String> tokenMap)
    {
        if (tokenMap == null)
            return null;

        return tokenMap.get(TimeUpdated);
    }

    public static String getTokenTypeFromTokenMap (Map<String, String> tokenMap)
    {
        if (tokenMap == null)
            return null;

        return tokenMap.get(TokenType);
    }

    public Map<String, String> refreshToken (String refreshToken)
    {
        Map<String, String> tokenMap = null;
        try {
            RestTemplate restTemplate = httpsProxy.getRestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.add(
                "Authorization",
                "Basic " + getBase64EncodedValue(
                    oauthClientId,
                    oauthClientPublicKey));

            MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
            parameters.add(grant_type, refresh_token);
            parameters.add(refresh_token, refreshToken);

            final HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<MultiValueMap<String, String>>(
                parameters,
                headers);

            final ResponseEntity<OAuth2TokenInfo> entity = (ResponseEntity) restTemplate.postForEntity(
                authServerRefreshTokenURI,
                requestEntity,
                OAuth2TokenInfo.class);
            OAuth2TokenInfo body = entity.getBody();

            tokenMap = getTokenMap(body);
        } catch (IllegalStateException | UnsupportedOperationException e) {
            logger.info("=== Error msg = " + e.getMessage());
        } catch(Exception e) {
            logger.info("=== Error msg = " + e.getMessage());
        }
        return tokenMap;
    }

    public Map<String, String> getTokenMap (OAuth2TokenInfo oAuth2TokenInfo)
    {
        Map<String, String> tokenMap = new HashMap<>(6);
        tokenMap.put(AccessToken, oAuth2TokenInfo.getAccess_token());
        tokenMap.put(RefreshToken, oAuth2TokenInfo.getRefresh_token());
        tokenMap.put(ExpiresIn, oAuth2TokenInfo.getExpires_in());
        tokenMap.put(Scope, oAuth2TokenInfo.getScope());
        tokenMap.put(TimeUpdated, oAuth2TokenInfo.getTimeUpdated());
        tokenMap.put(TokenType, oAuth2TokenInfo.getToken_type());

        return tokenMap;
    }

    private static String getBase64EncodedValue (String clientId,
                                                 String clientSecret)
    {
        String encodedString = null;
        try {
            encodedString = Base64.getEncoder().encodeToString((clientId + ":"
                + clientSecret).getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            logger.warn(e.getMessage());
        }
        return encodedString;
    }

    protected String getGrantType ()
    {
        if(accessTokenGrantType!=null &&
                (!accessTokenGrantType.isEmpty()))
          return accessTokenGrantType;
        return null;
    }
}
