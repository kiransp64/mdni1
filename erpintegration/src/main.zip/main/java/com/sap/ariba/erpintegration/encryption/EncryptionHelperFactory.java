package com.sap.ariba.erpintegration.encryption;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.ConfigRepository;
import com.sap.ariba.erpintegration.persistence.model.IntegrationConfig;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.SetUtils;
import org.apache.commons.collections4.map.PassiveExpiringMap;
import org.apache.commons.lang3.time.DateUtils;

public class EncryptionHelperFactory
{
    // Keys from Buyer side
    private static final String KeyCurrentVersion = "CurrentVersion";
    private static final String KeyEncryptionKeys = "EncryptionKeys";
    private static final String KeySecurityInformation = "SecurityInformation";
    private static final String KeyCallbackURL = "CallbackURL";
    private static final String KeyGetEncryptionInfo = "getEncryptionInfo";
    private static final String SystemTenantANID = "SYSTEMANID";

    // This is a self expiring map with TTL value of 24 hours currently
    private static Map<String, Map<String, Object>> securityInformationMap = null;
    private static final long ExpirationTime = 1 * DateUtils.MILLIS_PER_DAY;
    /**
     * The latest version of encryption key. This corresponding secret key will
     * be used for encryption.
     */
    private static String currentVersion = null;
    private static Map<String, EncryptionHelper> encryptionHelpers = null;

    public static synchronized void initializeEncryptionHelpers ()
        throws SecurityInitializationException, IOException
    {
        if (isConfigurationInvalid()) {
            boolean isValid = false;
            Log.encryption.info("Initializing security info from Buyer");
            if (MapUtils.isNotEmpty(encryptionHelpers)) {
                encryptionHelpers.clear();
            }
            currentVersion = null;
            try {
                isValid = getAndValidateSecurityMap();
            }
            catch (SecurityInitializationException ex) {
                // Retry once again before failing
                Log.encryption.warn("Retrying security information fetch from Buyer");
                isValid = getAndValidateSecurityMap();
            }
            if (isValid) {
                Map<String, Object> securityInfo = securityInformationMap.get(
                    KeySecurityInformation);
                // Get the current key version
                currentVersion = (String)securityInfo.get(KeyCurrentVersion);
                // Get the encryption keys
                Map<String, String> keysMap = (Map<String, String>)securityInfo.get(
                    KeyEncryptionKeys);
                encryptionHelpers = new HashMap<>();
                for (Map.Entry<String, String> keyInfo : keysMap.entrySet()) {
                    String version = keyInfo.getKey();
                    String key = keyInfo.getValue();
                    EncryptionHelper helper = new AESEncryptionHelper(key);
                    encryptionHelpers.put(version, helper);
                }
            }
            else {
                Log.encryption.warn("Security information not initialized");
            }
        }
    }

    private static boolean isConfigurationInvalid ()
    {
        return MapUtils.isEmpty(securityInformationMap)
            || !securityInformationMap.containsKey(KeySecurityInformation);
    }

    private static synchronized boolean getAndValidateSecurityMap ()
        throws SecurityInitializationException
    {
        boolean retval = false;
        String url = getSecurityURL();
        if (!isBlankString(url)) {
            Map<String, Object> mapFromBuyer = getSecurityMapFromBuyer(url);
            // Validate the information
            if (!MapUtils.isEmpty(mapFromBuyer)) {
                if (!mapFromBuyer.containsKey(KeyCurrentVersion)
                    || isBlankStringObject(mapFromBuyer.get(KeyCurrentVersion)))
                {
                    throw new SecurityInitializationException(
                        "CurrentVersion key missing in security information from buyer");
                }
                if (!mapFromBuyer.containsKey(KeyEncryptionKeys)
                    || MapUtils.isEmpty((Map)mapFromBuyer.get(KeyEncryptionKeys)))
                {
                    throw new SecurityInitializationException(
                        "Encryption keys missing in security information from buyer");
                }
            }
            else {
                throw new SecurityInitializationException(
                    "Buyer returned null security information");
            }
            securityInformationMap = new PassiveExpiringMap<>(ExpirationTime);
            securityInformationMap.put(KeySecurityInformation, mapFromBuyer);
            retval = true;
        }
        return retval;
    }
    
    private static String getSecurityURL ()
    {
        String securityURL = null;
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        ConfigRepository dao = (ConfigRepository)factory.getMiscDAO(
            ObjectTypes.IntegrationConfig.getValue());
        IntegrationConfig config = dao.findTopByKeyOrderByKey(KeyCallbackURL);
        if (config != null) {
            securityURL = config.getValue();
            // This will return something like 
            // https://<host>/Buyer/Main/ad/getConfig/ariba.integration.base.NativeIntegrationDirectAction?realm=<realm>
            // First, trim the query string from the URL
            int queryStringIndex = securityURL.indexOf('?');
            if (queryStringIndex != -1) {
                securityURL = securityURL.substring(0, queryStringIndex);
            }
            // Next, add realm=System to the URL
            securityURL = securityURL.concat("?realm=System");
            // Next, replace 'getConfig' with 'getEncryptionInfo' in the string
            securityURL = securityURL.replace(HandlerUtil.KeyGetConfig, KeyGetEncryptionInfo);
            
            // Add proxy information
            OAuthTokenManager oAuthTokenManager;
            if (ApplicationContextProvider.getApplicationContext() != null) {
                oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(
                    OAuthTokenManager.class);
                if (oAuthTokenManager.proxyURL != null && !oAuthTokenManager.proxyURL.isEmpty()) {
                    securityURL = HandlerUtil.addProxyInfo(securityURL, oAuthTokenManager.proxyURL);
                }
            }
        }
        return securityURL;
    }

    private static Map<String, Object> getSecurityMapFromBuyer (String url)
        throws SecurityInitializationException
    {
        try {
            Map<String, Object> secMap = HandlerUtil.postRequest(url, SystemTenantANID, false, 2, null);
            return secMap;
        }
        catch (IntegrationServiceException e) {
            String errMsg = "Failed to get security information from Buyer";
            Log.encryption.error(errMsg);
            throw new SecurityInitializationException(errMsg, e);
        }
    }

    /**
     * Returns an encrypted helper instance for a given secretKey version.
     * 
     * @param version encryption version for which helper is needed
     * @return an encrypted helper instance for a given secretKey version.
     * @throws SecurityInitializationException, IOException
     */
    public static synchronized EncryptionHelper getEncryptionHelper (String version)
        throws SecurityInitializationException, IOException
    {
        EncryptionHelper helper = null;
        if (isConfigurationInvalid()) {
            // Try to initialize the helpers
            initializeEncryptionHelpers();
        }
        if (MapUtils.isNotEmpty(encryptionHelpers)) {
            helper = encryptionHelpers.get(version);
        }
        return helper;
    }

    public static synchronized String getCurrentEncryptVersion ()
        throws SecurityInitializationException, IOException
    {
        if (isConfigurationInvalid()) {
            // Try to initialize the helpers
            initializeEncryptionHelpers();
        }
        return currentVersion;
    }

    public static synchronized Set<String> getAllEncryptVersions ()
        throws SecurityInitializationException, IOException
    {
        if (isConfigurationInvalid()) {
            // Try to initialize the helpers
            initializeEncryptionHelpers();
        }
        return SetUtils.unmodifiableSet(encryptionHelpers.keySet());
    }

    private static boolean isBlankStringObject (Object obj)
    {
        if (obj instanceof String str) {
            return isBlankString(str);
        }
        return false;
    }
    
    private static boolean isBlankString (String str)
    {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if ((Character.isWhitespace(str.charAt(i)) == false)) {
                return false;
            }
        }
        return true;
    }
}
