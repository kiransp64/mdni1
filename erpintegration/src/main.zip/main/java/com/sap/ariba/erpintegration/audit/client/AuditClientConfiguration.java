package com.sap.ariba.erpintegration.audit.client;

import com.sap.ariba.audit.auditclient.api.AuditClientFactory;
import com.sap.ariba.audit.auditclient.api.AuditPropertyKey;
import com.sap.ariba.audit.auditclient.exception.AuditClientException;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

/**
 * This class is used to initialize the audit client configuration for auditing.
 */
@Configuration
@ConditionalOnProperty(
        name = "remote.auditService.enable", havingValue = "true"
)
public class AuditClientConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(AuditClientConfiguration.class);

    private static final String SERVICE_NAME = "MDNI";

    private static final String ESS_OAUTH_SCOPE = "eventstoreservice";

    @Value("${mdniOauthClientPrivateKey}")
    private String oAuthPrivateSecret;

    @Value("${mdniOauthClientPublicKey}")
    private String oAuthPublicSecret;

    @Value("${mdniOauthClientId}")
    private  String oAuthClientId;

    @Value("${authServerURI}")
    private String oAuthTokenUri;

    @Value("${authServerRefreshTokenURI}")
    private String oAuthRefreshTokenUri;

    @Value("${remote.auditService.serverUrl}")
    private String remoteAuditServerUrl;

    @Value("${server.proxy.isProduction}")
    private String isProxyProduction;

    @Value("${server.proxy.proxyHost}")
    private String proxyHost;

    @Value("${server.proxy.proxyPort}")
    private String proxyPort;

    @Value("${server.proxy.nonProxyHosts}")
    private String nonProxyHosts;

    @Value("${remote.auditService.essUrl}")
    private String essUrl;



    //Method to instantiate Audit client
    @PostConstruct
    public void instantiateAuditClientFactory()  {
        Properties auditClientProperties = new Properties();
        auditClientProperties.setProperty(AuditPropertyKey.AUDIT_PUBLISH_URL.getValue(), remoteAuditServerUrl);
        auditClientProperties.setProperty(AuditPropertyKey.NODE_NAME.getValue(), getHostName());
        auditClientProperties.setProperty(AuditPropertyKey.IPADDRESS.getValue(), getIpAddress());
        auditClientProperties.setProperty(AuditPropertyKey.SERVICE_NAME.getValue(), SERVICE_NAME);
        auditClientProperties.setProperty(AuditPropertyKey.OAUTH_URL.getValue(), oAuthTokenUri);
        auditClientProperties.setProperty(AuditPropertyKey.OAUTH_REFRESH_URL.getValue(), oAuthRefreshTokenUri);
        auditClientProperties.setProperty(AuditPropertyKey.OAUTH_ClIENT_ID.getValue(), oAuthClientId);
        auditClientProperties.setProperty(AuditPropertyKey.OAUTH_PRIVATE_SECRET.getValue(), oAuthPrivateSecret);
        auditClientProperties.setProperty(AuditPropertyKey.OAUTH_PUBLIC_SECRET.getValue(), oAuthPublicSecret);
        auditClientProperties.setProperty(AuditPropertyKey.HTTPS_PROXY_ISPRODUCTION.getValue(), isProxyProduction);
        auditClientProperties.setProperty(AuditPropertyKey.HTTP_NONPROXYHOSTS.getValue(), nonProxyHosts);
        auditClientProperties.setProperty(AuditPropertyKey.HTTPS_PROXYPORT.getValue(), proxyPort);
        auditClientProperties.setProperty(AuditPropertyKey.HTTPS_PROXYHOST.getValue(), proxyHost);
        //For common error handling
        auditClientProperties.setProperty(AuditPropertyKey.ENABLE_COMMON_ERROR_HANDLER.getValue(), String.valueOf(true));
        auditClientProperties.setProperty(AuditPropertyKey.ESS_URL.getValue(), essUrl);
        auditClientProperties.setProperty(AuditPropertyKey.ESS_OAUTH_SCOPE.getValue(), ESS_OAUTH_SCOPE);
        try {
            AuditClientFactory.initializeAuditService(auditClientProperties);
        } catch (AuditClientException e) {
            logger.error("Audit initialization failed", e);
            throw new RuntimeException(e);
        }

    }

    String getHostName ()
    {
        String hostName = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostName = addr.getHostName();
            logger.info("getHostName() hostname: {}", hostName);
        }
        catch (UnknownHostException e) {
            logger.error("UnknownHostException: {}", e.getMessage());
        }
        return hostName;
    }

    String getIpAddress ()
    {
        String ipAddress = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            ipAddress = addr.getHostAddress();
            logger.info("getIpAddress() IP address: {}", ipAddress);
        }
        catch (UnknownHostException e) {
            logger.error("UnknownHostException: {}", e.getMessage());
        }
        return ipAddress;
    }

}
