package com.sap.ariba.erpintegration.audit.client;

import com.sap.ariba.audit.auditclient.message.AuditLogMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class AuditClientLoggerAsync {

    public static Logger logger = LoggerFactory.getLogger(AuditClientLoggerAsync.class);

    @Autowired
    private AuditClientLogger auditClientLogger;

    /**This method is used to run the audit in asynchronous way
     * @param auditLogMessage
     * @param operationType
     * @param realmName
     */
    @Async
    public void pushAuditLogAsync(AuditLogMessage auditLogMessage, String operationType, String realmName) {
        try {
            auditClientLogger.pushAuditLog(auditLogMessage, operationType, realmName);
        } catch (Exception e) {
            logger.error("Failed to Audit, ", e);;
        }
    }

}
