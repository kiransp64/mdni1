package com.sap.ariba.erpintegration.oauthsdk;

import com.ariba.matrix.oauth.sdk.exception.ErrorResponse;
import com.ariba.matrix.oauth.sdk.exception.OauthSdkException;
import com.ariba.matrix.oauth.sdk.pojo.OauthTokenInfo;
import com.ariba.matrix.oauth.sdk.service.OauthTokenInfoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.web.filter.GenericFilterBean;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@WebFilter(urlPatterns="/main/encryptionmanagement/v1/*")
@ConditionalOnProperty(name = "reEncryption", havingValue="true")
@Deprecated
public class MDNIOAuthAuthorizationFilter extends GenericFilterBean
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.encryption.MDNIOAuthAuthorizationFilter";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);
    
    private static final String ENCRYPTIONMANAGER_SCOPE = "erpnativeintgsvc:encryptionmanagement";
    static final String AUTHORIZATION = "Authorization";
    static final String API_KEY = "apikey";
    private static List<String> allowedScopes = new ArrayList<String>() {
        {
            add(ENCRYPTIONMANAGER_SCOPE);
        }
    };


    @Override
    public void doFilter (ServletRequest request,
                          ServletResponse response,
                          FilterChain chain)
        throws IOException,
        ServletException
    {
        logger.info("inside filter");
        
        try {
            AuthorizationProperty oauthProperties = new AuthorizationProperty();
            logger.info("initialized oauth properties, properties are {}", oauthProperties.getFrontDoorUrl());
            OauthTokenInfoService.INSTANCE.loadConfig(oauthProperties);;
            HttpServletRequest httpServletReq = (HttpServletRequest)request;
            String accessToken = getAccessToken(httpServletReq);
            
            OauthTokenInfo tokenInfo = OauthTokenInfoService.INSTANCE.validateOauthToken(accessToken);  
            logger.info("validated token");
            validateScope(tokenInfo);
            logger.info("validated scope");
            chain.doFilter(request, response);
            
        } catch (OauthSdkException e) {
            logger.info("Exception {}", e.getMessage());
            sendErrorResponse(response, e);
        }
        catch (IllegalArgumentException e) {
            logger.info("Exception {}", e.getMessage());
            sendErrorResponse(response, e);
        }
        
    }
    private void validateScope(OauthTokenInfo tokenInfo) {
        String scopes = null;
        if(tokenInfo!=null && tokenInfo.getAttributes().getScope()!=null) {
            scopes = tokenInfo.getAttributes().getScope();
        }else {
            throw new IllegalArgumentException("Missing scopes");
        }  
        logger.info("scope is {}", scopes);
        
        if (scopes == null || !isAllowedScopeInToken(scopes, allowedScopes)) {
            logger.error(
                "OAuth Token does not have required scope(s) to access the API");
            throw new IllegalArgumentException("OAuth Token does not have required scope(s) to access the API");
        }
    }
    
    private String getAccessToken(HttpServletRequest httpServletRequest)
        throws IllegalArgumentException {
      String authorization = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION);
      if (StringUtils.isBlank(authorization)) {
        throw new IllegalArgumentException("Authorization header is missing");
      }

      if (!authorization.startsWith("Bearer ")) {
        throw new IllegalArgumentException("Bearer token is missing");
      }

      return authorization.split(" ")[1];
    }
    
    private boolean isAllowedScopeInToken (String scopes, List<String> allowedScopes)
    {
        long count = allowedScopes.stream().filter(allowedScope -> {
            String regex = "\\b" + allowedScope + "\\b";
            return Pattern.compile(regex).matcher(scopes).find();
        }).count();
        return count > 0;
    }
    
    private void sendErrorResponse (ServletResponse servletResp,
                                    OauthSdkException e)
        throws IOException
    {
        HttpServletResponse httpServletResponse = (HttpServletResponse)servletResp;
        httpServletResponse.setContentType("application/json");
        httpServletResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR_500);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setDescription(e.getMessage());
        errorResponse.setError(e.getError());
        String serialized = new ObjectMapper().writeValueAsString(errorResponse);
        httpServletResponse.getOutputStream().write(serialized.getBytes());
    }
    
    private void sendErrorResponse (ServletResponse servletResp,
                                    IllegalArgumentException e)
        throws IOException
    {
        HttpServletResponse httpServletResponse = (HttpServletResponse)servletResp;
        httpServletResponse.setContentType("application/json");
        httpServletResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR_500);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setDescription(e.getMessage());
        String serialized = new ObjectMapper().writeValueAsString(errorResponse);
        httpServletResponse.getOutputStream().write(serialized.getBytes());
    }

}
