package com.sap.ariba.erpintegration.persistence.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * This the POJO for ENTITY_VERSION_TAB
 * 
 * @author i339952
 */

@Entity
@Table(name = "ENTITY_VERSION_TAB")
@DiscriminatorValue("b")
public class EntityVersion implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String objectType = "EntityVersion";
    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "DATE_LAST_SENT")
    private Date dateLastSent;

    public String getId () { return id;}

    public void setId (String id) { this.id = id;}

    public Date getDateLastSent () { return dateLastSent;}

    public void setDateLastSent (Date dateLastSent) { this.dateLastSent = dateLastSent;}

    public static String getObjectType ()
    {
        return objectType;
    }

    @Override
    public String toString ()
    {
        return """
            EntityVersion{\
            id='\
            """ + id + '\'' +
            ", dateLastSent=" + dateLastSent +
            '}';
    }
    @Override public boolean equals (Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        EntityVersion that = (EntityVersion)o;
        return Objects.equals(id, that.id) &&
            Objects.equals(dateLastSent, that.dateLastSent);
    }

    @Override public int hashCode ()
    {
        return Objects.hash(id, dateLastSent);
    }
}
