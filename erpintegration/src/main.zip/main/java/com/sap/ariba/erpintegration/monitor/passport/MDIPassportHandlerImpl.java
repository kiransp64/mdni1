package com.sap.ariba.erpintegration.monitor.passport;

import com.sap.ariba.erpintegration.mdi.api.APIUtil;
import com.sap.ariba.erpintegration.monitor.exception.PassportDAOException;
import com.sap.ariba.erpintegration.monitor.exception.PassportException;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.util.IMConstants;
import com.sap.ariba.erpintegration.monitor.passport.core.persistance.Passport;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.IM_CRITICAL_PASSPORT;

@Component(value = "mdiPassportHandler")
@ConditionalOnExpression(IMConstants.INTEGRATION_MONITORING_ENABLE)
public class MDIPassportHandlerImpl extends PassportHandlerImpl
    implements MDIPassportHandler
{
    private static final Logger log = LoggerFactory.getLogger(
        MDIPassportHandlerImpl.class);

    @Override
    public Passport saveMDIPassport (long batchID,
                                     String objectName,
                                     String sapPassportToken,
                                     String deltaToken) throws PassportException
    {
        if (batchID > 0 && !StringUtils.isEmpty(objectName)) {
            try {
                Passport existingPassport = passportDAO.getPassportTokenByMDIBatchIDObject(
                    batchID, objectName);
                if (existingPassport != null) {
                    if (existingPassport.isMDI() && objectName.equals(
                        existingPassport.getMdiObjectName()) && batchID == Long.parseLong(
                        existingPassport.getJobId()))
                    {
                        log.error("Cannot save passport for MDI batch - {} and object name - {} , as there is already an entry.",
                                  batchID,
                                  APIUtil.sanitizeInput(objectName));
                        throw new PassportException(
                            "Cannot save passport for MDI batch - " + batchID
                                + " and object name - " + objectName
                                + ", as there is already an entry.");
                    }
                }
                if (StringUtils.isNotEmpty(sapPassportToken)) {
                    Passport passport = new Passport(Long.toString(batchID),
                                                     sapPassportToken);
                    passport.setMDI(true);
                    passport.setMdiObjectName(objectName);
                    if(!StringUtils.isEmpty(deltaToken)){
                        passport.setMdiDeltaToken(deltaToken);
                    }
                    passportDAO.savePassportToken(passport);
                    return passport;
                }
            }
            catch (PassportDAOException e) {
                log.error(
                    "{} while trying to save passport for MDI Batch - {} and Object - {}",
                    ErrorUtil.getCompleteCausedByErrors(e), batchID, APIUtil.sanitizeInput(objectName));
                throw new PassportException(
                    "Error while trying to save passport for MDI batch - " + batchID
                        + " and object - " + objectName, e);
            }
        }
        return null;
    }

    @Override
    public Passport getMDIPassport (long batchID, String objectName)
    throws PassportException
    {
        if (batchID > 0 && !StringUtils.isEmpty(objectName)) {
            try {
                return passportDAO.getPassportTokenByMDIBatchIDObject(batchID,
                                                                      objectName);
            }
            catch (PassportDAOException e) {
                log.error(
                    "{} while trying to get MDI passport for batch id - {} and object - {}",
                    ErrorUtil.getCompleteCausedByErrors(e), batchID, APIUtil.sanitizeInput(objectName));
                throw new PassportException(
                    "Error while trying to get MDI passport for batch id - " + batchID
                        + " and object - " + objectName, e);
            }
        }
        return null;
    }

    @Override
    public Passport getWithInitialiseMDIPassport (String tenantID,
                                                  long batchID,
                                                  String objectName,
                                                  String deltaToken)
    throws PassportException
    {
        Passport passport = getMDIPassport(batchID, objectName);
        if (passport == null) {
            IntegrationContext integrationContext = new IntegrationContext();
            integrationContext.setSystem(IMConstants.MDNI);
            integrationContext.setPrevSystemId(IMConstants.MDI);
            String token = createInitialPassport(integrationContext);
            passport = saveMDIPassport(batchID, objectName, token, deltaToken);
        }
        return passport;
    }

    @Override
    public void deletePassportTokenBasedOnBatchIDObjectName (long batchID,
                                                             String objectName)
    throws PassportException
    {
        try {
            if (batchID > 0 && !StringUtils.isEmpty(objectName)) {
                //fetch sap passport taken for batch id and object name
                Passport passport = passportDAO.getPassportTokenByMDIBatchIDObject(
                    batchID, objectName);
                if (ObjectUtils.isNotEmpty(passport)) {
                    passportDAO.deletePassportEntry(passport);
                }
            }
        }
        catch (PassportDAOException e) {
            log.error(
                "{} , Batch ID - {} , Object Name - {}, Exception - {} while deleting sap passport token info from DB.",
                IM_CRITICAL_PASSPORT, batchID, APIUtil.sanitizeInput(objectName),
                ErrorUtil.getCompleteCausedByErrors(e));
            throw new PassportException(
                "Error while deleting sap passport token entry info for particular batch id - "
                    + batchID + ", and object name - " + objectName, e);
        }
    }

    @Override
    public boolean saveMDIPassportWithSourceEventID (long batchID,
                                                     String objectName,
                                                     String sourceEventID)
    throws PassportException
    {
        try {
            Passport passport = getMDIPassport(batchID, objectName);
            if (passport != null && StringUtils.isNotEmpty(sourceEventID)) {
                String existingSourceEventID = passport.getSourceEventId();
                if (StringUtils.isEmpty(existingSourceEventID)) {
                    passport.setSourceEventId(sourceEventID);
                    passportDAO.savePassportToken(passport);
                    return true;
                }
            }
        }
        catch (Exception e) {
            log.error(
                "{} {} while trying to save source event id with passport of batch ID - {} and Object Name - {}.",
                IM_CRITICAL_PASSPORT, ErrorUtil.getCompleteCausedByErrors(e), batchID,
                    APIUtil.sanitizeInput(objectName));
        }
        return false;
    }
}
