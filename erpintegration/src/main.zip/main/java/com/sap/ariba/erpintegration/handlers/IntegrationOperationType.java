package com.sap.ariba.erpintegration.handlers;

/**
 * Created by i318483 on 29/05/17.
 */
public enum IntegrationOperationType {
    FULLLOAD(1, "Full Load"),
    INCREMENTALLOAD(2,"Incremental Load");

    private final int value;

    private IntegrationOperationType (int value, String desc)
    {
        this.value = value;
        this.description = desc;
    }

    public int getValue ()
    {
        return this.value;
    }

    private final String description;

    public String getDescription ()
    {
        return this.description;
    }

    public static String getOperationTypeDescription (int opType)
    {
        String opDesc = "";
        for (IntegrationOperationType op : IntegrationOperationType.values()) {
            if (op.getValue() == opType) {
                opDesc = op.getDescription();
                break;
            }
        }
        return opDesc;
    }
}
