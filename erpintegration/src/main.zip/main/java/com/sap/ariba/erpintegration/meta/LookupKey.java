package com.sap.ariba.erpintegration.meta;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlValue;

/**
 * Created by i318483 on 07/06/17.
 */
public class LookupKey
{
    private String lookupKey;
    private String externalLookupKey;

    @XmlAttribute
    public String getExternalLookupKey() {
        return externalLookupKey;
    }

    public void setExternalLookupKey(String externalLookupKey) {
        this.externalLookupKey = externalLookupKey;
    }

    @XmlValue
    public String getLookupKey ()
    {
        return lookupKey;
    }

    public void setLookupKey (String lookupKey)
    {
        this.lookupKey = lookupKey;
    }
}
