package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.audit.AuditManagerImpl;
import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.common.metrics.MDNIMetrics;
import com.sap.ariba.erpintegration.common.metrics.MDNIServiceRegistry;
import com.sap.ariba.erpintegration.encryption.EncryptionUtil;
import com.sap.ariba.erpintegration.encryption.MDNIEncryptionService;
import com.sap.ariba.erpintegration.encryption.SecurityInitializationException;
import com.sap.ariba.erpintegration.monitor.exception.IntegrationMonitoringException;
import com.sap.ariba.erpintegration.monitor.im.helper.IMHelper;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.handler.MonitoringEventHandler;
import com.sap.ariba.erpintegration.monitor.im.util.IntegrationContextBuilder;
import com.sap.ariba.erpintegration.monitor.passport.PassportHandler;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.dao.SenderBusinessSystemRepository;
import com.sap.ariba.erpintegration.persistence.model.SenderBusinessSystem;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.service.BaseIdService;
import com.sap.ariba.erpintegration.persistence.service.BaseIdServiceImpl;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;
import com.sap.ariba.erpintegration.persistence.util.EncryptKey;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.security.WSMessageSignatureService;
import com.sap.ariba.erpintegration.service.exception.AuditFailedException;
import com.sap.ariba.erpintegration.service.exception.IntegrationPayloadProcessorException;
import com.sap.ariba.erpintegration.service.exception.XMLPayloadHandlerException;
import com.sap.ariba.erpintegration.storage.CloudStorageFactory;
import com.sap.ariba.erpintegration.util.ActionCodeTagValueHandler;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.erpintegration.util.IntegrationJobLogUtil;
import com.sap.ariba.erpintegration.util.XMLUtil;
import com.sap.ariba.erpintegration.util.cap.JWTUtil;
import com.sap.ariba.erpintegration.util.BeanUtil;
import com.sap.ariba.erpintegration.validation.ValidationSkipEntities;
import com.sap.ariba.security.encryption.prefix.PrefixType;
import com.sap.ariba.security.encryption.prefix.StreamDecryptInfo;
import com.thaiopensource.xml.sax.ErrorHandlerImpl;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.jaxws.handler.logical.LogicalMessageContextImpl;
import org.eclipse.jetty.io.WriterOutputStream;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.util.StringUtils;
import org.xml.sax.SAXException;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import jakarta.xml.ws.LogicalMessage;
import jakarta.xml.ws.handler.LogicalHandler;
import jakarta.xml.ws.handler.MessageContext;
import javax.xml.xpath.XPathExpressionException;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INBOUND_FAILURE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INBOUND_IN_PROCESS;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI_IM_CRITICAL_INBOUND;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI_IM_INTEGRATION;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI_IM_INTEGRATION_INBOUND;
import static com.sap.ariba.erpintegration.monitor.im.util.IMEvents.UPLOAD_XML;

/**
 * Created by i318483 on 03/05/17.
 */
public class XMLPayloadHandler
        implements LogicalHandler<LogicalMessageContextImpl> {
    private final String KeyisCigSource = "cigSource";
    private static final String NOT_A_VALID_XML_STR = "Not a Valid XML : ";
    private final String IS_INCREMENTAL_LOAD = "isIncrementalLoad";

    private static final Logger logger = LoggerFactory.getLogger(XMLPayloadHandler.class);
    private static final Set<String> EncryptableObjects = new HashSet<>();
    private final String ActionCodeTag = "ActionCode";

    @Value("${basePath:/tmp/nfs}")
    private String BASE_PATH;
  
    @Autowired
    WSMessageSignatureService signatureService;

    private MDNIServiceRegistry mdniServiceRegistry = null;

    public void setAuditClientDataService(AuditClientDataService auditClientDataService) {
        this.auditClientDataService = auditClientDataService;
    }

    @Autowired
    AuditClientDataService auditClientDataService;
    
    @Autowired(required = false)
    MDNIEncryptionService encryptionService;

    @Autowired(required = false)
    private CloudStorageFactory cloudStorageFactory;
    
    @Value("${kmsEnabled}")
    private Boolean kmsEnabled;
    
    @Value("${kmsEncryptedPath}")
    private String kmsBasePath;

    @Value("${integration.monitoring.enabled}")
    private Boolean isIMEnabled;

    @Lazy
    @Autowired
    @Qualifier("passportHandler")
    private PassportHandler passportHandler;

    @Lazy
    @Autowired
    @Qualifier("xmlPayloadMonitoringEventHandler")
    private MonitoringEventHandler monitoringEventHandler;


    static {
        // Add 'User' object to encryptable objects list
        EncryptableObjects.add("User");
    }

    private boolean auditEnabled = Boolean.TRUE;

    @Override
    public boolean handleMessage (LogicalMessageContextImpl context)
    {
        HashMap<String, String> parameterMap = generateParametersMap(context);
        return processMessage(
            context,
            parameterMap.get(Constants.KeyTenantId),
            parameterMap.get(Constants.KeyObjectName),
            parameterMap.get(Constants.KeySenderBusinessSystemId),
            Boolean.parseBoolean(parameterMap.get(KeyisCigSource)),
            Boolean.parseBoolean(parameterMap.get(IS_INCREMENTAL_LOAD)));
    }

    @Override
    public boolean handleFault (LogicalMessageContextImpl context)
    {
        HashMap<String, String> parameterMap = generateParametersMap(context);
        return processMessage(
            context,
            parameterMap.get(Constants.KeyTenantId),
            parameterMap.get(Constants.KeyObjectName),
            parameterMap.get(Constants.KeySenderBusinessSystemId),
            Boolean.parseBoolean(parameterMap.get(IS_INCREMENTAL_LOAD)));
    }

    private HashMap<String, String> generateParametersMap (LogicalMessageContextImpl context)
    {
        HashMap<String, String> parameterMap = new HashMap<String, String>();
        HttpServletRequest request = (HttpServletRequest) context.get("HTTP.REQUEST");
        Map<String, List<String>> header = (Map<String, List<String>>) context.get(MessageContext.HTTP_REQUEST_HEADERS);
        String anId = "";
        String objectName = "";
        String senderBusinessSystemID = "";
        String isCigSourceString = "";
        String isIncrementalLoad = "false";

        if (request.getParameter(Constants.KeyTenantId) != null) {
            Map<String, String[]> requestParameterMap = request.getParameterMap();
            /*Previous requestParam for senderBusinessSystemId is 'senderBusinessSystemID',
             * but for other API it is ''senderBusinessSystemId'.
             * To have backward compatibility, using LinkedCaseInsensitiveMap.
             */
            LinkedCaseInsensitiveMap<String[]> caseInsensitiveParameterMap = new LinkedCaseInsensitiveMap<>();
            caseInsensitiveParameterMap.putAll(requestParameterMap);
            anId = request.getParameter(Constants.KeyTenantId);
            objectName = request.getParameter(Constants.KeyObjectName);
            isCigSourceString = request.getParameter(KeyisCigSource);
            String[] senderBuisnessValue = caseInsensitiveParameterMap.get(
                Constants.KeySenderBusinessSystemId);
            if (senderBuisnessValue != null && senderBuisnessValue.length > 0) {
                senderBusinessSystemID = senderBuisnessValue[0];
            }
            else {
                senderBusinessSystemID = null;
            }
            isIncrementalLoad = request.getParameter(IS_INCREMENTAL_LOAD);
        }
        else {
            anId = fetchRequestHeaderValue(header, Constants.KeyTenantId);
            objectName = fetchRequestHeaderValue(header, Constants.KeyObjectName);
            senderBusinessSystemID = fetchRequestHeaderValue(header, Constants.KeySenderBusinessSystemId);
            isCigSourceString = fetchRequestHeaderValue(header, KeyisCigSource);
            isIncrementalLoad = fetchRequestHeaderValue(header, IS_INCREMENTAL_LOAD);
        }
        //If anId is not present in both header and request for an MDCS request,
        //we need to retrieve it from JWT
        if(anId.equalsIgnoreCase("") && HandlerUtil.isMDCS()){
            String authorizationToken = HandlerUtil.getTokenFromBearer(fetchRequestHeaderValue(header, Constants.Authorization));
            if (JWTUtil.isJWT(authorizationToken)) {
                //get the zone id as it's anId in case of MDCS
                anId = JWTUtil.getZoneId(authorizationToken);
                logger.info("[MDCS] Zone Id/ anId : {}", anId);
            }
            if(anId != null){
                Map<String, String[]> requestParameterMap = request.getParameterMap();
                LinkedCaseInsensitiveMap<String[]> caseInsensitiveParameterMap = new LinkedCaseInsensitiveMap<>();
                caseInsensitiveParameterMap.putAll(requestParameterMap);
                if(objectName.equalsIgnoreCase("")){
                    objectName = request.getParameter(Constants.KeyObjectName);
                }
                if(isCigSourceString.equalsIgnoreCase("")){
                    isCigSourceString = request.getParameter(KeyisCigSource);
                }
                if(senderBusinessSystemID!=null && senderBusinessSystemID.equalsIgnoreCase("")) {
                    String[] senderBuisnessValue = caseInsensitiveParameterMap.get(
                            Constants.KeySenderBusinessSystemId);
                    if (senderBuisnessValue != null && senderBuisnessValue.length > 0) {
                        senderBusinessSystemID = senderBuisnessValue[0];
                    } else {
                        senderBusinessSystemID = null;
                    }
                }

            }
        }
        parameterMap.put(Constants.KeyTenantId, anId);
        parameterMap.put(Constants.KeyObjectName, objectName);
        parameterMap.put(Constants.KeySenderBusinessSystemId, senderBusinessSystemID);
        parameterMap.put(KeyisCigSource, isCigSourceString);
        parameterMap.put(IS_INCREMENTAL_LOAD, isIncrementalLoad);
        return parameterMap;
    }

    /**
     * @param header HTTP Request Header
     * @param key - the key of which value has to be returned if present
     * @return return the first value from the list (not sure if list size can be greater than 1)
     */
    private String fetchRequestHeaderValue (Map<String, List<String>> header, String key)
    {
        List<String> valueList = header.get(key);
        if (key.equalsIgnoreCase(Constants.KeySenderBusinessSystemId)
            && !key.equals(Constants.KeySenderBusinessSystemId)) {
            LinkedCaseInsensitiveMap<List<String>> caseInsensitiveParameterMap = new LinkedCaseInsensitiveMap<>();
            caseInsensitiveParameterMap.putAll(header);
            valueList = caseInsensitiveParameterMap.get(Constants.KeySenderBusinessSystemId);
        }
        String value = "";
        if (valueList != null && valueList.size() > 0) {
            value = valueList.get(0);
        }
        return value;
    }

    @Override
    public void close(MessageContext context) {
        //
    }


    /**
     * Get the xmlPayload from LogicalMessageContextImpl object
     * Persist the xmlPayload to the FileSystem and validate against the corresponding rng file
     * If Validation passes make an entry in STAGEXMLDATATAB Table with the path to the xmlPayload File
     * If Validation fails throw an exception.
     *
     * @param context    -
     * @param anId       - anId passed in the request
     * @param objectName - uniqely identifies the object.
     * @return
     */
    private boolean processMessage (LogicalMessageContextImpl context,
                                    String anId,
                                    String objectName,
                                    String senderBusinessSystemID,
                                    boolean isIncrementalLoad)
    {
       return  processMessage(context, anId, objectName,senderBusinessSystemID,false, isIncrementalLoad);
    }

    /**
     * Overriding processMessage to take care of cigSource parameter
     *
     * @param context    -
     * @param anId       - anId passed in the request
     * @param objectName - uniqely identifies the object.
     * @pram isCigSource - if the request originates from CIG
     * @return
     */
    private boolean processMessage(LogicalMessageContextImpl context, String anId, String objectName, String senderBusinessSystemID, boolean isCigSource, boolean isIncrementalLoad) {
        String xmlPayload = null;
        Boolean outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        String response = "";
        StringWriter sw = new StringWriter();
        WriterOutputStream wo = null;
        ErrorHandlerImpl eh = null;
        long tenantId = -1;
        String savedFilePath = null;
        String baseId = null;
        HttpServletResponse httpServletResponse;
        int operationUsed = 0;
        try {
            logger.info(
                "[Native_Integration][XML][Request_Process] Processing for tenant - {}, object - {}, sender business system - {}, from CIG - {} and parameters - {}",
                anId, objectName, senderBusinessSystemID, isCigSource);
            if (!outboundProperty) {
                LogicalMessage message = context.getMessage();
                Source payload = message.getPayload();
                xmlPayload = getXMLPayload(payload);
                if (xmlPayload != null) {
                    HttpServletRequest request = (HttpServletRequest) context.get(
                            "HTTP.REQUEST");
                    if (anId == null || objectName == null) {
                        throw new Fault(new Throwable("Not a valid incoming request. Either TenantId or objectName is Missing"));
                    }
                    if (!Utility.isTenantActive(anId)) {
                        throw new Fault(new Throwable(
                            "Not a valid incoming request. Either tenant is inactive or not recognized"));
                    }

                    tenantId = Utility.getTenantId(anId);
                    if (auditEnabled) {
                        AuditManagerImpl.getInstance().logAudit(
                                anId,
                                Operation.DATA_UPLOAD,
                                "upload xml started for tenantId:" + tenantId + ",objectName:" + objectName +
                                        ",senderBusinessSystemID:" + senderBusinessSystemID);
                    }
                    wo = new WriterOutputStream(sw, StandardCharsets.UTF_8.name());
                    eh = new ErrorHandlerImpl(wo);

                    Boolean isEncryptable = false;
                    String encryptionVersion = null;
                    String UUID = null;
                    if(!HandlerUtil.isAdvancedStorageOptionEnabled()) {
                        isEncryptable = isEncryptableObject(objectName);
                        encryptionVersion = getEncryptionVersion(objectName);
                        // write file to file system
                        savedFilePath = this.writeFileToFileSystem(
                                xmlPayload,
                                anId,
                                objectName,
                                tenantId,
                                senderBusinessSystemID,
                                isEncryptable,
                                encryptionVersion);

                        logger.info("savedFilePath : {}", savedFilePath);
                        UUID = getValueOfTag(savedFilePath, "UUID", isEncryptable, encryptionVersion);
                        if (logger.isDebugEnabled())
                            logger.debug("UUID : {}", UUID);

                        operationUsed = getOperationType(savedFilePath, tenantId,
                                                         objectName, isEncryptable,
                                                         encryptionVersion,
                                                         isIncrementalLoad);
                        if (logger.isDebugEnabled())
                            logger.debug("operationUsed : {}", operationUsed);

                        if (UUID != null) {
                            // rename the file prefixing the UUID
                            savedFilePath = this.renameFile(anId, objectName, senderBusinessSystemID, UUID, savedFilePath, isEncryptable, encryptionVersion);
                        }
                        if (logger.isInfoEnabled())
                            logger.info("File saved to path {}", savedFilePath);
                    }else{
                        operationUsed = getOperationType(xmlPayload, objectName, isIncrementalLoad);
                    }

                    if (!ValidationSkipEntities.contains(objectName)) {
                        if (!validateIncomingXMLPayload(
                            xmlPayload,
                            eh,
                            anId,
                            objectName,
                            senderBusinessSystemID))
                        {
                            byte[] xmlPayloadBytes = XMLUtil.searchAndReplace(xmlPayload.getBytes(
                                            StandardCharsets.UTF_8.name()));
                            String replacedXmlPayload = new String(xmlPayloadBytes);

                            sw = new StringWriter();
                            wo = new WriterOutputStream(sw, StandardCharsets.UTF_8.name());
                            eh = new ErrorHandlerImpl(wo);
                            if (!validateIncomingXMLPayload(
                                replacedXmlPayload,
                                eh,
                                anId,
                                objectName, senderBusinessSystemID))
                            {
                                logger.info(NOT_A_VALID_XML_STR , " " , sw.toString());
                                response = NOT_A_VALID_XML_STR + "Check the payload.";
                                if(!HandlerUtil.isAdvancedStorageOptionEnabled()) {
                                    File f = new File(savedFilePath);
                                    if (f.exists()) {
                                        try {
                                            boolean fileDeleted = f.delete();
                                            if (!fileDeleted) {
                                                throw new Exception("Cannot delete file");
                                            }
                                        } catch (Exception e) {
                                            logger.error(
                                                    "Exception occured when deleting file {}",
                                                    e.getMessage(), e);
                                        }
                                    }
                                }
                                auditProcessXmlData(objectName, tenantId, operationUsed, response, senderBusinessSystemID, false);
                                throw new Fault(new Throwable(response));
                            }
                        }
                    }
                    else {
                        logger.info(
                            "Skipping RNG based payload validation for '{} ({})' entity",
                            ValidationSkipEntities.getMDSEntityName(objectName),
                            objectName);
                    }

                    if (HandlerUtil.isAdvancedStorageOptionEnabled()) {
                        UUID = this.getValueOfTag(xmlPayload, "UUID");
                        senderBusinessSystemID = this.getValueOfTag(xmlPayload, "SenderBusinessSystemID");
                        String uuidForFileName = "";
                        if (UUID != null) {
                            uuidForFileName = HandlerUtil.replaceForwardSlashFromUUIDForFileName(UUID);
                        }
                        savedFilePath = HandlerUtil.constructCloudStorageObjectName(anId,objectName,
                                senderBusinessSystemID, uuidForFileName);
                        logger.info("MDI File Object : {}", savedFilePath);
                        cloudStorageFactory.getCloudStorage().put(savedFilePath,xmlPayload);
                    }

                    String creationDate = null;
                    if(HandlerUtil.isAdvancedStorageOptionEnabled()) {
                        // get the creationDate
                        creationDate = this.getValueOfTag(xmlPayload, "CreationDateTime");
                        logger.info("CreationDateTime from message header : {}", creationDate);
                    }else{
                        creationDate = getValueOfTag(savedFilePath, "CreationDateTime", isEncryptable,
                                encryptionVersion);
                        logger.info("CreationDateTime from message header : {}", creationDate);
                    }

                    Timestamp sourceCreationTimeStamp = null;
                    if (!StringUtils.isEmpty(creationDate)) {
                        sourceCreationTimeStamp = convertToDateObject(creationDate);
                    }

                    baseId = persistXMLPayload(
                        savedFilePath,
                        objectName,
                        tenantId,
                        UUID,
                        operationUsed,
                        senderBusinessSystemID,
                        sourceCreationTimeStamp,
                        isEncryptable,
                        encryptionVersion);
                    httpServletResponse = (HttpServletResponse) context.get("HTTP.RESPONSE");

                    String responseStr = "";
                    if (isCigSource) { //CIG expects the response to be in Soap format.
                        responseStr = buildSoapResponse(baseId);
                    }
                    else {
                        responseStr = "JobId " + baseId;
                    }
					logger.info("Calling getWriter() on http response");

					ServletOutputStream out = httpServletResponse.getOutputStream();
					out.write(responseStr.getBytes());
					out.flush();
					out.close();

					logger.info("Output Written to response");
					
                    if (auditEnabled) {
                        AuditManagerImpl.getInstance().logAudit(
                                anId,
                                Operation.DATA_UPLOAD,
                                "upload xml ended for tenantId:" + tenantId + ",objectName:" + objectName +
                                        ",senderBusinessSystemID:" + senderBusinessSystemID);
                    }
                    processIMMonitoring(anId,
                                        objectName,
                                        baseId,
                                        senderBusinessSystemID,
                                        false,
                                        "",INBOUND_IN_PROCESS);

                    Response.status(HttpServletResponse.SC_OK).entity(
                            "Valid XML").build();
                }
            }
        }
        catch (XMLPayloadHandlerException | IOException | ParserConfigurationException
               | SAXException | IntegrationPayloadProcessorException ex) {
            logger.error("[MDNI_CRITICAL][ARIBA][Processing] Tenant ID - {}, Object Name - {} Exception {} while processing xml payload ",
                         anId,
                         objectName,
                         ErrorUtil.getCompleteCausedByErrors(ex));
            if(mdniServiceRegistry == null) {
                mdniServiceRegistry = BeanUtil.getMdniServiceRegistry();
            }
            if(mdniServiceRegistry != null) {
                mdniServiceRegistry.sendMetricsForCounter(MDNIMetrics.CIG_REQUEST_ERROR);
            }

            if(!HandlerUtil.isAdvancedStorageOptionEnabled()) {
                File f = new File(savedFilePath);
                if (f.exists()) {
                    try {
                        boolean fileDeleted = f.delete();
                        if (!fileDeleted) {
                            throw new Exception("Cannot delete file");
                        }
                    } catch (Exception e) {
                        logger.error(
                                "Security Exception occured when deleting file {}",
                                e.getMessage(), e);
                    }
                }
            }

                if (auditEnabled) {
                    AuditManagerImpl.getInstance().logAudit(
                            anId,
                            Operation.DATA_UPLOAD,
                            "upload xml started for tenantId:" + tenantId + ",objectName:" + objectName +
                                    ",senderBusinessSystemID:" + senderBusinessSystemID + " with Exception: " + ex.getMessage());
                }
                processIMMonitoring(anId,
                                    objectName,
                                    baseId,
                                    senderBusinessSystemID,
                                    true,
                                    ex.getMessage(),INBOUND_FAILURE);


                auditProcessXmlData(objectName, tenantId, operationUsed, ex.getMessage(), senderBusinessSystemID, false);
                throw new Fault(new Throwable(ex.getMessage()));
            }
        catch (Exception e)
        {
            logger.error("[MDNI_CRITICAL][ARIBA][Processing] Tenant ID - {}, Object Name - {} Exception {} while processing xml payload ",
                         anId,
                         objectName,
                         ErrorUtil.getCompleteCausedByErrors(e));
            if(mdniServiceRegistry == null) {
                mdniServiceRegistry = BeanUtil.getMdniServiceRegistry();
            }
            if(mdniServiceRegistry != null) {
                mdniServiceRegistry.sendMetricsForCounter(MDNIMetrics.CIG_REQUEST_ERROR);
            }
            processIMMonitoring(anId,
                                objectName,
                                baseId,
                                senderBusinessSystemID,
                                true,
                                e.getMessage(),INBOUND_FAILURE);


            auditProcessXmlData(objectName, tenantId, operationUsed, e.getMessage(), senderBusinessSystemID,false);
        	throw new Fault(new Throwable(e.getMessage()));
        }
		logger.info("processMessage Ended");
        return true;
    }

    /**
     * This method will process and log Inbound event for XML-Payload API
     *
     * @param tenantId
     * @param objectName
     * @param jobID
     * @param senderBusinessSystemId
     * @param isError
     * @param errorMessage
     */
    private void processIMMonitoring (String tenantId,
                                      String objectName,
                                      String jobID,
                                      String senderBusinessSystemId,
                                      boolean isError,
                                      String errorMessage,
                                      String direction)
    {
        //if im enable feature toggle is off and passport is not available in thread context then will not process IM event.
        if (!isIMEnabled
                        || BooleanUtils.isFalse(IMHelper.isPassportAvailableAsPartOfCurrentRequestThread())) {
            logger.info("{} ,IM monitoring will NOT process as Feature toggle for IM is off or SAP-Passport is not available,  Tenant ID - {}, Object Name - {} , Job Id - {} ,Error Status - {}",
                        MDNI_IM_INTEGRATION,
                        tenantId,
                        objectName,
                        jobID,
                        isError);
            return;
        }
        logger.info("{} ,processing IM monitoring event for XML-Payload API for InBound flow Tenant ID - {}, Object Name - {} , Job Id - {} ,Error Status - {}",
                    MDNI_IM_INTEGRATION_INBOUND,
                    tenantId,
                    objectName,
                    jobID,
                    isError);
        IntegrationContext integrationContext;
        integrationContext = IntegrationContextBuilder.builder().withTenantID(tenantId).withObjectName(objectName).withJobID(jobID)
                         .withEventName(UPLOAD_XML).withError(isError).withErrorMessage(errorMessage)
                        .withSenderBusinessSystemId(senderBusinessSystemId).withDirection(direction).build();
        try {
            //will log the inbound error or in_process event to
            monitoringEventHandler.logInboundEvent(integrationContext);
        }
        catch (IntegrationMonitoringException ime) {
            logger.error("{} ,Exception - {}, while sending INBOUND IM Event for XMLPayLoadHandler for Job ID - {} , Tenant ID - {} , Object Name - {}",
                         MDNI_IM_CRITICAL_INBOUND,
                         ErrorUtil.getCompleteCausedByErrors(ime),
                         jobID,
                         tenantId,
                         objectName);
        }
    }

    /**
     * get the actionCode tag value 
     * at top level in the payload
     * cannot use getValueOfTag method as
     * it get the value based on the tag name
     * and we cant rely on it due to presence of 
     * ActionCode tag in descendants of root node
     * @param savedFilePath
     * @param tagName
     * @param encryptionVersion
     * @return
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws XPathExpressionException
     */
    public String getActionCodeTagValue(String savedFilePath, String tagName, Boolean isEncryptable, String encryptionVersion)
        throws ParserConfigurationException, SAXException, IOException, XPathExpressionException
    {
        String actionCodeValue = null;
        String encryptedFilePath = savedFilePath;
        SAXParserFactory factory = SAXParserFactory.newInstance();
        String SECURE_PROCESSING_PARSER = "http://javax.xml.XMLConstants/feature/secure-processing";
		factory.setFeature(SECURE_PROCESSING_PARSER, true);
        SAXParser saxParser = factory.newSAXParser();
        ActionCodeTagValueHandler tagValueHangler = new ActionCodeTagValueHandler(ActionCodeTag);
        if (isEncryptable) {
            if (kmsEnabled) {
		        final InputStream pipedDecrInput = decryptFileAndUnzip(savedFilePath);
	            saxParser.parse(pipedDecrInput, tagValueHangler);
	            pipedDecrInput.close();
            }
            else {
                //system encryptionVerison decrypt
		        InputStream encryptedInputStream = new FileInputStream(
                    new File(encryptedFilePath));
                                final PipedInputStream pipedDecrInput = new PipedInputStream();
	            final PipedOutputStream pipedDecrOutput = new PipedOutputStream(pipedDecrInput);
	            new Thread(new Runnable() {
	                public void run() {
                            try {
	                        EncryptionUtil.decrypt(encryptedInputStream, pipedDecrOutput,
                                                       EncryptionUtil.getCurrentEncryptVersion());
	                    } catch (SecurityInitializationException | GeneralSecurityException | IOException e) {
	                        logger.error("Exception while decrypting {} : {}", encryptedFilePath, e);
                            }
                        }
                    }).start();
	            saxParser.parse(pipedDecrInput, tagValueHangler);
            }
		} else {
			saxParser.parse(savedFilePath, tagValueHangler);
        }

        actionCodeValue = tagValueHangler.getTagValue();
        return actionCodeValue;
    }

    private String getValueOfTag (String xmlPayload, String tagName) throws IOException, SAXException, ParserConfigurationException {
        InputStream xmlInputStream = new ByteArrayInputStream(xmlPayload.getBytes());
        return XMLUtil.getValueOfTag(xmlInputStream, tagName);
    }

    private String getValueOfTag (String savedFilePath, String tagName, Boolean isEncryptable, String encryptionVersion)
        throws FileNotFoundException,
        IOException,
        ParserConfigurationException,
        SAXException
    {
        String retval = null;
        if (isEncryptable) {
            if (kmsEnabled) {
                //kms system decryption
                InputStream pipedDecrInput = decryptFileAndUnzip(savedFilePath);
                retval = XMLUtil.getValueOfTag(pipedDecrInput, tagName);
                pipedDecrInput.close();
            }
            else {
                //regular system decryption
                logger.info("buyer decrypt");
                final String encryptedFilePath = savedFilePath;
                final InputStream encryptedInputStream = new FileInputStream(new File(encryptedFilePath));
                                final PipedInputStream pipedDecrInput = new PipedInputStream();
                final PipedOutputStream pipedDecrOutput = new PipedOutputStream(pipedDecrInput);
                new Thread(new Runnable() {
                        public void run ()
                        {
                            try {
                            EncryptionUtil.decrypt(
                                encryptedInputStream,
                                                       pipedDecrOutput,
                                                       EncryptionUtil.getCurrentEncryptVersion());
                            }
                        catch (SecurityInitializationException
                            | GeneralSecurityException | IOException e)
                        {
                            logger.error("Exception while decrypting {} : {}", encryptedFilePath, e);
                            }
                        }
                    }).start();
                retval = XMLUtil.getValueOfTag(pipedDecrInput, tagName);
            }    
        }
        else {
            retval = XMLUtil.getValueOfTag(savedFilePath, tagName);
        }
        return retval;
    }

    protected String getEncryptionVersion (String objectName)
    {
        String encrVersion = null;
        
        if(kmsEnabled) return encrVersion;

        if (!HandlerUtil.isMDCS()) {
            String errorMsg = "";
            try {
                encrVersion = EncryptionUtil.getCurrentEncryptVersion();
                if (StringUtils.isEmpty(encrVersion)) {
                    errorMsg = "Error occurred while getting encryption version ";
                    throw new SecurityInitializationException(errorMsg);
                }
            }
            catch (SecurityInitializationException | IOException e) {
                logger.error(errorMsg, e);
                throw new Fault(e);
            }
        }
        return encrVersion;
    }

    protected String persistXMLPayload (String savedFilePath,
        String objectName,
        long tenantId,
        String UUID,
        int opreationType,
        String senderBusinessSystemID,
        Timestamp sourceCreationTimeStamp,
        Boolean isEncryptable,
        String encryptionVersion)
    {
        return persistXMLPayload(
            savedFilePath,
            objectName,
            tenantId,
            UUID,
            opreationType,
            senderBusinessSystemID,
            sourceCreationTimeStamp,
            isEncryptable,
            encryptionVersion,
            false);
    }
    /**
     *
     * @param savedFilePath
     * @param objectName
     * @param tenantId
     * @param UUID
     * @paramsenderBusinessSystemID
     * @param sourceCreationTimeStamp
     * @param encryptionVersion
     */
    protected String persistXMLPayload (String savedFilePath,
                                    String objectName,
                                    long tenantId,
                                    String UUID,
                                    int opreationType,
                                    String senderBusinessSystemID,
                                    Timestamp sourceCreationTimeStamp,
                                    Boolean isEncryptable,
                                    String encryptionVersion,
                                    boolean isMDNIPayload)
    {

		logger.debug("persistXMLPayload Started");
        String baseId;
        boolean isAudited = true;
        String auditResponseMessage = null;
        try {
            if (!HandlerUtil.isAdvancedStorageOptionEnabled() && StringUtils.isEmpty(senderBusinessSystemID)) {
                senderBusinessSystemID = createSenderBusinessSystem(savedFilePath, tenantId, isEncryptable, encryptionVersion);
            }
            int status = StagingTableStatus.PENDING.getValue();
            if(opreationType == IntegrationOperationType.FULLLOAD.getValue()){
                if(HandlerUtil.isCurrentPayloadSourceCreationDateOlder(objectName,tenantId,senderBusinessSystemID, sourceCreationTimeStamp)){
                    logger.info("Payload {} for objectName {} , tenant {} is older than existing record, hence marking the job as duplicate",savedFilePath,objectName,tenantId);
                    status = StagingTableStatus.DUPLICATE.getValue();    
                }
            }
            baseId = getBaseId(tenantId, ObjectTypes.XmlPayload.getValue());
            StageXMLData stageXMLData = new StageXMLData();
            stageXMLData.setDataPath(savedFilePath);
            stageXMLData.setId(baseId);
            stageXMLData.setObjectName(objectName);
            stageXMLData.setDateCreated(new Date());
            stageXMLData.setDateUpdated(new Date());
            stageXMLData.setIsActive(0);
            stageXMLData.setStatus(status);
            stageXMLData.setTenantId(tenantId);
            stageXMLData.setSenderBusinesssytemId(senderBusinessSystemID);
            stageXMLData.setOperation(opreationType);
            stageXMLData.setMDNIPayload(isMDNIPayload);
            stageXMLData.setEncryptKey(
                kmsEnabled ? EncryptKey.KMS.name() : EncryptKey.ARIBA.name());
            if(isEncryptable && !kmsEnabled) { // this is not needed once we move to kms completely
                stageXMLData.setEncryptionVersion(encryptionVersion);
            }
            else if(isEncryptable && kmsEnabled) {
                stageXMLData.setDataCompressed(1);
            }

            if (!StringUtils.isEmpty(UUID)) {
                stageXMLData.setUUID(UUID);
            }

            if (!StringUtils.isEmpty(senderBusinessSystemID)) {
                stageXMLData.setSenderBusinesssytemId(senderBusinessSystemID);
            }

            stageXMLData.setSourceCreatedDate(sourceCreationTimeStamp);
            stageXMLData.setAuthenticationType(auditClientDataService.authenticationIdentifier.get());


            try {
                auditClientDataService.auditProcessXmlData( objectName, tenantId, stageXMLData, null, false );
            } catch (AuditFailedException e) {
                isAudited = false;
                stageXMLData.setStatus(StagingTableStatus.DISCARDED.getValue());
                auditResponseMessage = e.getMessage();
            }
            DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            GenericDAOStageData dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
            dao.save(stageXMLData);
            String ANID = Utility.getANId(stageXMLData.getTenantId());
            String senderBusinessSystemId = stageXMLData.getSenderBusinesssytemId();
            if (status == StagingTableStatus.DUPLICATE.getValue()) {
                String warnings = """
                    Payload is older than an existing record for this object, \
                    hence marking it job as duplicate and skipping records from processing\
                    """;
                List<String> warningsList = new ArrayList<String>();
                warningsList.add(warnings);
                IntegrationJobLogUtil.createIntegrationJobLogEntry(
                    ANID,
                    tenantId,
                    baseId,
                    senderBusinessSystemId,
                    objectName,
                    status,
                    warningsList);
            }
            if(!isAudited) {
                logger.error("Failed to Audit "+auditResponseMessage);
                throw new Fault(new Throwable(auditResponseMessage));
            }

			logger.info("Job created with ID {} for '{}' entities ANID '{}' with SenderBusinessSystemId '{}'", baseId, objectName, ANID, senderBusinessSystemId);
        }
        catch (InvalidTypeCodeException | IntegrationPayloadProcessorException
            | ParseException | IOException | ParserConfigurationException | SAXException ie)
        {
            logger.warn("Exception while persisting XML payload {}", ie);
            throw new Fault(new Throwable(ie.getMessage()));
        }

        return baseId;
    }

    /**
     * Validtes the incoming payload against the RNG file
     *
     * @param xmlPayload
     * @param eh
     * @param anId
     * @param objectName
     * @return
     * @throws XMLPayloadHandlerException
     * @throws IOException
     */
    private Boolean validateIncomingXMLPayload(String xmlPayload,
                                               ErrorHandlerImpl eh,
                                               String anId,
                                               String objectName,
                                               String senderBusinessSystemID)
            throws XMLPayloadHandlerException, IOException {
        boolean validXML = XMLUtil.isValidXML(objectName, senderBusinessSystemID, xmlPayload, eh, anId);
        return validXML;
    }

    /**
     * Get the xmlPayload from the Source Object
     *
     * @param payload
     * @return
     * @throws Fault
     */
    private String getXMLPayload(Source payload) throws Fault {
        try {
            Writer wr = new StringWriter();
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.ENCODING, StandardCharsets.UTF_8.name());
            Result result1 = new StreamResult(wr);
            transformer.transform(payload, result1);
            return wr.toString();
        } catch (TransformerException e) {
            throw new Fault(new Throwable(e.getMessage()));
        }
    }

    /**
     * Format of the BaseId
     * Total Length is 17 Characters
     * First 4 are for Variant
     * 2 Characters for the Service Code
     * 3 Characters for the Object Type Code
     * 8 Characters for the Sequence number
     *
     * @param variantId
     * @param objectName
     * @return
     * @throws InvalidTypeCodeException
     */
    private String getBaseId(long variantId, String objectName) throws
            InvalidTypeCodeException {
        BaseIdService service = BaseIdServiceImpl.getInstance();
        return service.allocateBaseId(objectName, variantId);
    }

    /**
     * Return senderBusiness Object if alreay exists else create and persist to SenderBusinessSystem Table
     *
     * @param savedFilePath
     * @param tenantId
     * @param encryptionVersion
     * @throws ParseException
     * @throws IOException
     * @throws IntegrationPayloadProcessorException
     * @throws InvalidTypeCodeException
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    private String createSenderBusinessSystem(String savedFilePath, long tenantId, Boolean isEncryptable,String encryptionVersion) throws
            ParseException,
            IOException,
            IntegrationPayloadProcessorException,
            InvalidTypeCodeException, ParserConfigurationException, SAXException {
        if (logger.isDebugEnabled())
            logger.debug("createSenderBusinessSystem Started");
        String senderBusinessSystemIdTag = "SenderBusinessSystemID";

        String value = getValueOfTag(savedFilePath, senderBusinessSystemIdTag, isEncryptable, encryptionVersion);

        if(value == null){
            logger.info("SenderBusinessSystemID value in the payload is null,hence not creating the Entry in TENANT_BUSINESS_SYSTEM_ID_TAB");
            return null;
        }

        logger.info("SenderBusinessSystemID : {} " , value);

        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        SenderBusinessSystemRepository senderBusinessSystemRepository = (SenderBusinessSystemRepository) factory.getMiscDAO(
                ObjectTypes.SenderBusinessSystem.getValue());
        SenderBusinessSystem senderBusinessSystem = senderBusinessSystemRepository.findOne(value, tenantId);
        if (senderBusinessSystem == null) {
            senderBusinessSystem = new SenderBusinessSystem();
            senderBusinessSystem.setDateCreated(new Date());
            senderBusinessSystem.setDateUpdated(new Date());
            senderBusinessSystem.setIsActive(0);
            senderBusinessSystem.setTenantId(tenantId);
            senderBusinessSystem.setBusinessSystemId(value);
            senderBusinessSystem.setId(getBaseId(
                    tenantId,
                    ObjectTypes.SenderBusinessSystem.getValue()));
            senderBusinessSystemRepository.save(senderBusinessSystem);
        }
        if (logger.isDebugEnabled())
            logger.debug("createSenderBusinessSystem Ended");

        return value;
    }

    /**
     * Return senderBusiness Object if alreay exists else create and persist to SenderBusinessSystem Table
     *
     * @param savedFilePath
     * @param tenantId
     * @throws ParseException
     * @throws IOException
     * @throws IntegrationPayloadProcessorException
     * @throws InvalidTypeCodeException
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws XPathExpressionException 
     */
    public int getOperationType (String savedFilePath,
                                 long tenantId,
                                 String objectName,
                                 Boolean isEncryptable,
                                 String encryptionVersion,
                                 boolean isIncrementalLoad)
    throws ParseException, IOException, IntegrationPayloadProcessorException,
           InvalidTypeCodeException, ParserConfigurationException, SAXException,
           XPathExpressionException
    {
        if(!isIncrementalLoad){
            String actionCodeValue = getActionCodeTagValue(savedFilePath,ActionCodeTag, isEncryptable, encryptionVersion);
            int operationType = actionCodeValue !=null ? getOperationTypeFromActionCodeValue(actionCodeValue) : getOperationTypeDefault(objectName);
            logger.debug("The operation for object - {} and tenant - {} is - {}", objectName, tenantId, operationType);
            return operationType;
        }
        return IntegrationOperationType.INCREMENTALLOAD.getValue();
    }

    /**
     * Getting the operation type for xml
     * @param xmlPayload
     * @param objectName
     * @return
     * @throws ParseException
     * @throws IOException
     * @throws IntegrationPayloadProcessorException
     * @throws InvalidTypeCodeException
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws XPathExpressionException
     */
    public int getOperationType(String  xmlPayload, String objectName, boolean isIncrementalLoad) throws
            ParseException,
            IOException,
            IntegrationPayloadProcessorException,
            InvalidTypeCodeException, ParserConfigurationException, SAXException, XPathExpressionException {
        if(!isIncrementalLoad){
            InputStream xmlInputStream = new ByteArrayInputStream(xmlPayload.getBytes());
            String actionCodeValue = XMLUtil.getValueOfTag(xmlInputStream, ActionCodeTag);
            int operationType = actionCodeValue !=null ? getOperationTypeFromActionCodeValue(actionCodeValue) : getOperationTypeDefault(objectName);
            logger.debug("The operation for " + objectName + " is " + operationType);
            return operationType;
        }
        return IntegrationOperationType.INCREMENTALLOAD.getValue();
    }
    
    /**
     * from the actionCode value in payload,
     * output the operationType
     * expecting only 01/02
     * @param actionCodeVal
     * @return
     */
    private int getOperationTypeFromActionCodeValue(String actionCodeVal) {
    		int opType = IntegrationOperationType.FULLLOAD.getValue();
    		if(IntegrationOperationType.INCREMENTALLOAD.getValue() == Integer.parseInt(actionCodeVal)) {
    			opType = IntegrationOperationType.INCREMENTALLOAD.getValue();
    		}
    		return opType;
    }
    
    /**
     * get the default operation type based on object type. Introduced for
     * backward compatibility as few classes support Incremental op only
     * 
     * @param objectName
     * @return
     */
    private int getOperationTypeDefault (String objectName)
    {
        int opType = IntegrationOperationType.FULLLOAD.getValue();
        if (HandlerUtil.isIncrementalLoadObject(objectName)) {
            opType = IntegrationOperationType.INCREMENTALLOAD.getValue();
        }
        return opType;
    }

    protected String writeFileToFileSystem (String payload,
                                            String anId,
                                            String objectName,
                                            Long tenantId,
                                            String senderBusinessSystemID,
                                            Boolean isEncryptable,
                                            String encryptionVersion)
        throws IntegrationPayloadProcessorException,
        SecurityInitializationException,
        GeneralSecurityException,
        IOException
    {
        return writeFileToFileSystem(
            payload,
            anId,
            objectName,
            tenantId,
            senderBusinessSystemID,
            isEncryptable,
            encryptionVersion,
            null);
    }

    /**
     * Only User Entity was encryptable until 2205. Done
     * via EncryptableObjects.
     *
     * After 2205 all entities are to be encrypted along
     * with KMS enablement.
     *
     * @param objectName - Entity Name whether to encrypt or not
     * @return
     */
    protected Boolean isEncryptableObject (String objectName)
    {
        return !HandlerUtil.isMDCS();
    }
    
    private InputStream decryptFileAndUnzip (String encryptedZippedFilePath)
        throws IOException
    {
        // first decrypt and then unzip
        // decrypting
        PipedInputStream pipedDecrInput = new PipedInputStream();
        PipedOutputStream pipedDecrOutput = new PipedOutputStream(pipedDecrInput);
        new Thread(new Runnable() {
                public void run ()
                {
              try (
                  InputStream encryptedInputStream = new FileInputStream(
                      new File(encryptedZippedFilePath));
                  InputStream decrInputStream = encryptionService.getEncryptionService().getDecryptingInputStream(
                      encryptedInputStream);)
              {
                        logger.info("get value of tag system based decryption");
                        byte[] buffer = new byte[1024];
                        int len;
                        while ((len = decrInputStream.read(buffer)) != -1) {
                            logger.info("inside decrypt");
                      pipedDecrOutput.write(buffer, 0, len);
                        }
                        pipedDecrOutput.close();

                    }
                    catch (GeneralSecurityException | IOException e) {
                  logger.error("Exception while decrypting {} : {}", encryptedZippedFilePath, e);
                    }
                }
            }).start();
            // unzipping the decrypted input stream
        ZipInputStream unzippedStream = new ZipInputStream(pipedDecrInput);
                unzippedStream.getNextEntry();
                return unzippedStream;
            }

    /**
     * Write the incoming message to the file
     *
     * @param payload
     * @param tenantId
     * @param objectName
     * @param senderBusinessSystemID
     * @param encryptionVersion
     * @return
     * @throws IntegrationPayloadProcessorException, SecurityInitializationException, GeneralSecurityException, IOException 
     */
    protected String writeFileToFileSystem (String payload,
                                          String anId,
                                          String objectName,
                                          Long tenantId,
                                          String senderBusinessSystemID,
                                          Boolean isEncryptable,
                                          String encryptionVersion,
                                          String filePath)
        throws IntegrationPayloadProcessorException,
        SecurityInitializationException,
        GeneralSecurityException,
        IOException
    {
        FileOutputStream outputStream = null;
        BufferedWriter outWriter = null;
        FileWriter fileWriter = null;

        String finalPath=null;
        try {
            if (logger.isInfoEnabled())
                logger.info("String Path : {}", finalPath);
            File nfsMountedDirectory = new File(BASE_PATH);
            if (!nfsMountedDirectory.exists()) {
                logger.warn("/tmp/nfs not Mounted");
                throw new IntegrationPayloadProcessorException("/tmp/nfs not Mounted");
            }
            if (kmsEnabled && isEncryptable) {
                finalPath = buildKMSPath(
                    anId,
                    objectName,
                    senderBusinessSystemID,
                    filePath);
            }
            else {
                finalPath = buildNonKMSPath(
                    anId,
                    objectName,
                    senderBusinessSystemID,
                    BASE_PATH,
                    filePath);
            }
            if (logger.isInfoEnabled())
                logger.info("String Path : {}", finalPath);
            finalPath = FilenameUtils.normalize(finalPath);
            File file = new File(finalPath);
            File parentDir = new File(file.getParent());
            if (!parentDir.exists()) {
                if (!parentDir.mkdirs()) {
                    logger.warn("Directory creation failed");
                }
            }
            if (isEncryptable) {
                if (kmsEnabled) {
                    // system encryption
                    logger.info("system encryption");
                    writePayloadToZipFileAndEnrypt(payload, finalPath);
                    boolean fileEncrypted = checkIfKMSKeyValid(finalPath);
                    if (!fileEncrypted) {
                        logger.info("the encryption was not successful");
                        throw new IOException("Failed to encrypt with KMS Key");
                    }
                    else {
                        logger.info("the encryption was successful");
                    }
                    logger.info("Path after zipping is {}", finalPath);
                }
                else {
                    // regular encryption
                    InputStream is = new ByteArrayInputStream(
                        payload.getBytes(StandardCharsets.UTF_8.name()));
                    EncryptionUtil.encrypt(
                        is,
                        new FileOutputStream(file),
                                               encryptionVersion);
                    }
            }
            else {
                fileWriter = new FileWriter(file);
                outWriter = new BufferedWriter(fileWriter);
                    outWriter.write(payload);
                    outWriter.flush();
                }
            }
        catch (IOException | IntegrationPayloadProcessorException | SecurityInitializationException
            | GeneralSecurityException ex)
        {
            deleteFile(finalPath);
            logger.error("[MDNI_CRITICAL][ARIBA][Processing] Tenant ID - {}, Object Name - {}, Exception {} while writing uploaded XML Data to file ",
                         anId,
                         objectName,
                         ErrorUtil.getCompleteCausedByErrors(ex));
            throw new Fault(new Throwable(ex.getMessage()));
        }
        finally {
            if (outWriter != null) {
                try {
                    outWriter.close();
                }
                catch (IOException ex) {
                    logger.warn(ex.getMessage());
                }
            }
        }

        return finalPath;
    }

    private void deleteFile (String finalPath)
    {
        if(finalPath == null) return;
        File f = new File(finalPath);
        if (f.exists()) {
            try {
                boolean fileDeleted = f.delete();
                if (!fileDeleted) {
                    throw new Exception("Cannot delete file");
                }
            }
            catch (Exception ex) {
                logger.error(
                    "Exception occurred when deleting file {}",
                    ex.getMessage());
            }
        }
    }

    private String buildNonKMSPath (String anId,
                                    String objectName,
                                    String senderBusinessSystemID,
                                    String BASE_PATH,
                                    String filePath)
    {
        String finalPath;
        if(StringUtils.isEmpty(filePath)) {
            if (!StringUtils.isEmpty(senderBusinessSystemID)) {
                finalPath = BASE_PATH + "/" + anId + "/data/" + objectName + "_"
                    + senderBusinessSystemID + "_" + HandlerUtil.getCurrentTime() + XMLUtil.XML_PATH_EXT;
            }
            else {
                finalPath = BASE_PATH + "/" + anId + "/data/" + objectName + "_"
                    + HandlerUtil.getCurrentTime() + XMLUtil.XML_PATH_EXT;
            }
        }else {
            finalPath = filePath;
        }
        return finalPath;
    }
    
    private String buildKMSPath (String anId,
                                 String objectName,
                                 String senderBusinessSystemID,
                                 String filePath)
    {
        String finalPath;
        if(StringUtils.isEmpty(filePath)) {
            finalPath = kmsBasePath;
            if (!StringUtils.isEmpty(senderBusinessSystemID)) {
                finalPath = finalPath + anId + "/data/" + objectName + "_"
                    + senderBusinessSystemID + "_" + HandlerUtil.getCurrentTime() + ".zip";
            }
            else {
                finalPath = finalPath + anId + "/data/" + objectName + "_"
                    + HandlerUtil.getCurrentTime() + ".zip";
            }
        }else {
            finalPath = filePath;
        }
        return finalPath;
    }
    
    /**
     * Rename the file if UUID is not null.
     *
     * @param tenantId
     * @param objectName
     * @param senderBusinessSystemID
     * @param UUID
     * @param oldFilePath
     * @return
     */
    private String renameFile(String tenantId,
                              String objectName,
                              String senderBusinessSystemID,
                              String UUID,
                              String oldFilePath,
                              Boolean isEncryptable,
                              String encryptionVersion) {

        String uuidForFileName = HandlerUtil.replaceForwardSlashFromUUIDForFileName(UUID);

        String newPath;
        if (kmsEnabled && isEncryptable) {
            newPath = buildKMSPathWithUUID(
                tenantId,
                objectName,
                senderBusinessSystemID,
                uuidForFileName);
        }
        else {
            if (!StringUtils.isEmpty(senderBusinessSystemID)) {
                newPath = BASE_PATH + "/" + tenantId + "/data/" + objectName + "_"
                                + senderBusinessSystemID + "_" + uuidForFileName + "_"
                                + HandlerUtil.getCurrentTime() + XMLUtil.XML_PATH_EXT;
            }
            else {
                newPath = BASE_PATH + "/" + tenantId + "/data/" + objectName + "_"
                                + uuidForFileName + "_" + HandlerUtil.getCurrentTime()
                                + XMLUtil.XML_PATH_EXT;
            }
        }
        File oldfile = new File(oldFilePath);
        File newfile = new File(newPath);

        if (oldfile.renameTo(newfile)) {
            return newPath;
        } else {
            return null;
        }
    }
    
    private String buildKMSPathWithUUID (String anId,
                                         String objectName,
                                         String senderBusinessSystemID,
                                         String uuidForFileName)
    {
        String finalPath = kmsBasePath;
        if (!StringUtils.isEmpty(senderBusinessSystemID)) {
            finalPath = finalPath + anId + "/data/" + objectName + "_" + senderBusinessSystemID
                            + "_" + uuidForFileName + "_" + HandlerUtil.getCurrentTime()
                            + ".zip";
        }
        else {
            finalPath = finalPath + anId + "/data/" + objectName + "_" + uuidForFileName + "_"
                            + HandlerUtil.getCurrentTime() + ".zip";
        }
        return finalPath;

    }
    
    public void writePayloadToZipFileAndEnrypt (String payload, String path)
        throws GeneralSecurityException,
        IOException
    {
        // First zip payload into a stream and then encrypt the stream into the
        // path
        path = FilenameUtils.normalize(path);
        File file = new File(path);
        String fileName = file.getName();
        File parentDir = new File(file.getParent());
        if (!parentDir.exists() && !parentDir.mkdirs()) {
                logger.warn("Directory creation failed");
        }
        try {
            // Zip first
            final ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (ZipOutputStream zos = new ZipOutputStream(baos)) {
                // zip to pipedinputstream
                byte[] zippedBuffer = new byte[1024];
                ZipEntry zipEntry = new ZipEntry(fileName.replace(XMLUtil.ZIP_PATH_EXT, XMLUtil.XML_PATH_EXT));

                byte[] payloadBytes = payload.getBytes();
                // zipEntry.setSize(payloadBytes.length);
                zos.putNextEntry(zipEntry);
                zos.write(payloadBytes);

                zos.closeEntry();
                zos.flush();
            }

            try (FileOutputStream fos = new FileOutputStream(file);
                OutputStream encryptingOutputStream = encryptionService.getEncryptionService().getEncryptingOutputStream(
                    fos))
            {

                logger.info(
                    "Encrypting stream is instance of {}",
                    encryptingOutputStream instanceof ZipOutputStream);

                encryptingOutputStream.write(baos.toByteArray());
                encryptingOutputStream.flush();
            }
            catch (GeneralSecurityException | IOException ex) {
                logger.error("Exception while encrypting and zipping XML Data: {}", ex);
                throw ex;
            }
        }
        catch (GeneralSecurityException | IOException e) {
            throw e;
        }
    }
    
    public boolean checkIfKMSKeyValid (String filePath)
    {
        try (FileInputStream is = new FileInputStream(filePath);)
        {
            final StreamDecryptInfo info = new StreamDecryptInfo(is, false);
            info.rewind();
            if (info.getPrefixType() == PrefixType.ARIBA_PREFIX
                || info.getPrefixType() == PrefixType.PER_TENANT_PREFIX) {
                return true;
            }
        }
        catch (IOException e) {
            logger.info("failed to encrypt {}", e.getMessage());
        }
        return false;
    }

    private Timestamp convertToDateObject(String creationDate){
        Date receivedCreationDate = HandlerUtil.parseDate(creationDate);
        Timestamp receivedCreationTimeStamp = new Timestamp(
                receivedCreationDate.getTime());

        return receivedCreationTimeStamp;
    }

    /**
     * Builds the response in Soap format as expected from CIG.
     * @param jobId - the id generated on the StageXMLDataTab
     * @return
     */
    private String buildSoapResponse(String jobId)
    {
    	logger.info("Building SOAP response");
        StringBuffer sb = new StringBuffer();
        String responseStr = "";
        sb.append(
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n\t");
        sb.append("<soap:Body>\n\t\t");
        sb.append("<JobId>");
        sb.append(jobId);
        sb.append("</JobId>\n\t");
        sb.append("</soap:Body>\n");
        sb.append("</soap:Envelope>");
        responseStr = sb.toString();
        
        //Sign the soap xml response
        return signatureService.signMessage(responseStr);
    }

    private void auditProcessXmlData(String objectName, long tenantId, int operation, String error, String senderBusinessSystemID, boolean runAsync) {
        StageXMLData stageXMLData = new StageXMLData();
        stageXMLData.setOperation(operation);
        stageXMLData.setAuthenticationType(auditClientDataService.authenticationIdentifier.get());
        stageXMLData.setSenderBusinesssytemId(senderBusinessSystemID);
        try {
            auditClientDataService.auditProcessXmlData(objectName, tenantId, stageXMLData, error, false);
        } catch (AuditFailedException e) {
            logger.error("Failed to Audit: "+e);
            throw new Fault(new Throwable(e.getMessage()));
        }
    }

    /**
     * Only for testing purpose , do not use this method
     * @param monitoringEventHandler
     */
    public void setMonitoringEventHandler (MonitoringEventHandler monitoringEventHandler)
    {
        this.monitoringEventHandler = monitoringEventHandler;
    }
}
