package com.sap.ariba.erpintegration.handlers;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.eclipse.jetty.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.ariba.erpintegration.util.Constants;

public class UploadLimitValidationHandler extends AbstractPhaseInterceptor<Message> {
	private static final Logger logger = 
			LoggerFactory.getLogger(UploadLimitValidationHandler.class.getName());
	private static final String ErrorMessageFmt = 
			"Request length exceeded maximum allowed limit of %s MB for tenant: %s for URL: %s";
	
	/**
	 * We are currently placing a limit on input request size to 150MB
	 */
	private static final int maxRequestSizeLimitMB = 150;
	
	public UploadLimitValidationHandler () {
		// Adding this in receive phase since we want to verify the content length
		// immediately after successful authentication 
		super(Phase.RECEIVE);
		addAfter(CredentialBasedAuthenticator.class.getName());
	}

	@Override
	public void handleMessage (Message message) throws Fault {
		HttpServletRequest request = (HttpServletRequest) message.get(AbstractHTTPDestination.HTTP_REQUEST);
		if (request != null) {
			long length = request.getContentLengthLong();
			if (length > getMaxRequestSizeLimitBytes()) {
				String clientANID = request.getParameter(Constants.KeyTenantId);
				String url = request.getRequestURL() + "?" + request.getQueryString();
				String errorMsg = ErrorMessageFmt.formatted(maxRequestSizeLimitMB, clientANID, url);
				logger.error(errorMsg);
				Fault fault = new Fault(new Throwable(errorMsg));
				fault.setStatusCode(HttpStatus.PAYLOAD_TOO_LARGE_413);
				throw fault;
			}
		}
	}

	/**
	 * Returns the value of <code>maxRequestSizeLimitMB</code> in bytes.
	 */
	private long getMaxRequestSizeLimitBytes() {
		return maxRequestSizeLimitMB * FileUtils.ONE_MB;
	}
}
