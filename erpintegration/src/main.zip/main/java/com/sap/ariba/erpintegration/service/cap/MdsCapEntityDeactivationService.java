package com.sap.ariba.erpintegration.service.cap;

import com.sap.ariba.erpintegration.mdi.cap.publish.MdsCapPublishService;
import com.sap.ariba.erpintegration.mdi.mds.exception.PublishException;
import com.sap.ariba.erpintegration.util.EventNameToObjectMap;
import com.sap.ariba.mdsclient.cap.util.MdsCapConfigHolder;
import com.sap.ariba.mdsclient.exception.InvalidObjectNameException;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sap.ariba.erpintegration.onemds.entity.common.EntityUtil;
import java.util.HashMap;
import java.util.Map;

/**
 * This service is used to deactivate entities in MDS CAP
 *
 * @author Satish Kumar Kara
 */
@Service
public class MdsCapEntityDeactivationService
{
    private static final Logger log = LoggerFactory.getLogger(MdsCapEntityDeactivationService.class);

    @Autowired
    protected MdsCapPublishService mdsCapPublishService;

    /**
     * Deactivates all the entities of type <code>objectName</code> for the
     * specified <code>anId</code>, <code>senderBusinessSystemId</code> and
     * <code>context</code> in MDS CAP
     *
     * @param objectName             the entity to delete
     * @param anId
     * @param senderBusinessSystemId
     * @return response message returned from the server in case of success
     */
    public Map<String, Object> deactivateExistingRecords (String objectName,
                                                          String anId,
                                                          String senderBusinessSystemId,
                                                          Boolean isOdmEntity) throws
        PublishException, InvalidObjectNameException
    {
        Map<String, Object> response = new HashMap<>();
        String entityName = EventNameToObjectMap.getEventName(objectName);
        String odmEntityLookUpName=entityName;
        if(isOdmEntity) {
            odmEntityLookUpName=EntityUtil.ODM+"."+entityName;
        }
        String context = MdsCapConfigHolder.getEntityContextName(odmEntityLookUpName);
        String odmEntityName = MdsCapConfigHolder.getEntityName(odmEntityLookUpName);

        String responseMessage = mdsCapPublishService.deactivateEntity(context,
            isOdmEntity?odmEntityName:entityName,
            anId,
            senderBusinessSystemId);
        response.put("StatusCode", HttpStatus.SC_OK);
        response.put("Message", responseMessage);
        return response;
    }
}
