package com.sap.ariba.erpintegration.persistence.dao;

import java.io.UnsupportedEncodingException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.persistence.EntityManager;
import javax.sql.rowset.serial.SerialBlob;

import org.json.simple.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.sap.ariba.erpintegration.cache.LookUpValueCache;
import com.sap.ariba.erpintegration.meta.ClassMetaDataProvider;
import com.sap.ariba.erpintegration.meta.Field;
import com.sap.ariba.erpintegration.meta.Relation;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import com.sap.ariba.erpintegration.persistence.service.BaseIdServiceImpl;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;
import com.sap.ariba.erpintegration.util.EntityFactory;

/**
 * Created by i318483 on 01/06/17.
 */
@NoRepositoryBean
public interface GenericDAO<T, D> extends PagingAndSortingRepository<GenericEntity, Long>,
                CrudRepository<GenericEntity, Long>
{
    public GenericEntity findOne (long tenantId, String lookupKey);

    public GenericEntity findOne (long tenantId, String lookupKey1, String lookupKey2);

    public List<GenericEntity> findAllReferences (String reference);

    public List<GenericEntity> findAll (Date timeUpdated, long tenantId);

    public List<GenericEntity> findAll (long tenantId);

    public List<GenericEntity> findAll (Date timeUpdated,
                                        String lastRecordId,
                                        long tenantId);

    public Page<GenericEntity> findAll (long tenantId,
                                        Date minTimeUpdated,
                                        Date maxTimeUpdated,
                                        Pageable pageable);

    public Page<GenericEntity> findAll (long tenantId,
                                        Date minTimeUpdated,
                                        Date maxTimeUpdated,
                                        String lastRecordId,
                                        Pageable pageable);

    /**
     * Set all the generic and required fields on the Entity and persist. Check
     * classmeta.xml file for referenced objects and create an entry for it if
     * required.
     * 
     * @param tenantId
     * @param senderBusinessSystemId
     * @param objectName
     * @param jsonObject
     * @param em
     * @throws InvalidTypeCodeException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    public default void save (long tenantId,
                              String senderBusinessSystemId,
                              String objectName,
                              JSONObject jsonObject,
                              EntityManager em,
                              LookUpValueCache lookUpValueCache)
        throws InvalidTypeCodeException, SQLException, UnsupportedEncodingException
    {
        Map<String, String> lookupDetails = getLookupValueForObject(
            objectName,
            jsonObject);
        GenericEntity entity = getEntity(tenantId, objectName, lookupDetails);

        if (entity == null) {
            entity = createEntity(objectName);
        }

        setRequiredFieldsForEntity(
            tenantId,
            senderBusinessSystemId,
            entity,
            jsonObject,
            lookupDetails,
            lookUpValueCache);
        entity.setStatus(0);
        byte[] buff = jsonObject.toJSONString().getBytes("UTF-8");
        Blob data = new SerialBlob(buff);
        entity.setData(data);

        em.merge(entity);

        createReferencedObject(
            tenantId,
            senderBusinessSystemId,
            objectName,
            jsonObject,
            em,
            lookUpValueCache);
    }

    /**
     * Sets all requiredFields , and in the call setLookupFields set Entity
     * specific Lookup fields
     * 
     * @param tenantId
     * @param senderBusinessSystemId
     * @param entity
     * @param jsonObject
     * @param lookupDetails
     * @throws InvalidTypeCodeException
     * @throws SQLException
     */
    default void setRequiredFieldsForEntity (long tenantId,
                                             String senderBusinessSystemId,
                                             GenericEntity entity,
                                             JSONObject jsonObject,
                                             Map<String, String> lookupDetails,
                                             LookUpValueCache lookUpValueCache)
        throws InvalidTypeCodeException, SQLException
    {
        String lookUpValue = "";
        for (Map.Entry<String, String> entry : lookupDetails.entrySet()) {
            lookUpValue += entry.getValue();
        }
        Date date = new Date();
        if (entity.getDateCreated() == null) {
            entity.setDateCreated(date);
            entity.setDateUpdated(date);
            String baseId = null;
            if (lookUpValueCache.containsKey(lookUpValue))
                baseId = lookUpValueCache.get(lookUpValue);
            else
                baseId = getBaseId(tenantId, entity.getObjectType());
            lookUpValueCache.put(lookUpValue, baseId);
            entity.setId(baseId);
        }
        entity.setDateUpdated(new Date());
        entity.setSenderBusinessSystemId(senderBusinessSystemId);
        entity.setIsActive(0);
        entity.setLookupFields(lookupDetails);
        entity.setTenantId(tenantId);
    }

    /**
     * Extract the lookup value from the JSONData
     * 
     * @param objectName
     * @param jsonObject
     * @return
     */
    default Map<String, String> getLookupValueForObject (String objectName,
                                                         JSONObject jsonObject)
    {

        Object obj = null;
        JSONObject jsonData = null;
        String lookupFields = null;
        String[] lookupKeys = null;
        String externalLookupKeyForObject = null;
        Map<String, String> lookupDetails = null;

        externalLookupKeyForObject = ClassMetaDataProvider.getExternalLookupKeyForObject(
            objectName);
        lookupFields = ClassMetaDataProvider.getLookupKeysForObject(objectName);
        lookupKeys = lookupFields.split(",");
        if (externalLookupKeyForObject.contains(".")) {
            obj = getNestedData(jsonObject, externalLookupKeyForObject);
        }
        else {
            obj = jsonObject.get(externalLookupKeyForObject);
        }
        lookupDetails = new HashMap<String, String>();

        if (obj instanceof JSONObject object) {
            jsonData = object;
            for (String lookupKey : lookupKeys) {
                lookupDetails.put(lookupKey, (String)jsonData.get(lookupKey));
            }
        }
        else if (obj instanceof String strType && lookupKeys.length == 1) {
            lookupDetails.put(lookupKeys[0], strType);
        }
        else {
            for (String lookupKey : lookupKeys) {
                lookupDetails.put(lookupKey, (String)jsonObject.get(lookupKey));
            }
        }

        return lookupDetails;
    }

    /**
     * Get lookup value for the Referenced Object from the input JSONObject
     * passed.
     * 
     * @param relation
     * @param jsonObject
     * @return
     */
    default String getLookupValueForReferencedObject (Relation relation,
                                                      JSONObject jsonObject)
    {
        Object lookupValue = null;
        Field referenceField = relation.getField();
        String referencedFieldKey = referenceField.getName();

        if (referencedFieldKey.contains(".")) {
            lookupValue = (String)this.getNestedData(jsonObject, referencedFieldKey);
        }
        else {
            lookupValue = jsonObject.get(referencedFieldKey);

            if (lookupValue instanceof Long value) {
                lookupValue = Long.toString(value);
            }
            else if (lookupValue instanceof String lookupStr) {
                lookupValue = lookupStr;
            }
        }

        return String.valueOf(lookupValue);
    }

    default Object getNestedData (JSONObject jsonObject, String key)
    {
        int index = key.indexOf(".");
        if (index != -1) {
            String currentKey = key.substring(0, index);
            if (jsonObject.get(currentKey) instanceof Map) {
                return getNestedData(
                    (JSONObject)jsonObject.get(currentKey),
                    key.substring(index + 1, key.length()));
            }
        }
        else {
            return jsonObject.get(key);
        }
        return null;
    }

    default GenericEntity getEntity (long tenantId,
                                     String objectName,
                                     Map<String, String> lookupDetails)
    {
        GenericEntity entity = null;
        String[] lookupKeys = new String[lookupDetails.keySet().size()];

        if (lookupDetails.keySet() != null) {
            lookupKeys = lookupDetails.keySet().toArray(new String[lookupKeys.length]);
        }

        if (lookupKeys.length > 1) {
            entity = (GenericEntity)findOne(
                tenantId,
                lookupDetails.get(lookupKeys[0]),
                lookupDetails.get(lookupKeys[1]));
        }
        else {
            entity = (GenericEntity)findOne(tenantId, lookupDetails.get(lookupKeys[0]));
        }

        return entity;
    }

    default GenericEntity createEntity (String objectName)
    {
        return EntityFactory.getEntity(objectName);
    }

    default String getBaseId (long variantId, String objectName)
        throws InvalidTypeCodeException
    {
        BaseIdServiceImpl service = BaseIdServiceImpl.getInstance();
        return service.allocateBaseId(objectName, variantId);
    }

    /**
     * Create Referenced Object based on classmeta
     * 
     * @param tenantId
     * @param senderBusinessSystemId
     * @param objectName
     * @param jsonObject
     * @param em
     * @throws InvalidTypeCodeException
     * @throws SQLException
     */
    default void createReferencedObject (long tenantId,
                                         String senderBusinessSystemId,
                                         String objectName,
                                         JSONObject jsonObject,
                                         EntityManager em,
                                         LookUpValueCache lookUpValueCache)
        throws InvalidTypeCodeException, SQLException
    {
        List<Relation> relations = ClassMetaDataProvider.getRelationsForObject(
            objectName);
        if (relations == null || relations.size() == 0) {
            return;
        }

        String targetObjectName = null;
        String referencedFieldKey = null;
        Field referenceField = null;
        JSONObject defaultData = null;
        Blob blobData = null;
        byte[] buff = null;
        for (Relation relation : relations) {
            targetObjectName = relation.getName().substring(
                relation.getName().lastIndexOf('.') + 1).trim();
            GenericEntity referencedObject = getReferencedObject(
                tenantId,
                targetObjectName,
                jsonObject,
                relation);

            if (referencedObject != null) {
                return;
            }

            DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            GenericDAO objectDao = factory.getDAO(targetObjectName);
            String lookupKey = getLookupValueForReferencedObject(relation, jsonObject);
            GenericEntity entity = objectDao.findOne(tenantId, lookupKey);

            referenceField = relation.getField();
            referencedFieldKey = referenceField.getName();
            if (referencedFieldKey.contains("."))
                referencedFieldKey = referencedFieldKey.substring(
                    referencedFieldKey.lastIndexOf(".") + 1,
                    referencedFieldKey.length());


            if (entity == null) {
                entity = EntityFactory.getEntity(targetObjectName);
                defaultData = new JSONObject();
                defaultData.put(referencedFieldKey, lookupKey);
                buff = defaultData.toJSONString().getBytes();
                blobData = new SerialBlob(buff);
                entity.setData(blobData);
            }
            entity.setStatus(1);
            Map<String, String> lookupDetails = new HashMap<>();
            lookupDetails.put(referencedFieldKey, lookupKey);

            setRequiredFieldsForEntity(
                tenantId,
                senderBusinessSystemId,
                entity,
                jsonObject,
                lookupDetails,
                lookUpValueCache);

            em.merge(entity);
        }
    }

    default GenericEntity getReferencedObject (long tenatId,
                                               String targetObjectName,
                                               JSONObject jsonObject,
                                               Relation relation)
    {
        String objectField = null;
        String targetFieldValue = null;
        GenericEntity targetObject = null;
        Object obj = null;

        objectField = relation.getField().getName();
        if (objectField.contains(".")) {
            obj = getNestedData(jsonObject, objectField);
        }
        else {
            obj = jsonObject.get(objectField);
        }

        if (obj instanceof Long fieldVal) {
            targetFieldValue = Long.toString(fieldVal);
        }
        else if (obj instanceof String fieldVal) {
            targetFieldValue = fieldVal;
        }

        if (targetFieldValue != null && !targetFieldValue.equals("")) {
            DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            GenericDAO targetDAO = factory.getDAO(targetObjectName);
            targetObject = targetDAO.findOne(tenatId, targetFieldValue);
        }

        return targetObject;
    }
}
