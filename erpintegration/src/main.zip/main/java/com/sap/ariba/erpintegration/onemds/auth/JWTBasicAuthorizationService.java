package com.sap.ariba.erpintegration.onemds.auth;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sap.ariba.erpintegration.mdi.common.util.URLUtil;
import com.sap.ariba.erpintegration.onemds.exception.AuthorizationException;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Component("authService")
public class JWTBasicAuthorizationService implements AuthorizationService
{
    private static final Logger logger = LoggerFactory.getLogger(
        JWTBasicAuthorizationService.class);

    public static final String GRANT_TYPE_FORM_KEY = "grant_type";
    public static final String CLIENT_CREDS_FORM_VALUE = "client_credentials";
    private static final String EXPIRES_IN_RESPONSE_KEY = "expires_in";
    private static final String OAUTH_TOKEN_URL_SUFFIX = "oauth/token";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String EXPIRES_IN_SEC = "expires_in";
    public static final String FETCHED_TIME_IN_MILISEC = "fetchTimeInMiliSec";
    public static final String X_ZID = "X-ZID";
    
    @Autowired
    @Qualifier("oneMDSRestTemplate")
    private RestTemplate restTemplate;

    @Override
    public Map<String, Object> getAccessToken (AuthorizationRequestInfo authorizationRequestInfo) throws AuthorizationException
    {
        
        if (!StringUtils.isEmpty(authorizationRequestInfo.getClientID()) && !StringUtils.isEmpty(authorizationRequestInfo.getClientSecret())
            && !StringUtils.isEmpty(authorizationRequestInfo.getAuthURL()))
        {
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add(GRANT_TYPE_FORM_KEY, CLIENT_CREDS_FORM_VALUE);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map,
                createHeaders(authorizationRequestInfo.getClientID(), authorizationRequestInfo.getClientSecret(),authorizationRequestInfo.getZoneId()));
            try {
                ResponseEntity<ObjectNode> response = restTemplate.postForEntity(normalizeAuthURL(authorizationRequestInfo.getAuthURL()),
                    request,
                    ObjectNode.class);
                Optional<ObjectNode> tokenBodyOptional = Optional.ofNullable(response.getBody());
                if (tokenBodyOptional.isPresent()) {
                    Map<String, Object> tokenMap = new HashMap<>();
                    ObjectNode responseNode = tokenBodyOptional.get();
                    tokenMap.put(ACCESS_TOKEN, responseNode.get(ACCESS_TOKEN).asText());
                    tokenMap.put(EXPIRES_IN_SEC, responseNode.get(EXPIRES_IN_RESPONSE_KEY).asInt());
                    tokenMap.put(FETCHED_TIME_IN_MILISEC, System.currentTimeMillis());
                    return tokenMap;
                }
                else {
                    logger.error("[MDI_CRITICAL][JWT_Token], Access Token not found while fetching from Authorization URL");

                    throw new AuthorizationException(
                        "Access Token not found while fetching from Authorization URL - "
                            + authorizationRequestInfo.getAuthURL());
                }
            }
            catch (RestClientException rce) {
                logger.error("[MDI_CRITICAL][JWT_Token] Exception {}, while getting JWT access token from Auth URL ",
                             ErrorUtil.getCompleteCausedByErrors(rce));
                throw new AuthorizationException(
                    "Error while getting JWT access token from Auth URL - " + authorizationRequestInfo.getAuthURL(),
                    rce);
            }
        }
        else {
            logger.error("[MDI_CRITICAL][JWT_Token] Client ID, Client Secret and Authorization URL cannot be blank.");
            throw new AuthorizationException(
                "Client ID, Client Secret and Authorization URL cannot be blank. Passed Client ID - "
                    + (StringUtils.isEmpty(authorizationRequestInfo.getClientID()) ? "Blank" : "Not Blank")
                    + ", client Secret - " + (StringUtils.isEmpty(authorizationRequestInfo.getClientSecret()) ?
                    "Blank" :
                    "Not Blank") + " and Auth URL - " + authorizationRequestInfo.getAuthURL());
        }

    }

    private HttpHeaders createHeaders (String username, String password, String zoneId)
    {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setBasicAuth(username, password);
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        if (!StringUtils.isEmpty(zoneId)) {
            httpHeaders.set(X_ZID, zoneId);
        }
        
        return httpHeaders;
    }

    private String normalizeAuthURL (String authURL)
    {
        return !authURL.endsWith(OAUTH_TOKEN_URL_SUFFIX) ?
            URLUtil.getURL(authURL, OAUTH_TOKEN_URL_SUFFIX).toString() :
            authURL;
    }
}
