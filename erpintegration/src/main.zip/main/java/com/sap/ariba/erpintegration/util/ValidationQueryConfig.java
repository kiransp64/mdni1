package com.sap.ariba.erpintegration.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.sap.ariba.erpintegration.mdi.common.util.JSONUtil;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class ValidationQueryConfig {
    private static JsonNode configJson;

    static {
        try {
            ObjectMapper mapper = JSONUtil.getObjectMapper();
            try (InputStream inputStream = ValidationQueryConfig.class.getResourceAsStream("/mdi/validation.queries.meta.json")) {
                if (inputStream == null) {
                    throw new FileNotFoundException("Classpath resource /mdi/validation.queries.meta.json not found");
                }
                configJson = mapper.readTree(inputStream);
            }
        } catch (IOException e) {
            String errorMessage = "Configuration Loading Error: Failed to load the JSON configuration from 'src/main/resources/mdi/validation.queries.meta.json'. "
                    + "Ensure the file exists, is accessible, and is properly formatted. Error details: " + e.getMessage();
            throw new IllegalStateException(errorMessage, e);
        }
    }
    public static String getValue(String key) {
        JsonNode valueNode = configJson.get(key);
        if (valueNode == null) {
            String errorMessage = "Missing Configuration Key Error: The key '" + key
                    + "' is not found in the JSON configuration. Please verify that the key is correctly specified and exists in the configuration file.";
            throw new IllegalArgumentException(errorMessage);
        }
        return valueNode.asText();
    }
}

