package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.Tenant;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

/**
 * Created by i318483 on 21/06/17.
 */
@Component("TenantIdGetterComponent")
public interface TenantIdGetter extends CrudRepository<Tenant, Long>
{
    @Query(value = "select tenant_id_sequence.nextval from dummy", nativeQuery = true)
    long getTenantId();
}

