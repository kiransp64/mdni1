package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.TypeMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

/**
 * Created by i318483 on 02/06/17.
 */
@Component("TypeMapRepositoryComponent")
public interface TypeMapDao extends CrudRepository<TypeMap, Long> {
    @Query("select T from TypeMap T where T.objectType = :objectType")
    TypeMap findOne(@Param("objectType") String objectType);
}
