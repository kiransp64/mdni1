package com.sap.ariba.erpintegration.schema;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sap.ariba.erpintegration.util.XMLUtil;

/**
 * <code>SchemaUtil</code> class is having to utility methods to extract object
 * definition from a given schema.
 * 
 * @author i339952
 */
public class SchemaUtil
{

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.schema.SchemaUtil";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private static final String XSD_SCHEMA = "xsd:schema";
    private static final String XSD_ATTRIBUTE = "xsd:attribute";
    private static final String XSD_COMPLEX_TYPE = "xsd:complexType";
    private static final String XSD_SIMPLE_TYPE = "xsd:simpleType";
    private static final String XSD_ELEMENT = "xsd:element";
    private static final String XMLNS_XSD = "xmlns:xsd";
    private static final String XSD_DATE_TIME = "xsd:dateTime";
    private static final String XSD_BOOLEAN = "xsd:boolean";

    private static final String XMLNS_XSD_VALUE = "http://www.w3.org/2001/XMLSchema";
    private static final String TYPE = "type";
    private static final String NAME = "name";
    private static final String YES = "yes";
    private static final String MIN_OCCURS = "minOccurs";
    private static final String TIME_CREATED = "TimeCreated";
    private static final String TIME_UPDATED = "TimeUpdated";
    private static final String IS_ACTIVE = "IsActive";

    /**
     * This method gets the object definition from a given schema based on the
     * object name
     * 
     * @param xsdPath
     * @param objectName
     * @return
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public static String getObjectSchema (String xsdPath, String objectName)
        throws ParserConfigurationException, SAXException, IOException
    {
        String objectDefinition = null;
        Document xsdDoc;
        Element root;
        Document objectMetadataDoc;
        if (logger.isInfoEnabled()) {
            logger.info("XSD Path : {}, Object Name : {}", xsdPath, objectName);
        }
        if (xsdPath == null || xsdPath.isEmpty() || objectName == null
            || objectName.isEmpty())
        {
            logger.warn("xsdPath or objectName is not valid");
            return null;
        }
        Stack<Node> stack = new Stack<>();
        try (FileInputStream is = new FileInputStream(xsdPath)) {
            // Create a new document
            objectMetadataDoc = XMLUtil.getDocBuilder().newDocument();
            if (logger.isDebugEnabled()) {
                logger.debug("Created the new document");
            }

            root = objectMetadataDoc.createElement(XSD_SCHEMA);
            root.setAttribute(XMLNS_XSD,
                              XMLNS_XSD_VALUE);
            objectMetadataDoc.appendChild(root);
            if (logger.isDebugEnabled()) {
                logger.debug("Appended xsd:schema to the document");
            }
            xsdDoc = XMLUtil.getDocBuilder().parse(is);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Created the document object for input xsd {}", xsdDoc);
        }

        Element rootElement = xsdDoc.getDocumentElement();
        if (rootElement.hasAttributes()) {
            NamedNodeMap namedNodeMap = rootElement.getAttributes();
            for (int j = 0; j < namedNodeMap.getLength(); j++) {
                Node attrNode = namedNodeMap.item(j);
                String attrName = attrNode.getNodeName();
                String attrValue = attrNode.getNodeValue();
                if (logger.isDebugEnabled()) {
                    logger.debug(
                        "adding attribute to new xsd:schema attrName :{}, attrValue:{}",
                        attrName,
                        attrValue);
                }
                root.setAttribute(attrName, attrValue);
            }
        }

        if (logger.isDebugEnabled()) {
            logger.debug(
                "Getting the start element to start with. Object Name : {}",
                objectName);
        }

        Node objectElement = getObjectElement(xsdDoc, objectName);

        String objectType = objectElement.getAttributes().getNamedItem(
            TYPE).getNodeValue();

        if (logger.isDebugEnabled()) {
            logger.debug("Type of the start object :{} ", objectType);
        }

        // add the first element
        root.appendChild(objectMetadataDoc.importNode(objectElement, true));
        if (logger.isDebugEnabled()) {
            logger.debug("Added the starting element to xsd:schema");
        }

        Node objectComplexType = getComplexType(xsdDoc, objectType);

        stack.push(objectComplexType);

        if (logger.isDebugEnabled()) {
            logger.debug(
                "Got the complexType for starting element and pushing it to stack for recursive processing");
        }

        // Add the default elements to start complexType
        addDefaultElement(xsdDoc, objectComplexType);

        if (logger.isDebugEnabled()) {
            logger.debug("Added the default elements to object complex type");
        }

        while (!stack.isEmpty()) {
            // pop one from stack and append to the new doc
            // get all the elements and simple content. check if complexType or
            // simple type.
            // if complex type add to the stack
            // if simple type append to the new doc
            if (logger.isDebugEnabled()) {
                logger.debug(
                    "stack is not empty, so let's pop the stack to process the complexType");
            }
            Node complexType = stack.pop();

            String complexTypeObjectType = complexType.getAttributes().getNamedItem(
                NAME).getNodeValue();

            if (logger.isDebugEnabled()) {
                logger.debug("Name of the complexType : {}", complexTypeObjectType);
            }

            root.appendChild(objectMetadataDoc.importNode(complexType, true));

            if (logger.isDebugEnabled()) {
                logger.debug(
                    "Adding the complex type {} to new doc",
                    complexTypeObjectType);
            }

            NodeList elements = getElementsInComplexType(xsdDoc, complexTypeObjectType);

            if (logger.isDebugEnabled()) {
                logger.debug(
                    "Got {} elements in complexType {}",
                    elements.getLength(),
                    complexTypeObjectType);
            }

            for (int i = 0; i < elements.getLength(); i++) {
                Node e = elements.item(i);
                if (e.getAttributes().getNamedItem(TYPE) == null) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("No type found for the element. Not processing");
                    }
                    continue;
                }

                String etype = e.getAttributes().getNamedItem(TYPE).getNodeValue();
                if (logger.isDebugEnabled()) {
                    logger.debug("Type of the element : {}", etype);
                }

                Node complexTypeElement = getComplexType(xsdDoc, etype);
                if (logger.isDebugEnabled()) {
                    logger.debug("getting the node with type : {}", etype);
                }

                if (complexTypeElement != null) {
                    if (logger.isDebugEnabled()) {
                        logger.debug(
                            "{} is a complexType, so pushing this to stack for processing",
                            etype);
                    }
                    stack.push(complexTypeElement);
                }
                else {
                    if (logger.isDebugEnabled()) {
                        logger.debug(
                            "{} is not a complexType, so checking if any simpleType present",
                            etype);
                    }
                    Node simpleTypeElement = getSimpleType(xsdDoc, etype);
                    if (simpleTypeElement != null) {
                        if (logger.isDebugEnabled()) {
                            logger.debug(
                                "{} is a simpleType, so appending this to document",
                                etype);
                        }
                        root.appendChild(
                            objectMetadataDoc.importNode(simpleTypeElement, true));
                    }
                }
            }

            NodeList attributes = null;
            if (complexType instanceof Element docElement) {
                attributes = docElement.getElementsByTagName(XSD_ATTRIBUTE);
                if (logger.isDebugEnabled()) {
                    logger.debug(
                        "Getting all the attributes for the starting complexType. No of attributes : {}",
                        attributes.getLength());
                }
            }
            if(attributes!=null) {
                for (int i = 0; i < attributes.getLength(); i++) {
                    Node e = attributes.item(i);
                    if (e.getAttributes().getNamedItem(TYPE) == null) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("No type found for the attribute. Not processing");
                        }
                        continue;
                    }
                    String etype = e.getAttributes().getNamedItem(TYPE).getNodeValue();
                    if (logger.isDebugEnabled()) {
                        logger.debug("Type of the attribute : {}", etype);
                    }

                    Node complexTypeElement = getComplexType(xsdDoc, etype);
                    if (logger.isDebugEnabled()) {
                        logger.debug("getting the node with type : {}", etype);
                    }
                    if (complexTypeElement != null) {
                        if (logger.isDebugEnabled()) {
                            logger.debug(
                                "{} is a complexType, so pushing this to stack for processing",
                                etype);
                        }
                        stack.push(complexTypeElement);
                    }
                    else {
                        if (logger.isDebugEnabled()) {
                            logger.debug(
                                "{} is not a complexType, so checking if any simpleType present",
                                etype);
                        }
                        Node simpleTypeElement = getSimpleType(xsdDoc, etype);
                        if (simpleTypeElement != null) {
                            if (logger.isDebugEnabled()) {
                                logger.debug(
                                    "{} is a simpleType, so appending this to document",
                                    etype);
                            }
                            root.appendChild(
                                objectMetadataDoc.importNode(simpleTypeElement, true));
                        }
                    }
                }
            }

            if (logger.isDebugEnabled()) {
                logger.debug("Stack Size : {}", stack.size());
            }
        }

        objectDefinition = nodeToString(objectMetadataDoc);

        if (logger.isDebugEnabled())
            logger.debug(
                "Object definition for objectName {} is \n {}",
                objectName,
                objectDefinition);

        return objectDefinition;
    }

    /**
     * This method converts a node to string
     * 
     * @param node
     * @return
     */
    public static String nodeToString (Node node)
    {
        StringWriter sw = new StringWriter();
        try {
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, YES);
            t.setOutputProperty(OutputKeys.INDENT, YES);
            t.transform(new DOMSource(node), new StreamResult(sw));
        }
        catch (TransformerException te) {
            logger.error("Exeption while coverting a node to string", te);
        }
        return sw.toString();
    }

    /**
     * This method gets the complex type from a given document based on the
     * name. If there is no complex type found in the document, it return null.
     * 
     * @param xsdDoc
     * @param name
     * @return
     */
    public static Node getComplexType (Document xsdDoc, String name)
    {
        if (logger.isDebugEnabled())
            logger.debug("ComplexType name : {}", name);
        NodeList nodeList = xsdDoc.getElementsByTagName(XSD_COMPLEX_TYPE);
        Node node = null;

        for (int i = 0; i < nodeList.getLength(); i++) {
            node = nodeList.item(i);
            String nodeName = node.getAttributes().getNamedItem(NAME).getNodeValue();
            if (nodeName.equals(name)) {
                if (logger.isDebugEnabled())
                    logger.debug("complexType found for the name : {}", name);
                break;
            }
            else {
                node = null;
            }
        }
        if (node == null) {
            logger.warn("complexType not found for the name : {}", name);
        }
        return node;
    }

    /**
     * This method gets the simple type from a given document based on the name.
     * If there is no complex type found in the document, it will return null.
     * 
     * @param xsdDoc
     * @param name
     * @return
     */
    public static Node getSimpleType (Document xsdDoc, String name)
    {
        if (logger.isDebugEnabled())
            logger.debug("simpleType name : {}", name);
        NodeList nodeList = xsdDoc.getElementsByTagName(XSD_SIMPLE_TYPE);
        Node node = null;
        for (int i = 0; i < nodeList.getLength(); i++) {
            node = nodeList.item(i);
            if (node.getAttributes().getNamedItem(NAME) == null)
                continue;
            String nodeName = node.getAttributes().getNamedItem(NAME).getNodeValue();
            if (nodeName.equals(name)) {
                if (logger.isDebugEnabled())
                    logger.debug("simpleType found for the name : {}", name);
                break;
            }
            else {
                node = null;
            }
        }
        if (node == null) {
            logger.warn("SimpleType not found for the name : {}", name);
        }
        return node;
    }

    /**
     * This method gets an element by name. If element by the given name is not
     * found, null will be returned.
     * 
     * @param xsdDoc
     * @param name
     * @return
     */
    public static Node getElement (Document xsdDoc, String name)
    {
        if (logger.isDebugEnabled())
            logger.debug("Element name : {}", name);
        NodeList nodeList = xsdDoc.getElementsByTagName(XSD_ELEMENT);
        Node node = null;

        for (int i = 0; i < nodeList.getLength(); i++) {
            node = nodeList.item(i);
            String nodeName = node.getAttributes().getNamedItem(NAME).getNodeValue();
            if (nodeName.equals(name)) {
                if (logger.isDebugEnabled())
                    logger.debug("Element found for the name : {}", name);
                break;
            }
            else {
                node = null;
            }
        }
        if (node == null) {
            logger.warn("Element not found for the name : {}", name);
        }
        return node;
    }

    /**
     * This method gets the element with the specified name and also checks if
     * the element have got a attribute named <code>minOccurs</code>. If it does
     * not find the element, it returns null.
     * 
     * @param xsdDoc
     * @param name
     * @return
     */
    public static Node getObjectElement (Document xsdDoc, String name)
    {
        if (logger.isDebugEnabled())
            logger.debug("Parent Element name : {}", name);
        NodeList nodeList = xsdDoc.getElementsByTagName(XSD_ELEMENT);
        Node node = null;

        for (int i = 0; i < nodeList.getLength(); i++) {
            node = nodeList.item(i);
            String nodeName = node.getAttributes().getNamedItem(NAME).getNodeValue();
            if (nodeName.equals(name)
                && node.getAttributes().getNamedItem(MIN_OCCURS) != null)
            {
                if (logger.isDebugEnabled())
                    logger.debug("Parent Element found for the name : {}", name);
                break;
            }
            else {
                node = null;
            }
        }
        if (node == null) {
            logger.warn("Parent Element not found for the name : {}", name);
        }
        return node;
    }

    /**
     * This method gets the list of elements in side a complexType.
     * 
     * @param xsdDoc
     * @param name
     * @return
     */
    public static NodeList getElementsInComplexType (Document xsdDoc, String name)
    {
        if (logger.isDebugEnabled())
            logger.debug(
                "Name of the complex type for which the elements need to be extracted : {}",
                name);
        XPath xPath = XPathFactory.newInstance().newXPath();
        String expression = "//complexType[@name='" + name + "']//element";
        NodeList result = null;
        try {
            result = (NodeList)xPath.compile(expression).evaluate(
                xsdDoc,
                XPathConstants.NODESET);
        }
        catch (XPathExpressionException e) {
            logger.error(
                "Exception while extracting elements in complex type : {}",
                name,
                e);
        }
        return result;
    }

    /**
     * This method get the metadata for default fields that need to be added to
     * the generated schema. Based on the requirement new fields can be added to
     * the metadata as default fields to the object schema.
     * 
     * @return
     */
    private static List<Map<String, String>> getDefaultFields ()
    {
        List<Map<String, String>> defaultFieldsList = new ArrayList<>();
        Map<String, String> defaultField = new HashMap<>();
        defaultField.put(NAME, TIME_CREATED);
        defaultField.put(TYPE, XSD_DATE_TIME);
        defaultFieldsList.add(defaultField);

        defaultField = new HashMap<>();
        defaultField.put(NAME, TIME_UPDATED);
        defaultField.put(TYPE, XSD_DATE_TIME);
        defaultFieldsList.add(defaultField);

        defaultField = new HashMap<>();
        defaultField.put(NAME, IS_ACTIVE);
        defaultField.put(TYPE, XSD_BOOLEAN);
        defaultFieldsList.add(defaultField);
        return defaultFieldsList;
    }

    /**
     * This method is responsible for adding the default fields to the object
     * definition.
     * 
     * @param xsdDoc
     * @param objectComplex
     */
    private static void addDefaultElement (Document xsdDoc, Node objectComplex)
    {
        List<Map<String, String>> defaultFieldsList = getDefaultFields();
        String complexTypeObjectType = objectComplex.getAttributes().getNamedItem(
            NAME).getNodeValue();

        NodeList elements = getElementsInComplexType(xsdDoc, complexTypeObjectType);

        for (Map<String, String> map : defaultFieldsList) {
            Element newElement = xsdDoc.createElement(XSD_ELEMENT);
            for (Map.Entry<String, String> entry : map.entrySet()) {
                newElement.setAttribute(entry.getKey(), entry.getValue());
            }
            elements.item(0).getParentNode().appendChild(newElement);
        }
    }
}
