package com.sap.ariba.erpintegration.service.exception;

/**
 * Created by c5259108 on 10/06/17.
 */

public class XMLPayloadHandlerException extends Exception
{
    private static final long serialVersionUID = 1L;

    public XMLPayloadHandlerException (Exception e)
    {
        super(e);
    }

    public XMLPayloadHandlerException (String message)
    {
        super(message);
    }

    public XMLPayloadHandlerException (String message, Exception e)
    {
        super(message, e);
    }

}
