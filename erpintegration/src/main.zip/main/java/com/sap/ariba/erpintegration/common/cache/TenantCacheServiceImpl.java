package com.sap.ariba.erpintegration.common.cache;

import com.sap.ariba.erpintegration.mdi.meta.customer.AribaCustomerMeta;
import com.sap.ariba.erpintegration.onemds.auth.handler.AccessTokenHandler;
import com.sap.ariba.erpintegration.onemds.tenant.TenantConfigurationProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class TenantCacheServiceImpl implements TenantCacheService
{
    private static final Logger logger = LoggerFactory.getLogger(TenantCacheServiceImpl.class);
    
    @Autowired
    private TenantConfigurationProvider tenantConfigurationProvider;

    @Autowired
    @Lazy
    private AribaCustomerMeta aribaCustomerMeta;
    
    @Autowired
    private AccessTokenHandler accessTokenHandler;


    /**
     * This method will clear the all the cache for particular tenant configuration
     * look AbstractTenantConfigurationProvider.java class
     */
    @Override
    public void clearTenantCache ()
    {
        try {
            //clearing the customer meta cache.
            tenantConfigurationProvider.removeTenantConfigurationDetail();
            accessTokenHandler.removeCachedAccessToken();
            aribaCustomerMeta.removeCustomer();
            logger.info("Successfully cleared the cache for all tenants.");
        }
        catch (Exception exp) {
            logger.error("Exception while removing/clearing the cache for tenantID.",
                         exp);
        }
    }

}
