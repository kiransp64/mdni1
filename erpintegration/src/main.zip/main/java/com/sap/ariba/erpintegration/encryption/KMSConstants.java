package com.sap.ariba.erpintegration.encryption;

public class KMSConstants {
    public static final String OAUTH_FRONT_URL = "oauth_front_door_url";
    public static final String OAUTH_CLIENT_ID = "oauth_clientId";
    public static final String OAUTH_PRIVATE_KEY = "oauth_private_secret";
    public static final String OAUTH_PUBLIC_KEY = "oauth_public_secret";
    public static final String KMS_ENDPOINT_URL = "kms_endpoint_url";
    public static final String CACHED_KEY_MANAGERS = "cached-key-managers";
    public static final String IS_MONITOR_KMS_SERVICE = "should_monitor_kms_services";

}