package com.sap.ariba.erpintegration.persistence;

/**
 * Created by i318483 on 31/05/17.
 */
public enum ObjectTypes
{
    PurchaseOrg("PurchaseOrg"),
    PurchaseGroup("PurchaseGroup"),
    TypeMap("TypeMap"),
    SequenceNumberGetter("SequenceNumberGetter"),
    TenantIdGetter("TenantIdGetter"),
    XmlPayload("XmlPayload"),
    IntegrationConfig("IntegrationConfig"),
    IncoTerms("IncoTerms"),
    InternalOrder("InternalOrder"),
    CurrencyMapping("CurrencyMapping"),
    ItemCategory("ItemCategory"),
    TaxCode("TaxCode"),
    WBSElement("WBSElement"),
    AccountCategory("AccountCategory"),
    CompanyCode("CompanyCode"),
    CostCenter("CostCenter"),
    CurrencyConversionRate("CurrencyConversionRate"),
    Address("Address"),
    Tenant("Tenant"),
    SenderBusinessSystem("SenderBusinessSystem"),
    Region("Region"),
    SimpleMapEntry("SimpleMapEntry"),
    PartitionedCommodityCode("PartitionedCommodityCode"),
    GeneralLedger("GeneralLedger"),
    PlantPurchaseOrgCombo("PlantPurchaseOrgCombo"),
    CurrencyCode("CurrencyCode"),
    CountryCode("CountryCode"),
    UOMCode("UnitOfMeasurement"),
    LocaleCode("LocaleCode"),
    PaymentMethodType("PaymentMethodType"), Audit("Audit"), Schema("Schema"),
    User("User"),
    IntegrationJobLog("IntegrationJobLog"), EntityVersion("EntityVersion"),
    Asset("Asset"),
    Currency("Currency"),
    UnitOfMeasurement("UnitOfMeasurement"),
    PaymentTerms("PaymentTerms"),
    AccCategoryFieldStatusCombo("AccCategoryFieldStatusCombo"),
	AdjustmentType("AdjustmentType"),
	Group("Group"),
    ProcurementUnit("ProcurementUnit"),
    ItemMaster("ItemMaster");

    private final String value;

    private ObjectTypes(String value)
    {
        this.value = value;
    }

    public String getValue ()
    {
        return this.value;
    }
}
