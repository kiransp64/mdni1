package com.sap.ariba.erpintegration.scheduler;

import java.util.Date;
import java.util.List;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;

import com.sap.ariba.erpintegration.SchedulerConfig;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;

/**
 * Created by i318483 on 05/06/17.
 */
@Component
@DisallowConcurrentExecution
@ConditionalOnExpression(    
    "${isInternal:false} == false"
)
public class IntegrationRecordStatusResetJob implements Job
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.scheduler.IntegrationRecordStatusResetJob";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);
    private final static int secondsPerMin = 60;
    private final static int milliSecondsPerHour = 60 * 60 * 1000;

    @Value("${integrationRecordStatusResetJob.cronExpression}")
    private String cronExpression;
    
    @Value("${MaxProcessingTimeForRecord}")
    int maxProcessingTimeForRecord;

    @Bean(name = "integrationRecordStatusResetJobBean")
    public JobDetailFactoryBean integrationRecordStatusResetJob ()
    {
        logger.info("Creating integrationRecordStatusResetJobBean");
        return SchedulerConfig.createJobDetail(this.getClass());
    }

    @Bean(name = "integrationRecordStatusResetJobTrigger")
    public CronTriggerFactoryBean integrationRecordStatusResetJobTrigger (@Qualifier("integrationRecordStatusResetJobBean") JobDetail jobDetail)
    {
        if (logger.isDebugEnabled())
            logger.debug("Creating integrationRecordStatusResetJobTrigger");
        return SchedulerConfig.createCronTrigger(jobDetail, cronExpression);
    }

    /**
     * This Scheduler resets the records back to STATUS =0 so that it is again picked up for re-processing.This is
     * done only for those records which got struck in STATUS =1 (IN_PROCESS) for time greater than the configured value(maxProcessingTimeForRecord) in the properties file.
     * @param jobExecutionContext
     * @throws JobExecutionException
     */
    @Override public void execute (JobExecutionContext jobExecutionContext) throws
        JobExecutionException
    {

        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        GenericDAOStageData dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());


            List<StageXMLData> recordsInProcessingStatus = dao.findRecordsInProcessingStatus();
            logger.info(
                "CUSTOM-> no. of records" + recordsInProcessingStatus.size());

            for (StageXMLData stagedXMLData : recordsInProcessingStatus) {
                long processingStartedAt = stagedXMLData.getDateUpdated().getTime();
                long currentTime = System.currentTimeMillis();
                if (currentTime - processingStartedAt > maxProcessingTimeForRecord * milliSecondsPerHour) {
                    dao.updateStatus(stagedXMLData.getId(),0,new Date());
                }
            }
    }
}
