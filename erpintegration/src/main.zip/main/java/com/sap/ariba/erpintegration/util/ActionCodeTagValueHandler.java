package com.sap.ariba.erpintegration.util;

import java.util.Stack;
import org.xml.sax.helpers.DefaultHandler;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Created by i340151
 */
public class ActionCodeTagValueHandler extends DefaultHandler
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.util.ActionCodeTagValueHandler";
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private String actionCodeTagName;

    private boolean tagFound = false;
    
    private boolean stopProcessing = false;

    private String currTagValue;

    private String rootTag;

    private Stack<String> visitedTags = new Stack<String>();

    public ActionCodeTagValueHandler (String tagName)
    {
        actionCodeTagName = tagName;
    }

    /**
     * gets the actioncode tag value if it is a child tag of root element. if it
     * is a descendant of child of root tag, ignores it
     */
    public void startElement (String uri,
                              String localName,
                              String qName,
                              Attributes attributes)
        throws SAXException
    {
        if (stopProcessing)
            return;
        if (rootTag == null) {
            rootTag = qName;
        }
        if (qName.equals(actionCodeTagName) && visitedTags.peek().equals(rootTag)) {
            tagFound = true;   
        }else {
            visitedTags.push(qName);
        }
    }

    public void characters (char ch[], int start, int length) throws SAXException
    {
        if(tagFound && !stopProcessing) {
            currTagValue = new String(ch, start, length);
        }
    }

    public void endElement (String uri, String localName, String qName)
        throws SAXException
    {
        if (stopProcessing)
            return;
        while (!visitedTags.isEmpty() && visitedTags.peek().equals(qName)) {
            visitedTags.pop();
        }
        if(tagFound) {
            stopProcessing = true;
            visitedTags.clear();
            if (logger.isDebugEnabled())
                logger.debug("actionCode tag found with value: {}", currTagValue);
        }

    }

    public String getTagValue ()
    {
        return currTagValue;
    }

}
