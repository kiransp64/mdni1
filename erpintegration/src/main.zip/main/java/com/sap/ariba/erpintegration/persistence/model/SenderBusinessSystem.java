package com.sap.ariba.erpintegration.persistence.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by i318483 on 19/06/17.
 */
@Entity
@Table(name="TENANT_BUSINESS_SYSTEM_ID_TAB")

public class SenderBusinessSystem implements Serializable
{

    private static final long serialVersionUID = 1L;
    private static final String objectType = "Tenant";

    @Id
    @Column(name="ID")
    private String id;

    @Column(name="TENANT_ID")
    private long tenantId;

    @Column(name="IS_ACTIVE")
    private int isActive;

    @Column(name="DATE_CREATED")
    private Date dateCreated;

    @Column(name="DATE_UPDATED")
    private Date dateUpdated;

    @Column(name="STATUS")
    private int status = 1;

    @Column(name="BUSINESS_SYSTEM_ID")
    private String businessSystemId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getTenantId() {
        return tenantId;
    }

    public void setTenantId(long tenantId) {
        this.tenantId = tenantId;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getBusinessSystemId() {
        return businessSystemId;
    }

    public void setBusinessSystemId(String businessSystemId)
    {
        this.businessSystemId = businessSystemId;
    }

    public String getObjectType ()
    {
        return objectType;
    }

    @Override
    public String toString() {
        return "Tenant [id=" + id + ", tenantId=" + tenantId + ", status=" + status
            + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + ", isActive=" + isActive + "]";
    }

}
