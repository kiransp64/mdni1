package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.MissingServletRequestParameterException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;

/**
 * Created by i318483 on 05/06/17.
 */
public abstract class RequestHandler
{
    private static enum action
    {RetrieveData, ProcessPayload, PersistIntegrationConfig, GetIntegrationJobs}

    ;

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.RequestHandler";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    public abstract Response execute (HttpServletRequest request) throws
        IntegrationServiceException,
        MissingServletRequestParameterException;

    /**
     * oAuth validation is done for the incoming request.
     * For MDCS mode, oAuth validation happens in the MDCSAuthFilter
     * @param request
     * @return
     */
    public boolean isRequestAuthorized (HttpServletRequest request) {
        if (HandlerUtil.isMDCS()) {
            logger.debug("OAuth validation happens in MdcJwtOAuthFilter/MdcsBasicOAuthFilter");
            return true;
        }
        String token = request.getHeader(HttpHeaders.AUTHORIZATION);
        OAuthTokenManager oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(
                OAuthTokenManager.class);
        return oAuthTokenManager.getUserInfo(token) != null;
    }

    /**
     * Delegate the call to repective handler's
     *
     * @param handlerForAction
     * @return
     */
    public static RequestHandler getHandler (String handlerForAction)
    {
        switch (action.valueOf(handlerForAction)) {
        case RetrieveData:
            return new IntegrationDataRetriever();
        case ProcessPayload:
            return new IntegrationDataPayloadProcessor();
        case PersistIntegrationConfig:
            return new IntegrationConfigPersistanceHandler();
        case GetIntegrationJobs:
            return new IntegrationJobLogProvider();
        default:
            return null;
        }
    }
}
