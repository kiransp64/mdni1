package com.sap.ariba.erpintegration.processor;

import com.sun.msv.driver.textui.DebugController;
import com.sun.msv.grammar.Grammar;
import com.sun.msv.reader.util.GrammarLoader;
import com.sun.msv.writer.relaxng.RELAXNGWriter;
import com.thaiopensource.validate.ValidationDriver;
import org.apache.commons.io.FilenameUtils;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class WSDLToRNGSchemaGenerator
{

    String operation = null;
    String filename = null;
    String objectName = null;
    String senderBusinessSystemId = null;
    private long wsdlUploadTime;
    private static final Logger logger = LoggerFactory.getLogger(WSDLToRNGSchemaGenerator.class);
    private String baseDir = null;
    private static final String SCHEMA_DIR = "schema";
    private static final String WSDL_DIR = "wsdl";
    private static final String SCHEMA_FILE_TYPE = ".xsd";
    private static final String RNG_FILE_TYPE = ".rng";
    private static final String WSDL_FILE_TYPE = ".wsdl";
    private String tempSechemDirPath = null;
    private static final String DOUBLE_HASH = "##";

    public long getWsdlUploadTime() {
        return wsdlUploadTime;
    }

    public void setWsdlUploadTime(long wsdlUploadTime) {
        this.wsdlUploadTime = wsdlUploadTime;
    }

    public WSDLToRNGSchemaGenerator (String baseDir,
        String filename,
        String objectName,
        String senderBusinessSystemId)
    {
        this.baseDir = baseDir;
        this.filename = filename;
        this.objectName = objectName;
        this.senderBusinessSystemId = senderBusinessSystemId;
        init(objectName, senderBusinessSystemId);
    }

    private void init (String objectName, String senderBusinessSystemId)
    {
        tempSechemDirPath = this.baseDir + "/" + SCHEMA_DIR + "/" + objectName
            + (senderBusinessSystemId == null ? "" : "_" + senderBusinessSystemId) + "/";
    }

    private void wsdlToXSD (InputStream is)
        throws ParserConfigurationException,
        SAXException,
        IOException,
        TransformerFactoryConfigurationError,
        TransformerException
    {
        try {
            DocumentBuilder builder;
            builder = getDocBuilder();
            Document wsdlDoc = builder.parse(is);
            populateXsdDoc(wsdlDoc);
            operation = getOperationName(wsdlDoc);
        }
        finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    logger.error(e.getMessage());
                }

            }
        }
    }

    private String getOperationName (Document wsdlDoc)
    {
        String operation = null;
        Element element = wsdlDoc.getDocumentElement();
        Node node = element.getElementsByTagName("wsdl:message").item(0);
        if (node != null) {
            NamedNodeMap nodeMap = node.getAttributes();
            operation = nodeMap.getNamedItem("name").getNodeValue();
        }

        return operation;
    }

    private void populateXsdDoc (Document wsdlDoc) throws ParserConfigurationException,
        IOException,
        TransformerFactoryConfigurationError,
        TransformerException
    {
        List<String> importNamespaces = null;
        Document xsdDoc = null;
        String inputMsgPrefix;
        String inputMsg;
        Node rootNode = wsdlDoc.getElementsByTagName("wsdl:definitions").item(0);
        boolean inputElementFound ;
        Element element = wsdlDoc.getDocumentElement();
        Node inputMessage = getInputMessageElement(element);
        int indexOfPrefix = inputMessage.getNodeValue().indexOf(":");
        if(indexOfPrefix != -1){
            inputMsgPrefix = inputMessage.getNodeValue().substring(0,indexOfPrefix);
            inputMsg = inputMessage.getNodeValue().substring(indexOfPrefix+1);
        } else {
            inputMsgPrefix = "";
            inputMsg = inputMessage.getNodeValue();
        }
        Node node = element.getElementsByTagName("wsdl:types").item(0);
        NodeList lst = node.getChildNodes();
        // In case of Product.wsdl we see that there are two schemas having the same root element
        // In that we can take any one of them as a main schema because both are at same level and
        // assumption is RNG will be same in either cases.
        boolean foundMainSchema = false;
        for (int i = 0; i < lst.getLength(); i++) {
            Node nd = lst.item(i);
            logger.info("node name : " + nd.getNodeName());
            if (nd.getNodeName().equals("xsd:schema")) {
                xsdDoc = getDocBuilder().newDocument();  // create a new document
                Element root = xsdDoc.createElement("xsd:schema");
                root.setAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
                xsdDoc.appendChild(root);
                String tempSchemaFilePostFix = "";
                populateNameSpaceAttributes( nd,
                    root); // populate namespace attributes
                inputElementFound = populateImportsAndElements(importNamespaces, xsdDoc, root,
                    nd.getChildNodes(),inputMsg); // populate Imports and elements from original name
                // If main schema is already found or if main schema is not found still
                // then we will prefix the schema name with path from corresponding targetNamespace
                if (foundMainSchema || !inputElementFound) {
                    NamedNodeMap nodeMap =
                        ((Element)xsdDoc.getDocumentElement()).getAttributes();
                    tempSchemaFilePostFix = getFileName(
                        nodeMap.getNamedItem("targetNamespace").getNodeValue());
                }else {
                    foundMainSchema = isMainSchema(rootNode, inputMsgPrefix, root);

                }
                // write to schema file on nfs
                writeToFile(xsdDoc, tempSchemaFilePostFix);
            }
        }
    }

    private boolean isMainSchema (Node rootNode, String inputMsgPrefix, Element root)
    {
        boolean foundMainSchema;
        String namespace = null;
        Node node = root.getAttributes().getNamedItem("xmlns:" + inputMsgPrefix);
        if (node != null) {
            namespace = node.getNodeValue();
        }
        String rootNameSpace = rootNode.getAttributes().getNamedItem("xmlns:"
            + inputMsgPrefix).getNodeValue();
        // Add missing namespace in the Main schema
        if (namespace == null && inputMsgPrefix != null) {
            root.setAttribute("xmlns:" + inputMsgPrefix,
                rootNode.getAttributes().getNamedItem("xmlns:"
                    + inputMsgPrefix).getNodeValue());
            foundMainSchema = true;
        }
        else if (namespace != null && namespace.equals(
            rootNameSpace)) { // match the nameSpace of schema with inputElement
            foundMainSchema = true;
        }
        else {
            foundMainSchema = false;
        }
        return foundMainSchema;
    }

    /**
     * This method will identify the root input element in the following way -
     * wsdl:defination --> wsdl:portType --> wsdl:operation --> wsdl:input --> message
     * This message.value will be root element in main schema.
     * @param element Element
     * @return inputMessage Node
     */
    private Node getInputMessageElement (Element element)
    {
        Node inputMessage = null;
        Node protoTypeNode = element.getElementsByTagName("wsdl:portType").item(0);
        NodeList nodePrototypeList = protoTypeNode.getChildNodes();
        for (int i= 0 ; i < nodePrototypeList.getLength();i++){
            if(nodePrototypeList.item(i).getNodeName().equals("wsdl:operation")){
                NodeList nodeList = nodePrototypeList.item(i).getChildNodes();
                for (int k=0 ;k < nodeList.getLength() ;k++){
                    Node inputNode = nodeList.item(k);
                    if(inputNode.getNodeName().equals("wsdl:input")) {
                        inputMessage =
                            inputNode.getAttributes().getNamedItem("message");
                    }
                }
            }
        }
        return inputMessage;
    }

    private boolean populateImportsAndElements (List<String> importNamespaces,
        Document xsdDoc, Element root, NodeList xsdNodes,String inputMsg) throws MalformedURLException
    {
        boolean inputElementFound = false;
        for (int j = 0; j < xsdNodes.getLength(); j++) {
            Node temp = xsdNodes.item(j);
            if (!temp.getNodeName().equals("xsd:import")) {
                Node toAdded = xsdDoc.importNode(temp, true);
                root.appendChild(toAdded);
                if( temp.getNodeName().equals("xsd:element")) {
                    inputElementFound = isInputElement(inputMsg, temp);
                }
            }
            else {
                // collect all the import namespaces
                NamedNodeMap namedNodeMap = temp.getAttributes();
                for (int k = 0; k < namedNodeMap.getLength(); k++) {
                    Node attrNode = namedNodeMap.item(k);
                    String attrName = attrNode.getNodeName();
                    String attrValue = attrNode.getNodeValue();
                    if (attrName.equals("namespace")) {
                        if (logger.isDebugEnabled())
                            logger.debug(
                                "Attribute name : {} and value : {} added to the import name space list",
                                attrName,
                                attrValue);
                        if (importNamespaces == null)
                            importNamespaces = new ArrayList<>();
                        importNamespaces.add(attrValue);
                        Node toAdded = xsdDoc.importNode(temp, true);
                        String fileName = getFileName(attrValue);
                        ((Element)toAdded).setAttribute("schemaLocation",
                            objectName + fileName + (senderBusinessSystemId == null ?
                                "" :
                                "_" + senderBusinessSystemId) + SCHEMA_FILE_TYPE);
                        root.appendChild(toAdded);
                    }
                }
            }
        }
        return inputElementFound;
    }

    /**
     * Return boolean true if input element is found as root element in schema
     * else false if not found.
     * @param inputElement
     * @param temp
     * @return  boolean
     */
    private boolean isInputElement (String inputElement, Node temp)
    {
        boolean inputElementFound = false;
        if (temp.getAttributes() != null && temp.getAttributes().getNamedItem(
            "name") != null &&
            inputElement.equals(
                temp.getAttributes().getNamedItem(
                    "name").getNodeValue())) {
            // detected inoutElement
            inputElementFound = true;
        }
        return inputElementFound;
    }

    private String getFileName (String attrValue) throws MalformedURLException
    {
        URL url = new URL(attrValue);
        String fileName = url.getFile();
        fileName = fileName.replace("/", "_");
        return fileName;
    }

    private void populateNameSpaceAttributes ( Node nd, Element root)
    {
        if (nd.hasAttributes()) {
            NamedNodeMap namedNodeMap = nd.getAttributes();
            for (int j = 0; j < namedNodeMap.getLength(); j++) {
                Node attrNode = namedNodeMap.item(j);
                String attrName = attrNode.getNodeName();
                String attrValue = attrNode.getNodeValue();
                if (attrName.equals("targetNamespace")) {
                    root.setAttribute(attrName, attrValue);
                    continue;
                }
                logger.info("Attribute " + attrName + " " + attrValue);
                // Adding :n0 because the serializer is removing the default namespace attribute
                // Thjs will be removed before persisting data to nfs
                if (attrName.equals("xmlns")) {
                    root.setAttribute("xmlns:n0", attrValue);
                }
                else {
                    root.setAttribute(attrName, attrValue);
                }
            }
        }
    }

    private void writeToFile (Document document, String tempSchemaFileName)
        throws TransformerFactoryConfigurationError,
        TransformerException,
        IOException
    {
        StringWriter wr = new StringWriter();
        String xsd = null;

        try {

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = transformerFactory.newTransformer();
            transformer.transform(new DOMSource(document), new StreamResult(wr));

            xsd = wr.toString();
            xsd = xsd.replace("xmlns:n0", "xmlns");  // change to default namespace

            String normalizedtempSchemaFilePath = FilenameUtils.normalize(
                this.tempSechemDirPath + objectName + tempSchemaFileName + (
                    senderBusinessSystemId == null ?
                        "" :
                        "_" + senderBusinessSystemId) + SCHEMA_FILE_TYPE);

            File xsdFile = new File(normalizedtempSchemaFilePath);
            if (xsdFile != null) {
                File parentDir = new File(xsdFile.getParent());
                if (!parentDir.exists()) {
                    boolean success = parentDir.mkdirs();
                    if (!success) {
                        logger.warn("parentDir.mkdirs() call failed");
                    }
                }
            }
            try (FileOutputStream fo1 = new FileOutputStream(xsdFile)) {
                fo1.write(xsd.getBytes("UTF-8"));
                fo1.flush();
            }
        } catch (IOException e) {
            logger.error(e.getMessage());
            throw e;
        }
    }

    public static DocumentBuilder getDocBuilder () throws ParserConfigurationException
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(true);
        String FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
        factory.setFeature(FEATURE, true);

        FEATURE = "http://xml.org/sax/features/external-general-entities";
        factory.setFeature(FEATURE, false);

        FEATURE = "http://xml.org/sax/features/external-parameter-entities";
        factory.setFeature(FEATURE, false);

        FEATURE = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
        factory.setFeature(FEATURE, false);

        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        DocumentBuilder builder = factory.newDocumentBuilder();
        return builder;
    }

    public void generateRNGSchemaFromWSDL () throws IOException,
        SAXException,
        ParserConfigurationException,
        TransformerFactoryConfigurationError,
        TransformerException
    {
        String wsdlFile = this.filename;
        Grammar g = null;
        String tempSchemaFileName = null;
        String rngFileGenerated = null;

            String normalizedFilePath = FilenameUtils.normalize(wsdlFile);
            File file = new File(normalizedFilePath);

            try (FileInputStream fi = new FileInputStream(file)) {
                tempSchemaFileName = tempSechemDirPath + objectName + (
                                senderBusinessSystemId == null ?
                                                "" :
                                                "_" + senderBusinessSystemId) + SCHEMA_FILE_TYPE;

                createParentDir(
                                tempSchemaFileName); // This will create a temp object dir if not present

                wsdlToXSD(fi);
            }

            SAXParserFactory factory = SAXParserFactory.newInstance();
            factory.setNamespaceAware(true);
            g = GrammarLoader.loadSchema(
                tempSchemaFileName,
                new DebugController(true, true, System.err),
                factory);

            if (g == null) {
                InputSource inRng = ValidationDriver.fileInputSource(tempSchemaFileName);

                g = GrammarLoader.loadSchema(inRng);
            }

            if (objectName != null) {
                rngFileGenerated = tempSechemDirPath + objectName + (
                    senderBusinessSystemId == null ?
                        "" :
                        "_" + senderBusinessSystemId) + RNG_FILE_TYPE;
            }

            if (g != null) {
                try (FileOutputStream fo2 = new FileOutputStream(new File(FilenameUtils.normalize(rngFileGenerated)))) {
                    writeGrammar(g,
                                 fo2);
                    fo2.flush();
                    // generateObjectMetadata(xsdFile);   
                }
                catch (SAXException | IOException e) {
                    throw e;
                }
            }
            else {
                logger.info("Grammar is null");
            }


            // rename the wsdl file having operation name
            try {
                Boolean fileRenamed = file.renameTo(
                    new File(
                        this.baseDir + "/" + WSDL_DIR + "/" + objectName
                            + (senderBusinessSystemId == null ? ""
                                : "_" + senderBusinessSystemId) + (this.wsdlUploadTime != 0 ? DOUBLE_HASH + this.wsdlUploadTime : "")
                            + WSDL_FILE_TYPE));
                if (!fileRenamed) {
                    throw new Exception("Unable to rename file");
                }
            }
            catch (Exception e) {
                logger.error(e.getMessage());
            }

            //this.setWsdlUploadPath(this.baseDir + "/" + WSDL_DIR + "/" + objectName +
            //        (senderBusinessSystemId == null ?
            //                "" :
            //                "_" + senderBusinessSystemId) + DOUBLE_HASH + this.wsdlUploadTime
            //        + WSDL_FILE_TYPE);

}

    private void createParentDir (String tempSchemaFileName)
    {
        String normalizedtempSchemaFileName = FilenameUtils.normalize(
            tempSchemaFileName);

        File xsdFile = new File(normalizedtempSchemaFileName);
        if (xsdFile != null) {
            File parentDir = new File(xsdFile.getParent());
            if (!parentDir.exists()) {
                boolean success = parentDir.mkdirs();
                if (!success) {
                    logger.warn("parentDir.mkdirs() call failed");
                }
            }
        }
    }

    /**
     * Writes a grammar to the specified output.
     */
    public static void writeGrammar (Grammar g, OutputStream out) throws SAXException
    {
        RELAXNGWriter writer = new RELAXNGWriter();
        writer.setDocumentHandler(
           new XMLSerializer(out, new OutputFormat("xml", null, true)));
        writer.write(g);
    }
}
