package com.sap.ariba.erpintegration.service.cap;

import com.sap.ariba.erpintegration.mdi.common.resource.request.RequestContext;
import com.sap.ariba.erpintegration.mdi.exception.PersistenceException;
import com.sap.ariba.erpintegration.mdi.cap.resource.manager.MdsCapEntityResourceManager;
import com.sap.ariba.erpintegration.mdi.mds.exception.PublishException;
import com.sap.ariba.erpintegration.service.exception.TransientWebClientResponseException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import org.apache.http.HttpStatus;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.client.HttpResponseException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.net.ConnectException;
import java.util.HashMap;
import java.util.Map;

@Component
@Qualifier("mdsCapEntityBatchResourceManager")
public class MdsCapEntityBatchResourceManager extends MdsCapEntityResourceManager
{
    public static final String INSERTED_KEY = "inserted";
    public static final String UPDATED_KEY = "updated";
    public static final String DELETED_KEY = "deleted";
    public static final String COUNT_KEY = "count";
    public static final String ERROR = "error";
    public static final String ERROR_INFO = "errorInfo";

    public Map<String, Object> load (RequestContext requestContext) throws PersistenceException
    {
        Map<String, Object> response = new HashMap<>();
        try {
            response = super.publishToMDS(requestContext);
            if (!response.containsKey(INSERTED_KEY) || !response.containsKey(UPDATED_KEY)
                || !response.containsKey(DELETED_KEY)) {
                throw new PersistenceException(
                    requestContext.getEntity() + " could not be loaded in MDCS");
            }
        } catch (PublishException ex) {
            throwAppropriateException(ex);
        }
        return response;
    }

    /**
     * This method checks if the specified exception is a transient HTTP
     * exception (HTTP status code 503 or 504). If yes, it throws a
     * {@link TransientWebClientResponseException} using which the
     * operation can be retried. In all other cases, it wraps the specified
     * exception in a {@link PersistenceException} and throws it
     *
     * @param ex
     * @throws TransientWebClientResponseException, PersistenceException
     */
    public void throwAppropriateException (PublishException ex) throws
        TransientWebClientResponseException,
        PersistenceException
    {
        Throwable throwable = ExceptionUtils.getRootCause(ex);
        if (ExceptionUtils.indexOfType(throwable, HttpResponseException.class) != -1) {
            HttpResponseException httpException = (HttpResponseException) throwable;
            int httpStatusCode = httpException.getStatusCode();
            // Check if we have a transient http exception
            if (HandlerUtil.isTransientHttpErrorCode(httpStatusCode)) {
                throw new TransientWebClientResponseException(httpException.getStatusCode(),
                    httpException.getReasonPhrase());
            }
        }
        else if (ExceptionUtils.indexOfType(throwable, ConnectException.class) != -1) {
            throw new TransientWebClientResponseException(HttpStatus.SC_SERVICE_UNAVAILABLE,
                "Connection refused");
        }
        throw new PersistenceException(ex);
    }
}
