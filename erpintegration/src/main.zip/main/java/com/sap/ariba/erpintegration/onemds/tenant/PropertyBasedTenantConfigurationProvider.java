package com.sap.ariba.erpintegration.onemds.tenant;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.onemds.exception.TenantConfigurationException;
import jakarta.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component("propertyBasedTenantConfigurationProvider")
@ConditionalOnExpression("${onemds.tenant.property.ariba.customer.based.configuration}==false")
public class PropertyBasedTenantConfigurationProvider
    extends AbstractTenantConfigurationProvider
{
    private static final Logger logger = LoggerFactory.getLogger(
        PropertyBasedTenantConfigurationProvider.class);

    @Value("${onemds.tenant.configuration}")
    private String tenantConfigurationStr;

    @Autowired
    private ObjectMapper simpleObjectMapper;

    @PostConstruct
    public void initialize ()
    {
        if (!StringUtils.isEmpty(tenantConfigurationStr)) {
            try {
                TypeReference<Map<String, Map<String, String>>> type = new TypeReference<Map<String, Map<String, String>>>()
                {
                };
                tenantConfigurationDetails = simpleObjectMapper.readValue(tenantConfigurationStr,
                    type);
                logger.info("tenantConfigurationDetails - {}" , tenantConfigurationDetails);
            }
            catch (JsonProcessingException e) {
                logger.error(
                    "Error while parsing tenant configuration string - {}",
                    tenantConfigurationStr,
                    e);
            }
        }
    }

    @Override
    protected void loadConfiguration (String tenantID) throws TenantConfigurationException
    {
        if (!StringUtils.isEmpty(tenantConfigurationStr)) {
            try {
                TypeReference<Map<String, Map<String, String>>> type = new TypeReference<Map<String, Map<String, String>>>()
                {
                };
                Map<String, Map<String, String>> configurationDetails = simpleObjectMapper.readValue(tenantConfigurationStr,
                    type);

                if (configurationDetails.containsKey(tenantID)) {
                    this.tenantConfigurationDetails.put(tenantID,
                        configurationDetails.get(tenantID));
                }
                else {
                    logger.error(
                        "Unable to find tenant configuration to load for tenant - "
                            + tenantID);
                }
            }
            catch (JsonProcessingException e) {
                logger.error(
                    "Error while parsing tenant configuration string - {}",
                    tenantConfigurationStr,
                    e);
            }
        }
    }
}
