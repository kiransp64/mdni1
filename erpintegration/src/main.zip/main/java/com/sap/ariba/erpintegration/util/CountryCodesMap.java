package com.sap.ariba.erpintegration.util;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Created by c5259108 on 19/12/17.
 */
public class CountryCodesMap
{
    private static final Map<String,String> mapOfAlpha3ToAplpha2CountryCodes = new HashMap<>();

    static {
        popualteCountryCodesMap();
    }

    public static void popualteCountryCodesMap()
    {
        String[] countries = Locale.getISOCountries();
        for (String country : countries) {
            Locale locale = new Locale("", country);
            mapOfAlpha3ToAplpha2CountryCodes.put(locale.getISO3Country().toUpperCase(), locale.getCountry());
        }
    }

    public static String getAplha2CountryCode(String alpha3Code)
    {
        return mapOfAlpha3ToAplpha2CountryCodes.get(alpha3Code);
    }
}

