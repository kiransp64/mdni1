/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.application;

import com.sap.ariba.erpintegration.monitor.application.model.ApplicationData;
import com.sap.ariba.erpintegration.monitor.exception.IntegrationMonitoringException;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.util.IMConstants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.integrationmonitoring.bean.ApplicationMonitoringBean;
import com.sap.ariba.integrationmonitoring.bean.IntegrationMonitoringBean;
import com.sap.ariba.integrationmonitoring.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.ERROR_DETAIL;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.ERROR_MESSAGE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.GROUP_ENTITY;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.HTTP;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INTEGRATION_CHANNEL;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INTEGRATION_CHANNEL_DISPLAY;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MASTER_DATA_OBJECT_TYPE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI_IM_CRITICAL;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.SCIM_DISPLAY_NAME;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.SCIM_REQUEST_TYPE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.TENANT_ID_DATA;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.TENANT_ID_DISPLAY;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.USER_ENTITY;
import static com.sap.ariba.erpintegration.monitor.im.util.IMLogMessage.IM_INVALID_INPUT;
import static com.sap.ariba.integrationmonitoring.bean.ApplicationMonitoringBean.ValueSizeLimitInBytes;

/**
 * This class will set Application data related to SCIM api.
 */
@Slf4j
@ConditionalOnExpression(IMConstants.INTEGRATION_MONITORING_ENABLE)
@Component(value = "scimApplicationContextDataHandler")
public class ScimApplicationContextDataHandler implements ApplicationContextDataHandler
{
    /**
     * @param integrationContext
     * @param imMonData
     * @throws IntegrationMonitoringException
     */
    @Override
    public void addApplicationData (IntegrationContext integrationContext,
                                    IntegrationMonitoringBean imMonData)
                    throws IntegrationMonitoringException
    {
        if (null != integrationContext && null != imMonData) {
            List<ApplicationData> applicationDataList = new ArrayList<>();
            setCommonApplicationData(integrationContext,
                                     applicationDataList);
            addTenantIdToApplicationData(integrationContext,
                                         applicationDataList);
            try {
                if (!applicationDataList.isEmpty()) {
                    for (ApplicationData appData : applicationDataList) {
                        ApplicationMonitoringBean appMonData = buildApplicationMonitoringBean(appData);
                        addApplicationContextToIntegrationMonitoringBean(imMonData,
                                                                         appMonData);
                    }
                }
            }
            catch (Exception exp) {
                log.error("{}, Event Name - {} , Exception - {}, while adding Application context data to IM Monitoring bean.",
                          MDNI_IM_CRITICAL,
                          integrationContext.getEventName(),
                          ErrorUtil.getCompleteCausedByErrors(exp));
                throw new IntegrationMonitoringException(
                                "Exception while forming application context to IM monitoring bean "
                                                + integrationContext.getEventName().getEventName(),
                                exp);
            }
        }

    }

    @Override
    public List<ApplicationMonitoringBean> buildLogEntries (IntegrationContext integrationContext)
    {
        return null;
    }

    /**
     * Setting common application data of SCIM
     *
     * @param integrationContext
     * @param applicationDataList
     */
    public void setCommonApplicationData (IntegrationContext integrationContext,
                                          List<ApplicationData> applicationDataList)
    {
        ApplicationData appDataForObjectType = new ApplicationData(MASTER_DATA_OBJECT_TYPE,
                                                                   MASTER_DATA_OBJECT_TYPE,
                                                                   integrationContext.getObjectName(),
                                                                   ApplicationMonitoringBean.Classification.CONTEXT,
                                                                   ApplicationMonitoringBean.ValueType.SIMPLE);
        applicationDataList.add(appDataForObjectType);
        ApplicationData appDataForResourceOperation = new ApplicationData(SCIM_REQUEST_TYPE,
                                                                          SCIM_REQUEST_TYPE,
                                                                          ObjectUtils.isNotEmpty(integrationContext.getOperation()) ?
                                                                                          integrationContext.getOperation()
                                                                                                          .toString() :
                                                                                          "",
                                                                          ApplicationMonitoringBean.Classification.CONTEXT,
                                                                          ApplicationMonitoringBean.ValueType.SIMPLE);
        applicationDataList.add(appDataForResourceOperation);
        ApplicationData appDataForDisplayName = new ApplicationData(SCIM_DISPLAY_NAME,
                                                                    SCIM_DISPLAY_NAME,
                                                                    integrationContext.getDisplayName(),
                                                                    ApplicationMonitoringBean.Classification.CONTEXT,
                                                                    ApplicationMonitoringBean.ValueType.SIMPLE);
        appDataForDisplayName.setPersonalData(true);
        applicationDataList.add(appDataForDisplayName);
        ApplicationData appDataForIntegrationChannel = new ApplicationData(INTEGRATION_CHANNEL,
                                                                           INTEGRATION_CHANNEL_DISPLAY,
                                                                           HTTP,
                                                                           ApplicationMonitoringBean.Classification.MESSAGE,
                                                                           ApplicationMonitoringBean.ValueType.SIMPLE);
        applicationDataList.add(appDataForIntegrationChannel);
        if (integrationContext.getIsError()) {
            String errorMsg = integrationContext.getErrorMessage();
            //since IM is not allowing more than 5000 char, we are logging it here.
            if (StringUtils.isNotEmpty(errorMsg)) {
                if (errorMsg.length() > ValueSizeLimitInBytes) {
                    log.warn(String.format(IM_INVALID_INPUT.getLogMessage(),
                                           integrationContext.getEventName(),
                                           ERROR_MESSAGE,
                                           ValueSizeLimitInBytes,
                                           errorMsg.length()));
                    errorMsg = CommonUtil.trimLength(errorMsg,
                                                     ValueSizeLimitInBytes);
                }
                ApplicationData appDataForError = new ApplicationData(ERROR_MESSAGE,
                                                                                ERROR_DETAIL,
                                                                                errorMsg,
                                                                                ApplicationMonitoringBean.Classification.MESSAGE,
                                                                                ApplicationMonitoringBean.ValueType.SIMPLE);
                appDataForError.setPersonalData(true);//setting personal data as true for scim related error message
                applicationDataList.add(appDataForError);
            }
        }
    }

    /**
     * SCIM only supports objects are User and Groups , so will consider all the error message as personal data.
     *
     * @param integrationContext
     * @return true
     */
    @Override
    public boolean shouldConsiderErrorAsPersonalData (IntegrationContext integrationContext)
    {
        return true;
    }
}
