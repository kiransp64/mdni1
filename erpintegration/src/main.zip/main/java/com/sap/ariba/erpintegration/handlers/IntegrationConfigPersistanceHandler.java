package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.mdi.common.util.DateUtil;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.ConfigRepository;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.dao.TenantRepository;
import com.sap.ariba.erpintegration.persistence.model.IntegrationConfig;
import com.sap.ariba.erpintegration.persistence.model.Tenant;
import com.sap.ariba.erpintegration.persistence.service.BaseIdServiceImpl;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by i318483 on 05/06/17.
 */
public class IntegrationConfigPersistanceHandler extends RequestHandler
{
    public static final String KeyFieldKey = "key";
    public static final String KeyValueKey = "value";

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.IntegrationConfigPersistanceHandler";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);
    private static final String KeyParentAnId = "parent";
    private static final String KeyRealmName = "realm";
    private static final String KeyWeight = "weight";
    private static final String KeyIsFeatureDisabled = "isFeatureDisabled";
    private static final String KeyDisabledRealms = "DisabledRealms";
    private static final String KeyMdiEnabled = "mdiEnabled";
    private static final String KeyMdiConfigTimeUpdated = "TimeUpdated";

    /**
     * Key - should be sent in request as 'CallbackURL'
     * value - is the actual call back URL.
     * Based on the anId passed in the request get check if Entry exists in CONFIGTAB table. If record doesn't exist create one.
     *
     * @param request
     * @return
     * @throws IntegrationServiceException
     */
    @Override
    public Response execute(HttpServletRequest request) throws IntegrationServiceException
    {
        logger.info(" IntegrationConfigPersistanceHandler:processConfigData");

        if (!super.isRequestAuthorized(request)) {
            return Response.status(HttpServletResponse.SC_UNAUTHORIZED).build();
        }

        String key = request.getHeader(KeyFieldKey);
        final boolean isFeatureDisabled = Boolean.valueOf(request.getParameter(KeyIsFeatureDisabled));
        if (isFeatureDisabled) {
            return handleFeatureDisablement(request.getParameter(KeyDisabledRealms), key);
        }
        String value = request.getHeader(KeyValueKey);
        String anId = request.getParameter(Constants.KeyTenantId);
        String parentAnId = request.getParameter(KeyParentAnId);
        String realmName = request.getParameter(KeyRealmName);
        String weight = request.getParameter(KeyWeight);
        String mdiEnabled = request.getHeader(KeyMdiEnabled);
        String mdiConfigTimeUpdatedStr = request.getHeader(KeyMdiConfigTimeUpdated);
        Date mdiConfigTimeUpdated = null;
        try {
            mdiConfigTimeUpdated = DateUtil.parseDate(mdiConfigTimeUpdatedStr,
                "yyyy-MM-dd HH:mm:ss", null);
        }
        catch (ParseException e) {
            logger.error(
                "Could not parse the mdi config time updated value. Original Value : {}",
                mdiConfigTimeUpdatedStr);
        }

        logger.info(
            "[Tenant_Config][Persistance] anId : {}, realmName : {}, weight : {}, MDI Enabled - {}, MDI Config Time Updated - {}",
            anId, realmName, weight, mdiEnabled, mdiConfigTimeUpdated);
        if (StringUtils.isEmpty(anId) || StringUtils.isEmpty(realmName)
            || StringUtils.isEmpty(weight))
        {
            throw new IntegrationServiceException(
                "Not a valid request. an id, realm name or weight missing");
        }

        try {
            DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            TenantRepository tenantDAO = (TenantRepository)factory.getMiscDAO(ObjectTypes.Tenant.getValue());
            ConfigRepository dao = (ConfigRepository) factory.getMiscDAO(ObjectTypes.IntegrationConfig.getValue());

            Tenant tenant = tenantDAO.findOne(anId);
            long tenantId = -1;
            if(tenant != null && HandlerUtil.KeyCallbackURL.equals(key)) {
                tenantId = tenant.getTenantId();
                IntegrationConfig existingConfig = dao.findOne(tenantId, key);
                if (existingConfig != null && Boolean.parseBoolean(
                    tenant.getMdiEnabled()))
                {
                    String existingValue = existingConfig.getValue();
                    if (!existingValue.equals(value)) {
                        logger.error(
                            """
                            [Tenant_Config][Persistance] There is already a tenant registered with MDI enabled and different call back URL for AN ID - {},\
                             with tenant ID - {}, \
                            and call back URL - {}, URL passed - {}\
                            """, anId,
                            tenantId, existingValue, value);
                        throw new IntegrationServiceException(
                            "There is already a tenant registered with MDI enabled and different call back URL.");
                    }
                }
            }
            tenantId = tenant == null ?
                getTenantIdWithCreate(anId, parentAnId, realmName, weight, mdiEnabled,
                                      mdiConfigTimeUpdated) :
                getTenantIdWithUpdate(anId, parentAnId, realmName, weight, mdiEnabled,
                                      mdiConfigTimeUpdated, tenant);

            IntegrationConfig config = dao.findOne(tenantId, key);
            if (config == null) {
                config = new IntegrationConfig();
                config.setId(getBaseId(tenantId, ObjectTypes.IntegrationConfig.getValue()));
                config.setDateCreated(new Date());
                config.setKey(key);
                config.setValue(value);
                config.setDateUpdated(new Date());
                config.setTenantId(tenantId);
            } else if(!value.equals(config.getValue())) {
                logger.info("value : {}, config.getValue() : {}", value, config.getValue());
                config.setKey(key);
                config.setValue(value);
                config.setDateUpdated(new Date());
                config.setTenantId(tenantId);
            }
            config.setIsActive(1);
            dao.save(config);
        } catch (InvalidTypeCodeException ie) {
            throw new IntegrationServiceException(ie.getMessage());
        }
        return Response.status(HttpServletResponse.SC_OK).build();
    }

    private String getBaseId (long variantId, String objectName) throws
        InvalidTypeCodeException
    {
        BaseIdServiceImpl service = BaseIdServiceImpl.getInstance();
        return service.allocateBaseId(objectName, variantId);
    }

    private long getTenantIdWithCreate (String anId,
                                        String parentAnId,
                                        String realmName,
                                        String weight,
                                        String mdiEnabled,
                                        Date mdiConfigTimeUpdated)
    throws IntegrationServiceException
    {
        long tenantId = -1;
        try{
            DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            TenantRepository dao = (TenantRepository)factory.getMiscDAO(ObjectTypes.Tenant.getValue());
            Tenant tenant = new Tenant();
            tenantId = Utility.getTenantId(anId);
            tenant.setId(getBaseId(tenantId, ObjectTypes.Tenant.getValue()));
            tenant.setDateCreated(new Date());
            tenant.setDateUpdated(new Date());
            tenant.setTenantId(tenantId);
            tenant.setAnId(anId);
            tenant.setRealmName(realmName);
            tenant.setParentAnId(parentAnId);
            Double weightDouble = Double.valueOf(weight);
            tenant.setWeight(weightDouble);
            tenant.setIsActive(1);
            //Default value of mdiEnabled will be NULL.
            if (StringUtils.equals(mdiEnabled, Constants.MDI_ENABLED_VALUE)
                || StringUtils.equals(mdiEnabled, Constants.MDI_DISABLED_VALUE))
            {
                tenant.setMdiEnabled(mdiEnabled);
                if(mdiConfigTimeUpdated != null) {
                    tenant.setMdiConfigTimeUpdated(mdiConfigTimeUpdated);
                }
            }
            dao.save(tenant);
        }catch (InvalidTypeCodeException ie) {
            logger.warn("[Tenant_Config][Persistance] Exception {} while getting the tenant ID for AN ID - {}",
                        ErrorUtil.getCompleteCausedByErrors(ie),
                        anId);
            throw new IntegrationServiceException(ie.getMessage());
        }
        return tenantId;
    }

    private long getTenantIdWithUpdate (String anId,
                                        String parentAnId,
                                        String realmName,
                                        String weight,
                                        String mdiEnabled,
                                        Date mdiConfigTimeUpdated,
                                        Tenant tenant) throws IntegrationServiceException
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository)factory.getMiscDAO(ObjectTypes.Tenant.getValue());
        long tenantId = tenant.getTenantId();
        if (tenant.getRealmName() == null || tenant.getWeight() == null ||
            !tenant.getRealmName().equals(realmName))
        {
            logger.info(
                "[Tenant_Config][Persistance] old realm in MDNI. Updating weight : {}, realm name : {} and parent an id : {} for an id : {}. tenant.getRealmName() : {}",
                weight,
                realmName,
                parentAnId,
                anId,
                tenant.getRealmName());
            tenant.setRealmName(realmName);
            tenant.setParentAnId(parentAnId);
            Double weightDouble = Double.valueOf(weight);
            tenant.setWeight(weightDouble);
        }
        tenantId = tenant.getTenantId();
        tenant.setIsActive(1);
        //Default value of mdiEnabled will be NULL.
        if (StringUtils.equals(mdiEnabled, Constants.MDI_ENABLED_VALUE)
            || StringUtils.equals(mdiEnabled, Constants.MDI_DISABLED_VALUE))
        {
            tenant.setMdiEnabled(mdiEnabled);
            if(mdiConfigTimeUpdated != null) {
                tenant.setMdiConfigTimeUpdated(mdiConfigTimeUpdated);
            }
        }
        dao.save(tenant);
        return tenantId;
    }

    /**
     * Feature disablement involves 3 steps:
     * <br /> 1. Deactivating tenant
     * <br /> 2. Deactivating tenant configuration
     * <br /> 3. Setting all pending staged XMLs of the tenant to 'DISCARDED' state
     */
    private Response handleFeatureDisablement (String disabledANIdsString, String key)
    {
        List<String> disabledANIds = Arrays.asList(StringUtils.split(
            disabledANIdsString,
            ","));
        if (CollectionUtils.isEmpty(disabledANIds)) {
            return Response.status(HttpServletResponse.SC_BAD_REQUEST).entity(
                "ANIDs missing in the request").build();
        }
        final DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        final TenantRepository tenantDao = (TenantRepository)factory.getMiscDAO(
            ObjectTypes.Tenant.getValue());
        List<Long> disabledTenantIds = tenantDao.getTenantIds(disabledANIds);
        EntityManager em = null;
        try {
            logger.info(
                "Attempting to deactivate tenants with ANIDs : {}",
                disabledANIdsString);
            // Begin transaction
            EntityManagerFactory emf = ApplicationContextProvider.getApplicationContext().getBean(
                EntityManagerFactory.class);
            em = emf.createEntityManager();
            em.getTransaction().begin();
            // 1. Deactivate tenants
            final int tenantUpdated = tenantDao.deactivateTenants(disabledTenantIds);
            final ConfigRepository configDao = (ConfigRepository)factory.getMiscDAO(
                ObjectTypes.IntegrationConfig.getValue());
            // 2. Deactivate tenants' configuration
            final int configUpdated = configDao.deactivateConfigurations(
                disabledTenantIds,
                key);
            final GenericDAOStageData stageXMLDao = factory.getGenericDAOStageData(
                ObjectTypes.XmlPayload.getValue());
            // 3. Set all 'PENDING' and 'NEEDSREPROCESSING' staged XMLs of the tenants to 'DISCARDED' state
            final List<Integer> statuses = Arrays.asList(
                StagingTableStatus.PENDING.getValue(),
                StagingTableStatus.NEEDSREPROCESSING.getValue());
            final int stageUpdated = stageXMLDao.updateStatusForTenants(
                StagingTableStatus.DISCARDED.getValue(),
                disabledTenantIds,
                statuses,
                new Date());
            // Commit transaction
            em.getTransaction().commit();
            logger.debug(
                "Number of tenants deactivated: {} ({})",
                tenantUpdated,
                disabledANIdsString);
            logger.debug(
                "Number of configurations deactivated: {} ({})",
                configUpdated,
                disabledANIdsString);
            logger.debug(
                "Number of unprocessed StageXMLs moved to '{}' state: {}",
                StagingTableStatus.DISCARDED,
                stageUpdated);
            logger.info("Deactivated tenants with ANIDs : {}", disabledANIdsString);
        }
        finally {
            if (em != null) {
                em.close();
            }
        }
        return Response.status(HttpServletResponse.SC_OK).build();
    }
}
