package com.sap.ariba.erpintegration.persistence.model;

import org.json.simple.JSONObject;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.io.Serializable;
import java.util.Map;

@Entity
@Table(name="UOMCODE_TAB")
@DiscriminatorValue("b")

public class UnitOfMeasurement
        extends GenericEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final String objectType = "UnitOfMeasurement";

    @Column(name="Code")
    private String Code;

    @Transient
    private static String[] lookupFields = {"Code"};

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    @Override
    public void setLookupFields (Map<String, String> lookupDetails)
    {
        Object specialField1 = lookupDetails.get(lookupFields[0]);
        setCode((String) specialField1);
    }

    @Override
    public String getObjectType()
    {
        return objectType;
    }

    @Override
    public void processCountryCode(JSONObject jsonObject){}
}
