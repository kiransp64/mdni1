package com.sap.ariba.erpintegration.audit;

/**
 * This enum holds the id and name of all the audit operations happening from
 * ERP side, Buyer side and native integration side, inspector side. These operations are only
 * for the interfaces.
 * 
 * @author i339952
 */
public enum Operation {
    DATA_UPLOAD(1, "dataUpload"), PROCESS_CONFIG_DATA(2, "processConfigData"),
    PROCESS_INTEGRATION_DATA(3, "processIntegrationData"),
    PROCESS_XML_DATA(4, "processXMLData"), RESET_STAGE_XML(5, "resetStageXML"),
    WSDL_UPLOAD(6, "wsdlUpload"),
    GET_INTEGRATION_JOB_LOG(7, "getIntegrationJobs"),
    PURGE_XML_DATA(8, "dataPurgeJob"),
    DOWNLOAD_PAYLOAD_INSPECTOR_ACTION(9, "donwnload_payload_inspector_action");

    private long operationId;
    private String operationName;

    Operation (long operationId, String operationName)
    {
        this.operationId = operationId;
        this.operationName = operationName;
    }

    public long getOperationId ()
    {
        return operationId;
    }

    public void setOperationId (long operationId)
    {
        this.operationId = operationId;
    }

    public String getOperationName ()
    {
        return operationName;
    }

    public void setOperationName (String operationName)
    {
        this.operationName = operationName;
    }
}
