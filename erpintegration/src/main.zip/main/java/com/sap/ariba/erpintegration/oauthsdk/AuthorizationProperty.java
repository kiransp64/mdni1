package com.sap.ariba.erpintegration.oauthsdk;

import com.ariba.matrix.oauth.sdk.AuthorizationServerProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthorizationProperty implements AuthorizationServerProperty {
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.oauthsdk.AuthorizationProperty";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);
        
    public static final long CACHE_SIZE = 10000L;

    @Deprecated
    public String getFrontDoorUrl() {
        return "https://svcgcpmbdev1mobile.lab-us.gcpint.ariba.com";
    }

    @Override
    public String getClientId() {
        return "";
    }

    @Override
    public String getPublicSecret() {
        return "";
    }

    @Override
    public String getPrivateSecret() {
        return "";
    }

    @Override
    public Long get2LHeap(){
        return CACHE_SIZE;
    }

    @Override
    public Long get3LHeap(){
        return CACHE_SIZE;
    }

    @Override
    public Long get2LDisk(){
        return CACHE_SIZE;
    }

    @Override
    public Long get3LDisk(){
        return CACHE_SIZE;
    }
}
