package com.sap.ariba.erpintegration.mdi.common;

import com.sap.ariba.mdsclient.connection.PoolingHttpClientConnectionManagerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ConnectionConfig implements DisposableBean
{
    @Value("${mdi.connection.pool.maxConnections}")
    private int maxConnections;
    @Value("${mdi.connection.pool.maxPerRoute}")
    private int maxPerRoute;

    private Logger logger = LoggerFactory.getLogger(ConnectionConfig.class);

    private PoolingHttpClientConnectionManagerImpl httpClientConnectionManager;

    @Bean(name = "mdsRestTemplate")
    public RestTemplate mdsRestTemplate ()
    {
        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
        logger.info("""
            Initialized HTTP Client Pool with maxConn:{}, \
            maxPerRoute:{}\
            """, maxConnections, maxPerRoute);
        return restTemplate;
    }

    public HttpComponentsClientHttpRequestFactory clientHttpRequestFactory ()
    {
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory =
            new HttpComponentsClientHttpRequestFactory();
        httpClientConnectionManager =
            new PoolingHttpClientConnectionManagerImpl(maxConnections,
            maxPerRoute);
        clientHttpRequestFactory.setHttpClient(httpClientConnectionManager.getClient());
        return clientHttpRequestFactory;
    }

    @Override
    public void destroy ()
    {
        logger.info("Shutting down MDNI Connection Manager");
        if (httpClientConnectionManager != null) {
            httpClientConnectionManager.shutdown();
        }
        logger.info("Shut down MDNI Connection Manager");
    }
}
