package com.sap.ariba.erpintegration.cache;

public interface LookUpValueCache
{
    public String get (String key);

    public String put (String key, String value);

    public boolean containsKey (String key);

}
