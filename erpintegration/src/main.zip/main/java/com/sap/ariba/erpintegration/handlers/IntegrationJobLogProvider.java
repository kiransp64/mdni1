package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.audit.AuditManagerImpl;
import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.persistence.model.AggregatedIntegrationJobLogResults;
import com.sap.ariba.erpintegration.persistence.model.IntegrationJobLog;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationJobLogProviderException;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.IntegrationJobLogUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.MissingServletRequestParameterException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;
import java.util.Arrays;
import java.util.List;

public class IntegrationJobLogProvider extends RequestHandler
{
    public static final String STATUS = "Status";
    public static final String START_DATE = "StartDate";
    public static final String END_DATE = "EndDate";
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.util.IntegrationJobLogUtil";
    public static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    public static final String characterEncoding = "UTF-8";
    public static final String WARNINGS = "Warnings";
    public static final String FATAL_ERRORS = "FatalErrors";
    public static final String NON_FATAL_EXCEPTIONS = "NonFatalExceptions";
    public static final String RECORDS_INSERTED = "RecordsInserted";
    public static final String RECORDS_UPDATED = "RecordsUpdated";
    public static final String RECORDS_DELETED = "RecordsDeleted";
    private static boolean auditEnabled = Boolean.TRUE;
    private long tenantId;
    private String externalTenantId;
    private String objectName;
    private String jobId;
    private static final List<String> listOfObjectNames = Arrays.asList("Incoterms",
        "PurchasingGroup",
        "PurchasingOrg",
        "PlantPurchasingOrg",
        "WBSElement",
        "TaxCode",
        "PurchaseDocumentItemCategory",
        "Plant",
        "CompanyCode",
        "GLAccount",
        "ExchangeRate",
        "MaterialGroup",
        "InternalOrder",
        "CostCentre",
        "AccountAssignmentCategory",
        "FixedAsset",
        "PaymentTerms",
        "PaymentMethod",
        "UnitOfMeasurement",
        "Currency",
        "User",
        "ProcurementUnit",
        "Group",
        "Product",
        "Region",
        "AdjustmentType");

    @Override public Response execute (HttpServletRequest request) throws
        IntegrationServiceException,
        MissingServletRequestParameterException
        {
            return getIntegrationJobStatus(request.getParameter(Constants.KeyTenantId),
                request.getParameter(Constants.KeyJobId),
                request.getParameter(Constants.KeyObjectName));
        }

    public Response getIntegrationJobStatus (String anId, String integrationJobId, String objectName)
        throws MissingServletRequestParameterException, IntegrationServiceException
    {
        boolean tenantExists;
        JSONObject jsonObject = new JSONObject();
        String warningMessage, fatalErrors, nonFatalExceptions;
        StageXMLData stageXMLData;

        try {
            externalTenantId = anId;

            if (externalTenantId == null || StringUtils.isEmpty(externalTenantId)) {
                logger.error("Not a valid incoming request.TenantId is Missing");
                throw new MissingServletRequestParameterException(Constants.KeyTenantId, "String");
            }

            tenantExists = Utility.isTenantExists(externalTenantId);

            if (!tenantExists) {
                logger.error("Not a valid incoming request. Tenant {} not recognized",externalTenantId);
                throw new IntegrationServiceException(
                    "Not a valid incoming request. Tenant " + externalTenantId + " not recognized");
            }
            tenantId = Utility.getTenantId(externalTenantId);
            jobId = integrationJobId;
            if(!StringUtils.isEmpty(jobId)){
                if (auditEnabled) {
                    AuditManagerImpl.getInstance().logAudit(externalTenantId,
                        Operation.GET_INTEGRATION_JOB_LOG,
                        "get integration job logs started for Tenant :" + tenantId);
                }
                stageXMLData = IntegrationJobLogUtil.getStageXmlDataForJobId(jobId, tenantId);

                if(stageXMLData == null){
                    logger.error("No record in StageXMLDataTab for jobId {} and tenantId {}",
                        jobId,
                        externalTenantId);
                    throw new IntegrationServiceException(
                        "There is no jobId " + jobId + " for tenant " + externalTenantId);
                }
            }
            else{
                objectName = objectName;
                if (objectName == null || StringUtils.isEmpty(objectName)) {
                    logger.error("Not a valid incoming request. ObjectName is Missing");
                    throw new MissingServletRequestParameterException(Constants.KeyObjectName, "String");
                }

                if(!listOfObjectNames.contains(objectName)){
                    logger.error("Not a valid incoming request.ObjectName {} is not valid", objectName);
                    throw new IntegrationServiceException(
                        "Not a valid incoming request.ObjectName " + objectName + " is not valid");
                }

                if (auditEnabled) {
                    AuditManagerImpl.getInstance().logAudit(externalTenantId,
                        Operation.GET_INTEGRATION_JOB_LOG,
                        "get integration job logs started for Tenant :" + tenantId);
                }
                stageXMLData = IntegrationJobLogUtil.getLatestStageXmlDataForObject(objectName,
                    tenantId);

                if(stageXMLData == null){
                    logger.error("No record in StageXMLDataTab for objectName {} and tenantId {}",
                        objectName,
                        tenantId);
                    throw new IntegrationServiceException(
                        "No Job Status information found for objectName " + objectName + " and tenant " + externalTenantId);
                }
            }

            logger.debug(
                "Record picked from StageXMLDataTab Table is {} for objectName {} , jobId {} , Tenant {}",
                stageXMLData.getId(),
                objectName,
                jobId,
                tenantId);

            if(IntegrationJobLogUtil.integrationJobLogExist(stageXMLData.getId())) {
                jsonObject = getAggregatedData(stageXMLData.getId());
                IntegrationJobLog integrationJobLog = IntegrationJobLogUtil.getLatestIntegrationJobLogDateUpdated(
                    stageXMLData.getId());
                if (integrationJobLog != null) {
                    jsonObject.put(START_DATE, integrationJobLog.getStartDate());
                    jsonObject.put(END_DATE, integrationJobLog.getEndDate());

                    warningMessage = IntegrationJobLogUtil.convertBlobToString(integrationJobLog.getWarningMessages());
                    if (!StringUtils.isEmpty(warningMessage)) {
                        jsonObject.put(WARNINGS, warningMessage);
                    }

                    fatalErrors = IntegrationJobLogUtil.convertBlobToString(integrationJobLog.getFatalErrors());
                    if (!StringUtils.isEmpty(fatalErrors)) {
                        jsonObject.put(FATAL_ERRORS, fatalErrors);
                    }

                    nonFatalExceptions = IntegrationJobLogUtil.convertBlobToString(integrationJobLog.getNonFatalExceptions());
                    if (!StringUtils.isEmpty(nonFatalExceptions)) {
                        jsonObject.put(NON_FATAL_EXCEPTIONS, nonFatalExceptions);
                    }
                }
            }
            // fetching status of job from staging table
            String jobStatus = StagingTableStatus.getJobStatusDescription(
                stageXMLData.getStatus());
            jsonObject.put(STATUS, jobStatus);
        } catch (IntegrationJobLogProviderException ex) {
            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(externalTenantId,
                    Operation.GET_INTEGRATION_JOB_LOG,
                    "get integration job logs ended with Exception for Tenant:" + tenantId);
            }

            logger.error("Exception", ex);
            throw new IntegrationServiceException(ex.getMessage());
        }

        if (auditEnabled) {
            AuditManagerImpl.getInstance().logAudit(externalTenantId,
                Operation.GET_INTEGRATION_JOB_LOG,
                "get integration job logs ended for Tenant:" + tenantId);
        }
        return Response.status(HttpServletResponse.SC_OK).entity(jsonObject.toString()).build();
    }

    private JSONObject getAggregatedData (String jobId)
    {
        JSONObject jsonObject = new JSONObject();
        AggregatedIntegrationJobLogResults aggregatedIntegrationJobLogResults = IntegrationJobLogUtil.getAggregatedRecordsData(
            jobId);
        if(aggregatedIntegrationJobLogResults!=null) {
            jsonObject.put(RECORDS_INSERTED, aggregatedIntegrationJobLogResults.getRecordsInserted());
            jsonObject.put(RECORDS_UPDATED, aggregatedIntegrationJobLogResults.getRecordsUpdated());
            jsonObject.put(RECORDS_DELETED, aggregatedIntegrationJobLogResults.getRecordsDeleted());
        }
        return jsonObject;
    }
}
