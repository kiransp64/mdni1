package com.sap.ariba.erpintegration.onemds.logevent;

public enum LogEventType {
    CREATED("created"), UPDATED("updated"), DELETED("deleted"),
    REJECTED("rejected"), INCLUDED("included"), EXCLUDED("excluded");

    String value;

    LogEventType(String value) {
        this.value = value;
    }

    /**
     * Checks if provided event is one of the supported types: created, updated and deleted
     *
     * @param currentEvent String value of current event
     * @return true for supported events, else false
     */
    public static boolean isSupportedLogEvent(String currentEvent) {
        return CREATED.getValue().equals(currentEvent)
                || UPDATED.getValue().equals(currentEvent)
                || DELETED.getValue().equals(currentEvent)
                || INCLUDED.getValue().equals(currentEvent)
                || EXCLUDED.getValue().equals(currentEvent);
    }

    public String getValue() {
        return this.value;
    }
}
