package com.sap.ariba.erpintegration.service.rs;

/**
 * Created by i340151.
 */
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

public class CustomBlobSerializer extends StdSerializer<Blob>
{

    public CustomBlobSerializer ()
    {
        this(null);
    }

    public CustomBlobSerializer (Class<Blob> t)
    {
        super(t);
    }

    @Override
    public void serialize (Blob value, JsonGenerator gen, SerializerProvider arg2)
        throws IOException
    {
        try {
            if (value == null) {
                return;
            }
            String objectData = new String(value.getBytes(1, (int)value.length()));
            gen.writeString(objectData);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
