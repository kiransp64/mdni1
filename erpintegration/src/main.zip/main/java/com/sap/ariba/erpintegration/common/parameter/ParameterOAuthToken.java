package com.sap.ariba.erpintegration.common.parameter;

import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ParameterOAuthToken extends OAuthTokenManager {

    @Value("${parameter.api.accesstoken.granttype}") private String parameterAccessTokenGrantType;


    @Override
    protected String getGrantType ()
    {
        return parameterAccessTokenGrantType;
    }

}
