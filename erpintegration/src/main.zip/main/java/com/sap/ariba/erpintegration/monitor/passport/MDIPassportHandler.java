package com.sap.ariba.erpintegration.monitor.passport;

import com.sap.ariba.erpintegration.monitor.exception.PassportException;
import com.sap.ariba.erpintegration.monitor.passport.core.persistance.Passport;

public interface MDIPassportHandler extends PassportHandler
{
    Passport saveMDIPassport (long batchID,
                              String objectName,
                              String token,
                              String deltaToken) throws PassportException;

    Passport getMDIPassport(long batchID, String objectName) throws PassportException;

    Passport getWithInitialiseMDIPassport (String tenantID,
                                         long batchID,
                                         String objectName,
                                         String deltaToken) throws PassportException;

    void deletePassportTokenBasedOnBatchIDObjectName (long batchID, String objectName) throws PassportException;

    boolean saveMDIPassportWithSourceEventID (long batchID,
                                              String objectName,
                                              String sourceEventID)
    throws PassportException;

}
