package com.sap.ariba.erpintegration.service.exception;

public class DataDeletionException extends Exception {

    public DataDeletionException(String message) {
        super(message);
    }

    public DataDeletionException(String message, Exception e) {
        super(message, e);
    }
}
