package com.sap.ariba.erpintegration.service.cap;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsonorg.JsonOrgModule;
import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.mdi.common.resource.Resource;
import com.sap.ariba.erpintegration.mdi.common.resource.ResourceOperation;
import com.sap.ariba.erpintegration.mdi.common.resource.ResourceType;
import com.sap.ariba.erpintegration.mdi.common.resource.request.RequestContext;
import com.sap.ariba.erpintegration.mdi.common.transform.TransformContext;
import com.sap.ariba.erpintegration.mdi.common.transform.exception.TransformException;
import com.sap.ariba.erpintegration.mdi.common.transform.service.JSONtransformService;
import com.sap.ariba.erpintegration.mdi.exception.PersistenceException;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.service.PublishService;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.service.exception.TransientWebClientResponseException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.erpintegration.util.IntegrationJobResponseProcessor;
import jakarta.annotation.PostConstruct;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.sap.ariba.erpintegration.handlers.IntegrationOperationType.FULLLOAD;
import static com.sap.ariba.erpintegration.service.cap.MdsCapEntityBatchResourceManager.*;
import static com.sap.ariba.erpintegration.service.mds.MDSPublishStatus.FAILURE;
import static com.sap.ariba.erpintegration.service.mds.MDSPublishStatus.SUCCESS;

@Service
public class MdniToMdsCapPublishService implements PublishService
{
    private static final Logger log = LoggerFactory.getLogger(MdniToMdsCapPublishService.class);

    @Autowired
    @Qualifier("mdniToMdsCapTransformService")
    private JSONtransformService mdniToMdsCapTransformService;

    @Autowired
    @Qualifier("mdsCapEntityBatchResourceManager")
    private MdsCapEntityBatchResourceManager mdsCapEntityBatchResourceManager;

    @Autowired
    private MdsCapEntityDeactivationService deactivationService;

    private ObjectMapper objectMapper;

    @PostConstruct
    private void initialize ()
    {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JsonOrgModule());
    }

    @Override
    public Map<String, Object> publish(JSONArray dataArray,
                                       String anId,
                                       int operation,
                                       String objectName,
                                       String senderBusinessSystemId, StageXMLData stageXMLData) throws
        IntegrationServiceException
    {
        Boolean isOdmEntity = false;
        if (stageXMLData.isMDNIPayload()) {
            isOdmEntity = true;
        }
        if (StringUtils.isBlank(senderBusinessSystemId)) {
            final String errorMsg = 
                "Failed to publish '%s' data for ANID:'%s' to MDS CAP as SenderBusinessSystemId is null".formatted(
                    objectName,
                    anId);
            log.error(errorMsg);
            // Populate error message in response map to fail the job
            return getErrorResponseFor(errorMsg);
        }
        try {
            if (FULLLOAD.getValue() == operation) {
                log.info("""
                        Attempting to deactivate existing '{}' entities for ANID '{}' \
                        with SenderBusinessSystemId '{}' in MDS CAP\
                        """,
                    objectName,
                    anId,
                    senderBusinessSystemId);
                // Deactivate existing entities
                deactivationService.deactivateExistingRecords(objectName,
                    anId,
                    senderBusinessSystemId,
                    isOdmEntity);
                log.info("""
                        Successfully deactivated '{}' entities for ANID '{}' \
                        with SenderBusinessSystemId '{}' in MDS CAP\
                        """,
                    objectName,
                    anId,
                    senderBusinessSystemId);
            }
            // Publish 'dataArray' to MDCS
            return transformAndPublish(dataArray, anId, objectName, senderBusinessSystemId,isOdmEntity);
        } catch (TransientWebClientResponseException ex) {
            log.error(
                """
                TransientWebClientResponseException encountered while publishing '{}' \
                entity for ANID '{}' with SenderBusinessSystemId '{}' to MDS CAP.\
                """,
                objectName,
                anId,
                senderBusinessSystemId,
                ex);
            // Transient exceptions can be retried later
            // Throw IntegrationServiceException to stop the current
            // execution
            throw new IntegrationServiceException(ex, true);
        } catch (Exception ex) {
            log.error("""
                    Exception encountered while publishing '{}' entity for ANID '{}' \
                    with SenderBusinessSystemId '{}' to MDS CAP.\
                    """,
                objectName,
                anId,
                senderBusinessSystemId,
                ex);
            // Any other exception caught at this point is a fatal error
            // Populate error message in response map
            return getErrorResponseFor(ExceptionUtils.getRootCauseMessage(ex));
        }
    }

    protected Map<String, Object> transformAndPublish (JSONArray dataArray,
                                                       String anId,
                                                       String objectName,
                                                       String senderBusinessSystemId,
                                                       Boolean isOdmEntity) throws
        TransformException,
        PersistenceException
    {
        if (dataArray.size() <= HandlerUtil.KeyBatchSize) {
            // Publish the entire payload in one go
            log.info("""
                    Attempting to publish {} '{}' entities for ANID '{}' \
                    with SenderBusinessSystemId '{}' to MDS CAP\
                    """,
                dataArray.size(),
                objectName,
                anId,
                senderBusinessSystemId);
            Map<String, Object> mdcsResponse = publishData(dataArray,
                anId,
                objectName,
                senderBusinessSystemId,
                isOdmEntity);
            // Generate and return success/error response
            Map<String, Object> error = (Map<String, Object>) mdcsResponse.get(ERROR);
            if (error != null && error.containsKey(COUNT_KEY) && (int) error.get(COUNT_KEY) > 0) {
                String errorMessage =
                    error.get(ERROR_INFO) != null ? error.get(ERROR_INFO).toString() : ERROR;
                log.error(
                    """
                    Publish Failed {} '{}' entities for ANID '{}' \
                    with SenderBusinessSystemId '{}' to MDS CAP. Error Message :\s
                    {}\
                    """,
                    dataArray.size(),
                    objectName,
                    anId,
                    senderBusinessSystemId,
                    errorMessage);
                return getErrorResponseFor(errorMessage);
            }
            else {
                log.info("""
                        Successfully published {} '{}' entities for ANID '{}' \
                        with SenderBusinessSystemId '{}' to MDS CAP\
                        """,
                    dataArray.size(),
                    objectName,
                    anId,
                    senderBusinessSystemId);
            }
            return generateSuccessResponse(getCountFor(mdcsResponse, INSERTED_KEY),
                getCountFor(mdcsResponse, UPDATED_KEY),
                getCountFor(mdcsResponse, DELETED_KEY));
        }
        else {
            int recordsInserted = 0, recordsUpdated = 0, recordsDeleted = 0;
            int batchNumber = 0, totalRecordsPublished = 0;
            // Divide the payload into batches
            List<List<? extends JSONObject>> payloadBatches = ListUtils.partition(dataArray,
                HandlerUtil.KeyBatchSize);
            log.info("""
                    Number of records for '{}' entity for ANID '{}' with \
                    SenderBusinessSystemId '{}' is {} which exceeds batch size of {}. \
                    This payload will be published to MDS CAP in {} batches.\
                    """,
                objectName,
                anId,
                senderBusinessSystemId,
                dataArray.size(),
                HandlerUtil.KeyBatchSize,
                payloadBatches.size());
            for (final List<? extends JSONObject> payloadBatch : payloadBatches) {
                log.info("""
                        Attempting to publish batch {} (of size {}) '{}' entities \
                        for ANID '{}' with SenderBusinessSystemId '{}' to MDS CAP\
                        """,
                    ++batchNumber,
                    payloadBatch.size(),
                    objectName,
                    anId,
                    senderBusinessSystemId);
                Map<String, Object> mdcsResponse = publishData(payloadBatch,
                    anId,
                    objectName,
                    senderBusinessSystemId,
                    isOdmEntity);
                recordsInserted += getCountFor(mdcsResponse, INSERTED_KEY);
                recordsUpdated += getCountFor(mdcsResponse, UPDATED_KEY);
                recordsDeleted += getCountFor(mdcsResponse, DELETED_KEY);
                totalRecordsPublished += payloadBatch.size();

                // Generate and return success/error response
                Map<String, Object> error = (Map<String, Object>) mdcsResponse.get(ERROR);
                if (error != null && error.containsKey(COUNT_KEY)
                    && (int) error.get(COUNT_KEY) > 0) {
                    String errorMessage =
                        error.get(ERROR_INFO) != null ? error.get(ERROR_INFO).toString() : ERROR;
                    log.error(
                        """
                        Publish Failed {} '{}' entities for ANID '{}' \
                        with SenderBusinessSystemId '{}' to MDS CAP. Error Message :\s
                        {}\
                        """,
                        dataArray.size(),
                        objectName,
                        anId,
                        senderBusinessSystemId,
                        errorMessage);
                    return getErrorResponseFor(errorMessage);
                }
                else {
                    log.info("""
                            Successfully published {} '{}' entities for ANID '{}' \
                            with SenderBusinessSystemId '{}' to MDS CAP\
                            """,
                        dataArray.size(),
                        objectName,
                        anId,
                        senderBusinessSystemId);
                }
            }
            // Generate and return success response
            return generateSuccessResponse(recordsInserted, recordsUpdated, recordsDeleted);
        }
    }

    protected Map<String, Object> publishData (List<? extends JSONObject> dataArray,
                                               String anId,
                                               String objectName,
                                               String senderBusinessSystemId,
                                               Boolean isOdmEntity) throws
        TransformException,
        PersistenceException
    {
        JsonNode body = getJsonNode(dataArray);
        log.debug("""
                SOAP converted JSON payload for '{}' entity for ANID '{}' \
                with SenderBusinessSystemId '{}' to be published to MDS CAP:\s
                 {}\
                """,
            objectName,
            anId,
            senderBusinessSystemId,
            body);
        final Entity entity = Entity.getEntity(objectName);
        ResourceType targetResourceType=null;
        if (isOdmEntity) {
            targetResourceType = ResourceType.MDCS_ODM;
        }
        else {
            targetResourceType = ResourceType.MDCS;
        }
        TransformContext transformContext = new TransformContext(anId,
            body,
            Resource.ENTITY,
            ResourceType.MDNI,
            ResourceOperation.LOAD,
            entity,
            targetResourceType);
        JsonNode mdsNode = mdniToMdsCapTransformService.transform(transformContext);
        log.debug("""
                Payload for '{}' entity for ANID '{}' \
                with SenderBusinessSystemId '{}' to be published to MDS CAP:\s
                 {}\
                """,
            objectName,
            anId,
            senderBusinessSystemId,
            mdsNode);
        RequestContext<JsonNode> reqContext = new RequestContext(anId,
            mdsNode,
            Resource.ENTITY,
            ResourceType.MDS,
            ResourceOperation.LOAD,
            entity);
        return mdsCapEntityBatchResourceManager.load(reqContext);
    }

    private Map<String, Object> generateSuccessResponse (final int recordsInserted,
                                                         final int recordsUpdated,
                                                         final int recordsDeleted)
    {
        Map<String, Object> response = new HashMap<>();
        response.put(IntegrationJobResponseProcessor.MDSPublishStatus, SUCCESS);
        response.put(IntegrationJobResponseProcessor.RecordsCreated, recordsInserted);
        response.put(IntegrationJobResponseProcessor.RecordsUpdated, recordsUpdated);
        response.put(IntegrationJobResponseProcessor.RecordsDeleted, recordsDeleted);
        return response;
    }

    private int getCountFor (Map<String, Object> mdsResponse, String key)
    {
        if (MapUtils.isNotEmpty(mdsResponse)) {
            if (mdsResponse.containsKey(key)) {
                if (mdsResponse.get(key) instanceof Map) {
                    Map<String, Object> innerMap = (Map) mdsResponse.get(key);
                    if (innerMap.containsKey(COUNT_KEY)) {
                        return (int) innerMap.get(COUNT_KEY);
                    }
                }
            }
        }
        return 0;
    }

    private JsonNode getJsonNode (List<? extends JSONObject> dataArray)
    {
        return objectMapper.valueToTree(dataArray);
    }

    /**
     * Returns the error response map for the specified
     * <code>errorMessage</code>
     */
    private Map<String, Object> getErrorResponseFor (String errorMessage)
    {
        Map<String, Object> response = new HashMap<>();
        // Populate error message in response map
        List<Map<String, String>> errorMessages = new ArrayList<>();
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put(IntegrationJobResponseProcessor.ErrorMessage, errorMessage);
        errorMessages.add(errorMap);
        response.put(IntegrationJobResponseProcessor.MDSPublishStatus, FAILURE);
        response.put(IntegrationJobResponseProcessor.FatalErrors, errorMessages);
        return response;
    }

    /**
     * For MDCS it's always true
     *
     * @param anId
     * @param objectName
     */
    @Override
    public boolean isMDSPublishEnabled (String anId, String objectName, StageXMLData stageXMLData)
    {
        return true;
    }

    /**
     * For MDCS it's always true
     *
     * @param anId
     * @param objectName
     * @return
     */
    @Override
    public boolean isAppPublishExcuded (String anId, String objectName)
    {
        return true;
    }
}
