package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

/**
 * Created by i318483 on 02/06/17.
 */
@Component("SequenceNumberGetterComponent")
public interface SequenceNumberGetter extends CrudRepository<StageXMLData, Long> {
    @Query(value = "select hibernate_sequence.nextval from dummy", nativeQuery = true)
    long getNextSequenceNumber();
    
    @Query(value = "select batch_id_sequence.nextval from dummy", nativeQuery = true)
    long getNexBatchId();
    
    @Query(value = "select pos_tenant_meta_id_sequence.nextval from dummy", nativeQuery = true)
    long getPosTenantMetaId();
}
