package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.AggregatedIntegrationJobLogResults;
import com.sap.ariba.erpintegration.persistence.model.IntegrationJobLog;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by i318483 on 19/06/17.
 */
@Component("IntegrationJobLogRepositoryComponent")
public interface IntegrationJobLogRepository extends GenericDataDao<IntegrationJobLog>
{
    @Query("select C from IntegrationJobLog C where C.tenantId = :tenantId")
    IntegrationJobLog[] findAll(@Param("tenantId") long tenantId);

    @Query("select C from IntegrationJobLog C where C.id = :id")
    IntegrationJobLog findOne(@Param("id") String id);

    @Query("select C from IntegrationJobLog C where C.jobId = :jobId order by dateUpdated desc")
    IntegrationJobLog[] findAll(@Param("jobId") String jobId);

    @Query("select new com.sap.ariba.erpintegration.persistence.model.AggregatedIntegrationJobLogResults(sum(C.recordsInserted) as recordsInserted, sum(C.recordsUpdated) as recordsUpdated,sum(C.recordsDeleted) as recordsDeleted)  from IntegrationJobLog C where C.jobId = :jobId")
    AggregatedIntegrationJobLogResults findAggregatedRecordsData(@Param("jobId") String jobId);

    @Query("select C from IntegrationJobLog C where C.jobId = :jobId and C.dateUpdated = (select max(C.dateUpdated) from IntegrationJobLog C where C.jobId = :jobId)")
    IntegrationJobLog findLatestDateUpdatedRecord(@Param("jobId") String jobId);

    @Query("select C from IntegrationJobLog C where C.jobId = :jobId")
    IntegrationJobLog findOneWithJobId(@Param("jobId") String jobId);
    
    @Query("select id,dateCreated,dateUpdated from IntegrationJobLog s where tenantId = :tenantId order by id desc")
    public Page<IntegrationJobLog> findKeyFieldsOfAllRecords(@Param("tenantId") long tenantId, Pageable pageable);

    @Transactional
    long deleteByTenantId(long tenantId);
    
}
