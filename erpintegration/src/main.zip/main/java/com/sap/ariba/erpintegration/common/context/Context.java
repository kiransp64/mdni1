package com.sap.ariba.erpintegration.common.context;

/**
 * Created by i318483 on 24/04/17.
 */
public interface Context
{
    public String getSystem();
    public String getUserName();
    public String getScheme();
    public String getScope();
    public String getTenant();
    public String getAuthorizationHeader();

}
