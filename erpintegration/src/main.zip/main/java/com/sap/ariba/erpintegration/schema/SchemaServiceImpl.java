package com.sap.ariba.erpintegration.schema;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.OracleDAOFactory;
import com.sap.ariba.erpintegration.persistence.dao.SchemaRepository;
import com.sap.ariba.erpintegration.persistence.model.Schema;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.InvalidTenantIdException;

public class SchemaServiceImpl implements SchemaService
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.schema.SchemaServiceImpl";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private OracleDAOFactory daoFactory = null;
    private SchemaRepository dao = null;

    /**
     * {@inheritDoc}
     * 
     * @throws InvalidTenantIdException
     */
    @Override
    public List<SchemaDetail> getAllSchemas (String tenantId)
        throws InvalidTenantIdException
    {
        List<SchemaDetail> schemaDetails = null;

        if (!Utility.isTenantExists(tenantId)) {
            logger.warn("Invalid Tenant {}", tenantId);
            throw new InvalidTenantIdException("Invalid Tenant" + tenantId);
        }

        long internalTenantId = Utility.getTenantId(tenantId);

        daoFactory = (OracleDAOFactory)DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        dao = (SchemaRepository)daoFactory.getMiscDAO(ObjectTypes.Schema.getValue());

        List<Schema> schemas = dao.find(internalTenantId);

        if (schemas != null && schemas.size() > 0) {
            schemaDetails = new ArrayList<>();

            for (Schema schema : schemas) {
                if (logger.isDebugEnabled())
                    logger.debug(
                        "SenderBusinessSystemId : {} , ObjectName : {}, isFMD : {} ,DateUpdated : {}",
                        schema.getSenderBusinessSystemId(),
                        schema.getObjectName(),
                        schema.isFMD(),
                        schema.getDateUpdated());
                schemaDetails.add(
                    new SchemaDetail(
                        schema.getSenderBusinessSystemId(),
                        schema.getObjectName(),
                        schema.isFMD(),
                        schema.getDateUpdated()));
            }
        }
        else {
            if (logger.isDebugEnabled())
                logger.debug("No Schemas found for tenant is {}", tenantId);
        }

        return schemaDetails;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws InvalidTenantIdException
     */
    @Override
    public List<SchemaDetail> getAllSchemas (String tenantId,
                                             String senderBusinessSystemId)
        throws InvalidTenantIdException
    {
        List<SchemaDetail> schemaDetails = null;

        if (!Utility.isTenantExists(tenantId)) {
            logger.warn("Invalid Tenant {}", tenantId);
            throw new InvalidTenantIdException("Invalid Tenant" + tenantId);
        }

        long internalTenantId = Utility.getTenantId(tenantId);

        daoFactory = (OracleDAOFactory)DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        dao = (SchemaRepository)daoFactory.getMiscDAO(ObjectTypes.Schema.getValue());

        List<Schema> schemas = null;

        if (senderBusinessSystemId == null) {
            schemas = dao.findBySenderBusinessSystemIdNull(internalTenantId);
        }
        else {
            schemas = dao.find(internalTenantId, senderBusinessSystemId);
        }

        if (schemas != null && schemas.size() > 0) {
            schemaDetails = new ArrayList<>();

            for (Schema schema : schemas) {
                if (logger.isDebugEnabled())
                    logger.debug(
                        "SenderBusinessSystemId : {} , ObjectName : {}, isFMD : {} ,DateUpdated : {}",
                        schema.getSenderBusinessSystemId(),
                        schema.getObjectName(),
                        schema.isFMD(),
                        schema.getDateUpdated());
                schemaDetails.add(
                    new SchemaDetail(
                        schema.getSenderBusinessSystemId(),
                        schema.getObjectName(),
                        schema.isFMD(),
                        schema.getDateUpdated()));
            }
        }
        else {
            if (logger.isDebugEnabled())
                logger.debug(
                    "No Schemas found for tenant is {} and SenderBusinessSystemId",
                    tenantId,
                    senderBusinessSystemId);
        }

        return schemaDetails;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws InvalidTenantIdException
     */
    @Override
    public String getSchemaDetail (String tenantId,
                                   String objectName,
                                   String senderBusinessSystemId)
        throws InvalidTenantIdException
    {
        if (logger.isDebugEnabled()) {
            logger.debug(
                "tenantId : {}, objectName: {}, senderBusinessSystemId: {}",
                tenantId,
                objectName,
                senderBusinessSystemId);
        }
        Schema schema = null;
        if (!Utility.isTenantExists(tenantId))
            throw new InvalidTenantIdException("Invalid Tenant" + tenantId);

        long internalTenantId = Utility.getTenantId(tenantId);

        daoFactory = (OracleDAOFactory)DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        dao = (SchemaRepository)daoFactory.getMiscDAO(ObjectTypes.Schema.getValue());

        if (senderBusinessSystemId != null) {
            schema = dao.findOne(internalTenantId, objectName, senderBusinessSystemId);
        }
        else {
            schema = dao.findOne(internalTenantId, objectName);
        }

        if (schema != null) {
            if (logger.isDebugEnabled())
                logger.debug(
                    "Schema found for the tenant id {}, objectName {} and senderBusinessSystemId {}",
                    tenantId,
                    objectName,
                    senderBusinessSystemId);
            try {
                return SchemaUtil.getObjectSchema(
                    schema.getPath(),
                    schema.getObjectName());
            }
            catch (ParserConfigurationException | SAXException | IOException e) {
                logger.error(
                    "Exception while getting object definition for tenantId : {}, objectName : {} and senderBusinessSystemId : {}",
                    tenantId,
                    objectName,
                    senderBusinessSystemId,
                    e);
            }
            ;
        }
        else {
            if (logger.isDebugEnabled())
                logger.debug(
                    "No schema found for the tenant id {}, objectName {} and senderBusinessSystemId {}",
                    tenantId,
                    objectName,
                    senderBusinessSystemId);
        }

        return null;
    }

    @Override
    public String getSchemaDetail (String tenantId, String objectName)
        throws InvalidTenantIdException
    {
        if (logger.isDebugEnabled()) {
            logger.debug("tenantId : {}, objectName: {}", tenantId, objectName);
        }

        if (!Utility.isTenantExists(tenantId))
            throw new InvalidTenantIdException("Invalid Tenant" + tenantId);

        long internalTenantId = Utility.getTenantId(tenantId);

        daoFactory = (OracleDAOFactory)DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        dao = (SchemaRepository)daoFactory.getMiscDAO(ObjectTypes.Schema.getValue());

        Schema schema = dao.findOne(internalTenantId, objectName);

        if (schema != null) {
            if (logger.isDebugEnabled())
                logger.debug(
                    "Schema found for the tenant id {} and objectName {}",
                    tenantId,
                    objectName);
            try {
                return SchemaUtil.getObjectSchema(
                    schema.getPath(),
                    schema.getObjectName());
            }
            catch (ParserConfigurationException | SAXException | IOException e) {
                logger.error(
                    "Exception while getting object definition for tenantId : {} and objectName : {}",
                    tenantId,
                    objectName,
                    e);
            }
        }
        else {
            if (logger.isDebugEnabled())
                logger.debug(
                    "No schema found for the tenant id {} and objectName {}",
                    tenantId,
                    objectName);
        }

        return null;
    }
}
