package com.sap.ariba.erpintegration.service.rs;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.meta.ClassMetaDataProvider;
import com.sap.ariba.erpintegration.persistence.model.EntityVersion;
import com.sap.ariba.erpintegration.persistence.PersistenceOperationType;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Component
public class EntityVersionRepositoryCustomImpl implements EntityVersionRepositoryCustom
{
    public static final String nameOfLogger = "com.sap.ariba.erpintegration.persistence.dao.EntityVersionRepositoryCustomImpl";
    public static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    public static final String fmdLookupKey = "UniqueName";
    public static final int  batchSize = 10000;

    /**
     * Extract the lookup value from the JSONData
     *
     * @param objectName
     * @param jsonObject
     * @return
     */
    public Map<String, String> getLookupValueForObject (String objectName,
        JSONObject jsonObject,
        boolean isFMDObject)
    {

        Object obj = null;
        JSONObject jsonData = null;
        String lookupFields = null;
        String[] lookupKeys = null;
        String externalLookupKeyForObject = null;
        Map<String, String> lookupDetails = null;

        if(isFMDObject){
            obj = jsonObject.get(fmdLookupKey);
            lookupKeys = new String[1];
            lookupKeys[0] = fmdLookupKey;
        }
        else {
            externalLookupKeyForObject = ClassMetaDataProvider.getExternalLookupKeyForObject(
                objectName);
            lookupFields = ClassMetaDataProvider.getLookupKeysForObject(objectName);
            lookupKeys = lookupFields.split(",");
            if (externalLookupKeyForObject.contains(".")) {
                obj = getNestedData(jsonObject, externalLookupKeyForObject);
            }
            else {
                obj = jsonObject.get(externalLookupKeyForObject);
            }
        }
        lookupDetails = new HashMap<String, String>();

        if (obj instanceof JSONObject object) {
            jsonData = object;
            for (String lookupKey : lookupKeys) {
                lookupDetails.put(lookupKey, (String)jsonData.get(lookupKey));
            }
        }
        else if (obj instanceof String lookupKey && lookupKeys.length == 1) {
            lookupDetails.put(lookupKeys[0], lookupKey);
        }
        else {
            for (String lookupKey : lookupKeys) {
                lookupDetails.put(lookupKey, (String)jsonObject.get(lookupKey));
            }
        }

        return lookupDetails;
    }

    /**
     * @param jsonObject
     * @param key
     * @return
     */
    public Object getNestedData (JSONObject jsonObject, String key)
    {
        int index = key.indexOf(".");
        if (index != -1) {
            String currentKey = key.substring(0, index);
            if (jsonObject.get(currentKey) instanceof Map) {
                return getNestedData(
                    (JSONObject)jsonObject.get(currentKey),
                    key.substring(index + 1, key.length()));
            }
        }
        else {
            return jsonObject.get(key);
        }
        return null;
    }

    public void processRecords (Map<PersistenceOperationType,Set<EntityVersion>> mapOfEntityVersions)
    {
        if (mapOfEntityVersions.isEmpty()) {
            logger.debug("EntityVersionList is Empty");
            return;
        }

        EntityManager em = null;
        try {
            EntityManagerFactory emf = ApplicationContextProvider.getApplicationContext().getBean(
                EntityManagerFactory.class);
            em = emf.createEntityManager();
            em.getTransaction().begin();
            int counter = 0;
            for (Map.Entry<PersistenceOperationType, Set<EntityVersion>> eachMapEntry : mapOfEntityVersions.entrySet()) {
                for (EntityVersion entry : eachMapEntry.getValue()) {
                    switch (eachMapEntry.getKey()){
                    case INSERT: em.persist(entry); break;
                    case UPDATE: em.merge(entry); break;
                    default: throw new UnsupportedOperationException(eachMapEntry.getKey() + " Operation no supported");
                    }
                    counter++;
                    if (counter % batchSize == 0) {
                        logger.debug("Reached BatchSize of {} ,hence flushing",
                            batchSize);
                        em.flush();
                        em.clear();
                        counter = 0;
                    }
                }
            }
            em.getTransaction().commit();
        }finally {
            if (em != null) {
                em.close();
            }
        }
    }
}
