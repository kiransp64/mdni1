package com.sap.ariba.erpintegration.util;

import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.model.Address;
import com.sap.ariba.erpintegration.persistence.model.Asset;
import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import com.sap.ariba.erpintegration.persistence.model.IncoTerms;
import com.sap.ariba.erpintegration.persistence.model.PurchaseOrg;
import com.sap.ariba.erpintegration.persistence.model.TaxCode;
import com.sap.ariba.erpintegration.persistence.model.UnitOfMeasurement;

/**
 * Created by i318483 on 01/06/17.
 */
public class EntityFactory
{
    public static GenericEntity getEntity (String forEntity)
    {
        ObjectTypes objectTypes = ObjectTypes.valueOf(forEntity);
        switch (objectTypes) {
            case PurchaseOrg:
                return new PurchaseOrg();
            case IncoTerms:
                return new IncoTerms();
            case UOMCode:
                return new UnitOfMeasurement();
            case Asset:
                return new Asset();
            case Address:
                return new Address();
            case TaxCode:
                return new TaxCode();
            default:
                return null;
        }
    }
}
