package com.sap.ariba.erpintegration.onemds.tenant;

public enum TenantConfiguration
{
    CLIENT_ID("clientID"), CLIENT_SECRET("clientSecret"), AUTH_URL("authURL"), APP_URL(
    "appURL"), TIME_UPDATED("TimeUpdated");

    String value;

    TenantConfiguration (String value)
    {
        this.value = value;
    }

    public String getValue ()
    {
        return this.value;
    }
}
