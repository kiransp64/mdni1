package com.sap.ariba.erpintegration.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

public class IntegrationJobResponseProcessor
{
    private static final String NonFatalExceptions = "NonFatalExceptions";
    private static final String WarningMessages = "WarningMessages";
    private static final String WarningRowNumber = "WarningRowNumber";
    private static final String WarningMessage = "WarningMessage";
    private static final int ThresholdWarningCount = 500;
    
    public static final String RecordsCreated = "RecordsCreated";
    public static final String RecordsDeleted = "RecordsDeleted";
    public static final String RecordsUpdated = "RecordsUpdated";
    public static final String FatalErrors = "FatalErrors";
    public static final String ErrorMessage = "ErrorMessage";
    public static final String MDSPublishStatus = "MDSPublishStatus";

    /**
     * Number of records, created by the event
     */
    private int m_recordsCreated;

    /**
     * Number of records, updated by the event
     */
    private int m_recordsUpdated;

    /**
     * Number of records, de-activated by the event
     */
    private int m_recordsDeleted;

    private List<Map<String, Object>> warnings;
    private List<Map<String, String>> fatalErrors;
    private List<String> nonFatalExceptions;

    private String reprocessLineNumbers = null;

    private StringBuffer warningMessages = null;
    private StringBuffer fatalErrorMessages = null;
    private StringBuffer nonFatalMessages = null;
    private int m_reprocessLineNumbersCumulativeCounter;
    private boolean shouldContinueProcessing = true;

    private boolean statusError = false;

    private boolean noRespose;
    
    /**
     * Flag to indicate if there has been a transient failure during job
     * execution. This can be used to retry the job at a later point of time
     */
    private boolean isTransientFailure = false;

    public IntegrationJobResponseProcessor ()
    {
        this.warningMessages = new StringBuffer();
        this.fatalErrorMessages = new StringBuffer();
        this.nonFatalMessages = new StringBuffer();
        this.warnings = new ArrayList<>();
        this.fatalErrors = new ArrayList<>();
        this.nonFatalExceptions = new ArrayList<>();
    }

    public boolean processJobResponse (Map<String, Object> responseMap, int batchNumber,Map<Integer, String> lineNumLookupKeyMap)
    {
        List<Integer> lineNumberList = new ArrayList<>();
        if (MapUtils.isEmpty(responseMap)) {
            setNoRespose(true);
            return shouldContinueProcessing;
        }

        for (Map.Entry<String, Object> entry : responseMap.entrySet()) {

            if (entry.getKey() == null || entry.getValue() == null) {
                continue;
            }

            switch (entry.getKey()) {
                case RecordsCreated:
                    m_recordsCreated += (Integer)entry.getValue();
                    break;
                case RecordsDeleted:
                    m_recordsDeleted += (Integer)entry.getValue();
                    break;
                case RecordsUpdated:
                    m_recordsUpdated += (Integer)entry.getValue();
                    break;
                case WarningMessages:
                    warnings = (List<Map<String, Object>>)entry.getValue();
                    break;
                case NonFatalExceptions:
                    nonFatalExceptions = (List<String>)entry.getValue();
                    break;
                case FatalErrors:
                    fatalErrors = (List<Map<String, String>>)entry.getValue();
            }
        }

        for (Map<String, Object> nonFatalException: warnings) {
            int actualLineNumber =  ((Integer)nonFatalException.get(WarningRowNumber) + batchNumber * HandlerUtil.KeyBatchSize);
            if(!lineNumberList.contains(actualLineNumber)) {
                if (reprocessLineNumbers == null)
                    reprocessLineNumbers = actualLineNumber + "";
                else {
                    reprocessLineNumbers = reprocessLineNumbers + "," + actualLineNumber;
                }
                lineNumberList.add(actualLineNumber);
                m_reprocessLineNumbersCumulativeCounter++;
                if(m_reprocessLineNumbersCumulativeCounter >= ThresholdWarningCount){
                    shouldContinueProcessing = false;
                    break;
                }
            }
            String lookupKey = lineNumLookupKeyMap.get(actualLineNumber);
            String warningMsg;
            if(!StringUtils.isEmpty(lookupKey)){
                warningMsg = nonFatalException.get(WarningMessage) + " for lookupKey:  " + lookupKey;
            }
            else{
                warningMsg = (String)nonFatalException.get(WarningMessage);
            }
            warningMessages.append(warningMsg + "\n");
        }

        for (Map<String, String> fatalError: fatalErrors) {
             fatalErrorMessages.append(fatalError.get(ErrorMessage) + "\n");
        }

        for (String nonFatalException: nonFatalExceptions) {
            nonFatalMessages.append(nonFatalException + "\n");
        }
        return shouldContinueProcessing;
    }

    public int getRecordsCreated() {
        return m_recordsCreated;
    }

    public int getRecordsUpdated() {
        return m_recordsUpdated;
    }

    public int getRecordsDeactivated() {
        return m_recordsDeleted;
    }

    public String getWarningMessages () {
        return warningMessages.toString();
    }

    public String getFatalErrorMessages() {
        return fatalErrorMessages.toString();
    }

    public String getNonFatalExceptions() {
        return nonFatalMessages.toString();
    }

    public String getReprocessLineNumbers() {
        return reprocessLineNumbers;
    }

    public boolean isNoRespose ()
    {
        return noRespose;
    }

    public void setNoRespose (boolean noRespose)
    {
        this.noRespose = noRespose;
    }

    public int getTotalRecordsProcessed ()
    {
        return m_recordsCreated + m_recordsUpdated;
    }

    public boolean isStatusError () { return statusError; }

    public void setStatusError (boolean statusError) { this.statusError = statusError; }
    
    /**
     * Indicates if a transient failure has occurred during job execution
     */
    public boolean isTransientFailure ()
    {
        return isTransientFailure;
    }
    
    /**
     * Sets {@link #isTransientFailure transient} failure to true
     */
    public void markTransientFailure ()
    {
        isTransientFailure = true;
    }
}
