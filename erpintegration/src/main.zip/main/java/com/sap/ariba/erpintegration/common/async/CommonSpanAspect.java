package com.sap.ariba.erpintegration.common.async;

import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * Aspect class to manage/add trace id and span for async schedule and Job api classes.
 */
@Aspect
@Component
@RequiredArgsConstructor
public class CommonSpanAspect
{
    private final Tracer tracer;

    @Pointcut("@annotation(org.springframework.scheduling.annotation.Scheduled) || @annotation(org.springframework.scheduling.annotation.Async)")
    public void annotatedWithScheduledOrAsync ()
    {
    }

    @Pointcut("""
                    execution( * com.sap.ariba.erpintegration.scheduler.IntegrationDataProcessorJob.execute(..)) 
                    || execution( * com.sap.ariba.erpintegration.onemds.process.job.TenantDistributionJob.execute(..))  
                    || execution( * com.sap.ariba.erpintegration.onemds.process.job.FailedBatchRecoveryJob.execute(..))  
                    || execution( * com.sap.ariba.erpintegration.scheduler.DataCompressionJob.execute(..)) 
                    || execution( * com.sap.ariba.erpintegration.onemds.process.job.MDISyncJobMonitoringJob.execute(..)) 
                    || execution( * com.sap.ariba.erpintegration.purge.tenant.job.TenantPurgeJob.execute(..))
                    ||execution( *  com.sap.ariba.erpintegration.scheduler.DataPurgeJob.execute(..))
                               """)
    public void executeMethodPoint ()
    {
    }

    @Around("annotatedWithScheduledOrAsync()")
    public Object wrapScheduledIntoSpan (ProceedingJoinPoint pjp) throws Throwable
    {
        var methodName = pjp.getSignature().getDeclaringTypeName() + "." + pjp.getSignature()
                        .getName();

        var span = tracer.nextSpan().name(methodName).start();
        try (var ignoredSpanInScope = tracer.withSpan(span.start())) {
            return pjp.proceed();
        }
        finally {
            span.end();
        }
    }

    /**
     * Advice for adding trace id with Span for async execute method for Job.
     *
     * @param pjp
     * @return
     * @throws Throwable
     */
    @Around("executeMethodPoint()")
    public Object wrapAsyncExecuteIntoSpanAdvice (ProceedingJoinPoint pjp) throws Throwable
    {
        var methodName = pjp.getSignature().getDeclaringTypeName() + "." + pjp.getSignature()
                        .getName();

        var span = tracer.nextSpan().name(methodName).start();
        try (var ignoredSpanInScope = tracer.withSpan(span.start())) {
            return pjp.proceed();
        }
        finally {
            span.end();
        }
    }
}
