/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.mdi.common;

import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import com.sap.ariba.erpintegration.monitor.im.helper.IMHelper;
import com.sap.ariba.erpintegration.monitor.passport.context.ContextHandler;
import com.sap.ariba.erpintegration.monitor.passport.context.EventContext;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.jaxrs.interceptor.JAXRSDefaultFaultOutInterceptor;
import org.apache.cxf.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INBOUND_FAILURE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMEvents.SCIM;

/**
 * This fault interceptor introduced for to get the scim Fault error message(error which is trigger before calling actual scim UsersExt or GroupsExt API) and LOG the event to Integration Monitoring or ESS
 * IM Data object already been set as part of Current Thread context from  MonitoringFilter .
 */
@Slf4j
@Component
public class ScimInvalidPayloadFaultInterceptor extends JAXRSDefaultFaultOutInterceptor
{
    public ScimInvalidPayloadFaultInterceptor ()
    {
        super();
    }

    @Lazy
    @Autowired
    private IMHelper imHelper;

    @Lazy
    @Autowired
    private ContextHandler contextHandler;

    /**
     * @param message
     * @throws Fault
     */
    @Override
    public void handleMessage (Message message) throws Fault
    {
        Fault fault = (Fault)message.getContent(Exception.class);
        //sending error inbound event to im for scim Invalid Payload error.
        if (IMHelper.isIMEnable() && fault != null && fault.getCause() != null && fault.getCause().getCause() != null
                        && fault.getCause().getCause() instanceof MismatchedInputException) {
            logImEvent(fault.getCause().getCause());
        }
    }

    /**
     * Processing IM event by fetching necessary parameter from current Thread context.
     *
     * @param cause error cause with Exception message .
     * @see com.sap.ariba.erpintegration.filters.ScimMonitoringFilter
     */
    private void logImEvent (Throwable cause)
    {
        try {
            EventContext eventContext = contextHandler.fetchCurrentEventContextThreadDetails();
            if (ObjectUtils.isNotEmpty(eventContext)) {
                imHelper.processIMMonitoring(eventContext.getTenantId(),
                                             "",
                                             eventContext.getObjectName(),
                                             eventContext.getOperation(),
                                             cause.getMessage(),
                                             true,
                                             INBOUND_FAILURE,
                                             SCIM);
            }
        }
        catch (Exception e) {
            log.error("Exception - {} ,while processing im event from Fault Interceptor.",
                      ErrorUtil.getCompleteCausedByErrors(e));
        }
    }

}
