package com.sap.ariba.erpintegration.mdi.exception;

public class NotValidException extends RuntimeException
{
    /**
     * Using for throwing 204 No Content special circumstances
     * @param message
     */

    public NotValidException (String message)
    {
        super(message);
    }

    public NotValidException (String message, Exception e)
    {
        super(message, e);
    }
}
