package com.sap.ariba.erpintegration.persistence;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAO;
import com.sap.ariba.erpintegration.persistence.dao.GenericJPADAO;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

/**
 * Created by i318483 on 31/05/17.
 */
@Component("DAOFactory")
public abstract class DAOFactory
{

    public static final int ORACLE = 1;
    public static final int SYBASE = 2;

    public abstract GenericDAO getDAO (String objectName);
    public abstract GenericJPADAO getJPADAO (String objectName);
    public abstract CrudRepository getMiscDAO (String objectName);
    public abstract GenericDAOStageData getGenericDAOStageData (String objectName);

    public static DAOFactory getDAOFactory (int factory)
    {
        switch (factory) {
        case ORACLE:
            return ApplicationContextProvider.getApplicationContext().getBean(
                OracleDAOFactory.class);
        case SYBASE:
            return ApplicationContextProvider.getApplicationContext().getBean(
                SybaseDAOFactory.class);
        default:
            return null;
        }
    }
}
