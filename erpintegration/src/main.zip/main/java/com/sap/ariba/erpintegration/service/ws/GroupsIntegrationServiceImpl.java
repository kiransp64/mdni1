package com.sap.ariba.erpintegration.service.ws;

import com.sap.ariba.erpintegration.persistence.model.GroupExport.Group;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import jakarta.annotation.Resource;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.xml.ws.WebServiceContext;
import jakarta.xml.ws.handler.MessageContext;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by c5259108 on 04/12/17.
 */
public class GroupsIntegrationServiceImpl implements GroupsIntegrationService {

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.service.ws.GroupsIntegrationServiceImpl";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);
    private static final String urlReplacementStringForObject = "getGroups";

    @Resource
    private WebServiceContext ctx;

    public List<Group> getGroups() throws IntegrationServiceException {

        HttpServletRequest request = (HttpServletRequest) ctx.getMessageContext().get(MessageContext.SERVLET_REQUEST);
        String anID = request.getParameter(Constants.KeyTenantId);

        if (anID == null || anID.length() == 0) {
            logger.error("Empty tenant Passed");
            throw new IntegrationServiceException("Empty tenant Passed");
        }

        if(!Utility.isTenantExists(anID)){
            logger.error("[MDNI_CRITICAL][ARIBA][Processing] Tenant - {}  given anID not available in TENANT_TAB Table for group",
                         anID);
            throw new IntegrationServiceException("Tenant not recognized for " + anID);
        }

        List<Group> groupList = new ArrayList<Group>();
        ObjectMapper mapper = new ObjectMapper();
        Group group;
        JSONArray jsonGroupsArray;
        try {
            jsonGroupsArray = HandlerUtil.getDataFromBuyer(anID,urlReplacementStringForObject);
            if (jsonGroupsArray != null) {
                for (int i = 0; i < jsonGroupsArray.length(); i++) {
                    if (jsonGroupsArray.getJSONObject(i) instanceof JSONObject) {
                        group = mapper.readValue(jsonGroupsArray.getJSONObject(i).toString(), Group.class);
                        groupList.add(group);
                    }
                }
            }
        } catch (IOException ex) {
            logger.warn("[MDNI_CRITICAL][ARIBA][Processing] Tenant ID- {}, Exception {} while parsing Group Data ",
                        anID,
                        ErrorUtil.getCompleteCausedByErrors(ex));
            throw new IntegrationServiceException(ex.getMessage());
        }
        catch (GeneralSecurityException ex){
            logger.warn("Exception while parsing Group Data ", ex);
            throw new IntegrationServiceException(ex.getMessage());
        }
        return groupList;
    }
}


