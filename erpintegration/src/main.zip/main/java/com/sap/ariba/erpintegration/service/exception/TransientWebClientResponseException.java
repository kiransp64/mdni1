package com.sap.ariba.erpintegration.service.exception;

import org.springframework.web.reactive.function.client.WebClientResponseException;

/**
 * Can be used in case of transient HTTP errors like 504 (Gateway Timeout) or
 * 503 (Service Unavailable) etc
 */
public class TransientWebClientResponseException extends WebClientResponseException
{
    private static final long serialVersionUID = 1L;

    public TransientWebClientResponseException (WebClientResponseException ex)
    {
        super(
            ex.getRawStatusCode(),
            ex.getStatusText(),
            ex.getHeaders(),
            ex.getResponseBodyAsByteArray(),
            null);
    }
    
    public TransientWebClientResponseException (int statusCode, String statusText)
    {
        super(
            statusCode,
            statusText,
            null,
            null,
            null);
    }
}
