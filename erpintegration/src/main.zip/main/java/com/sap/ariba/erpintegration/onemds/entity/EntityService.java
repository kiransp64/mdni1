package com.sap.ariba.erpintegration.onemds.entity;

import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.onemds.exception.EntityServiceException;

import java.util.List;

public interface EntityService
{
    public Entity getNextEntityToFetchFromMDI (String tenantID, long batchID) throws
        EntityServiceException;

    public Entity getNextEntityToSync (String tenantID, long batchID) throws
        EntityServiceException;

    public boolean isBatchComplete (String tenantID, long batchID) throws
        EntityServiceException;

    public boolean isLogFetchComplete (String tenantID, long batchID) throws
        EntityServiceException;

    public List<String> getKeys (Entity entity) throws EntityServiceException;
}
