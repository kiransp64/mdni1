package com.sap.ariba.erpintegration.reencryption;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.sap.ariba.erpintegration.mdi.common.util.DateUtil;

import java.io.IOException;
import java.util.Date;

public class DateFormatSerializer extends JsonSerializer<Date>
{

    private String format = DateUtil.DATE_FORMAT;

    public DateFormatSerializer (String format)
    {
        this.format = format;
    }

    public DateFormatSerializer ()
    {

    }

    @Override
    public void serialize (Date value, JsonGenerator gen, SerializerProvider serializers)
    throws IOException
    {
        String serializedInstant = "";
        if (value != null) {
            serializedInstant = DateUtil.format(value, this.format, null);
        }
        gen.writeString(serializedInstant);
    }
}
