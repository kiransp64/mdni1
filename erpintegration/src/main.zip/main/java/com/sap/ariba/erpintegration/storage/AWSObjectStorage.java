package com.sap.ariba.erpintegration.storage;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.sap.ariba.erpintegration.storage.exception.CloudStorageException;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

@Service
@Qualifier("AWSObjectStorage")
@ConditionalOnExpression(value = "${advanced.storage.option}")
public class AWSObjectStorage implements CloudStorage {

    private Logger logger = LoggerFactory.getLogger(AWSObjectStorage.class);

    @Value("${vcap.services.objectstore.credentials.access_key_id}")
    private String accessKeyId;
    @Value("${vcap.services.objectstore.credentials.secret_access_key}")
    private String secretAccessKey;
    @Value("${vcap.services.objectstore.credentials.bucket}")
    private String bucketName;
    @Value("${vcap.services.objectstore.credentials.host}")
    private String endPoint;

    private AmazonS3 s3client;

    @PostConstruct
    public void init() {
        try {
            AWSCredentials credentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
            s3client = new AmazonS3Client(credentials);
            s3client.setEndpoint(endPoint);
        }catch (Exception e){
            logger.error("Error while creating the AWS storage client");
        }
    }

    @Override
    public void put(String path, String content) throws CloudStorageException {
        File temp = null;
        try {
            temp = createTempFile(content);
            s3client.putObject(new PutObjectRequest(bucketName, path, temp));
            logger.info("Object {} successfully uploaded to S3 bucket {}", path, bucketName);
        } catch (IOException e) {
            logger.error("Exception while creating the object in S3 ", e);
            throw new CloudStorageException(e);
        } finally {
            if (temp != null && temp.exists()) {
                temp.delete();
            }
        }

    }

    @Override
    public String getContent(String path) throws CloudStorageException {
        try {
            logger.info("Object {} getting downloaded from S3 bucket {}", path, bucketName);
            return getContent(s3client.getObject(new GetObjectRequest(bucketName, path)));
        } catch (IOException t) {
            logger.error("Exception while getting the object from S3 ", t);
            throw new CloudStorageException(t);
        }
    }

    @Override
    public CloudStorageResponse getStream(String path) throws CloudStorageException {
        try {
            logger.info("Object {} getting downloaded from S3 bucket {}", path, bucketName);
            return getInputStream(s3client.getObject(new GetObjectRequest(bucketName, path)));
        } catch (IOException e) {
            logger.error("Exception while getting the object stream from S3 ", e);
            throw new CloudStorageException(e);
        }
    }

    @Override
    public void remove(String path) throws CloudStorageException {
        logger.info("Object {} getting deleted from S3 bucket ", path , bucketName);
        s3client.deleteObject(bucketName, path );
    }

    private File createTempFile(String content) throws IOException {
        File temp = null;

        // Create temp file.
        temp = File.createTempFile("payload" + System.currentTimeMillis(), ".xml");

        // Delete temp file when program exits.
        temp.deleteOnExit();

        // Write to temp file
        BufferedWriter out = new BufferedWriter(new FileWriter(temp));
        try {
            out.write(content);
        } finally {
            out.close();
        }

        return temp;
    }

    private String getContent (S3Object s3Object) throws IOException
    {
        S3ObjectInputStream s3ObjectInputStream = s3Object.getObjectContent();
        byte[] content = null;
        try {
            content = IOUtils.toByteArray(s3ObjectInputStream);
        }
        finally {
            closeS3Object(s3Object);
        }

        return new String(content);
    }

    private CloudStorageResponse getInputStream (S3Object s3Object) throws IOException
    {
        InputStream is = s3Object.getObjectContent();            
        return new CloudStorageResponse(s3Object,is);
    }

    protected void setS3client(AmazonS3 s3client) {
        this.s3client = s3client;
    }
    
    @Override
    public void closeCloudObject (CloudStorageResponse responseStream)
    {
        if (responseStream != null && responseStream.getCloseableObject() != null) {
            Object s3Object = responseStream.getCloseableObject();
            if (s3Object instanceof S3Object object) {
                closeS3Object(object);
            }
        }
    }
    private void  closeS3Object(S3Object s3Object) {
        if (s3Object != null) {
            try {
                // Close the object
                s3Object.close();
            }
            catch (IOException s3e) {
                logger.error("Unable to close S3 object.Error {} ", ErrorUtil.getCompleteCausedByErrors(s3e));
            }
        } 
    }
}
