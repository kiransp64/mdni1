package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.GenericEntityStageData;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Component("StageXMLDataRepositoryComponent")
public interface StageXMLDataRepository extends GenericDAOStageData<StageXMLData,Long> {

    @Query("select s from StageXMLData s where s.id = :id")
    public StageXMLData findOne(@Param("id") String id);

    @Query("select T from StageXMLData T where T.status = 1")
    public List<GenericEntityStageData> findRecordsInProcessingStatus();

    @Query(value = "SELECT T FROM StageXMLData T WHERE T.status=0 ORDER BY T.dateCreated ASC")
    public Page<GenericEntityStageData> findLastNRows(Pageable pageable);

    @Query(value = "SELECT T FROM StageXMLData T WHERE T.status=0 AND T.processedCount< com.sap.ariba.erpintegration.handlers.IntegrationDataPayloadProcessor.MAXRETRYCOUNT ORDER BY T.sourceCreatedDate ASC")

    public List<StageXMLData> findAllUnprocessedRows ();

    @Modifying
    @Transactional(readOnly = false)
    @Query("update StageXMLData T set T.status = :status, T.dateUpdated = :dateUpdated where T.id = :id")
    public void updateStatus(@Param("id") String id, @Param("status")int status, @Param("dateUpdated") Date dateUpdated);

    @Query("""
            select T from StageXMLData T where T.objectName = :objectName and T.tenantId = :systemTenantId \
            and T.isStatic = 1 and T.status >=0 and T.status<=1 \
            """)
    public StageXMLData findStaticRecord(@Param("objectName") String objectName,@Param("systemTenantId") long systemTenantId);

    @Query("select C from StageXMLData C where C.tenantId = :tenantId")
    StageXMLData[] findAll(@Param("tenantId") long tenantId);

    @Query("select C from StageXMLData C where C.objectName = :objectName and C.tenantId = :tenantId and C.dateUpdated = (select max(C.dateUpdated) from StageXMLData C where C.objectName = :objectName and C.tenantId = :tenantId )")
    StageXMLData findLatest(@Param("objectName") String objectName, @Param("tenantId") long tenantId);

    @Query("select C from StageXMLData C where C.status in (2, 6, 7)  and C.dataPurged = 0 and C.dateUpdated < :retainNoOfDays order by C.dateUpdated")
    List<StageXMLData> findListOfDataPathForProcessing(@Param("retainNoOfDays") Date retainNoOfDays, Pageable pageReq);
    
    @Query("select C from StageXMLData C where C.status in (3, 4, 5) and C.dataPurged = 0 and C.dateUpdated < :retainNoOfDays")
    List<StageXMLData> findListOfDataPathForErrorJobsProcessing(@Param("retainNoOfDays") Date retainNoOfDays);

    @Query("select C from StageXMLData C where C.status = :status and C.tenantId = :tenantId and C.objectName = :objectName")
    public List<StageXMLData> findRecordsInNeedsReprocessingStatus(@Param("objectName") String objectName, @Param("status") int status, @Param("tenantId") long tenantId);

    @Query("""
            select CASE WHEN COUNT(C) > 0 THEN 'true' ELSE 'false' END from StageXMLData C \
            where C.tenantId = :tenantId and ((:senderBusinessSystemId is null and C.senderBusinesssytemId is null) \
            or C.senderBusinesssytemId = :senderBusinessSystemId) \
            and C.objectName = :objectName and C.sourceCreatedDate > :sourceCreatedDate\
            """)
    public Boolean olderSourceCreationDateExists(@Param("objectName") String objectName, @Param("tenantId") long tenantId,
                                                 @Param("senderBusinessSystemId") String senderBusinessSystemId,
                                                 @Param("sourceCreatedDate") Timestamp sourceCreatedDate);
    @Query("select id,dateCreated,dateUpdated from StageXMLData s where tenantId = :tenantId order by id desc")
    public Page<StageXMLData> findKeyFieldsOfAllRecords(@Param("tenantId") long tenantId, Pageable pageable);

    @Query("select C from StageXMLData C where C.id = :jobId and C.tenantId = :tenantId")
    StageXMLData findStageXmlDataForJobId(@Param("jobId") String jobId, @Param("tenantId") long tenantId);
    
    @Query("select C from StageXMLData C where C.tenantId = :tenantId and dateCreated between :start and :end order by dateCreated desc")
    public Page<StageXMLData> findRecordsInRange(@Param("tenantId") long tenantId, @Param("start") Date start, @Param("end") Date end, Pageable pageable);   
    
    @Query("""
        select C from StageXMLData C where C.tenantId = :tenantId and C.status = :status and dateCreated \
        between :start and :end order by dateCreated desc\
        """) 
    public Page<StageXMLData> findRecordsInRangeForStatus(@Param("tenantId") long tenantId, 
                           @Param("start") Date start, @Param("end") Date end, @Param("status") int status, Pageable pageable);
    
    //TODO need to clean this method since not been used any where
    @Query("select C from StageXMLData C where C.tenantId = :tenantId order by dateCreated desc")
    public Page<StageXMLData> findLatestJobsForTenant(@Param("tenantId") long tenantId, Pageable pageable);

    @Modifying
    @Transactional(readOnly = false)
    @Query("""
           update StageXMLData T \
           set T.status = :newStatus, T.dateUpdated = :dateUpdated \
           where T.status IN (:currentStatuses) and T.tenantId IN (:tenantIds)\
           """)
    public int updateStatusForTenants (@Param("newStatus") int newStatus,
                                       @Param("tenantIds") List<Long> tenantIds,
                                       @Param("currentStatuses") List<Integer> currentStatuses,
                                       @Param("dateUpdated") Date dateUpdated);



    @Query("select C from StageXMLData C where C.status in (2, 3, 4, 5, 6, 7) and C.dataPurged = 0 and C.dataCompressed = 0")
    public List<StageXMLData> findStageXmlDataForCompressing();

    @Query("select c from StageXMLData  c WHERE c.status IN (:statuses) AND c.encryptKey = :encryptKey order by dateUpdated asc")
    public List<StageXMLData> findCompletedEncrypted (@Param("statuses") List<Integer> statuses,
                                                      @Param("encryptKey") String encryptKey,
                                                      Pageable pageable);

    @Query("select C.status, count(*) from StageXMLData C where C.status in (0, 5) and C.dateUpdated <= :last6Hours group by C.status order by C.status")
    public List<Object[]> findLast6HoursStuckJob (@Param("last6Hours") Date last6Hours);

    @Transactional
    long deleteByTenantId(long tenantId);

    /**
     *
     * @param MAXRETRYCOUNT
     * @param maxParallelJobs
     * @return
     *
     * The query is executed in 3 parts.
     * 1. Step 1 is to determine the tenants in combination with the sender business system id which are in progress status. These combination shouldn't be processed until the processing of the previous jobs are completed.
     *      Query is: SELECT
     * 			Tenant_id,
     * 			IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK') sbsid
     * 		FROM
     * 			STAGEXMLDATATAB
     * 		WHERE
     * 			status = 1
     * 		GROUP BY
     * 			Tenant_id,
     * 			IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK')
     * 2. Step 2 is to determine the tenants for job processing excluding the combination determined in step 1.
     *      Query: SELECT
     * 		T.tenant_Id,
     * 		IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')
     * 	FROM
     * 		STAGEXMLDATATAB T
     * 	WHERE
     * 		T.status = 0
     * 		AND T.processedCount < :MAXRETRYCOUNT
     * 		AND (T.TENANT_ID,
     * 		IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')) NOT IN (
     * 		SELECT
     * 			Tenant_id,
     * 			IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK') sbsid
     * 		FROM
     * 			STAGEXMLDATATAB
     * 		WHERE
     * 			status = 1
     * 		GROUP BY
     * 			Tenant_id,
     * 			IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK') )
     * 	GROUP BY
     * 		T.tenant_Id,
     * 		IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')
     * 	ORDER BY
     * 		MIN(T.date_Created) ASC
     * 	LIMIT :maxParallelJobs
     *
     * 	Note: Maximum of 10 tenants can be selected for job processing at a time. This is configurable value.
     *
     * 	Step 3: Determine the jobs for the selected tenants sorted by Date_Created and all these jobs needs to be ranked and stored in a virtual table called RankedJobs.
     * 	Query: WITH RankedJobs AS (
     * SELECT
     * 	T.ID,
     * 	T.DATA_PATH,
     * 	T.DATE_CREATED,
     * 	T.DATE_UPDATED,
     * 	T.IS_ACTIVE,
     * 	T.STATUS,
     * 	T.TENANT_ID,
     * 	T.OBJECTNAME,
     * 	T.UUID,
     * 	T.SENDERBUSINESSSYSTEMID,
     * 	T.ISSTATIC,
     * 	T.VERSION,
     * 	T.OPERATION,
     * 	T.PROCESSFROM,
     * 	T.PROCESSEDCOUNT,
     * 	T.SOURCE_CREATED_DATE,
     * 	T.DATA_PURGED,
     * 	T.ENCRYPTIONVERSION,
     * 	T.DATA_COMPRESSED,
     * 	T.AUTH_TYPE,
     * 	T.IS_MDNI_PAYLOAD,
     * 	T.ENCRYPT_KEY,
     * 	DENSE_RANK () OVER (PARTITION BY T.TENANT_ID,
     * 	T.SENDERBUSINESSSYSTEMID
     * ORDER BY
     * 	T.DATE_CREATED ASC,
     * 	T.ID ASC) AS job_rank
     * FROM
     * 	STAGEXMLDATATAB T
     * WHERE
     * 	T.status = 0
     * 	AND T.processedCount < :MAXRETRYCOUNT
     * 	AND (T.TENANT_ID,
     * 	IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')) IN (
     * 	SELECT
     * 		T.tenant_Id,
     * 		IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')
     * 	FROM
     * 		STAGEXMLDATATAB T
     * 	WHERE
     * 		T.status = 0
     * 		AND T.processedCount < :MAXRETRYCOUNT
     * 		AND (T.TENANT_ID,
     * 		IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')) NOT IN (
     * 		SELECT
     * 			Tenant_id,
     * 			IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK') sbsid
     * 		FROM
     * 			STAGEXMLDATATAB
     * 		WHERE
     * 			status = 1
     * 		GROUP BY
     * 			Tenant_id,
     * 			IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK') )
     * 	GROUP BY
     * 		T.tenant_Id,
     * 		IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')
     * 	ORDER BY
     * 		MIN(T.date_Created) ASC
     * 	LIMIT :maxParallelJobs) )
     *
     * 	Step 4: Select the jobs with least rank for the final processing. Maximum of 10 jobs can be selected which is a configurable number.
     *
     */
    @Query(value = "WITH RankedJobs AS (" +
            " SELECT T.ID, T.DATA_PATH, T.DATE_CREATED, T.DATE_UPDATED, T.IS_ACTIVE, T.STATUS, T.TENANT_ID, T.OBJECTNAME, T.UUID, T.SENDERBUSINESSSYSTEMID, T.ISSTATIC, T.VERSION, T.OPERATION, T.PROCESSFROM, T.PROCESSEDCOUNT, T.SOURCE_CREATED_DATE, T.DATA_PURGED, T.ENCRYPTIONVERSION, T.DATA_COMPRESSED, T.AUTH_TYPE, T.IS_MDNI_PAYLOAD, T.ENCRYPT_KEY," +
            " DENSE_RANK () OVER (PARTITION BY T.TENANT_ID, T.SENDERBUSINESSSYSTEMID" +
            " ORDER BY" +
            " T.DATE_CREATED ASC, T.ID ASC) AS job_rank" +
            " FROM" +
            " STAGEXMLDATATAB T" +
            " WHERE" +
            " T.status = 0 AND T.processedCount < :MAXRETRYCOUNT" +
            " AND (T.TENANT_ID, IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')) IN (" +
            " SELECT" +
            " T.tenant_Id, IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')" +
            " FROM" +
            " STAGEXMLDATATAB T" +
            " WHERE" +
            " T.status = 0 AND T.processedCount < :MAXRETRYCOUNT" +
            " AND (T.TENANT_ID, IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')) NOT IN (" +
            " SELECT" +
            " Tenant_id, IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK') sbsid" +
            " FROM" +
            " STAGEXMLDATATAB" +
            " WHERE" +
            " status = 1" +
            " GROUP BY" +
            " Tenant_id, IFNULL(SENDERBUSINESSSYSTEMID, 'BLANK') )" +
            " GROUP BY" +
            " T.tenant_Id, IFNULL(T.SENDERBUSINESSSYSTEMID, 'BLANK')" +
            " ORDER BY" +
            " MIN(T.date_Created) ASC LIMIT :maxParallelJobs) )" +
            " SELECT S.ID, S.DATA_PATH, S.DATE_CREATED, S.DATE_UPDATED, S.IS_ACTIVE, S.STATUS, S.TENANT_ID, S.OBJECTNAME, S.UUID, S.SENDERBUSINESSSYSTEMID, S.ISSTATIC, S.VERSION, S.OPERATION, S.PROCESSFROM, S.PROCESSEDCOUNT, S.SOURCE_CREATED_DATE, S.DATA_PURGED, S.ENCRYPTIONVERSION, S.DATA_COMPRESSED, S.AUTH_TYPE, S.IS_MDNI_PAYLOAD, S.ENCRYPT_KEY" +
            " FROM" +
            " RankedJobs S" +
            " WHERE" +
            " S.job_rank < :maxParallelJobs" +
            " ORDER BY" +
            " S.job_rank," +
            " S.DATE_CREATED" +
            " LIMIT :maxParallelJobs", nativeQuery = true)
    public List<StageXMLData> getAllUnprocessedJobs(@Param("MAXRETRYCOUNT") int MAXRETRYCOUNT, @Param("maxParallelJobs") int maxParallelJobs);


}

