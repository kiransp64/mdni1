package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.common.metrics.MDNIMetrics;
import com.sap.ariba.erpintegration.common.metrics.MDNIServiceRegistry;
import com.sap.ariba.erpintegration.handlers.cap.JWTBasedAuthenticator;
import com.sap.ariba.erpintegration.monitor.im.helper.IMHelper;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.BeanUtil;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.erpintegration.util.cap.JWTUtil;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.interceptor.Fault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;

/**
 * Created by c5259108 on 12/12/17.
 */

public class AuthenticateRequestHandlerBase extends AbstractSoapInterceptor {

    public static final String authUsingCIGCertificate = "AUTH_CIG_CERTIFICATE";
    public static final String authUsingCredentials = "AUTH_CREDENTIAL";
    public static final String authUsingCertificate = "AUTH_CERTIFICATE";
    public static final String authUsingMDCSJWT = "AUTH_MDCS_JWT";

    private static final String INVALID_AUTHENTICATION_MSG = "Missing / Invalid Authentication Credentials.";
    private static final String INVALID_CREDENTIAL_MSG = "CredentialBasedAuthentication verification failed. ";
    private static final String SIGNATURE_VERIFICATION_FAILED_MSG = "Signature verification failed.";

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.service.ws.AuthenticateRequestHandlerBase";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);

    @Autowired
    public CertificateBasedAuthenticator certificateBasedAuthenticator;

    @Autowired(required = false)
    @Lazy
    public JWTBasedAuthenticator jwtBasedAuthenticator;

    public AuthenticateRequestHandlerBase(String phase)
    {
        super(phase);
    }

    @Autowired
    public AuditClientDataService auditClientDataService;

    @Lazy
    @Autowired
    private IMHelper imHelper;

    @Value("${integration.monitoring.enabled}")
    private Boolean isIMEnabled;

    private MDNIServiceRegistry mdniServiceRegistry = null;

    @Override
    public void handleMessage (SoapMessage message) throws Fault
    {
        String anId = HandlerUtil.getANId(message);
        String authorizationToken = null;
        if(anId == null && HandlerUtil.isMDCS()) {
            logger.debug("[MDCS] Tenant Id is missing as part of request parameter. As it's MDCS mode checking if the request has a JWT token");
            //Check if it has jwt token as part of Bearer
            authorizationToken = HandlerUtil.getTokenFromBearer(HandlerUtil.getAuthorizationToken(message));
            logger.debug("[MDCS] Authorization Header : {}", authorizationToken);
            if (JWTUtil.isJWT(authorizationToken)) {
                //get the zone id as it's anId in case of MDCS
                anId = JWTUtil.getZoneId(authorizationToken);
                logger.info("[MDCS] Zone Id : {}", anId);
            }
        }

        String authType = null;
        // if tenantId doesn't exist or is not registered
        if(!(Utility.isTenantExists(anId)))
        {
            logger.error("[MDNI_CRITICAL][ARIBA][Authentication] Tenant ID - {} not recognized, Not a valid incoming request ",
                         anId);
            throw new Fault(new Throwable("Not a valid incoming request. Tenant " + anId + " not recognized"));
        }
        boolean isCigSource = HandlerUtil.isCigSource(message);
        if(HandlerUtil.isMDCS() && !isCigSource && authorizationToken!= null
            && JWTUtil.isJWT(authorizationToken)){
            // Verify the JWT Token for MDCS
            auditClientDataService.authenticationIdentifier.set(authUsingMDCSJWT);
            performJWTBasedAuthentication(message);
            return;
        }
        else if (isCigSource) {
            // If cigSource query parameter is set, that is to say that the request
            // arises from CIG and the mode of authentication is Certificate based
            // Get CIG Certificate here.
            auditClientDataService.authenticationIdentifier.set(authUsingCIGCertificate);
            performCertificateBasedAuthentication(message);
            return;
        }
        else {
            // Get the message and check if Authorization headers are supplied.
            // Based on that, either perform credential based or certificate
            // based
            // authentication
            if (shouldPerformCredentialBasedAuthentication(message)) {
                auditClientDataService.authenticationIdentifier.set(authUsingCredentials);
                performCredentialBasedAuthentication(message);
            }
            else {
                auditClientDataService.authenticationIdentifier.set(authUsingCertificate);
                performCertificateBasedAuthentication(message);
            }
        }
    }

    private void performCertificateBasedAuthentication (SoapMessage message) throws Fault
    {
        try {
            if(!certificateBasedAuthenticator.authenticate(message)) {
                auditClientDataService.auditAuthentication(message,SIGNATURE_VERIFICATION_FAILED_MSG);
                if (isIMEnabled) {
                    imHelper.processIMMonitoring(message,
                                                 SIGNATURE_VERIFICATION_FAILED_MSG,
                                                 true);
                }
                throw new Fault(new Throwable(SIGNATURE_VERIFICATION_FAILED_MSG));

            }else {
                auditClientDataService.auditAuthentication(message,null);
            }
        }
        catch (IntegrationServiceException ex){
            logger.error("[MDNI_CRITICAL][ARIBA][Authentication], CertificateBasedAuthentication verification failed",
                    ex);
            if (isIMEnabled) {
                imHelper.processIMMonitoring(message,
                                             ex.getMessage(),
                                             true);
            }
            if(mdniServiceRegistry == null) {
                mdniServiceRegistry = BeanUtil.getMdniServiceRegistry();
            }
            if(mdniServiceRegistry != null) {
                mdniServiceRegistry.sendMetricsForCounter(MDNIMetrics.CIG_REQUEST_AUTH_ERROR);
            }
            if(auditClientDataService != null) {
                auditClientDataService.auditAuthentication(message,ex.getMessage());
            }
            throw new Fault(new Throwable(ex.getMessage()));
        }


    }

    private void performCredentialBasedAuthentication (SoapMessage message) throws Fault
    {
        try {
            if (!getCredentialBasedAuthenticator().authenticate(message)) {
                auditClientDataService.auditAuthentication(message,INVALID_AUTHENTICATION_MSG);
                if (isIMEnabled) {
                    imHelper.processIMMonitoring(message,
                                                 INVALID_AUTHENTICATION_MSG,
                                                 true);
                }
                throw new Fault(new Throwable(INVALID_AUTHENTICATION_MSG));
            }else {
                auditClientDataService.auditAuthentication(message,null);
            }
        }
        catch (IntegrationServiceException ex){
            logger.error(INVALID_CREDENTIAL_MSG,ex.getMessage());
            auditClientDataService.auditAuthentication(message,INVALID_CREDENTIAL_MSG + ex.getMessage());
            if (isIMEnabled) {
                imHelper.processIMMonitoring(message,
                                             INVALID_CREDENTIAL_MSG + ex.getMessage(),
                                             true);
            }
            throw new Fault(new Throwable(ex.getMessage()));
        }
    }

    private boolean shouldPerformCredentialBasedAuthentication (SoapMessage message)
    {
        AuthorizationPolicy policy = message.get(AuthorizationPolicy.class);
        logger.debug("AuthenticateRequestHandlerBase: message"+ message);
        return (policy != null);
    }

    private void performJWTBasedAuthentication (SoapMessage message) throws Fault {
        try {
            if (!jwtBasedAuthenticator.authenticate(message)) {
                auditClientDataService.auditAuthentication(message, "JWT verification failed");
                throw new Fault(new Throwable("JWT verification failed"));
            } else {
                auditClientDataService.auditAuthentication(message, null);
            }
        } catch (Throwable t) {
            logger.error("[MDNI_CRITICAL] JwtBasedAuthenticator verification failed", t.getMessage());
            auditClientDataService.auditAuthentication(message, t.getMessage());
            throw new Fault(new Throwable(t.getMessage()));
        }
    }

    private CredentialBasedAuthenticator getCredentialBasedAuthenticator ()
    {
        CredentialAuthenticatorFactory credentialAuthenticatorFactory = BeanUtil.getBean(
            CredentialAuthenticatorFactory.class);
        if (credentialAuthenticatorFactory != null) {
            return credentialAuthenticatorFactory.getCredentialBasedAuthenticator();
        }
        throw new RuntimeException(
            "Couldn't get CredentialAuthenticatorFactory bean from Spring Context.");
    }
}
