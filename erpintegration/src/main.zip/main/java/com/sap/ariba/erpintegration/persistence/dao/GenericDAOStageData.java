package com.sap.ariba.erpintegration.persistence.dao;


import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.sap.ariba.erpintegration.persistence.model.GenericEntityStageData;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;

/**
 * Created by c5259108 on 05/06/17.
 */
@NoRepositoryBean
public interface GenericDAOStageData<T,D> extends PagingAndSortingRepository<GenericEntityStageData, Long>,
                CrudRepository<GenericEntityStageData, Long>
{

    public GenericEntityStageData findOne(String lookupKey);

    public List<GenericEntityStageData> findRecordsInProcessingStatus();

    public Page<GenericEntityStageData> findLastNRows (Pageable pageable);

    public List<StageXMLData> findAllUnprocessedRows ();

    public void updateStatus(String id, int status,Date dateUpdated);

    public int updateStatusForTenants (int newStatus, List<Long> tenantIds, List<Integer> currentStatuses, Date dateUpdated);

    public GenericEntityStageData findStaticRecord(String objectName,long systemTenantId);

    public List<StageXMLData> findRecordsInNeedsReprocessingStatus (String objectName, int status, long tenantId);

    public Page<StageXMLData> findKeyFieldsOfAllRecords(long tenantId, Pageable pageable);
    
    public Page<StageXMLData> findRecordsInRange(long tenantId, Date start, Date end, Pageable pageable);

    public List<StageXMLData> getAllUnprocessedJobs(int MAXRETRYCOUNT, int maxParallelJobs);

    
}
