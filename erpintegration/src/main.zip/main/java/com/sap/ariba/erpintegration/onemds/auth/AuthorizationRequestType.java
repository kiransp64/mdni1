package com.sap.ariba.erpintegration.onemds.auth;

public enum AuthorizationRequestType {
    ARIBA("Ariba"), MDCS_MDI("mdcs_mdi"), MDCS_DESTINATION("mdcs_destination");

    String value;

    AuthorizationRequestType (String value)
    {
        this.value = value;
    }

    public String getValue ()
    {
        return this.value;
    }
}
