package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.PurchaseOrg;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created by i318483 on 01/06/17.
 */
@Component("PurchaseOrgJPARepositoryComponent")
public interface PurchaseOrgJPARespository extends GenericJPADAO<PurchaseOrg, Long>
{
    @Query(value = "select Min(Id) from StagePurchaseOrg_Tab where Date_Updated > :timeUpdated and Tenant_Id = :tenantId", nativeQuery = true)
    public String findMinId(@Param("timeUpdated") Date timeUpdated, @Param("tenantId") String tenantId);

    @Query(value = "select Max(Id) from StagePurchaseOrg_Tab where Date_Updated > :timeUpdated and Tenant_Id = :tenantId", nativeQuery = true)
    public String findMaxId(@Param("timeUpdated") Date timeUpdated, @Param("tenantId") String tenantId);
}
