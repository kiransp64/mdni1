package com.sap.ariba.erpintegration.common.async;

/**
 * Created by i318483 on 24/04/17.
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.security.concurrent.DelegatingSecurityContextExecutor;
import java.util.concurrent.Executor;

@Configuration
public class AsyncConfig implements AsyncConfigurer
{

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public Executor getAsyncExecutor ()
    {
        SimpleAsyncTaskExecutor delegateExecutor = new SimpleAsyncTaskExecutor();
        DelegatingSecurityContextExecutor executor = new DelegatingSecurityContextExecutor(delegateExecutor);
        return executor;
    }

    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler ()
    {
        return (ex, method, params) -> logger.error("Uncaught async error", ex);
    }

}
