package com.sap.ariba.erpintegration.handlers;

import org.apache.cxf.message.Message;


/**
 * Created by i318483 on 04/05/17.
 */
public class WSDLValidator //extends DocLiteralInInterceptor
{
    public WSDLValidator ()
    {
        super();
    }


    public void handleMessage(Message message)
    {

    }
}
