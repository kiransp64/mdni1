package com.sap.ariba.erpintegration.service.mds;

public enum MDSPublishStatus {
    SUCCESS,
    FAILURE
}
