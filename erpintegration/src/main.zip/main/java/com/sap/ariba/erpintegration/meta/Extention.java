package com.sap.ariba.erpintegration.meta;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by i318483 on 07/06/17.
 */
@XmlRootElement
public class Extention
{
    private String name;
    private List<Module> module;

    @XmlAttribute
    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    @XmlElement
    public List<Module> getModule ()
    {
        return module;
    }

    public void setModule (List<Module> module)
    {
        this.module = module;
    }
}
