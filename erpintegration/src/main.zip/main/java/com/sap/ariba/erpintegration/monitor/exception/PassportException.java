/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.exception;

public class PassportException extends Exception
{
    public PassportException ()
    {
        super();
    }

    public PassportException (String message)
    {
        super(message);
    }

    public PassportException (String message,
                              Throwable cause)
    {
        super(message,
              cause);
    }

    public PassportException (Throwable cause)
    {
        super(cause);
    }

    public PassportException (String message,
                              Throwable cause,
                              boolean enableSuppression,
                              boolean writableStackTrace)
    {
        super(message,
              cause,
              enableSuppression,
              writableStackTrace);
    }
}
