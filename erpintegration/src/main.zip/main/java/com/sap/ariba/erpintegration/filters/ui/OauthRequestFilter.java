package com.sap.ariba.erpintegration.filters.ui;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Base64;
import java.util.Map;

//@Component
//@Order(1)
public class OauthRequestFilter implements Filter
{
    @Autowired
    private OAuthTokenManager oAuthTokenManager;
    
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.filters.ui.OauthRequestFilter";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    @Override
    public void init (FilterConfig filterConfig) throws ServletException
    {
        
    }

    @Override
    public void doFilter (ServletRequest req,
                          ServletResponse res,
                          FilterChain chain)
        throws IOException,
        ServletException
    {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res; 
        response = addAuthHeader(response);            
        chain.doFilter(request, response);     
    }
    
    public  HttpServletResponse addAuthHeader(HttpServletResponse response) {
        //added for debugging to check which service is receiving this,will remove later
        logger.info("in the interceptor");
        oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(OAuthTokenManager.class);
        Map<String, String> tokenMap = oAuthTokenManager.getTokens("system", null);
        if(tokenMap == null) {
            logger.error("No token returned from the token fetch server");
            return response;
        }
        JSONObject jsonToken = new JSONObject();
        
        tokenMap.entrySet().forEach((entry) -> {
            jsonToken.put(entry.getKey(), entry.getValue());
        });        
        String encodedToken = Base64.getEncoder().encodeToString(jsonToken.toString().getBytes());
        response.setHeader(HttpHeaders.AUTHORIZATION, encodedToken);        
        return response;
        
    }

    @Override
    public void destroy ()
    {
        
    }
}
