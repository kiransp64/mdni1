package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import jakarta.annotation.PostConstruct;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.map.LRUMap;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.common.util.StringUtils;
import org.apache.wss4j.common.crypto.CertificateStore;
import org.apache.wss4j.common.crypto.Crypto;
import org.apache.wss4j.common.ext.WSSecurityException;
import org.apache.wss4j.dom.WSConstants;
import org.apache.wss4j.dom.engine.WSSecurityEngine;
import org.apache.wss4j.dom.engine.WSSecurityEngineResult;
import org.apache.wss4j.dom.handler.WSHandlerResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

import jakarta.xml.soap.SOAPMessage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@ConfigurationProperties(prefix = "certificate.cache")
@Component
public class CertificateBasedAuthenticator
{
    private static final Logger logger = LoggerFactory.getLogger(
        CertificateBasedAuthenticator.class);
    public static final String KeyCertificateContent = "CertificateContent";
    public static final String KeyCIGCertificateContent = "CIGCertificateContent";
    private static final String CIG = "CIG";
    private static final String X509 = "X.509";
    /**
     * Maximum number of certificates that will be stored in the cache.
     */
    private static final int MaxCacheSize = 500;
    private static final String SOAPAction_ANID = "SOAPAction";
    // Cache now holds Certificates corresponding to a each tenant when
    // cigSource is false(read from configured Endpoint), else it stores one CIG
    // certificate Keys would be like AN001, AN002, ...., CIG.
    private static final Map<String, X509Certificate> certificateCache = Collections.synchronizedMap(
        new LRUMap<>(MaxCacheSize));
    private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private static long initialDelayMin;
    private static long delayMin;

    public CertificateBasedAuthenticator()
    {
        logger.info("CertificateBasedAuthenticator constructor");
    }

    @PostConstruct
    public void init ()
    {
        logger.info("CertificateBasedAuthenticator init");
        Runnable cacheClearTask = () -> {
            //Handling the exception, else the scheduled task on exception shall suspend the
            //further executions of the same.
            //Please read the javadoc of scheduleWithFixedDelay.
            try {
                clearCertificateCache();
            } catch (Exception e) {
                logger.warn("Exception in CertificateBasedAuthenticator task : {}", e.getMessage(), e);
            }
        };
        scheduler.scheduleWithFixedDelay(cacheClearTask, initialDelayMin, delayMin, TimeUnit.MINUTES);
    }

    public boolean authenticate (SoapMessage message) throws IntegrationServiceException
    {
        String anId = getANId(message);
        if(anId == null){
            logger.error("Tenant not passed");
            throw new IntegrationServiceException("Tenant not passed");
        }
        boolean authenticated = false;
        authenticated = verifyCertificate(anId, message);
        if (authenticated) {
            logger.info(
                "Certificate based authentication successful for tenant: " + anId);
        }
        else {
            boolean isCigSource = HandlerUtil.isCigSource(message);
            logger.info(
                "Clearing certificate cache and retrying authentication for tenant: " + anId);
            removeCachedCertificateForTenant(anId, isCigSource);
            authenticated = verifyCertificate(anId, message);
        }
        return authenticated;
    }

    private boolean verifyCertificate (String anId, SoapMessage message)
    {
        boolean authenticated = false;
        boolean isCigSource = HandlerUtil.isCigSource(message);
        SOAPMessage doc = message.getContent(SOAPMessage.class);
        if (doc == null) {
            SAAJInInterceptor.INSTANCE.handleMessage(message);
            doc = message.getContent(SOAPMessage.class);
        }
        Document soapDoc = (Document)doc.getSOAPPart();
        try {
            X509Certificate tenantCert = null;
            if(HandlerUtil.isMDCS()){
                tenantCert = getMdcsCIGCertificate(anId);
            }else{
                if (isCigSource) {
                    tenantCert = getCIGCertificate(anId);
                }
                else {
                    tenantCert = getTenantCertificate(anId);
                }
            }

            X509Certificate[] certs = new X509Certificate[1];
            certs[0] = tenantCert;

            Crypto crypto = new CertificateStore(certs);

            WSSecurityEngine wsEngine = new WSSecurityEngine();
            logger.info("Starting certificate based authentication for tenant: " + anId);
            WSHandlerResult wsHandlerResult = wsEngine.processSecurityHeader(
                soapDoc,
                null,
                null,
                crypto,
                null);
            List<WSSecurityEngineResult> results = wsHandlerResult.getResults();

            if (!CollectionUtils.isEmpty(results)) {
                // Get signature result
                WSSecurityEngineResult signatureResult = null;
                Iterator iterator = results.iterator();

                while(iterator.hasNext()) {
                    WSSecurityEngineResult result = (WSSecurityEngineResult)iterator.next();
                    int resultAction = (Integer)result.get("action");
                    if (resultAction == WSConstants.SIGN) {
                        signatureResult = result;
                    }
                }

                if (!MapUtils.isEmpty(signatureResult)) {
                    authenticated = true;
                }
            }
        }
        catch (IntegrationServiceException | WSSecurityException e) {
            logger.error("[MDNI_CRITICAL] Certificate based authentication failed for tenant: {} ", anId , e);
        }
        return authenticated;
    }

    /**
     * @param anId
     * @return fetches the realm specific Certificate stored in the Endpoint
     *         configured,
     * @throws IntegrationServiceException
     */
    private X509Certificate getTenantCertificate (String anId) throws IntegrationServiceException
    {
        X509Certificate certificate = certificateCache.get(anId);
        if (certificate == null) {
            logger.info("CertificateBasedAuthenticator: getTenantCertificate - certificate not available in cache");
            Map responseAsMap = HandlerUtil.getConfiguredCertificate(anId, false);
            if (!MapUtils.isEmpty(responseAsMap)) {
                try {
                    String certificateContent = null;
                    certificateContent = (responseAsMap.get(KeyCertificateContent) != null)
                        ? (String) responseAsMap.get(KeyCertificateContent)
                        : null;
                    certificate = createCertificate(certificateContent);
                    certificateCache.put(anId, certificate);
                } catch (CertificateException | IOException e) {
                    throw new IntegrationServiceException(
                        "Error getting certificate for tenant: " + anId,
                        e);
                }
            }
        }
        return certificate;
    }
 
    /**
     * @param anId
     * @return fetches the CIG Certificate
     * @throws IntegrationServiceException
     */
    private X509Certificate getCIGCertificate (String anId) throws IntegrationServiceException
    {
        X509Certificate certificate = certificateCache.get(CIG);
        if (certificate == null) {
            logger.info("CertificateBasedAuthenticator: getCIGCertificate - certificate not available in cache");
            Map responseAsMap = HandlerUtil.getConfiguredCertificate(anId, true);
            if (!MapUtils.isEmpty(responseAsMap)) {
                try {
                    String certificateContent = null;
                    certificateContent = (responseAsMap.get(KeyCIGCertificateContent) != null)
                        ? (String) responseAsMap.get(KeyCIGCertificateContent)
                        : null;      
                    certificate = createCertificate(certificateContent);
                    certificateCache.put(CIG, certificate);
                } catch (CertificateException | IOException e) {
                    throw new IntegrationServiceException(
                        "Error getting CIG certificate for tenant: " + anId,
                        e);
                }
            }
        }
        return certificate;
    }
    /**
     * @return fetches the CPI Certificate
     * @throws IntegrationServiceException
     */
    private X509Certificate getMdcsCIGCertificate (String anId) throws IntegrationServiceException {
        X509Certificate certificate = certificateCache.get(CIG);
        if (certificate == null) {
            logger.info("CertificateBasedAuthenticator: getMdcsCIGCertificate - certificate not available in cache");
            String certificateContent = HandlerUtil.getMDCSConfiguredCIGCertificate();
            if (!StringUtils.isEmpty(certificateContent)) {
                try {
                    certificate = createCertificate(certificateContent);
                    certificateCache.put(CIG, certificate);
                } catch (CertificateException | IOException e) {
                    logger.error("Exception in fetching the CIG certificates");
                    throw new IntegrationServiceException(
                            "Error getting CPI certificate : ",
                            e);
                }
            }
        }
        return certificate;
    }


    private X509Certificate createCertificate (String certContent)
        throws CertificateException, IOException
    {
        if (StringUtils.isEmpty(certContent)) {
            logger.error("Certificate content stored in the application is empty");
            throw new CertificateException("Certificate content stored in the application is empty");
        }
        try (InputStream stream = new ByteArrayInputStream(certContent.getBytes())) {
            CertificateFactory cf = CertificateFactory.getInstance(X509);
            return (X509Certificate)cf.generateCertificate(stream);
        }
    }
    
    /**
     * @param anId
     * @param cigSource Depending on the cigSource clears the CIG certificate or
     *            the tenant specific Certificate from cache
     */
    private void removeCachedCertificateForTenant (String anId, boolean cigSource)
    {
        if(cigSource)
        {
            certificateCache.remove(CIG);
        }
        else if (!StringUtils.isEmpty(anId)) {
            certificateCache.remove(anId);
        }
    }

    public void clearCertificateCache ()
    {
        logger.info("CertificateBasedAuthenticator: clearing the cached certificate");
        certificateCache.clear();
    }

    private String getANId (SoapMessage message)
    {
        String anId = HandlerUtil.getANId(message);
        if (anId == null) {
            anId = (String) message.get(SOAPAction_ANID);
        }
        return anId;
    }

    public void setDelayMin (int cacheDelayMin)
    {
        delayMin = cacheDelayMin;
    }

    public void setInitialDelayMin (int cacheInitialDelayMin)
    {
        initialDelayMin = cacheInitialDelayMin;
    }

}
