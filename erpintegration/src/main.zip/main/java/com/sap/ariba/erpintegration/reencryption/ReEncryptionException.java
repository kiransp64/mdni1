package com.sap.ariba.erpintegration.reencryption;

public class ReEncryptionException extends Exception
{
    public ReEncryptionException (String message)
    {
        super(message);
    }

    public ReEncryptionException (String message, Throwable cause)
    {
        super(message, cause);
    }
}
