package com.sap.ariba.erpintegration.cache;
import com.sap.ariba.audit.auditclient.enums.PurgeScope;
import org.apache.commons.collections4.map.LRUMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Collections;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * This class is used for storing the value of audit PurgeScope in cache.
 * It will reduce the call to database.
 */
@Component
public class AuditPurgeScopeCache {
    private static AuditPurgeScopeCache instance;
    public static Logger logger = LoggerFactory.getLogger(AuditPurgeScopeCache.class);
    private static  Map<String, PurgeScope> auditPurgeScopeCache = null;
    private static long timeSinceCacheRefreshed = 0L;

    @Value("${purgescope.cache.expirationtime}")
    private long expirationTimeInMillis;

    @Value("${purgescope.cache.maxsize}")
    private int maxCacheSize;

    private AuditPurgeScopeCache() {}

    public PurgeScope getPurgeScopeCache (String anId)
    {
        checkForCacheExpiration();
        PurgeScope purgeScopeCache = auditPurgeScopeCache.get(anId);
        return purgeScopeCache;
    }

    public Map<String, PurgeScope> put (String anId, PurgeScope url)
    {
        checkForCacheExpiration();
        auditPurgeScopeCache.put(anId,url);
        return auditPurgeScopeCache;
    }

    private void checkForCacheExpiration ()
    {
        if (auditPurgeScopeCache == null || (System.currentTimeMillis()
                - timeSinceCacheRefreshed) > expirationTimeInMillis) {
            auditPurgeScopeCache = Collections.synchronizedMap(new LRUMap<>(maxCacheSize));
            timeSinceCacheRefreshed = System.currentTimeMillis();
        }
    }

}
