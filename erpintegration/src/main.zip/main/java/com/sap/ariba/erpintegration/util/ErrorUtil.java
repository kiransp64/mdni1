package com.sap.ariba.erpintegration.util;

public class ErrorUtil
{
    public static final int MAX_CHARACTERS = 250;

    public static final String DB_PREFIX = "SAP DBTech JDBC";

    public static final String TRUNCATED_MSG_SUFFIX = "...}";
    public static final String X_PROCESSING_FAILURE = "x-processing-failure";

    public static String getCompleteCausedByErrors (Throwable exception)
    {
        StringBuilder resultBuilder = new StringBuilder();
        if (exception != null) {
            Throwable causedBy = exception;
            while (causedBy != null) {
                String message = causedBy.getMessage();
                if(message!=null) {
                    if (resultBuilder.length() > 0) {
                        resultBuilder.append(" :: ");
                    }
                    if (message.length() > MAX_CHARACTERS) {
                        if (!message.contains(DB_PREFIX))
                            message = message.substring(0, MAX_CHARACTERS);
                        else {
                            int dbPrefixIndex = message.indexOf(DB_PREFIX) + DB_PREFIX.length();
                            message = message.substring(dbPrefixIndex);
                        }
                        resultBuilder.append(message).append(TRUNCATED_MSG_SUFFIX);
                    }
                    else {
                        resultBuilder.append(message);
                    }
                }

                causedBy = causedBy.getCause();
            }
        }
        return resultBuilder.toString();
    }
}
