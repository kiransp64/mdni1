package com.sap.ariba.erpintegration.service.rs;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sap.ariba.erpintegration.handlers.RequestHandler;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;


/**
 * Created by i318483 on 31/05/17.
 */
// @RestController
public class IntegrationPayloadProcessorService
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.service.rs.IntegrationPayloadProcessorService";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);

    private static final String KeyAction = "ProcessPayload";

    @POST @RequestMapping("/processXMLPayload") public Response processXMLPayload (
        @Context HttpServletRequest request) throws IntegrationServiceException,MissingServletRequestParameterException
    {
        logger.info("Process Payload Hit");
        RequestHandler requestHandler = RequestHandler.getHandler(KeyAction);
        return requestHandler.execute(request);
    }
}
