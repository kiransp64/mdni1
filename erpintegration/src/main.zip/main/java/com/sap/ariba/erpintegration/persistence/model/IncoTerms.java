package com.sap.ariba.erpintegration.persistence.model;

import org.json.simple.JSONObject;

import java.io.Serializable;
import java.util.Map;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;


@Entity
@Table(name="INCOTERMS_TAB")
@DiscriminatorValue("b")
public class IncoTerms
		extends GenericEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String objectType = "IncoTerms";

	
	@Column(name="CODE")
	private String code;

	@Transient
	private static String[] lookupFields = {"Code"};

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public void setLookupFields(Map<String, String> lookupDetails) {
		Object specialField1 = lookupDetails.get(lookupFields[0]);

		setCode((String) specialField1);
	}

	@Override
	public String getObjectType()
	{
		return objectType;
	}

	@Override
	public void processCountryCode(JSONObject jsonObject){}
}
