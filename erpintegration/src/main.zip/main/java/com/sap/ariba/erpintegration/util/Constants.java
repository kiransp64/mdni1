package com.sap.ariba.erpintegration.util;

public class Constants
{
    public static final String KeyTenantId = "tenantId";
    public static final String KeyObjectName = "objectName";
    public static final String KeySenderBusinessSystemId = "senderBusinessSystemId";
    public static final String KeyJobId = "jobId";
    public static final String Authorization = "Authorization";
    public static final String MDI_ENABLED_VALUE = "true";
    public static final String MDI_DISABLED_VALUE = "false";
    public static final int MDI_ACTIVE_VALUE = 1;
    public static final boolean DESTINATION_ENABLED_VALUE = true;

}
