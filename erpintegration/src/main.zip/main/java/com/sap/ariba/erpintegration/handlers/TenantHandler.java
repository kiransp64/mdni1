package com.sap.ariba.erpintegration.handlers;

import java.util.Map;

import com.sap.ariba.erpintegration.service.exception.ResourceNotFoundException;

public interface TenantHandler
{
    Map<String, Object> getTenant (String tenantIdentifier)
        throws ResourceNotFoundException;
}
