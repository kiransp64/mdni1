package com.sap.ariba.erpintegration.handlers;

import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import org.apache.commons.collections4.map.LRUMap;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
@ConditionalOnExpression("${credential.cache.enabled} == true")
public class CredentialBasedAuthenticatorCache extends CredentialBasedAuthenticator
{
    private static final Logger logger = LoggerFactory.getLogger(CredentialBasedAuthenticatorCache.class);

    private static final int MaxCacheSize = 500;
    /**
     * Credentials Cache
     *
     * Key - AN ID
     * Value is a string array
     *  0th Element - User Name
     *  1st Element - Password
     */
    private final Map<String, String[]> credentialCache = Collections.synchronizedMap(
        new LRUMap<>(MaxCacheSize));
    private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    @Value("${credential.cache.initialDelayMin}")
    private long initialDelayMin;

    @Value("${credential.cache.delayMin}")
    private long delayMin;

    @PostConstruct
    public void init ()
    {
        Runnable cacheClearTask = () -> {
            //Handling the exception, else the scheduled task on exception shall suspend the
            //further executions of the same.
            //Please read the javadoc of scheduleWithFixedDelay.
            clearCache();
        };
        scheduler.scheduleWithFixedDelay(cacheClearTask, initialDelayMin, delayMin,
                                         TimeUnit.MINUTES);
    }

    @Override
    public boolean validateCredentials (String anId,
                                        String authorizationToken,
                                        String userName,
                                        String password)
    throws IntegrationServiceException
    {
        if (userName != null && password != null) {
            if (!super.validateCredentials(anId, authorizationToken, userName,
                                           password))
            {
                removeCacheEntry(anId);
                return super.validateCredentials(anId, authorizationToken, userName,
                                                 password);
            }
            return true;
        }
        else {
            return super.validateCredentials(anId, authorizationToken, userName,
                                             password);
        }
    }

    @Override
    protected String[] getConfiguredCredentials (String anID)
    throws IntegrationServiceException
    {
        String[] credentials = credentialCache.get(anID);
        if (ArrayUtils.isEmpty(credentials)) {
            logger.debug(
                "[Credential_Cache] Didn't find entry for credentials in cache for an ID - {}. Loading.",
                anID);
            credentials = super.getConfiguredCredentials(anID);
            credentialCache.putIfAbsent(anID, credentials);
        }
        return credentials;
    }

    private void clearCache ()
    {
        try {
            logger.info("[Credential_Cache] Clearing Cache.");
            credentialCache.clear();
        }
        catch (Exception e) {
            logger.error("Error while trying to clear credential based cache.", e);
        }
    }

    private void removeCacheEntry (String anID)
    {
        logger.debug("[Credential_Cache] Removing cache entry for an ID - {}", anID);
        credentialCache.remove(anID);
    }
}
