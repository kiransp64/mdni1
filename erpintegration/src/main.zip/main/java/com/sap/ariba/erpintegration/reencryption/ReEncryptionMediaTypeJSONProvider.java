package com.sap.ariba.erpintegration.reencryption;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.sap.ariba.erpintegration.mdi.api.SCIMMeditaTypeJSONProvider;
import com.sap.ariba.erpintegration.mdi.common.util.DateUtil;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.Provider;
import java.util.Date;

@Provider
@Consumes({ MediaType.APPLICATION_JSON })
@Produces({ MediaType.APPLICATION_JSON })
public class ReEncryptionMediaTypeJSONProvider extends SCIMMeditaTypeJSONProvider
{
    private static ObjectMapper mapper = new ObjectMapper();

    static {
        JavaTimeModule module = new JavaTimeModule();
        module.addSerializer(Date.class, new DateFormatSerializer(DateUtil.DATE_FORMAT));
        mapper.registerModule(module);
    }

    public ReEncryptionMediaTypeJSONProvider ()
    {
        super();
        setMapper(mapper);
    }
}
