package com.sap.ariba.erpintegration.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class MasterDataDependencyInfo
{
    private static final Map<String, List<String>> objectDependencyMap = new HashMap<>();

    static void addDependency (String object, List<String> dependcies)
    {
        objectDependencyMap.put(object, dependcies);
    }

    public static List<String> getDependecies (String object)
    {
        return objectDependencyMap.get(object);
    }
}

public class MasterDataDependencyProvider
{

    private static final List<String> objectDependencyOrderList = Arrays.asList(
        "Region",
        "Currency",
        "UnitOfMeasurement",
        "ExchangeRate",
        "IncoTerms",
        "TaxCode",
        "PaymentMethod",
        "PurchaseDocumentItemCategory",
        "CompanyCode",
        "PaymentTerms",
        "CostCentre",
        "WBSElement",
        "Plant",
        "InternalOrder",
        "FixedAsset",
        "GLAccount",
        "PurchasingOrg",
        "PurchasingGroup",
        "MaterialGroup",
        "AccountAssignmentCategory",
        "PlantPurchasingOrg",
        "User",
        "AccCategoryFieldStatusCombo",
        "AdjustmentType",
        "Group",
        "ProcurementUnit",
        "Product",
        "FMD",
        "BusinessPartner",
        "ProjectControllingObject",
        "BusinessPartnerRelationship",
        "PurchasingOrganization",
        "PurchasingCategory",
        "ProductGroup",
        "SymbolicGeneralLedgerAccount"
);

    static
    {
        populateMasterDataDependencyInfo();
    }

    public static void populateMasterDataDependencyInfo ()
    {
        MasterDataDependencyInfo.addDependency("CompanyCode", Arrays.asList("CostCentre","Plant", "InternalOrder", "GLAccount", "PurchasingOrg","FixedAsset"));
        MasterDataDependencyInfo.addDependency("Plant", Arrays.asList("PlantPurchasingOrg"));
        //MasterDataDependencyInfo.addDependency("User",  );
    }

    public static List<String> getObjectDependencyOrderList ()
    {
        return objectDependencyOrderList;
    }

    public static List<String> getDependencies (String objectName)
    {
        return MasterDataDependencyInfo.getDependecies(objectName);
    }

}
