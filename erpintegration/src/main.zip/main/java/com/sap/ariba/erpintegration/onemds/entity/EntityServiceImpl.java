package com.sap.ariba.erpintegration.onemds.entity;

import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.onemds.exception.BatchServiceException;
import com.sap.ariba.erpintegration.onemds.exception.EntityOrderException;
import com.sap.ariba.erpintegration.onemds.exception.EntityServiceException;
import com.sap.ariba.erpintegration.onemds.exception.NoDataFoundException;
import com.sap.ariba.erpintegration.onemds.tenant.batch.BatchService;
import com.sap.ariba.erpintegration.onemds.tenant.batch.core.persistance.Batch;
import com.sap.ariba.erpintegration.onemds.tenant.batch.core.persistance.BatchDetail;
import com.sap.ariba.erpintegration.onemds.tenant.batch.core.persistance.GenericBatchDetails;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.mdsclient.exception.MetaServiceException;
import com.sap.ariba.mdsclient.meta.MetaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EntityServiceImpl implements EntityService
{
    private static final Logger logger = LoggerFactory.getLogger(EntityServiceImpl.class);

    @Autowired
    private BatchService batchService;

    @Autowired
    private EntityOrderService entityOrderService;

    @Autowired
    @Lazy
    @Qualifier("clientMetaService")
    private MetaService metaService;

    @Override
    public Entity getNextEntityToFetchFromMDI (String tenantID, long batchID) throws
        EntityServiceException
    {
        try {
            List<Entity> entities = entityOrderService.getMDIOrder();
            Entity lastProcessedEntity = batchService.getLastProcessedEntityForLogFetch(tenantID, batchID);
            return lastProcessedEntity != null ?
                entityOrderService.getNextEntityForMDI(lastProcessedEntity) :
                entities.get(0);
        }
        catch (BatchServiceException bse) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {}, Exception  {}, while trying to get batch information for tenant ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(bse));
            throw new EntityServiceException(
                "Error while trying to get batch information for tenant - " + tenantID,
                bse);
        }
        catch (EntityOrderException eoe) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {}, Exception  {}, while trying to fetch entity order information for tenant ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(eoe));
            throw new EntityServiceException("Error while trying to fetch entity order information for tenant - "
                    + tenantID,
                eoe);
        }
        catch (RuntimeException rte) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {}, Exception  {}, while trying to get next entity for log processing ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(rte));
            throw new EntityServiceException(
                "Error while trying to get next entity for log processing for tenant - "
                    + tenantID + " and batch - " + batchID);
        }
    }

    @Override
    public Entity getNextEntityToSync (String tenantID, long batchID) throws
        EntityServiceException
    {
        try {
            Batch currentBatch = batchService.getBatch(tenantID, batchID);
            if (currentBatch != null) {
                List<Entity> entities = entityOrderService.getSyncOrder();
                Entity lastProcessedEntity = batchService
                    .getLastProcessedEntityForSync(tenantID, batchID);
                Entity nextEntity = null;
                if (lastProcessedEntity != null) {
                    nextEntity = entityOrderService.getNextEntityForSync(
                        lastProcessedEntity);
                }
                else {
                    nextEntity = entities.get(0);
                }
                BatchDetail batchDetail = null;
                while (nextEntity != null) {
                    batchDetail = batchService
                        .getBatchDetail(tenantID, batchID, nextEntity);
                    if (batchDetail == null) {
                        logger.info("[MDI_MONITOR][Sync] Tenant ID - {}, Batch ID - {}, Entity - {}, No batch detail found for log fetch, Moving to next entity.",
                                    tenantID,
                                    batchID,
                                    nextEntity);
                        nextEntity = entityOrderService.getNextEntityForSync(nextEntity);
                    }
                    else {
                        break;
                    }
                }
                return nextEntity;
            }
            else {
                logger.info("""
                                There is no batch found for tenant - {}, to sync data. \
                                Sync cannot be started unless log fetch is done.\
                                """,
                            tenantID);
                throw new NoDataFoundException(
                    "There is no batch found for tenant - " + tenantID
                        + ", to sync data. Sync cannot be started unless log fetch is done.");
            }
        }
        catch (BatchServiceException bse) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {},  Exception {}, while trying to get batch information for tenant ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(bse));
            throw new EntityServiceException(
                "Error while trying to get batch information for tenant - " + tenantID,
                bse);
        }
        catch (EntityOrderException eoe) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {},  Exception {}, while trying to fetch entity order information for tenant ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(eoe));
            throw new EntityServiceException("Error while trying to fetch entity order information for tenant - "
                    + tenantID,
                eoe);
        }
        catch (RuntimeException rte) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {},  Exception {}, while trying to get next entity for sync processing for tenant ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(rte));
            throw new EntityServiceException(
                "Error while trying to get next entity for sync processing for tenant - "
                    + tenantID + " and batch - " + batchID);
        }
    }

    @Override
    public boolean isBatchComplete (String tenantID, long batchID) throws
        EntityServiceException
    {
        try {
            Batch batch = batchService.getBatch(tenantID, batchID);
            GenericBatchDetails.BatchStatus status = batch.getStatus();
            if (GenericBatchDetails.BatchStatus.isSyncComplete(status)) {
                return true;
            }
            boolean hasSyncStarted = Batch.Stage.SYNC.equals(batch.getCurrentStage());
            if (hasSyncStarted) {
                List<Entity> syncEntities = entityOrderService.getSyncOrder();
                Entity nextEntity = getNextEntityToSync(tenantID, batchID);
                return areAllEntitiesProcessedForSync(batchID, tenantID, syncEntities)
                    || nextEntity == null;
            }
            return false;
        }
        catch (BatchServiceException | EntityOrderException e) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {},  Exception {}, while trying to find if batch is complete for tenant ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new EntityServiceException("Error while trying to find if batch is complete for tenant - " + tenantID
                    + " and batch ID - " + batchID,
                e);
        }
    }

    @Override
    public boolean isLogFetchComplete (String tenantID, long batchID) throws
        EntityServiceException
    {
        try {
            Batch batch = batchService.getBatch(tenantID, batchID);
            boolean hasSyncStarted = Batch.Stage.SYNC.equals(batch.getCurrentStage());
            GenericBatchDetails.BatchStatus batchStatus = batch.getStatus();
            boolean isLogFetchComplete = GenericBatchDetails.BatchStatus
                .isLogFetchComplete(batchStatus);
            if (hasSyncStarted || isLogFetchComplete) {
                return true;
            }
            else {
                List<Entity> logFetchEntities = entityOrderService.getMDIOrder();
                Entity entity = getNextEntityToFetchFromMDI(tenantID, batchID);
                return areAllEntitiesProcessedForLogFetch(batchID, tenantID, logFetchEntities)
                    || entity == null;
            }
        }
        catch (BatchServiceException | EntityOrderException e) {
            logger.error("[MDI_CRITICAL][Entity] Tenant ID - {}, Batch ID - {},  Exception {}, while trying to find if log fetch is complete for tenant ",
                         tenantID,
                         batchID,
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new EntityServiceException(
                "Error while trying to find if log fetch is complete for tenant - "
                    + tenantID + " and batch ID - " + batchID, e);
        }
    }

    @Override
    public List<String> getKeys (Entity entity) throws EntityServiceException
    {
        try {
            if (entity == null) {
                logger.error( "Entity passed cannot be blank, to get keys.");
                throw new EntityServiceException(
                    "Entity passed cannot be blank, to get keys.");
            }
            return metaService.getKeys(entity.getMdsName());
        }
        catch (MetaServiceException e) {
            logger.error("[MDI_CRITICAL][Entity] Entity - {}, Exception {}, while trying to get keys for entity ",
                         entity,
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new EntityServiceException("Error while trying to get keys for entity - " + entity,
                e);
        }
    }

    private boolean areAllEntitiesProcessedForSync (long batchID, String tenantID, List<Entity> allEntities) throws BatchServiceException
    {
        return batchService.getAllProcessedEntityForSync(tenantID, batchID).size() == allEntities.size();
    }

    private boolean areAllEntitiesProcessedForLogFetch(long batchID, String tenantID, List<Entity> allEntities) throws BatchServiceException
    {
        return batchService.getAllProcessedEntityForLogFetch(tenantID, batchID).size() == allEntities.size();
    }

}
