package com.sap.ariba.erpintegration.onemds.entity;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.onemds.exception.EntityOrderException;
import com.sap.ariba.mdsclient.util.JSONUtil;

@Component 
@ConditionalOnExpression("${environment.mdcs:false}==true")
public class MdcsOdmEntityOrderService extends EntityOrderService
{
    private static final Logger logger = LoggerFactory.getLogger(
        MdcsOdmEntityOrderService.class);

    private static final String MDCS_ODM_ENTITY_CONFIG = "mdcs.odm.entity.config.json";
    private static final String MDI_URI_PATH = "mdiURIPath";
    private static final String MDNI_EVENT_NAME = "mdniEventName";

    private static Map<String, Object> mdcsOdmEntityConfig;
    static {
        try {
            ObjectMapper mapper = new ObjectMapper();
            ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
            JsonNode jsonNode = mapper.readTree(
                contextClassLoader.getResourceAsStream(MDCS_ODM_ENTITY_CONFIG));
            mdcsOdmEntityConfig = JSONUtil.getMapFromJSON(jsonNode.toString());
        }
        catch (FileNotFoundException e) {
            logger.error("File not found", e);
        }
        catch (IOException e) {
            logger.error("Exception while reading the file", e);
        }
    }

    @Override
    public Entity getEntity (String entity) throws EntityOrderException
    {
        Entity entityObject = Entity.getEntity(entity);
        entityObject.setMdiURIPath((String)(getEntityConfig(entity).get(MDI_URI_PATH)));
        return entityObject;
    }

    public static Map<String, Object> getEntityConfig (String entityName)
        throws EntityOrderException
    {
        Map<String, Object> entityConfig = (Map<String, Object>)mdcsOdmEntityConfig.get(
            entityName);
        if (entityConfig == null) {
            logger.warn(
                "Could not get Entity Config.Invalid entity Name [{}]",
                entityName);
            throw new EntityOrderException("Invalid Entity Name [{" + entityName + "}]");
        }
        return entityConfig;
    }

}
