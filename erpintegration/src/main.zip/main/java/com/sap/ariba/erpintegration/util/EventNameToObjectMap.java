package com.sap.ariba.erpintegration.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by i318483 on 12/16/16.
 */
public class EventNameToObjectMap
{
    private static Map<String, String> operationToObjectMap = new HashMap<>();
    private static Map<String, String> objectToJsonObjectMap = new HashMap<>();
    private static Map<String, String> objectToOperationMap = new HashMap<>();
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.util.EventNameToObjectMap";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);


    private static String basePath;
    private boolean eventNameToObjectMapPopulated = false;

    static {
        popualteEventToObjectNameMap();
        populateObjectToEventNameMap();
    }

    public EventNameToObjectMap (@Value("${basePath}") String basePath)
    {
        this.basePath = basePath;
    }

    public static void addEventNameToObjectMap (String eventName, String objectName)
    {
        operationToObjectMap.put(eventName, objectName);
    }

    public static String getObjectName (String eventName)
    {
        return operationToObjectMap.get(eventName);
    }

    public static String getJSONObjectName (String objectName)
    {
        return objectToJsonObjectMap.get(objectName);
    }

    private static void populateObjectToEventNameMap ()
    {
        for (String key : operationToObjectMap.keySet()) {
            objectToOperationMap.put(operationToObjectMap.get(key), key);
        }
    }

    public static String getEventName (String objectName)
    {
        return objectToOperationMap.get(objectName);
    }

    public static void popualteEventToObjectNameMap()
    {
        addEventNameToObjectMap("PurchasingOrg", "PurchaseOrg");
        addEventNameToObjectMap("PurchasingGroup", "PurchaseGroup");
        addEventNameToObjectMap("Incoterms", "IncoTerms");
        addEventNameToObjectMap("InternalOrder", "InternalOrder");
        addEventNameToObjectMap("Currency", "Currency");
        addEventNameToObjectMap("PurchaseDocumentItemCategory", "ItemCategory");
        addEventNameToObjectMap("TaxCode", "TaxCode");
        addEventNameToObjectMap("WBSElement", "WBSElement");
        addEventNameToObjectMap("AccountAssignmentCategory", "AccountCategory");
        addEventNameToObjectMap("CompanyCode", "CompanyCode");
        addEventNameToObjectMap("CostCentre", "CostCenter");
        addEventNameToObjectMap("ExchangeRate", "CurrencyConversionRate");
        addEventNameToObjectMap("Plant", "Address");
        addEventNameToObjectMap("Region", "Region");
        addEventNameToObjectMap("GLAccount", "GeneralLedger");
        addEventNameToObjectMap("SymbolicGeneralLedgerAccount", "SymbolicGeneralLedgerAccount");
        addEventNameToObjectMap("MaterialGroup","PartitionedCommodityCode");
        addEventNameToObjectMap("ProductGroup","ProductGroup");
        addEventNameToObjectMap("PlantPurchasingOrg","PlantPurchaseOrgCombo");
        addEventNameToObjectMap("PaymentMethod","PaymentMethodType");
        addEventNameToObjectMap("CurrencyCode","CurrencyCode");
        addEventNameToObjectMap("CountryCode","CountryCode");
        addEventNameToObjectMap("UnitOfMeasurement","UnitOfMeasurement");
        addEventNameToObjectMap("LocaleCode","LocaleCode");
        addEventNameToObjectMap("User", "User");
        addEventNameToObjectMap("FixedAsset", "Asset");
        addEventNameToObjectMap("PaymentTerms", "PaymentTerms");
        addEventNameToObjectMap("AccCategoryFieldStatusCombo", "AccCategoryFieldStatusCombo");
        addEventNameToObjectMap("AdjustmentType", "AdjustmentType");
        addEventNameToObjectMap("Group", "Group");
        addEventNameToObjectMap("ProcurementUnit", "ProcurementUnit");
        addEventNameToObjectMap("Product", "ItemMaster");
        addEventNameToObjectMap("BusinessPartner","BusinessPartner");
        addEventNameToObjectMap("ProjectControllingObject","ProjectControllingObject");
        addEventNameToObjectMap("BusinessPartnerRelationship","BusinessPartnerRelationship");
        addEventNameToObjectMap("PurchasingOrganization","PurchasingOrganization");
        addEventNameToObjectMap("PurchasingCategory","PurchasingCategory");
        //addEventNameToObjectMap("CostCenter","CostCenter");
        
        objectToJsonObjectMap.put("PurchaseOrg", "PurchasingOrg");
        objectToJsonObjectMap.put("PurchaseGroup", "PurchasingGroup");
        objectToJsonObjectMap.put("IncoTerms", "Incoterms");
        objectToJsonObjectMap.put("InternalOrder", "InternalOrderReplicationRequestMessage");
        objectToJsonObjectMap.put("Currency", "Currency");
        objectToJsonObjectMap.put("ItemCategory", "PurchaseDocumentItemCategory");
        objectToJsonObjectMap.put("TaxCode", "TaxCode");
        objectToJsonObjectMap.put("WBSElement", "WBSElementReplicationRequestMessage");
        objectToJsonObjectMap.put("AccountCategory", "AccountAssignmentCategory");
        objectToJsonObjectMap.put("CompanyCode", "CompanyCode");
        objectToJsonObjectMap.put("CostCenter", "CostCentreReplicationRequestMessage");
        objectToJsonObjectMap.put("CurrencyConversionRate", "ExchangeRate");
        objectToJsonObjectMap.put("Address", "Plant");
        objectToJsonObjectMap.put("Region", "Region");
        objectToJsonObjectMap.put("GeneralLedger", "GLAccountReplicationRequestMessage");
        objectToJsonObjectMap.put("PartitionedCommodityCode", "MaterialGroup");
        objectToJsonObjectMap.put("PlantPurchaseOrgCombo", "PlantPurchasingOrg");
        objectToJsonObjectMap.put("CurrencyCode", "Currency");
        objectToJsonObjectMap.put("CountryCode", "Country");
        objectToJsonObjectMap.put("UnitOfMeasurement", "UnitOfMeasurement");
        objectToJsonObjectMap.put("LocaleCode", "Locale");
        objectToJsonObjectMap.put("PaymentMethodType", "PaymentMethod");
        objectToJsonObjectMap.put("User","User");
        objectToJsonObjectMap.put("Asset","FixedAsset");
        objectToJsonObjectMap.put("PaymentTerms","PaymentTerms");
        objectToJsonObjectMap.put("AccCategoryFieldStatusCombo","AccCategoryFieldStatusCombo");
        objectToJsonObjectMap.put("AdjustmentType","AdjustmentType");
        objectToJsonObjectMap.put("Group","Group");
        objectToJsonObjectMap.put("ProcurementUnit","ProcurementUnit");
        objectToJsonObjectMap.put("ItemMaster","ProductMDMReplicateRequestMessage");
        objectToJsonObjectMap.put("BusinessPartner","BusinessPartner");
        objectToJsonObjectMap.put("ProjectControllingObject","ProjectControllingObject");
        objectToJsonObjectMap.put("BusinessPartnerRelationship","BusinessPartnerRelationship");
        objectToJsonObjectMap.put("PurchasingOrganization","PurchasingOrganization");
        objectToJsonObjectMap.put("PurchasingCategory","PurchasingCategory");
        objectToJsonObjectMap.put("ProductGroup","ProductGroup");
        objectToJsonObjectMap.put("SymbolicGeneralLedgerAccount","SymbolicGeneralLedgerAccount");

    }

    public static Map<String, String> getOperationToObjectMap() {
        return operationToObjectMap;
    }

    public static Map<String, String> getObjectToJsonObjectMap() {
        return objectToJsonObjectMap;
    }

}
