package com.sap.ariba.erpintegration.persistence.model;

import org.json.simple.JSONObject;

import java.io.Serializable;
import java.util.Map;

public class Asset
    extends GenericEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final String objectType = "Asset";

    private static String[] lookupFields = {"CompanyCode,UniqueName,SubNumber"};

    @Override
    public void setLookupFields (Map<String, String> lookupDetails) {
    }

    @Override
    public String getObjectType()
    {
        return objectType;
    }

    @Override
    public void processCountryCode(JSONObject jsonObject){}
}
