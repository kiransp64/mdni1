package com.sap.ariba.erpintegration.service.exception;

/**
 * @author i339952
 */
public class UnauthorizedException extends Exception
{
    private static final long serialVersionUID = 1L;

    public UnauthorizedException (Exception e)
    {
        super(e);
    }

    public UnauthorizedException (String message)
    {
        super(message);
    }

    public UnauthorizedException (String message, Exception e)
    {
        super(message, e);
    }

}
