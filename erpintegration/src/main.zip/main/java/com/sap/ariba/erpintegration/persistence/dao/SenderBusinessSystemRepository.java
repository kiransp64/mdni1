package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.SenderBusinessSystem;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by i318483 on 21/06/17.
 */
@Component("SenderBusinessSystemRepositoryComponent")
public interface SenderBusinessSystemRepository extends GenericDataDao<SenderBusinessSystem>
{
    @Query("select C from SenderBusinessSystem C where C.businessSystemId = :businessSystemId and C.tenantId = :tenantId")
    SenderBusinessSystem findOne(@Param("businessSystemId") String businessSystemId, @Param("tenantId") long tenantId);
    
    @Query("select id,dateCreated,dateUpdated from SenderBusinessSystem s where tenantId = :tenantId order by id desc")
    public Page<SenderBusinessSystem> findKeyFieldsOfAllRecords(@Param("tenantId") long tenantId, Pageable pageable);

    @Transactional
    long deleteByTenantId(long tenantId);
    
}
