package com.sap.ariba.erpintegration.service.exception;

public class ParameterFetcherException extends Exception {
    private static final long serialVersionUID = 1L;

    public ParameterFetcherException (Exception ex)
    {
        super(ex);
    }

    public ParameterFetcherException (String message)
    {
        super(message);
    }

    public ParameterFetcherException (String message, Exception ex)
    {
        super(message, ex);
    }




}
