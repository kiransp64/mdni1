package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.IntegrationConfig;
import com.sap.ariba.erpintegration.persistence.model.SenderBusinessSystem;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

/**
 * Created by i318483 on 19/06/17.
 */
@Component("BusinessSystemRepositoryComponent")
public interface BusinessSystemRepository extends CrudRepository<SenderBusinessSystem,Long>
{
    @Query("select C from SenderBusinessSystem C where C.businessSystemId = :businessSystemId")
    IntegrationConfig findOne(@Param("businessSystemId") String businessSystemId);
}
