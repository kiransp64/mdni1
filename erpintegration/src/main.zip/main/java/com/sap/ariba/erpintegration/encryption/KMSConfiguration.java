package com.sap.ariba.erpintegration.encryption;

import ariba.util.security.secretsmanager.vault.VaultPropertyNames;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Properties;


@Component
@ConditionalOnProperty(name = "kmsEnabled", havingValue="true")
public class KMSConfiguration
{
    private static final String VAULT_SECRET_ID = "vault-secret-id";
    private static final String APP_UUID ="APP_UUID_NO_HASH";

    private static final Logger logger = LoggerFactory.getLogger(
            KMSConfiguration.class);

    @Value(value = "${encryption.usingEncrytionLibrary:true}")
    private boolean usingEncrytionLibrary;

    @Value(value = "${encryption.vault-consul-url}")
    private String consulUrl;

    @Value(value = "${encryption.vault-vault-url}")
    private String vaultUrl;

    @Value(value = "${encryption.vault-namespace}")
    private String vaultNameSpace;

    @Value(value = "${encryption.vault-servicename}")
    private String vaultServiceName;

    @Value(value = "${encryption.servicename}")
    private String serviceName;

    @Value(value = "${ARIBA_VAULT_SECRET_ID:}")
    private String vaultSecretId;

    @Value(value = "${kms.oauth_front_door_url}")
    private String oauthFrontUrl;

    @Value(value = "${kms.oauth2.clientId}")
    private String oauthClientId;

    @Value(value = "${kms.oauth2.privateSecret}")
    private String privateKey;

    @Value(value = "${kms.oauth2.publicSecret}")
    private String publicKey;

    @Value(value = "${kms.kms_endpoint_url}")
    private String kmsUrl;

    @Value(value = "${kms.cached-key-managers}")
    private String cachedKeyManagers;

    @Value(value ="${kms.should_monitor_kms_services}")
    private String monitorService;

    @Autowired
    private Environment env;

    public Properties getEncryptionVaultConfigAsProperties () throws IOException
    {
        Properties properties;
        if (usingEncrytionLibrary) {
            properties = setUpVaultConfigurations();
        } else {
            properties = setUpKmsConfigurations();
        }

        properties.put(VaultPropertyNames.APP_NAME, env.getProperty(APP_UUID));
        properties.put(VaultPropertyNames.SERVICE_NAME, this.serviceName);
        properties.put(VaultPropertyNames.USE_CLUSTER_DNS, "true");
        properties.put(VAULT_SECRET_ID, this.vaultSecretId);

        logger.info("app name {}", env.getProperty(APP_UUID));
        logger.info("properties : {}", properties.toString());
        return properties;
    }

    private Properties setUpVaultConfigurations() {
        Properties properties = new Properties();
        properties.put(VaultPropertyNames.CONSUL_URL, this.consulUrl);
        properties.put(VaultPropertyNames.VAULT_URL, this.vaultUrl);
        properties.put(VaultPropertyNames.VAULT_SERVICENAME, this.vaultServiceName);
        properties.put(VaultPropertyNames.NAMESPACE, this.vaultNameSpace);
        return properties;
    }

    private Properties setUpKmsConfigurations() {
        Properties properties = new Properties();
        properties.put(KMSConstants.OAUTH_FRONT_URL, this.oauthFrontUrl);
        properties.put(KMSConstants.OAUTH_CLIENT_ID, this.oauthClientId);
        properties.put(KMSConstants.OAUTH_PRIVATE_KEY, this.privateKey);
        properties.put(KMSConstants.OAUTH_PUBLIC_KEY, this.publicKey);
        properties.put(KMSConstants.KMS_ENDPOINT_URL, this.kmsUrl);
        properties.put(KMSConstants.CACHED_KEY_MANAGERS, this.cachedKeyManagers);
        properties.put(KMSConstants.IS_MONITOR_KMS_SERVICE, this.monitorService);
        return properties;
    }
}
