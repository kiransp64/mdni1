package com.sap.ariba.erpintegration.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class TagValueHandler extends DefaultHandler
{

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.util.TagValueHandler";
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private List<String> tagValues = null;

    private boolean tagFound = false;

    private String tagName;
    
    private List<String> tagNames = new ArrayList<String>();

    public List<String> getTagNames() {
		return tagNames;
	}

	public void clearTagNames() {
		tagNames.clear();
	}

	public TagValueHandler (String tagName)
    {
        this.tagName = tagName;
    }

    public void startElement (String uri,
                              String localName,
                              String qName,
                              Attributes attributes)
        throws SAXException
    {
    		tagNames.add(qName);
        if (qName.equalsIgnoreCase(tagName)) {
            if (logger.isDebugEnabled())
                logger.debug("{} tag name found started", tagName);
            tagFound = true;
        }

    }

    public void endElement (String uri, String localName, String qName)
        throws SAXException
    {
        if (qName.equalsIgnoreCase(tagName)) {
            if (logger.isDebugEnabled())
                logger.debug("{} tag name found ended", tagName);
        }

    }

    public void characters (char ch[], int start, int length) throws SAXException
    {

        if (tagFound) {
            logger.debug(tagName + " " + new String(ch, start, length));
            if (tagValues == null)
                tagValues = new ArrayList<>();
            tagValues.add(new String(ch, start, length));
            tagFound = false;
        }
    }
    
    public List<String> getTagValues ()
    {
        return this.tagValues;
    }
}
