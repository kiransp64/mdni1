package com.sap.ariba.erpintegration.util;

import com.sap.ariba.erpintegration.processor.XMLSchemaValidator;
import com.sap.ariba.erpintegration.service.exception.DataCompressionException;
import com.sap.ariba.erpintegration.service.exception.XMLPayloadHandlerException;
import com.thaiopensource.xml.sax.ErrorHandlerImpl;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.cxf.interceptor.Fault;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Created by i318483 on 12/14/16.
 */
public class XMLUtil
{

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.util.XMLUtil";
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(nameOfLogger);
    private static final String SECURE_PROCESSING_PARSER = "http://javax.xml.XMLConstants/feature/secure-processing";
    public static final String JSON_PATH_EXT =".json";
    public static final String XML_PATH_EXT =".xml";
    public static final String ZIP_PATH_EXT =".zip";

    public static void writeToStream (Document document, OutputStream os) throws IOException, TransformerFactoryConfigurationError, TransformerException, Exception
    {
        StringWriter wr = new StringWriter();

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        Transformer transformer = transformerFactory.newTransformer();
        transformer.transform(new DOMSource(document), new StreamResult(wr));
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

        String xsd = wr.toString();
        StringBuffer buf = new StringBuffer(xsd);
        os.write(buf.toString().getBytes("UTF-8"));
        os.flush();
        os.close();
    }

    public static DocumentBuilder getDocBuilder () throws ParserConfigurationException
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(true);
        String FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
        factory.setFeature(FEATURE, true);

        FEATURE = "http://xml.org/sax/features/external-general-entities";
        factory.setFeature(FEATURE, false);

        FEATURE = "http://xml.org/sax/features/external-parameter-entities";
        factory.setFeature(FEATURE, false);

        FEATURE = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
        factory.setFeature(FEATURE, false);

        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        DocumentBuilder builder = factory.newDocumentBuilder();
        return builder;
    }

    /**
     * Validate xml against the RNG schema.
     * 
     * @param objectName
     * @param xmlPayload
     * @param eh
     * @return
     * @throws XMLPayloadHandlerException
     * @throws IOException
     */
    public static boolean isValidXML (String objectName,
                                      String senderBusinessSystemID,
                                      String xmlPayload,
                                      ErrorHandlerImpl eh,
                                      String anId)
        throws XMLPayloadHandlerException, IOException
    {
        XMLSchemaValidator xmlSchemaValidator = new XMLSchemaValidator(
            objectName,
            senderBusinessSystemID,
            xmlPayload,
            anId);
        return xmlSchemaValidator.validate(eh);
    }

    public static String getValueOfTag (String savedFilePath, String tagKey)
        throws ParserConfigurationException, SAXException, IOException
    {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setFeature(SECURE_PROCESSING_PARSER, true);
        SAXParser saxParser = factory.newSAXParser();
        TagValueHandler tagValueHangler = new TagValueHandler(tagKey);
        // saxParser.parse(new InputSource(new StringReader(xmlData)),
        // tagValueHangler);
        saxParser.parse(savedFilePath, tagValueHangler);
        if (tagValueHangler.getTagValues() != null
            && tagValueHangler.getTagValues().size() > 0)
        {
            if (logger.isDebugEnabled())
                logger.debug(
                    "value found for tag {} is {}",
                    tagKey,
                    tagValueHangler.getTagValues().get(0));
            return tagValueHangler.getTagValues().get(0);
        }
        else {
            return null;
        }
    }
    
    public static String getValueOfTag (InputStream inputStream, String tagKey)
        throws ParserConfigurationException, SAXException, IOException
    {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setFeature(SECURE_PROCESSING_PARSER, true);
        SAXParser saxParser = factory.newSAXParser();
        TagValueHandler tagValueHangler = new TagValueHandler(tagKey);
        saxParser.parse(inputStream, tagValueHangler);
        try {
            if (tagValueHangler.getTagValues() != null
                && tagValueHangler.getTagValues().size() > 0)
            {
                if (logger.isDebugEnabled()) {
                    logger.debug(
                        "value found for tag {} is {}",
                        tagKey,
                        tagValueHangler.getTagValues().get(0));
                }
                return tagValueHangler.getTagValues().get(0);
            }
            else {
                return null;
            }
        }
        finally {
            IOUtils.closeQuietly(inputStream);
        }
    }

    /**
     * Iterate through the JSONData looking for objKey provided and extract the
     * value based on the objKey and return back JSONArray.
     * 
     * @param jsondata
     * @param objKey
     * @return
     * @throws ParseException
     * @throws IOException
     */
    public static JSONArray getJSONObjectArray (org.json.simple.JSONObject jsondata,
                                                                String objKey)
        throws ParseException, IOException
    {
        if (logger.isDebugEnabled())
            logger.debug("objKey:" + objKey);
        Set<String> keys = jsondata.keySet();
        JSONArray arr = null;
        boolean keyFound = false;
        Object jsonObject = null;

        while (!keys.contains(objKey)) {
            for (String key : keys) {
                jsonObject = jsondata.get(key);
                String jsonStr = jsonObject.toString();
                logger.info("Reading key 1 " + key);
                // logger.info("jsonStr: " + jsonStr);

                if (key.contains("xmlns:") || key.contains("MessageHeader"))
                    continue;

                JSONParser parser = new JSONParser();
                Object parsedObject = parser.parse(jsonStr);
                if (parsedObject instanceof org.json.simple.JSONObject object) {
                    jsondata = object;
                    Set<String> keys1 = jsondata.keySet();
                    if (keys1.contains(objKey)) {
                        keyFound = true;
                        break;
                    }
                }

                logger.info("Reading key " + key);
            }
            if (keyFound) {
                break;
            }

            keys = jsondata.keySet();
        }

        arr = getObjectList(jsondata, objKey);

        return arr;
    }

    private static JSONArray getObjectList (org.json.simple.JSONObject obj,
                                                            String objKey)
        throws ParseException
    {
        JSONArray arr = null;
        JSONParser parser = new JSONParser();
        String jsonStr = obj.get(objKey).toString();
        Object parsedObj = parser.parse(jsonStr);
        if (parsedObj instanceof JSONArray array) {
            arr = array;
        }
        else {
            arr = new JSONArray();
            arr.add(parsedObj);
        }

        return arr;
    }

    /**
     * Replace n0: or ns3: or ns4: with blank value in the provided input.
     * 
     * @param input
     * @return
     * @throws UnsupportedEncodingException
     */
    public static byte[] searchAndReplace (byte[] input)
        throws UnsupportedEncodingException
    {
        if (logger.isDebugEnabled())
            logger.debug("searchAndReplace Started");
        Pattern HEADER_PATTERN = Pattern.compile("n0:|ns3:|ns4:|nm:", Pattern.DOTALL);
        String str = new String(input);
        Matcher matcher = HEADER_PATTERN.matcher(str);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(sb, "");
        }
        matcher.appendTail(sb);
        if (logger.isDebugEnabled())
            logger.info("searchAndReplace Ended");
        return sb.toString().trim().getBytes("UTF-8");
    }

    public static String replaceSpecialChar (char ch[], int start, int length)
    {
        StringBuffer output = new StringBuffer();
        if (ch == null)
            return "";
        for (int i = start; i < start + length; i++) {
            switch (ch[i]) {
            case '&':
                output.append("&amp;");
                break;
            case '<':
                output.append("&lt;");
                break;
            case '>':
                output.append("&gt;");
                break;
            case '"':
                output.append("&quot;");
                break;
            case '\'':
                output.append("&apos;");
                break;
            default:
                output.append(ch[i]);
            }
        }

        return output.toString();
    }

    public static File convertStreamToFile(InputStream inputStream, String prefix, String suffix) throws IOException{
        Path tempFilePath = Files.createTempFile(prefix, suffix);
        File tempFile = tempFilePath.toFile();
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream(tempFile);
        IOUtils.copy(inputStream, out);
        return tempFile;
    }

    public static  byte[] convertBolbToByteArray(Blob blob) throws SQLException {
        ByteArrayOutputStream byteArrayOutputStreamObj = new ByteArrayOutputStream();
        InputStream inputStreamObj = null;
        try {
            byte[] buf = new byte[4000];
            inputStreamObj = blob.getBinaryStream();

            int dataSize;
            for (; ; ) {
                dataSize = inputStreamObj.read(buf);
                if (dataSize == -1) {
                    break;
                }
                byteArrayOutputStreamObj.write(buf, 0, dataSize);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex.getMessage());
        } finally {
            try {
                if (inputStreamObj != null)
                    inputStreamObj.close();

                if (byteArrayOutputStreamObj != null)
                    byteArrayOutputStreamObj.close();
            }
            catch(IOException ex)
            {
                logger.warn(ex.getMessage());
            }
        }
        return byteArrayOutputStreamObj.toByteArray();
    }


     public static String compressXMLData(String path) throws DataCompressionException {
         //input file path
         String sourcePath = path;

         //Output file path
         String destinationPath;

         if (path == null) {
             throw new DataCompressionException("path is null, so can't compress it");
         }

         if (path.contains(JSON_PATH_EXT)) {
             destinationPath = path.replace(JSON_PATH_EXT,
                                            ZIP_PATH_EXT);
         }
         else {
             destinationPath = path.replace(XML_PATH_EXT,
                                            ZIP_PATH_EXT);
         }

         //Input file name
         String inputFileName = new File(sourcePath).getName();

         try(BufferedInputStream bufferedInput = new BufferedInputStream(new FileInputStream(sourcePath));
             BufferedOutputStream bufferedOutput = new BufferedOutputStream(new FileOutputStream(destinationPath));
             ZipOutputStream zipOutput = new ZipOutputStream(bufferedOutput)) {

             zipOutput.putNextEntry(new ZipEntry(inputFileName));
             byte[] bytes = new byte[1024];
             int length;
             while ((length = bufferedInput.read(bytes)) >= 0) {
                 zipOutput.write(bytes,0,length);
             }
             logger.info("Successfully compressed "+ path);
             return destinationPath;
         } catch (IOException e) {
             throw new DataCompressionException("Failed to compress the data due to "+e.getMessage(), e);
         }

     }
     
     public static void compressPayload(String path, String payload) {
         //File file = new File(path);
         path = FilenameUtils.normalize(path);
         File file = new File(path);
         String fileName = file.getName();
         File parentDir = new File(file.getParent());
         try ( 
             InputStream is = new ByteArrayInputStream(
                 payload.getBytes(StandardCharsets.UTF_8.name()));
             BufferedOutputStream bufferedOutput = new BufferedOutputStream(new FileOutputStream(path));
             ZipOutputStream zos = new ZipOutputStream(bufferedOutput);){
             
             byte[] buffer = new byte[1024];
             int len;
             zos.putNextEntry(new ZipEntry(fileName)); // zip to pipedinputstream
             while ((len = is.read(buffer)) != -1) {
                 zos.write(buffer, 0, len);
             }
             zos.closeEntry();
             zos.flush();
             zos.close();
         }  catch (IOException ex) {
             logger.error("Exception while encrypting and zipping XML Data: ", ex);
             throw new Fault(new Throwable(ex.getMessage()));
         }
     }
 }
