package com.sap.ariba.erpintegration.handlers;

import org.apache.cxf.phase.Phase;

public class AuthenticateRequestHandlerObjectExport extends AuthenticateRequestHandlerBase
{
    public AuthenticateRequestHandlerObjectExport()
    {
        super(Phase.PRE_INVOKE);
    }
}
