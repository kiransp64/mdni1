package com.sap.ariba.erpintegration.persistence.model;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sap.ariba.erpintegration.service.rs.CustomBlobSerializer;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.sql.Blob;
import java.util.Date;

/**
 * Created by i318483 on 19/06/17.
 */
@Entity
@Table(name = "IntegrationJobLog_TAB")

public class IntegrationJobLog implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final String objectType = "IntegrationJobLog";

    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "TENANT_ID")
    private long tenantId;

    @Column(name = "SENDERBUSINESSSYSTEMID")
    private String senderBusinessSytemId;

    @Column(name = "IS_ACTIVE")
    private int isActive;

    @Column(name = "DATE_CREATED")
    private Date dateCreated;

    @Column(name = "DATE_UPDATED")
    private Date dateUpdated;

    @Column(name = "DATE_START")
    private Date startDate;

    @Column(name = "DATE_END")
    private Date endDate;

    @Column(name = "STATUS")
    private int status = 0;

    @Column(name = "RECORDSINSERTED")
    private int recordsInserted = 0;

    @Column(name = "RECORDSUPDATED")
    private int recordsUpdated = 0;

    @Column(name = "RECORDSDELETED")
    private int recordsDeleted = 0;

    @Column(name = "NONFATALEXCEPTIONS")
    @JsonSerialize(using = CustomBlobSerializer.class)
    private Blob nonFatalExceptions;

    @Column(name = "WARNINGS")
    @JsonSerialize(using = CustomBlobSerializer.class)
    private Blob warningMessages;

    @Column(name = "FATALERRORS")
    @JsonSerialize(using = CustomBlobSerializer.class)
    private Blob fatalErrors;

    @Column(name = "REPROCESSLINES")
    private String reprocessLines;

    @Column(name = "JOBID")
    private String jobId;

    public String getJobId()
    {
        return jobId;
    }

    public void setJobId(String jobId)
    {
        this.jobId = jobId;
    }

    public int getRecordsInserted()
    {
        return recordsInserted;
    }

    public void setRecordsInserted(int recordsInserted)
    {
        this.recordsInserted = recordsInserted;
    }

    public int getRecordsUpdated()
    {
        return recordsUpdated;
    }

    public void setRecordsUpdated(int recordsUpdated)
    {
        this.recordsUpdated = recordsUpdated;
    }

    public int getRecordsDeleted() {
        return recordsDeleted;
    }

    public void setRecordsDeleted(int recordsDeleted)
    {
        this.recordsDeleted = recordsDeleted;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getTenantId() {
        return tenantId;
    }

    public void setTenantId(long tenantId)
    {
        this.tenantId = tenantId;
    }

    public String getSenderBusinessSytemId()
    {
        return senderBusinessSytemId;
    }

    public void setSenderBusinessSytemId(String senderBusinessSytemId)
    {
        this.senderBusinessSytemId = senderBusinessSytemId;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getObjectType() {
        return objectType;
    }

    public Blob getWarningMessages ()
    {
        return warningMessages;
    }

    public void setWarningMessages (Blob warningMessages)
    {
        this.warningMessages = warningMessages;
    }

    public Blob getFatalErrors()
    {
        return fatalErrors;
    }

    public void setFatalErrors(Blob fatalErrors)
    {
        this.fatalErrors = fatalErrors;
    }

    public String getReprocessLines()
    {
        return reprocessLines;
    }

    public void setReprocessLines(String reprocessLines)
    {
        this.reprocessLines = reprocessLines;
    }

    public Date getStartDate()
    {
        return startDate;
    }

    public void setStartDate(Date startDate)
    {
        this.startDate = startDate;
    }

    public Date getEndDate()
    {
        return endDate;
    }

    public void setEndDate(Date endDate)
    {
        this.endDate = endDate;
    }

    public Blob getNonFatalExceptions ()
    {
        return nonFatalExceptions;
    }

    public void setNonFatalExceptions (Blob nonFatalExceptions)
    {
        this.nonFatalExceptions = nonFatalExceptions;
    }

    @Override
    public String toString() {
        return "integrationJobLog [id=" + id + ", status=" + status
                + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + ", isActive=" + isActive
                + ", recordsInserted=" + recordsInserted + ", recordsUpdated=" + recordsUpdated + ", recordsDeleted=" + recordsDeleted + "]";
    }

}
