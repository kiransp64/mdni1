package com.sap.ariba.erpintegration.persistence.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Created by i318483 on 02/06/17.
 */
@Entity
@Table(name="TypeMap_Tab")
public class TypeMap
{
    @Id
    @Column(name = "TypeMapCode")
    private int typeMapCode;

    @Column(name = "ObjectType")
    private String objectType;

    @Column(name = "Variant")
    private String variant;

    @Column(name = "FlexSuperType")
    private String flexSuperType;

    public int getTypeMapCode ()
    {
        return typeMapCode;
    }

    public void setTypeMapCode (int typeMapCode)
    {
        this.typeMapCode = typeMapCode;
    }

    public String getObjectType ()
    {
        return objectType;
    }

    public void setObjectType (String objectType)
    {
        this.objectType = objectType;
    }

    public String getVariant ()
    {
        return variant;
    }

    public void setVariant (String variant)
    {
        this.variant = variant;
    }

    public String getFlexSuperType ()
    {
        return flexSuperType;
    }

    public void setFlexSuperType (String flexSuperType)
    {
        this.flexSuperType = flexSuperType;
    }
}
