package com.sap.ariba.erpintegration.mdi.parser;

import com.sap.ariba.erpintegration.mdi.parser.model.Attributes;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * Attribute Parser class will accept Group or User attribute param that may contain pagination
 * option or type or filter option and
 * return the Attributes Object after parsing the attribute string
 */
@Service
public class AttributeParser
{
    private static final String TYPE = "type";
    private static final String STAR = "*";

    /**
     * Will be taking SCIM USER/GROUP get apis attribute query param and parse it using internal
     * User/Group antlr grammar
     *
     * @param attribute <p>
     * exp-
     * String attribute= *,groups[count=2&startIndex=1]
     * String attribute= *,members[type eq user&count=2&startIndex=1]
     * </p>
     * @return Attributes object contains Pagination option and attribute type
     */
    public Attributes parseAttribute (String attribute)
    {
        if (!StringUtils.containsIgnoreCase(attribute,
                                            TYPE) || StringUtils.equalsIgnoreCase(attribute,
                                                                                  STAR)) {
            return new UserOption().getPaginationOptions(attribute);
        }
        return new GroupOption().getGroupPaginationOptions(attribute);
    }

}
