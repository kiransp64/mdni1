package com.sap.ariba.erpintegration.common.utility;

/**
 * Created by i318483 on 14/06/17.
 */

import java.util.Map;

public class OAuth2UserInfo
{
    private String name;
    private String clientId;
    private String uniqAttr1;
    private String uniqAttr2;
    private String anId;

    Map<String, Object> attributes;

    public String getAnId ()
    {
        return anId;
    }

    public void setAnId (String anId)
    {
        this.anId = anId;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getClientId ()
    {
        return clientId;
    }

    public void setClientId (String clientId)
    {
        this.clientId = clientId;
    }

    public String getUniqAttr1 ()
    {
        return uniqAttr1;
    }

    public void setUniqAttr1 (String uniqAttr1)
    {
        this.uniqAttr1 = uniqAttr1;
    }

    public String getUniqAttr2 ()
    {
        return uniqAttr2;
    }

    public void setUniqAttr2 (String uniqAttr2)
    {
        this.uniqAttr2 = uniqAttr2;
    }

    public Map<String, Object> getAttributes ()
    {
        return attributes;
    }

    public void setAttributes (Map<String, Object> attributes)
    {
        this.attributes = attributes;
    }

}
