package com.sap.ariba.erpintegration.mdi.exception;

public class ResourceParseException extends RuntimeException
{
    public ResourceParseException (String message)
    {
        super(message);
    }

    public ResourceParseException (Exception e)
    {
        super(e);
    }

    public ResourceParseException (String message,
                                   Throwable cause)
    {
        super(message,
              cause);
    }
}
