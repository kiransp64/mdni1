package com.sap.ariba.erpintegration.common.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MDNIServiceRegistry {
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.common.metrics.MDNIServiceRegistry";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    
    @Autowired
    MeterRegistry meterRegistry;

    @Value("${mdni.metrics.custom.tag:mds.mdni}")
    String mdniCustomTag;

    @Value("${mdni.isTelemetry.enabled:false}")
    boolean isTelemetryEnabled;

    @Autowired
    public MDNIServiceRegistry(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @PostConstruct
    public void init() {
        if(isTelemetryEnabled && this.meterRegistry.config() != null)
            this.meterRegistry.config().commonTags("appName", mdniCustomTag);
    }

    /**
     * Increments the counter of the input metric
     * @param mdniMetrics - MDNI Metric Name Enum
     */
    public void sendMetricsForCounter(MDNIMetrics mdniMetrics) {
        if(isTelemetryEnabled)
            meterRegistry.counter(mdniMetrics.getKey()).increment();
    }

    /**
     * Reports current value of the input metric
     * @param mdniMetrics - MDNI Metric Name Enum
     * @param val - Value Associated with the Metric
     */
    public void sendMetricsForGauge(MDNIMetrics mdniMetrics, int val) {
        if(isTelemetryEnabled)
            meterRegistry.gauge(mdniMetrics.getKey(), val);
    }

    public void setIsTelemetryEnabled(boolean isTelemetryEnabled) {
        this.isTelemetryEnabled = isTelemetryEnabled;
    }
}
