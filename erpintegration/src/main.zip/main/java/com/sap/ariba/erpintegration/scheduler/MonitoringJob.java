package com.sap.ariba.erpintegration.scheduler;

import com.sap.ariba.erpintegration.SchedulerConfig;
import com.sap.ariba.erpintegration.mdi.common.util.DateUtil;
import com.sap.ariba.erpintegration.onemds.exception.BatchDAOException;
import com.sap.ariba.erpintegration.onemds.tenant.batch.core.persistance.Batch;
import com.sap.ariba.erpintegration.onemds.tenant.batch.dao.BatchDAO;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.joda.time.DateTime;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;
import java.util.Date;
import java.util.List;

@Component
@DisallowConcurrentExecution
public class MonitoringJob implements Job
{

    private static Logger log = LoggerFactory.getLogger(MonitoringJob.class);

    @Value("${mdni.stuck.job.schedule}")
    private String monitoringJobSchedule;

    @Autowired
    protected BatchDAO batchDAO;

    @Override
    public void execute (JobExecutionContext jobExecutionContext) throws JobExecutionException
    {
        try {
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            StageXMLDataRepository dao = (StageXMLDataRepository)daoFactory.getGenericDAOStageData(ObjectTypes.XmlPayload.name());
            Date d = new DateTime(new Date()).minusHours(6).toDate();
            List<Object[]> stageXMLDataList = dao.findLast6HoursStuckJob(d);
            int pendingCount = 0, failedCount = 0;
            for (Object[] stageXMLData : stageXMLDataList) {
                if (stageXMLData[0].equals(0)) {
                    pendingCount = ((Long)stageXMLData[1]).intValue();
                }
                else if (stageXMLData[0].equals(5)) {
                    failedCount = ((Long)stageXMLData[1]).intValue();
                }
            }

            log.info("[MDNI_NON_RECOVERABLE_JOB] Number of MDNI jobs in pending state: {} and in failed state: {} since 6 hours or more and these jobs might not be processed further",
                     pendingCount,
                     failedCount);

            logMDINonRecoverableJobs();

        }
        catch (Exception e) {
            log.error("Exception occur while running monitoring job scheduler, {}",
                      ErrorUtil.getCompleteCausedByErrors(e));
        }

    }

    private void logMDINonRecoverableJobs ()
    {
        int beforeTime = 6 * 60;
        try {
            List<Batch> batchList = batchDAO.findAllFailedBatchesBeforeTime(DateUtil.getBeforeTimeFromNow(beforeTime));
            int failedBatchCount = batchList != null ? batchList.size() : 0;
            log.info("[MDI_MONITOR][MDI_NON_RECOVERABLE_JOB] Number of MDI non-recoverable failed job: {} since 6 hours or more and these jobs might not be processed further",
                     failedBatchCount);
        }
        catch (BatchDAOException e) {
            log.error("Error while getting failed MDI batched, {}",
                      ErrorUtil.getCompleteCausedByErrors(e));
        }
    }

    @Bean(name = "monitoringJobDetailBean")
    public JobDetailFactoryBean monitoringJobDetailFactory ()
    {
        log.debug("Creating monitoringJobDetailBean");
        return SchedulerConfig.createJobDetail(this.getClass());
    }

    @Bean(name = "monitoringCronTrigger")
    public CronTriggerFactoryBean monitoringCronTrigger (
                    @Qualifier("monitoringJobDetailBean") JobDetail jobDetail)
    {
        log.debug("Creating monitoringCronTrigger");
        return SchedulerConfig.createCronTrigger(jobDetail,
                                                 monitoringJobSchedule);
    }
}
