package com.sap.ariba.erpintegration.reencryption;

import com.sap.ariba.encryption.config.ReEncryptionType;
import com.sap.ariba.encryption.config.SupportedJobTypes;
import com.sap.ariba.encryption.config.SupportedSourceTypes;
import com.sap.ariba.encryption.scheduler.service.JobStatus;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.security.encryption.Constants;
import com.sap.ariba.security.tool.keyrotation.v1.model.AppTenantLevels;
import com.sap.ariba.security.tool.keyrotation.v1.model.EncryptionJobResponse;
import com.sap.ariba.security.tool.keyrotation.v1.model.EncryptionJobStatus;
import com.sap.ariba.security.tool.keyrotation.v1.model.TenantLevel;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * This is same as MDNIReencryptionService but response and request
 * as per the library contract.
 */
@Component("contractReEncryptionService")
@ConditionalOnExpression("${environment.mdcs:false} == false && ${isInternal:false} == false && ${kmsEnabled:false} == true && ${reEncryption:false} == true")
public class ReEncryptionLibContractService extends MDNIReEncryptionService
{
    private static final Logger logger = LoggerFactory.getLogger(ReEncryptionLibContractService.class);
    public static final String APP_UUID_NO_HASH = "APP_UUID_NO_HASH";

    @Autowired
    private Environment env;

    public EncryptionJobResponse submitJob (AppTenantLevels request)
    throws ReEncryptionException
    {
        List<TenantLevel> tenants = request.getTenantLevels();
        if (tenants.get(0).getName().equals(Constants.SYSTEM)) {
            try {
                reEncryptionLib.getReEncryption().setSystemFileEncryptionJob(folderPath,
                                                                             ReEncryptionType.SYSTEM_JOB,
                                                                             SupportedSourceTypes.FILE_SOURCE);
            }
            catch (Exception e) {
                logger.error("[Re-Encryption] {} while trying to submit a job.",
                             ErrorUtil.getCompleteCausedByErrors(e));
                throw new ReEncryptionException("Error while trying to submit a job.", e);
            }
        }
        else {
            logger.warn(
                "[Re-Encryption] Jobs are supported only for system level tenant.");
        }
        return buildJobResponse(request, reEncryptionLib.getReEncryption()
                                                        .getSystemJobStatus(
                                                            SupportedJobTypes.FileType));
    }

    public EncryptionJobResponse getStatusReport (AppTenantLevels appTenantLevels)
    throws ReEncryptionException
    {
        try {
            return buildJobResponse(appTenantLevels, reEncryptionLib.getReEncryption()
                                                                    .getSystemJobStatus(
                                                                        SupportedJobTypes.FileType));
        }
        catch (Exception e) {
            logger.error("[Re-Encryption] {} while trying to get job status report.",
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new ReEncryptionException(
                "Error while trying to get job status report.", e);
        }
    }

    public EncryptionJobResponse pauseJob (AppTenantLevels appTenantLevels)
    throws ReEncryptionException
    {
        try {
            return buildJobResponse(appTenantLevels, pauseJob());
        }
        catch (Exception e) {
            logger.error("[Re-Encryption] {} while trying to pause job.",
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new ReEncryptionException("Error while trying to pause job.", e);
        }
    }

    public EncryptionJobResponse resumeJob (AppTenantLevels appTenantLevels)
    throws ReEncryptionException
    {
        try {
            return buildJobResponse(appTenantLevels, resumeJob());
        }
        catch (Exception e) {
            logger.error("[Re-Encryption] {} while trying to resume job.",
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new ReEncryptionException("Error while trying to resume job.", e);
        }
    }

    public EncryptionJobResponse abortJob (AppTenantLevels appTenantLevels)
    throws ReEncryptionException
    {
        try {
            return buildJobResponse(appTenantLevels, cancelJob());
        }
        catch (Exception e) {
            logger.error("[Re-Encryption] {} while trying to abort job.",
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new ReEncryptionException("Error while trying to abort job.", e);
        }
    }

    private EncryptionJobResponse buildJobResponse (AppTenantLevels appTenantLevels,
                                                    List<JobStatus> jobStatuses)
    {
        TenantLevel tenantLevel = appTenantLevels.getTenantLevels().get(0);
        final List<EncryptionJobStatus> encryptionJobStatuses = new ArrayList<>();
        for (JobStatus jobStatus : jobStatuses) {
            EncryptionJobStatus encryptionJobStatus = new EncryptionJobStatus();
            encryptionJobStatus.setName(tenantLevel.getName());
            encryptionJobStatus.setId(tenantLevel.getId());
            encryptionJobStatus.setJobPercent(jobStatus.getPercentage());
            encryptionJobStatus.setJobState(jobStatus.getStatus().name());
            encryptionJobStatus.setJobTimestamp(jobStatus.getUpdatedDate());
            encryptionJobStatuses.add(encryptionJobStatus);
        }
        EncryptionJobStatus latestStatus = null;
        if (!encryptionJobStatuses.isEmpty()) {
            latestStatus = encryptionJobStatuses.stream().max(
                Comparator.comparing(EncryptionJobStatus::getJobTimestamp)).get();
        }
        EncryptionJobResponse encryptionJobResponse = new EncryptionJobResponse();
        encryptionJobResponse.setApplicationId(appTenantLevels.getApplicationId());
        encryptionJobResponse.setSupportedTenantLevel(
            appTenantLevels.getSupportedTenantLevel());
        encryptionJobResponse.setEncryptionJobStatuses(Arrays.asList(latestStatus));
        return encryptionJobResponse;
    }

    public String getAppName () throws ReEncryptionException
    {
        String appName = env.getProperty(APP_UUID_NO_HASH);
        if (StringUtils.isEmpty(appName)) {
            logger.error(
                "App UUID is blank while trying to get App Name in Re-Encryption.");
            throw new ReEncryptionException("App UUID is blank");
        }
        return appName;
    }
}
