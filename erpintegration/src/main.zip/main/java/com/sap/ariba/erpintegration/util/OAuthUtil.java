package com.sap.ariba.erpintegration.util;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;

public class OAuthUtil
{
    /**
     * <pre>
     * Checks whether the actualScope - Received from request token validation, is the expected
     * scope.
     * actual scope should be fetched while validating the token with Auth server.
     * </>
     * @param actualScope - Input scope obtained while validating input token with Auth server
     * @param expectedScope - Expected scope for the current API call
     * @return
     */
    public static boolean isScopeValid (String actualScope, String expectedScope)
    {
        if (!StringUtils.isEmpty(actualScope) && !StringUtils.isEmpty(expectedScope)) {
            List<String> scopes = Arrays.asList(actualScope.split(","));
            String[] expectedScopes = expectedScope.split(",");
            for (String curExpScope : expectedScopes) {
                if (!scopes.contains(curExpScope)) {
                    return false;
                }
            }
            return true;
        }
        // Secure by default
        return false;
    }
}
