package com.sap.ariba.erpintegration.meta;

import jakarta.xml.bind.annotation.XmlElement;
import java.util.List;

/**
 * Created by i318483 on 07/06/17.
 */
public class Relationship
{
    private List<Relation> relation;

    @XmlElement
    public List<Relation> getRelation ()
    {
        return relation;
    }

    public void setRelation (List<Relation> relation)
    {
        this.relation = relation;
    }
}
