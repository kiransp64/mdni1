/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.application;

import com.sap.ariba.erpintegration.monitor.application.model.ApplicationData;
import com.sap.ariba.erpintegration.monitor.exception.IntegrationMonitoringException;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.integrationmonitoring.bean.ApplicationMonitoringBean;
import com.sap.ariba.integrationmonitoring.bean.IntegrationMonitoringBean;
import com.sap.ariba.integrationmonitoring.exception.InvalidBeanException;
import org.thymeleaf.util.ListUtils;

import java.util.List;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.TENANT_ID_DATA;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.TENANT_ID_DISPLAY;

/**
 * This interface will help to add application related data to monitoring bean.
 */
public interface ApplicationContextDataHandler
{

    void addApplicationData (IntegrationContext integrationContext,
                             IntegrationMonitoringBean imMonData)
                    throws IntegrationMonitoringException;

    default void addApplicationContextToIntegrationMonitoringBean (
        IntegrationMonitoringBean monData,
        List<ApplicationMonitoringBean> appMonBeans) throws InvalidBeanException
    {
        if (monData != null && !ListUtils.isEmpty(appMonBeans)) {
            for (ApplicationMonitoringBean appMonBean : appMonBeans) {
                monData.addApplicationMonitoringBean(appMonBean);
            }
        }
    }

    default void addApplicationContextToIntegrationMonitoringBean (IntegrationMonitoringBean monData,
                                                                   ApplicationMonitoringBean appData)
                    throws InvalidBeanException
    {
        if (monData != null && appData != null) {
            monData.addApplicationMonitoringBean(appData);
        }
    }

    default ApplicationMonitoringBean buildApplicationMonitoringBean (ApplicationData applicationData)
                    throws InvalidBeanException
    {
        ApplicationMonitoringBean applicationMonitoringBean = new ApplicationMonitoringBean();
        if (applicationData != null) {
            applicationMonitoringBean.setName(applicationData.getName());
            applicationMonitoringBean.setDisplayName(applicationData.getDisplayName());
            applicationMonitoringBean.setValue(applicationData.getValue());
            applicationMonitoringBean.setValueType(applicationData.getValueType());
            applicationMonitoringBean.setClassification(applicationData.getClassification());
            applicationMonitoringBean.setPersonalData(applicationData.isPersonalData());
            applicationMonitoringBean.setSensitiveData(applicationData.isSensitiveData());
        }
        return applicationMonitoringBean;
    }

    default ApplicationMonitoringBean buildApplicationMonitoringBeanWithSequence (
        ApplicationData applicationData,
        int seqNo) throws InvalidBeanException
    {
        ApplicationMonitoringBean applicationMonitoringBean = buildApplicationMonitoringBean(
            applicationData);
        applicationMonitoringBean.setSequenceNo(seqNo + 1);
        return applicationMonitoringBean;
    }

    List<ApplicationMonitoringBean> buildLogEntries(IntegrationContext integrationContext);

    /**
     * Adding tenant id as part of application data.
     *
     * @param integrationContext
     * @param applicationDataList
     */
    default void addTenantIdToApplicationData (IntegrationContext integrationContext,
                                               List<ApplicationData> applicationDataList)
    {
        if (integrationContext != null && integrationContext.getTenantID() != null
                        && applicationDataList != null) {
            applicationDataList.add(new ApplicationData(TENANT_ID_DATA,
                                                        TENANT_ID_DISPLAY,
                                                        integrationContext.getTenantID(),
                                                        ApplicationMonitoringBean.Classification.CONTEXT,
                                                        ApplicationMonitoringBean.ValueType.SIMPLE));
        }
    }

    /**
     * It will verify if Error message need to mark as personal data or not.
     *
     * @return
     */
    boolean shouldConsiderErrorAsPersonalData (IntegrationContext integrationContext);

}
