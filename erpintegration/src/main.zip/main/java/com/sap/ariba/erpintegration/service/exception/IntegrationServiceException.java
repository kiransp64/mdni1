package com.sap.ariba.erpintegration.service.exception;

/**
 * Created by i318483 on 28/04/17.
 */
public class IntegrationServiceException extends Exception
{
    private static final long serialVersionUID = 1L;
    
    /**
     * Flag to indicate if this is a transient exception
     */
    private boolean isTransient = false;

    public IntegrationServiceException (Exception e)
    {
        super(e);
    }

    public IntegrationServiceException (String message)
    {
        super(message);
    }

    public IntegrationServiceException (String message, Exception e)
    {
        super(message, e);
    }

    public IntegrationServiceException (Exception e, boolean isTransient)
    {
        super(e);
        this.isTransient = isTransient;
    }
    
    /**
     * Check whether the exception has occurred due to a transient failure
     */
    public boolean isTransient ()
    {
        return isTransient;
    }
}
