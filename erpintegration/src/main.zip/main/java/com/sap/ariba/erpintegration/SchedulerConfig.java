package com.sap.ariba.erpintegration;

import org.quartz.JobDetail;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.spi.JobFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import javax.sql.DataSource;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

@Configuration
@ConditionalOnExpression(    
    "${quartz.enabled:true} and (${isInternal:false} == false)"
)
public class SchedulerConfig
{
    private static final Logger LOG = LoggerFactory.getLogger(SchedulerConfig.class);

    private static final String QRTZ_DS_KEY = "org.quartz.dataSource.";
    private static final String USERNAME_KEY = "user";
    private static final String PASSWORD_KEY = "password";
    private static final String URL_KEY = "URL";
    private static final String DRIVER_CLASS_KEY = "driver";

    @Autowired
    List<Trigger> listOfTrigger;

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password}")
    private String password;

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.driver-class-name}")
    private String driverClass;


    @Bean
    public JobFactory jobFactory(ApplicationContext applicationContext) {
        AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
        jobFactory.setApplicationContext(applicationContext);
        return jobFactory;
    }

    @Bean
    public SchedulerFactoryBean schedulerFactoryBean (JobFactory jobFactory,
                                                      DataSource dataSource)
        throws IOException, SchedulerException
    {
        SchedulerFactoryBean factory = new SchedulerFactoryBean();
        factory.setOverwriteExistingJobs(true);
        factory.setAutoStartup(true);
        factory.setDataSource(dataSource);
        factory.setJobFactory(jobFactory);
        factory.setQuartzProperties(quartzProperties());

        if (listOfTrigger != null && listOfTrigger.size() > 0) {
            factory.setTriggers(listOfTrigger.toArray(new Trigger[listOfTrigger.size()]));
        }
        LOG.info("Starting jobs");
        return factory;
    }

    @Bean
    public Properties quartzProperties () throws IOException
    {
        PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
        propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));
        propertiesFactoryBean.afterPropertiesSet();
        String quartzDSName = QRTZ_DS_KEY + propertiesFactoryBean.getObject()
                        .getProperty("org.quartz.jobStore.dataSource") + ".";
        propertiesFactoryBean.getObject().setProperty(quartzDSName + USERNAME_KEY,
                                                      username);
        propertiesFactoryBean.getObject().setProperty(quartzDSName + PASSWORD_KEY,
                                                      password);
        propertiesFactoryBean.getObject().setProperty(quartzDSName + URL_KEY,
                                                      url);
        propertiesFactoryBean.getObject().setProperty(quartzDSName + DRIVER_CLASS_KEY,
                                                      driverClass);
        return propertiesFactoryBean.getObject();
    }

    public static CronTriggerFactoryBean createCronTrigger (JobDetail jobDetail,
                                                            String cronExpression)
    {
        if (LOG.isDebugEnabled())
            LOG.debug("Calling createCronTrigger");
        CronTriggerFactoryBean factoryBean = new CronTriggerFactoryBean();
        factoryBean.setJobDetail(jobDetail);
        factoryBean.setCronExpression(cronExpression);
        factoryBean.setMisfireInstruction(SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
        return factoryBean;
    }

    public static JobDetailFactoryBean createJobDetail (Class jobClass)
    {
        if (LOG.isDebugEnabled())
            LOG.debug("Calling createJobDetail");
        JobDetailFactoryBean factoryBean = new JobDetailFactoryBean();
        factoryBean.setJobClass(jobClass);
        // job has to be durable to be stored in DB:
        factoryBean.setDurability(true);
        return factoryBean;
    }

}
