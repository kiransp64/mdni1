package com.sap.ariba.erpintegration.service.mds;

import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "mds.publish")
public class MDSPublishConfiguration
{
    private Set<String> enabledEntities;
    private Set<String> buyerPublishExcludedEntities;
    private Set<String> s4PublishExcludedEntities;
    private Integer connectTimeout;
    private Long readTimeout;
    private String featureCheckURL;
    
    public Set<String> getEnabledEntities ()
    {
        return enabledEntities;
    }

    public void setEnabledEntities (Set<String> enabledEntities)
    {
        this.enabledEntities = enabledEntities;
    }
    
    public Set<String> getBuyerPublishExcludedEntities ()
    {
        return buyerPublishExcludedEntities;
    }

    public void setBuyerPublishExcludedEntities (Set<String> excludedEntities)
    {
        this.buyerPublishExcludedEntities = excludedEntities;
    }

    public Set<String> getS4PublishExcludedEntities ()
    {
        return s4PublishExcludedEntities;
    }

    public void setS4PublishExcludedEntities (Set<String> s4PublishExcludedEntities)
    {
        this.s4PublishExcludedEntities = s4PublishExcludedEntities;
    }

    public int getConnectTimeout ()
    {
        return connectTimeout;
    }
    
    public void setConnectTimeout (int connectTimeout)
    {
        this.connectTimeout = connectTimeout;
    }

    public long getReadTimeout ()
    {
        return readTimeout;
    }

    public void setReadTimeout (long readTimeout)
    {
        this.readTimeout = readTimeout;
    }
    
    public String getFeatureCheckURL ()
    {
        return featureCheckURL;
    }

    public void setFeatureCheckURL (String featureCheckURL)
    {
        this.featureCheckURL = featureCheckURL;
    }
}
