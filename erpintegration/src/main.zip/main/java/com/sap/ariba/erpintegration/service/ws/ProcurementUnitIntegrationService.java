package com.sap.ariba.erpintegration.service.ws;

import com.sap.ariba.erpintegration.persistence.model.ProcurementUnit;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;

import jakarta.jws.WebMethod;
import jakarta.jws.WebResult;
import jakarta.jws.WebService;
import jakarta.xml.ws.ResponseWrapper;
import java.util.List;

/**
 * Created by c5259108 on 04/12/17.
 */
@WebService(serviceName = "ProcurementUnitIntegrationService",targetNamespace = "http://procurementUnitIntegrationService.com")
public interface ProcurementUnitIntegrationService {
    @WebMethod(operationName = "fetchProcurementUnits")
    @WebResult(name = "ProcurementUnit")
    @ResponseWrapper(localName = "ProcurementUnitsResponse")
    List<ProcurementUnit> getProcurementUnits() throws IntegrationServiceException;
}
