package com.sap.ariba.erpintegration.service.rs;

import com.sap.ariba.erpintegration.persistence.model.EntityVersion;
import com.sap.ariba.erpintegration.persistence.PersistenceOperationType;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;

/**
 * This is the custom repository class for ENTITY_VERSION_TAB table.
 * @author i345104
 */
@Component
public interface EntityVersionRepositoryCustom
{
    /**
     * Extract the lookup value from the JSONData
     * @param objectName
     * @param jsonObject
     * @return
     */
    Map<String, String> getLookupValueForObject (String objectName, JSONObject jsonObject, boolean isFMDObject);

    /**
     * Fetched Nested Data from ENTITY_VERSION_TAB
     * @param jsonObject
     * @param key
     * @return
     */
    Object getNestedData (JSONObject jsonObject, String key);

    /**
     * Persists records to ENTITY_VERSION_TAB. This method supports only
     * INSERT and UPDATE operations.
     * @param mapOfEntityVersions
     */
    void processRecords (Map<PersistenceOperationType,Set<EntityVersion>> mapOfEntityVersions);
}
