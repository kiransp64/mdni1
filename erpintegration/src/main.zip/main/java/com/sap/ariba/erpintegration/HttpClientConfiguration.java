package com.sap.ariba.erpintegration;

import jakarta.annotation.PostConstruct;
import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.DefaultHttpRequestRetryStrategy;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpHeaders;
import org.apache.hc.core5.http.HttpRequest;
import org.apache.hc.core5.http.io.SocketConfig;
import org.apache.hc.core5.http.message.BasicHeader;
import org.apache.hc.core5.http.protocol.HttpContext;
import org.apache.hc.core5.pool.ConnPoolControl;
import org.apache.hc.core5.pool.PoolStats;
import org.apache.hc.core5.util.TimeValue;
import org.apache.hc.core5.util.Timeout;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class HttpClientConfiguration implements DisposableBean {

	@Value("${http.client.maxConnPerRoute}")
	private int maxConnPerRoute;

	@Value("${http.client.httpPoolMaxConn}")
	private int httpPoolMaxConn;

	@Value("${http.client.connectionRequestTimeoutMs}")
	private int connReqTimeOutMs;

	@Value("${http.client.connectTimeoutMs}")
	private int connTimeOutMs;

	@Value("${http.client.socketTimeoutMs}")
	private int sockTimeOutMs;

	@Value("${http.client.printstats}")
	private boolean printStatistics;

	private HttpClient httpclient;

	private PoolingHttpClientConnectionManager connectionManager;

	private IdleConnectionMonitorThread monitorThread;

	@Autowired
	private MasterDataPublishServiceProxyConfiguration proxyConf;

	private static final Logger logger = LoggerFactory.getLogger(HttpClientConfiguration.class);

	@PostConstruct
	public void initializehttpClientCommunicator() {
		// Connection pool manager associated with the client
		connectionManager = new PoolingHttpClientConnectionManager();
		connectionManager.setMaxTotal(httpPoolMaxConn);
		connectionManager.setDefaultMaxPerRoute(maxConnPerRoute);
		connectionManager.setDefaultSocketConfig(SocketConfig.custom()
																 .setSoTimeout(Timeout.ofMilliseconds(sockTimeOutMs))
																 .build());
		// Configure connection parameters with RequestConfig
		RequestConfig requestConfig = RequestConfig.custom()
						.setConnectionRequestTimeout(Timeout.ofMilliseconds(connReqTimeOutMs))
						.setConnectTimeout(Timeout.ofMilliseconds(connTimeOutMs)).build();
		Header contentHeader = new BasicHeader(HttpHeaders.CONTENT_TYPE,
											   MediaType.APPLICATION_JSON_UTF8_VALUE);

		List<Header> headers = new ArrayList<>(5);
		headers.add(contentHeader);
		if (proxyConf != null && proxyConf.isProduction()) {
			logger.info("https proxy isProduction is set, so creating proxy http client ");
			httpclient = HttpClients.custom().useSystemProperties().setDefaultHeaders(headers)
							.setConnectionManager(connectionManager).setDefaultRequestConfig(requestConfig)
							.setRetryStrategy(new CustomRetryStrategy())
							.build();
		}
		else {
			httpclient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setDefaultHeaders(headers).
											setConnectionManager(connectionManager)
							.setRetryStrategy(new CustomRetryStrategy())
							.build();
		}
		monitorThread = new IdleConnectionMonitorThread(connectionManager);
		monitorThread.start();
	}

	public void setOAuthHeader(HttpEntityEnclosingRequestBase request, String token)
			throws GeneralSecurityException, IOException {

		request.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + token);
	}

	public HttpClient getHttpClient() {
		return httpclient;
	}

	public void printConnectionStats() {

		if (connectionManager == null) {
			logger.info("Http Client Connection Manager is null , not able to log connection stats");
			return;
		}

		PoolStats totalStats = connectionManager.getTotalStats();
		int pendingConn = totalStats.getPending();

		if(pendingConn > 0 || printStatistics)
		{
			logger.info(
					"Http Client Pending Connections: Number of connections request being blocked awaiting a free connection : {} ",
					pendingConn);
			logger.info("Http Client Leased Connections: Number of connections used to execute request : {} ",
		                totalStats.getLeased());
			logger.info("Http Client Available Connections: Number of idle persistent connections : {} ",
			                totalStats.getAvailable());
			logger.info("Http Client Maximum Connections: Maximum number of allowed connections : {} ",
			                totalStats.getMax());
		}
		if(!printStatistics){
			logger.debug("Http Client Leased Connections: Number of connections used to execute request : {} ",
						 totalStats.getLeased());
			logger.debug("Http Client Available Connections: Number of idle persistent connections : {} ",
						 totalStats.getAvailable());
			logger.debug("Http Client Maximum Connections: Maximum number of allowed connections : {} ",
						 totalStats.getMax());
		}
	}

	@Override
	public void destroy() {
		logger.info("Shutting down Http Client Connection Manager");
		if (monitorThread != null) {
			monitorThread.shutdown();
		}
		if (connectionManager != null) {
			connectionManager.close();
		}
		logger.info("Shut down Http Client Connection Manager");
	}

	static class IdleConnectionMonitorThread extends Thread {
		private final PoolingHttpClientConnectionManager connMgr;
		private volatile boolean shutdown = false;

		IdleConnectionMonitorThread(PoolingHttpClientConnectionManager connMgr) {
			super("MDNDIIdleHttpConnectionThreadMonitor");
			this.connMgr = connMgr;
		}

		public void run() {
			while(true) {
				try {
					if (!this.shutdown) {
						synchronized(this) {
							this.wait(60000L);
							if (logger.isDebugEnabled() && this.connMgr != null && this.connMgr instanceof ConnPoolControl) {
								PoolStats stats = this.connMgr.getTotalStats();
								logger.debug("Pool Statistics : {} ", stats.toString());
							}

							this.connMgr.closeExpired();
							this.connMgr.closeIdle(TimeValue.of(1L,TimeUnit.MINUTES));
							continue;
						}
					}
				} catch (InterruptedException var5) {
					logger.error("Unexpected interruption in IdleConnectionMonitorThread", var5);
				}
				return;
			}
		}

		void shutdown() {
			this.shutdown = true;
			synchronized(this) {
				this.notifyAll();
			}
		}
	}
	// Custom HttpRequestRetryHandler with backoff and dynamic delay
	static class CustomRetryStrategy extends DefaultHttpRequestRetryStrategy
	{
		private static final int MAX_RETRIES = 3;

		public CustomRetryStrategy ()
		{
			super(MAX_RETRIES,
				  TimeValue.ofMilliseconds(10));
		}

		@Override
		public boolean retryRequest (HttpRequest request,
									 IOException exception,
									 int executionCount,
									 HttpContext context)
		{
			if (executionCount > MAX_RETRIES) {
				// Do not retry if over MAX_RETRIES
				return false;
			}
			long delay = calculateDelay(executionCount);
			try {
				Thread.sleep(delay);
			}
			catch (InterruptedException e) {
				return false;
			}

			return super.retryRequest(request,
									  exception,
									  executionCount,
									  context);
		}

		private long calculateDelay (int executionCount)
		{
			// Calculate dynamic delay with specified values
			switch (executionCount) {
			case 1:
				return 10;  // 10 ms for the first retry
			case 2:
				return 50;  // 50 ms for the second retry
			case 3:
				return 100; // 100 ms for the third retry
			default:
				return 10;
			}
		}
	}
}
