package com.sap.ariba.erpintegration.persistence.model;

import java.util.List;

import com.sap.ariba.encryption.scheduler.service.JobStatus;

public class ReEncryptionResponse
{
    List<TenantLevelStatus> tenantLevels;

    String applicationId;

    String supportedTenantLevel;
    
    List<JobStatus> jobStatus;
    
    public ReEncryptionResponse() {
    }

    public ReEncryptionResponse(String applicationId, String supportedTenantLevel, List<TenantLevelStatus> statusForTenant) {
        this.applicationId = applicationId;
        this.supportedTenantLevel = supportedTenantLevel;
        this.tenantLevels = statusForTenant;
    }

    public List<TenantLevelStatus> getTenant_levels ()
    {
        return tenantLevels;
    }

    public void setTenantLevels (List<TenantLevelStatus> tenantLevels)
    {
        this.tenantLevels = tenantLevels;
    }

    public String getApplicationId ()
    {
        return applicationId;
    }

    public void setApplicationId (String applicationId)
    {
        this.applicationId = applicationId;
    }

    public String getSupportedTenantLevel ()
    {
        return supportedTenantLevel;
    }

    public void setSupportedTenantLevel (String supportedTenantLevel)
    {
        this.supportedTenantLevel = supportedTenantLevel;
    }
    
    public List<JobStatus> getJobStatus ()
    {
        return jobStatus;
    }

    public void setJobStatus (List<JobStatus> jobStatus)
    {
        this.jobStatus = jobStatus;
    }
}
