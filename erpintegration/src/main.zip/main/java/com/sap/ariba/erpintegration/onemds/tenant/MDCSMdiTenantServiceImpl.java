package com.sap.ariba.erpintegration.onemds.tenant;

import com.sap.ariba.erpintegration.mdi.cap.config.MDCSSecretsManager;
import com.sap.ariba.erpintegration.mdi.cap.config.ServiceBinding;
import com.sap.ariba.erpintegration.mdi.cap.util.MdcsConstants;
import com.sap.ariba.erpintegration.onemds.exception.TenantServiceException;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import javax.json.JsonObject;

@Component
@ConditionalOnExpression("${environment.mdcs:false}==true")
@Qualifier("mdcsMdiTenantService")
public class MDCSMdiTenantServiceImpl extends TenantServiceImpl
{
    private static final Logger logger = LoggerFactory.getLogger(
        MDCSMdiTenantServiceImpl.class);

    @Override
    public String getAppURL (String tenantID) throws TenantServiceException
    {
        ServiceBinding serviceBinding = MDCSSecretsManager.getServiceBinding(
            MdcsConstants.ONE_MDS);
        JsonObject oneMDsConfig = serviceBinding.getSecrets();
        return oneMDsConfig.getString(MdcsConstants.URI);
    }

    @Override
    public String getClientID (String tenantID) throws TenantServiceException
    {
        String clientID = null;
        org.json.simple.JSONObject jsondata = getOneMdsSecretKeys();
        if (jsondata != null) {
            clientID = (String)jsondata.get(MdcsConstants.CLIENTID);
        }

        return clientID;

    }

    @Override
    public String getClientSecret (String tenantID) throws TenantServiceException
    {
        String clientSecret = null;
        org.json.simple.JSONObject jsondata = getOneMdsSecretKeys();
        if (jsondata != null) {
            clientSecret = (String)jsondata.get(MdcsConstants.CLIENTSECRET);
        }

        return clientSecret;

    }

    @Override
    public String getAuthURL (String tenantID) throws TenantServiceException
    {
        String authURL = null;
        org.json.simple.JSONObject jsondata = getOneMdsSecretKeys();
        if (jsondata != null) {
            authURL = (String)jsondata.get(MdcsConstants.URL);
        }

        return authURL;
    }

    @Override
    public boolean isTenantValid (String tenantID) throws TenantServiceException
    {
        return true;
    }

    private org.json.simple.JSONObject getOneMdsSecretKeys ()
        throws TenantServiceException
    {

        ServiceBinding serviceBinding = MDCSSecretsManager.getServiceBinding(
            MdcsConstants.ONE_MDS);
        JsonObject oneMdsConfig = serviceBinding.getSecrets();
        String uaaJsonString = oneMdsConfig.getString(MdcsConstants.UAA);
        JSONParser parser = new JSONParser();
        Object parsedObject;
        try {
            parsedObject = parser.parse(uaaJsonString);
        }
        catch (ParseException e) {
            logger.error(
                "Error - {}, while parsing ONE MDS secret key :uaa {}",
                ErrorUtil.getCompleteCausedByErrors(e),
                uaaJsonString);
            throw new TenantServiceException(
                "Error while parsing ONE MDS secret key uaa " + uaaJsonString,
                e);
        }
        org.json.simple.JSONObject jsondata = null;
        if (parsedObject instanceof org.json.simple.JSONObject object) {
            jsondata = object;
        }
        return jsondata;
    }

}
