package com.sap.ariba.erpintegration.persistence.dao;

/**
 * Created by i340151.
 */
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;


@NoRepositoryBean
public interface GenericDataDao<T> extends PagingAndSortingRepository<T, Long>, CrudRepository<T, Long>
{

    public Page<T> findKeyFieldsOfAllRecords(long tenantId, Pageable pageable);
    
}
