package com.sap.ariba.erpintegration.encryption;

public class SecurityInitializationException extends Exception
{
    private static final long serialVersionUID = 1L;

    public SecurityInitializationException (String message)
    {
        super(message);
    }
    
    public SecurityInitializationException (Throwable t)
    {
        super(t);
    }
    
    public SecurityInitializationException (String message, Exception e)
    {
        super(message, e);
    }
}
