package com.sap.ariba.erpintegration.persistence.util;

import org.apache.commons.lang3.StringUtils;

public enum EncryptKey
{
    ARIBA, KMS;

    public static EncryptKey getEncryptKey(String name){
        if(!StringUtils.isEmpty(name)){
            for(EncryptKey encryptKey : EncryptKey.values()){
                if(encryptKey.name().equals(name)){
                    return encryptKey;
                }
            }
        }
        return null;
    }
}
