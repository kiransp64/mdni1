package com.sap.ariba.erpintegration.service.exception;

/**
 * This exception is thrown, when we get an invalid tenant
 * 
 * @author i339952
 */
public class InvalidTenantIdException extends Exception
{
    private static final long serialVersionUID = 1L;

    public InvalidTenantIdException (Exception e)
    {
        super(e);
    }

    public InvalidTenantIdException (String message)
    {
        super(message);
    }

    public InvalidTenantIdException (String message, Exception e)
    {
        super(message, e);
    }

}
