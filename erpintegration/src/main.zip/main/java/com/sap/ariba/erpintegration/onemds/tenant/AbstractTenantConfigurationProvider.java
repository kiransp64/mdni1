package com.sap.ariba.erpintegration.onemds.tenant;

import com.sap.ariba.erpintegration.onemds.exception.TenantConfigurationException;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.TenantRepository;
import com.sap.ariba.erpintegration.persistence.model.Tenant;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public abstract class AbstractTenantConfigurationProvider
    implements TenantConfigurationProvider
{
    private static final Logger logger = LoggerFactory.getLogger(
        AbstractTenantConfigurationProvider.class);

    protected Map<String, Map<String, String>> tenantConfigurationDetails = new ConcurrentHashMap<>();

    protected abstract void loadConfiguration (String tenantID) throws TenantConfigurationException;

    @Override
    public Map<String, Map<String, String>> getTenantConfigurationDetails ()
    {
        return Collections.unmodifiableMap(tenantConfigurationDetails);
    }
    
    @Override
    public void removeTenantConfigurationDetail (String tenantId){
        tenantConfigurationDetails.remove(tenantId);
    }

    @Override
    public void removeTenantConfigurationDetail (){
        tenantConfigurationDetails.clear();
    }


    @Override
    public String getAppURL (String tenantID) throws TenantConfigurationException
    {
        return getConfiguration(tenantID, TenantConfiguration.APP_URL);
    }

    @Override
    public String getClientID (String tenantID) throws TenantConfigurationException
    {
        return getConfiguration(tenantID, TenantConfiguration.CLIENT_ID);
    }

    @Override
    public String getClientSecret (String tenantID) throws TenantConfigurationException
    {
        return getConfiguration(tenantID, TenantConfiguration.CLIENT_SECRET);
    }

    @Override
    public String getAuthURL (String tenantID) throws TenantConfigurationException
    {
        return getConfiguration(tenantID, TenantConfiguration.AUTH_URL);
    }

    @Override
    public String getConfiguration (String tenantID,
                                    TenantConfiguration tenantConfiguration) throws
        TenantConfigurationException
    {
        if (this.tenantConfigurationDetails != null) {
            if (!this.tenantConfigurationDetails.containsKey(tenantID)) {
                loadConfiguration(tenantID);
            }
            if (this.tenantConfigurationDetails.containsKey(tenantID)) {
                Map<String, String> configuration = this.tenantConfigurationDetails.get(
                    tenantID);
                if (configuration != null && configuration.containsKey(
                    tenantConfiguration.getValue()))
                {
                    return configuration.get(tenantConfiguration.getValue());
                }
                else {
                    logger.error(
                        "Unable to find configuration details for tenant - {} and configuration - {}",
                        tenantID,
                        tenantConfiguration);
                    throw new TenantConfigurationException(
                        "Unable to find configuration details for tenant - " + tenantID
                            + " and configuration - " + tenantConfiguration);
                }
            }
            else {
                logger.error(
                    "Unable to find configuration details for tenant - {}, while looking for configuration - {}",
                    tenantID,
                    tenantConfiguration);
                throw new TenantConfigurationException(
                    "Unable to find configuration details for tenant - " + tenantID
                        + ", while looking for configuration - " + tenantConfiguration);
            }
        }
        logger.error(
            "Tenant Configuration is not instantiated properly. Found while searching for configuration - {}, of tenant - {}",
            tenantConfiguration,
            tenantID);
        throw new TenantConfigurationException(
            "Tenant Configuration is not instantiated properly. Found while searching for configuration - "
                + tenantConfiguration + ", of tenant - " + tenantID);
    }

    @Override
    public Set<String> getAllTenants () throws TenantConfigurationException
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository)factory.getMiscDAO(ObjectTypes.Tenant.getValue());
        List<Tenant> tenants = dao.findAllMdiEnabledTenants(Constants.MDI_ENABLED_VALUE);
        Set<String> tenantsIds = new LinkedHashSet<>();
        if(CollectionUtils.isNotEmpty(tenants)){
            for(Tenant tenant : tenants) {
                tenantsIds.add(tenant.getAnId());
            }
        }
        return tenantsIds;
    }

    @Override
    public boolean doesConfigurationExist (String tenantID)
        throws TenantConfigurationException
    {
        if (!StringUtils.isEmpty(tenantID)) {
            if (tenantConfigurationDetails.containsKey(tenantID)) {
                return true;
            }
            else {
                try {
                    loadConfiguration(tenantID);
                    if (tenantConfigurationDetails.containsKey(tenantID)) {
                        return true;
                    }
                }
                catch (Exception e) {
                    // Catch all exceptions and wrap them with TenantConfigurationException
                    logger.error(
                        "Error - {} while loading the configuration for tenant - {}",
                        ErrorUtil.getCompleteCausedByErrors(e), tenantID);
                    throw new TenantConfigurationException(
                                "Error while loading the configuration for tenant - " + tenantID, e);
                }
            }
        }
        return false;
    }
}
