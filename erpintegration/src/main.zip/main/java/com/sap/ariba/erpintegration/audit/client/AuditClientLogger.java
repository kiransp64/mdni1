package com.sap.ariba.erpintegration.audit.client;

import com.sap.ariba.audit.auditclient.api.AuditClientResponse;
import com.sap.ariba.audit.auditclient.api.AuditLogger;
import com.sap.ariba.audit.auditclient.message.AuditLogMessage;
import com.sap.ariba.audit.auditclient.message.IntegrationAuditLogMessage;
import com.sap.ariba.audit.auditclient.message.SecurityAuditLogMessage;
import com.sap.ariba.audit.auditclient.message.validations.AuditLogMessageValidationHelper;
import com.sap.ariba.erpintegration.service.exception.AuditFailedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class AuditClientLogger {

    public static Logger logger = LoggerFactory.getLogger(AuditClientLogger.class);

    public void pushAuditLog(AuditLogMessage auditLogMessage, String operationType, String realmName) throws AuditFailedException {

        long start = System.currentTimeMillis();
        List<AuditClientResponse.ErrorMessage> validLogMessage = new ArrayList<>();
        validLogMessage = AuditLogMessageValidationHelper.validateAuditLog(auditLogMessage);
        long elapsedTime = System.currentTimeMillis() - start;
        logger.info("*******Audit Validation time for "+operationType +"is "+elapsedTime+"milli seconds");
        switch (operationType) {

            case AuditClientDataService.OPERATION_WSDL_UPLOAD:
            case AuditClientDataService.OPERATION_DATA_UPLOAD:
                auditUploadData(auditLogMessage, operationType, realmName, validLogMessage);
                break;

            case AuditClientDataService.OPERATION_AUTHENTICATION:
                auditAuthenticationData(auditLogMessage, operationType, realmName, validLogMessage);
                break;

            case AuditClientDataService.OPERATION_FETCH_GROUPS:
            case AuditClientDataService.OPERATION_FETCH_USERS:
            case AuditClientDataService.OPERATION_FETCH_PROCUREMENT_UNITS:
            case AuditClientDataService.OPERATION_WSDL_DOWNLOAD:
            case AuditClientDataService.OPERATION_DATA_DOWNLOAD:
            case AuditClientDataService.OPERATION_INSPECTOR_ACCESS:
                auditFetchData(auditLogMessage, operationType, realmName, validLogMessage);
                break;

            case AuditClientDataService.OPERATION_PROCESS_XML_DATA:
            case AuditClientDataService.OPERATION_MDS_PUBLISH:
                auditProcessData(auditLogMessage, operationType, realmName, validLogMessage);
                break;

        }
    }

    //This method sends uploadWsdl and uploadXml data to auditService
    private void auditUploadData(AuditLogMessage auditLogMessage, String operationType, String realmName, List<AuditClientResponse.ErrorMessage> validLogMessage) throws AuditFailedException {
        String objectName = ((IntegrationAuditLogMessage) auditLogMessage).getParam2();
        String senderBusinessId = ((IntegrationAuditLogMessage) auditLogMessage).getParam3();
        if (validLogMessage.size() == 0) {
            long start = System.currentTimeMillis();
            AuditClientResponse audited = AuditLogger.log(auditLogMessage);
            long elapsedTime = System.currentTimeMillis() - start;
            logger.info("*******Audit log time for "+operationType +"is "+elapsedTime+"milli seconds");
            if (audited.getStatus() != null &&
                audited.getStatus().equals(AuditClientResponse.ResponseStatus.SUCCESS)) {
                logger.info("Successfully Audited for operation: {}, tenantId: {}, objectName: {}, senderBusinessId: {}", operationType, realmName, objectName, senderBusinessId);
            } else {
                String errorMessage = "";
                if(audited.failureCount() != null &&
                    audited.failureCount() > 0) {
                    errorMessage += audited.failureMessage(1).get(0).getErrorDetails();
                }
                logger.error("Auditing Failed for operation: {}, tenantId: {}, objectName: {}, senderBusinessId: {}", operationType, realmName, objectName, senderBusinessId);
                throw new AuditFailedException(errorMessage);
            }
        } else {
            logger.error("Audit validation failed for operation: {} with error details {} ", operationType, validLogMessage.get(0).getErrorDetails());
            throw new AuditFailedException("Audit validation failed with error message "+validLogMessage.get(0).getErrorDetails());
        }
    }

    //This method sends security data to auditService
    private void auditAuthenticationData(AuditLogMessage auditLogMessage, String operationType, String realmName, List<AuditClientResponse.ErrorMessage> validLogMessage) {
        String urlPath = ((SecurityAuditLogMessage) auditLogMessage).getParam6();
        if (validLogMessage.size() == 0) {
            long start = System.currentTimeMillis();
            AuditClientResponse audited = AuditLogger.log(auditLogMessage);
            long elapsedTime = System.currentTimeMillis() - start;
            logger.info("*******Audit log time for "+operationType +"is "+elapsedTime+"milli seconds");
            if (audited.getStatus().equals(AuditClientResponse.ResponseStatus.SUCCESS)) {
                logger.info("Successfully Audited for invalid authentication while accessing the url: {}", urlPath);
            } else {
                logger.error("Auditing Failed for invalid authentication while accessing the url: {}", urlPath);
            }
        } else {
            logger.error("Audit validation failed for operation: {}, with error details {}", operationType, validLogMessage.get(0).getErrorDetails());
        }
    }

    //This method sends fetchgroups, fetchusers, fetchProcurement units, downloadwsdl, downloadxml, inspector access data to auditService
    private void auditFetchData(AuditLogMessage auditLogMessage, String operationType, String realmName, List<AuditClientResponse.ErrorMessage> validLogMessage){
        if (validLogMessage.size() == 0) {
            AuditClientResponse audited = AuditLogger.log(auditLogMessage);
            if (audited.getStatus().equals(AuditClientResponse.ResponseStatus.SUCCESS)) {
                logger.info("Successfully Audited for operation: {}, tenant: {}", operationType, realmName);
            } else {
                logger.error("Auditing Failed for operation: {}, tenant: {}", operationType, realmName);
            }
        } else {
            logger.error("Audit validation failed for operation: {}, with error details {}", operationType, validLogMessage.get(0).getErrorDetails());
        }
    }

    //This method sends processed data information to auditService
    private void auditProcessData(AuditLogMessage auditLogMessage, String operationType, String realmName, List<AuditClientResponse.ErrorMessage> validLogMessage) throws AuditFailedException {
        String objectName = ((IntegrationAuditLogMessage) auditLogMessage).getParam2();
        if (validLogMessage.size() == 0) {
            long start = System.currentTimeMillis();
            AuditClientResponse audited = AuditLogger.log(auditLogMessage);
            long elapsedTime = System.currentTimeMillis() - start;
            logger.info("*******Audit log time for "+operationType +"is "+elapsedTime+" milli seconds");
            if (audited.getStatus() != null &&
                audited.getStatus().equals(AuditClientResponse.ResponseStatus.SUCCESS)) {
                logger.info("Successfully Audited for operation: {}, objectName: {}, tenantId: {}", operationType, objectName, realmName);
            } else {
                String errorMessage = "";
                if(audited.failureCount() != null &&
                    audited.failureCount() > 0) {
                    errorMessage += audited.failureMessage(1).get(0).getErrorDetails();
                }
                logger.error("Auditing Failed  for operation: {}, objectName: {}, tenantId: {}", operationType, objectName, realmName);
                throw new AuditFailedException(errorMessage);
            }
        } else {
            logger.error("Audit validation failed for operation: {}, with error details {}", operationType, validLogMessage.get(0).getErrorDetails());
            throw new AuditFailedException("Audit validation failed with error message "+validLogMessage.get(0).getErrorDetails());
        }
    }


}
