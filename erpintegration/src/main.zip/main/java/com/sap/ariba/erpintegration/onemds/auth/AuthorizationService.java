package com.sap.ariba.erpintegration.onemds.auth;

import java.util.Map;

import com.sap.ariba.erpintegration.onemds.exception.AuthorizationException;

public interface AuthorizationService
{
    public Map<String, Object> getAccessToken (AuthorizationRequestInfo authorizationRequestInfo) throws
        AuthorizationException;
}
