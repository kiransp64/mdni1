package com.sap.ariba.erpintegration.filters.ui;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RestApiControllerFilterRegistrationConfig {
    @Bean
    public FilterRegistrationBean<RestApiControllerRequestFilter> uiApiFilter() {
        FilterRegistrationBean<RestApiControllerRequestFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new RestApiControllerRequestFilter());
        registrationBean.addUrlPatterns("/inspectorapi", "/main/inspector");        
        return registrationBean;
    }
    
}
