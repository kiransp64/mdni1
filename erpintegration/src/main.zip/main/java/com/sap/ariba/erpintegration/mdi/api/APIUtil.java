package com.sap.ariba.erpintegration.mdi.api;

import com.sap.ariba.erpintegration.mdi.exception.InvalidInputException;
import com.sap.scimono.entity.Group;
import com.sap.scimono.entity.User;
import com.sap.scimono.entity.patch.PatchBody;
import com.sap.scimono.entity.patch.PatchOperation;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sap.scimono.entity.Resource;
public class APIUtil
{
    private static final Logger logger = LoggerFactory.getLogger(APIUtil.class);
    public static final String CXF_API_PREFIX = "api";
    public static final String SCIM_API_PATH_PREFIX = "scim";

    public static void validate (String tenantId)
    {
        if (StringUtils.isEmpty(tenantId)) {
            logger.error("Tenant ID header is not provided. Tenant ID is mandatory.");
            throw new InvalidInputException("Tenant ID (x-anId) header is mandatory");
        }
    }

    public static <T extends Resource> void validate (T resource, String tenantId)
    {
        if (resource == null) {
            logger.error("Payload is not present");
            throw new InvalidInputException("User Payload not present");
        }
        validate(tenantId);
    }

    public static <T extends Resource> void validate (T resource, String tenantId,
                                                      String pathParamName)
    {
        validate(resource, tenantId);
        if (resource instanceof Group group) {
            if (!pathParamName.equals(group.getDisplayName())) {
                logger.error("Group Display Name in payload and path parameter does not match");
                throw new InvalidInputException("Group Display Name in payload and path parameter does not match");
            }
        }
        if (resource instanceof User user) {
            if (!pathParamName.equals(user.getUserName())) {
                logger.error("User Name in payload and path parameter does not match");
                throw new InvalidInputException("User Name in payload and path parameter does not match");
            }
        }
    }

    public static String patchBodyToString (PatchBody patchBody)
    {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PatchBody{schema=" + patchBody.getSchemas() + "," +
                "PatchOperations[");
        patchBody.getOperations().stream().forEach(patchOperation -> stringBuilder.append(operationToString(patchOperation)));
        return stringBuilder.append("]}").toString();
    }

    private static String operationToString (PatchOperation op)
    {
        return """
                {\
                op=\
                """ + op.getOp().getValue() +
                ", path='" + (op.getPath() == null ? "null" : op.getPath()) + '\'' +
                ", value=" + (op.getValue() == null ? "null" : op.getValue().asText()) +
                '}';
    }

    public static String sanitizeInput(String input){
        return StringEscapeUtils.escapeJava(input);
    }
}