/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sap.ariba.erpintegration.handlers.IntegrationJobLogProvider;
import com.sap.ariba.erpintegration.mdi.api.APIUtil;
import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.mdi.mds.search.constants.MDSsearchConstants;
import com.sap.ariba.erpintegration.monitor.application.logentry.LogEntryBuilderException;
import com.sap.ariba.erpintegration.monitor.application.logentry.LogEntryUtil;
import com.sap.ariba.erpintegration.monitor.application.logentry.XMLPayloadStatusLogEntryBuilder;
import com.sap.ariba.erpintegration.monitor.application.model.ApplicationData;
import com.sap.ariba.erpintegration.monitor.exception.IntegrationMonitoringException;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.util.IMConstants;
import com.sap.ariba.erpintegration.monitor.im.util.IMEvents;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.integrationmonitoring.bean.ApplicationMonitoringBean;
import com.sap.ariba.integrationmonitoring.bean.IntegrationMonitoringBean;
import com.sap.ariba.integrationmonitoring.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import org.thymeleaf.util.ListUtils;

import java.util.ArrayList;
import java.util.List;

import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.*;
import static com.sap.ariba.erpintegration.monitor.im.util.IMEvents.PROCESS_XML_DATA;
import static com.sap.ariba.erpintegration.monitor.im.util.IMLogMessage.IM_INVALID_INPUT;
import static com.sap.ariba.integrationmonitoring.bean.ApplicationMonitoringBean.ValueSizeLimitInBytes;

/**
 * This class will be handling application related data for particular event
 */
@Slf4j
@ConditionalOnExpression(IMConstants.INTEGRATION_MONITORING_ENABLE)
@Component(value = "xmlPayloadApplicationContextDataHandler")
public class XMLPayloadApplicationContextDataHandler implements ApplicationContextDataHandler
{
    @Autowired
    private ObjectMapper simpleObjectMapper;

    @Autowired
    private XMLPayloadStatusLogEntryBuilder logEntryBuilder;

    /**
     * This will take Integration mon bean and IntegrationContext object ,it will form application related data and add to IntegrationMonitoringBean .
     *
     * @param integrationContext - having necessary information to build ApplicationMonitoringBean
     * @param imMonData IntegrationMonitoringBean having all the log related information
     * @throws IntegrationMonitoringException
     */
    @Override
    public void addApplicationData (IntegrationContext integrationContext,
                                    IntegrationMonitoringBean imMonData)
    throws IntegrationMonitoringException
    {
        if (null != integrationContext && null != imMonData) {
            IMEvents eventName = integrationContext.getEventName();
            List<ApplicationData> applicationDataList = new ArrayList<>();
            try {
                setCommonApplicationDataForXMLPayload(integrationContext,
                                                      applicationDataList);
                addTenantIdToApplicationData(integrationContext,
                                             applicationDataList);
                setApplicationData(integrationContext, applicationDataList);
                if (!applicationDataList.isEmpty()) {
                    for (ApplicationData appData : applicationDataList) {
                        ApplicationMonitoringBean appMonData = buildApplicationMonitoringBean(appData);
                        addApplicationContextToIntegrationMonitoringBean(imMonData,
                                                                         appMonData);
                    }
                }
                List<ApplicationMonitoringBean> appMonBeans =  buildLogEntries(integrationContext);
                addApplicationContextToIntegrationMonitoringBean(imMonData, appMonBeans);
            }
            catch (Exception exp) {
                log.error("{}, Event Name - {} , Exception - {}, while adding Application context data to IM Monitoring bean.",
                          MDNI_IM_CRITICAL,
                          eventName,
                          ErrorUtil.getCompleteCausedByErrors(exp));
                throw new IntegrationMonitoringException(
                    "Exception while forming application context to IM monitoring bean "
                        + eventName.getEventName(),
                    exp);
            }
        }
    }

    @Override
    public List<ApplicationMonitoringBean> buildLogEntries (IntegrationContext integrationContext)
    {
        if (integrationContext != null && !integrationContext.getIsMDI()) {
            String statusText = integrationContext.getStatusText();
            if (StringUtils.isNotEmpty(statusText)) {
                try {
                    List<ApplicationMonitoringBean> appMonBeans = new ArrayList<>();
                    JsonNode statusNode = simpleObjectMapper.readTree(statusText);
                    if (statusNode != null && statusNode instanceof ObjectNode) {
                        int seqNo = 0;
                        JsonNode warningsNode = statusNode.get(
                            IntegrationJobLogProvider.WARNINGS);
                        if (warningsNode != null && !warningsNode.isNull()
                            && warningsNode.asText() != null
                            && !LogEntryUtil.hasCrossedMaxAppDataLength(
                            integrationContext.getAppDataSize()))
                        {
                            List<ApplicationData> warningsData = logEntryBuilder.buildApplicationData(
                                warningsNode.asText(),
                                ApplicationMonitoringBean.Classification.MESSAGE,
                                ApplicationMonitoringBean.ValueType.JSON,
                                LogEntryUtil.XML_PAYLOAD_LOG_ENTRY_WARNING,
                                integrationContext);
                            List<ApplicationMonitoringBean> warningsAppMonBeans = buildAppMonBeansFromAppDataWithSeq(
                                warningsData, seqNo);
                            if (!ListUtils.isEmpty(warningsAppMonBeans)) {
                                seqNo = warningsAppMonBeans.get(
                                    warningsAppMonBeans.size() - 1).getSequenceNo();
                                appMonBeans.addAll(warningsAppMonBeans);
                            }
                        }
                        JsonNode fatalErrorsNode = statusNode.get(
                            IntegrationJobLogProvider.FATAL_ERRORS);

                        if (fatalErrorsNode != null && !fatalErrorsNode.isNull()
                            && fatalErrorsNode.asText() != null
                            && !LogEntryUtil.hasCrossedMaxAppDataLength(
                            integrationContext.getAppDataSize()))
                        {
                            List<ApplicationData> fatalErrorAppData = logEntryBuilder.buildApplicationData(
                                fatalErrorsNode.asText(),
                                ApplicationMonitoringBean.Classification.MESSAGE,
                                ApplicationMonitoringBean.ValueType.JSON,
                                LogEntryUtil.XML_PAYLOAD_LOG_ENTRY_FATAL_ERROR,
                                integrationContext);
                            List<ApplicationMonitoringBean> fatalErrorMonBeans = buildAppMonBeansFromAppDataWithSeq(
                                fatalErrorAppData, seqNo);
                            if (!ListUtils.isEmpty(fatalErrorMonBeans)) {
                                seqNo = fatalErrorMonBeans.get(
                                    fatalErrorMonBeans.size() - 1).getSequenceNo();
                                appMonBeans.addAll(fatalErrorMonBeans);
                            }
                        }

                        JsonNode nonFatalExcepsNode = statusNode.get(
                            IntegrationJobLogProvider.NON_FATAL_EXCEPTIONS);

                        if (nonFatalExcepsNode != null && !nonFatalExcepsNode.isNull()
                            && nonFatalExcepsNode.asText() != null
                            && !LogEntryUtil.hasCrossedMaxAppDataLength(
                            integrationContext.getAppDataSize()))
                        {
                            List<ApplicationData> nonFatalExcepAppData = logEntryBuilder.buildApplicationData(
                                nonFatalExcepsNode.asText(),
                                ApplicationMonitoringBean.Classification.MESSAGE,
                                ApplicationMonitoringBean.ValueType.JSON,
                                LogEntryUtil.XML_PAYLOAD_LOG_ENTRY_NON_FATAL_EXCEPTION,
                                integrationContext);
                            List<ApplicationMonitoringBean> nonFatalExcepMonBeans = buildAppMonBeansFromAppDataWithSeq(
                                nonFatalExcepAppData, seqNo);
                            if (!ListUtils.isEmpty(nonFatalExcepMonBeans)) {
                                seqNo = nonFatalExcepMonBeans.get(
                                    nonFatalExcepMonBeans.size() - 1).getSequenceNo();
                                appMonBeans.addAll(nonFatalExcepMonBeans);
                            }
                        }
                    }
                    return appMonBeans;
                }
                catch (JsonProcessingException | LogEntryBuilderException e) {
                    log.error(
                        "{} {} while trying to build log entries for tenant ID - {} and Job ID - {}.",
                        MDNI_IM_CRITICAL, ErrorUtil.getCompleteCausedByErrors(e),
                        APIUtil.sanitizeInput(integrationContext.getTenantID()), APIUtil.sanitizeInput(integrationContext.getJobID()));
                }
            }
        }
        return null;
    }

    protected List<ApplicationMonitoringBean> buildAppMonBeansFromAppDataWithSeq (List<ApplicationData> appData,
                                                                                int seqNo)
    {
        if (!ListUtils.isEmpty(appData)) {
            List<ApplicationMonitoringBean> appMonData = new ArrayList<>();
            for (ApplicationData appDataItem : appData) {
                ApplicationMonitoringBean applicationMonitoringBean = null;
                try {
                    applicationMonitoringBean = buildApplicationMonitoringBeanWithSequence(
                        appDataItem, seqNo);
                    seqNo = applicationMonitoringBean.getSequenceNo();
                    appMonData.add(applicationMonitoringBean);
                }
                catch (Exception e) {
                    log.error(
                        "{} {} while trying to build log entry application monitoring data with sequence - {}.",
                        MDNI_IM_CRITICAL, ErrorUtil.getCompleteCausedByErrors(e), seqNo);
                }
            }
            return appMonData;
        }
        return null;
    }

    private void setCommonApplicationDataForXMLPayload (IntegrationContext integrationContext,
                                                        List<ApplicationData> applicationDataList)
    {
        ApplicationData xmlPayloadAppDataForObjectType = new ApplicationData(MASTER_DATA_OBJECT_TYPE,
                                                                             MASTER_DATA_OBJECT_TYPE,
                                                                             integrationContext.getObjectName(),
                                                                             ApplicationMonitoringBean.Classification.CONTEXT,
                                                                             ApplicationMonitoringBean.ValueType.SIMPLE);
        applicationDataList.add(xmlPayloadAppDataForObjectType);

        ApplicationData xmlPayloadAppDataForJobID = new ApplicationData(JOB_ID,
                                                                        JOB_ID,
                                                                        integrationContext.getJobID(),
                                                                        ApplicationMonitoringBean.Classification.CONTEXT,
                                                                        ApplicationMonitoringBean.ValueType.SIMPLE);
        applicationDataList.add(xmlPayloadAppDataForJobID);

        String errorMsg = integrationContext.getErrorMessage();
        //since IM is not allowing more than 5000 char, we are logging it here.
        if (integrationContext.getIsError() && StringUtils.isNotEmpty(errorMsg)) {
            if (errorMsg.length() > ValueSizeLimitInBytes) {
                log.warn(String.format(IM_INVALID_INPUT.getLogMessage(),
                                       integrationContext.getEventName(),
                                       ERROR_MESSAGE,
                                       ValueSizeLimitInBytes,
                                       errorMsg.length()));
                errorMsg = CommonUtil.trimLength(errorMsg,
                                                 ValueSizeLimitInBytes);
            }
            ApplicationData xmlPayloadAppDataForError = new ApplicationData(ERROR_MESSAGE,
                                                                            ERROR_DETAIL,
                                                                            errorMsg,
                                                                            ApplicationMonitoringBean.Classification.MESSAGE,
                                                                            ApplicationMonitoringBean.ValueType.SIMPLE);
            //if Object name is User/Group then will mark error message related to those as personal data.
            if (shouldConsiderErrorAsPersonalData(integrationContext)) {
                xmlPayloadAppDataForError.setPersonalData(true);
            }
            applicationDataList.add(xmlPayloadAppDataForError);
        }
        //If sender business system id is empty
        if (null != integrationContext.getSenderBusinessSystemId()
                        && !StringUtils.isEmpty(integrationContext.getSenderBusinessSystemId())
                        && !MDSsearchConstants.NULL_STRING.equals(integrationContext.getSenderBusinessSystemId())) {
            ApplicationData xmlPayloadAppDataForSenderBusinessSystemId = new ApplicationData(SENDER_BUSINESS_SYSTEM_ID,
                                                                                             SENDER_BUSINESS_SYSTEM_ID_DISPLAY,
                                                                                             integrationContext.getSenderBusinessSystemId(),
                                                                                             ApplicationMonitoringBean.Classification.CONTEXT,
                                                                                             ApplicationMonitoringBean.ValueType.SIMPLE);
            applicationDataList.add(xmlPayloadAppDataForSenderBusinessSystemId);
        }

        //if request is for MDI event ,then will not set Integration channel as Webservices.
        if (!integrationContext.getIsMDI()) {
            ApplicationData appDataForIntegrationChannel = new ApplicationData(INTEGRATION_CHANNEL,
                                                                               INTEGRATION_CHANNEL_DISPLAY,
                                                                               getIntegrationChannel(),
                                                                               ApplicationMonitoringBean.Classification.MESSAGE,
                                                                               ApplicationMonitoringBean.ValueType.SIMPLE);
            applicationDataList.add(appDataForIntegrationChannel);
        }
    }

    protected String getIntegrationChannel ()
    {
        return WEBSERVICE;
    }

    private void setApplicationDataForIntegrationProcessXMLPayload (IntegrationContext integrationContext,
                                                                    List<ApplicationData> applicationDataList)
    {
        ApplicationData xmlPayloadAppDataForStatusText = new ApplicationData(STATUS_TEXT,
                                                                             STATUS_TEXT,
                                                                             integrationContext.getStatusText(),
                                                                             ApplicationMonitoringBean.Classification.MESSAGE,
                                                                             ApplicationMonitoringBean.ValueType.JSON);
        applicationDataList.add(xmlPayloadAppDataForStatusText);
        ApplicationData xmlPayloadAppDataForStatus = new ApplicationData(STATUS,
                                                                         STATUS,
                                                                         integrationContext.getStatus(),
                                                                         ApplicationMonitoringBean.Classification.MESSAGE,
                                                                         ApplicationMonitoringBean.ValueType.SIMPLE);
        applicationDataList.add(xmlPayloadAppDataForStatus);
    }

    protected void setApplicationData(IntegrationContext integrationContext,
                                      List<ApplicationData> applicationDataList){
        return;
    }

    protected IMEvents getEventName(){
        return PROCESS_XML_DATA;
    }

    /**
     * This method will check if error application data need to mark as personal data
     *
     * @return true/false
     */
    @Override
    public boolean shouldConsiderErrorAsPersonalData (IntegrationContext integrationContext)
    {
        boolean shouldConsider = false;
        //Based on object name if it is user/group then mark as true
        String objectName = integrationContext.getObjectName();
        if (!StringUtils.isEmpty(objectName)) {
            Entity entity = Entity.getEntity(objectName);
            if (entity != null && (entity.equals(Entity.USER) || entity.equals(Entity.GROUP))) {
                shouldConsider = true;
            }
        }
        return shouldConsider;
    }
}
