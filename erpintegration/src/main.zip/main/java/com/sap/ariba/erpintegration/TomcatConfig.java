package com.sap.ariba.erpintegration;

/*
    Config Class to relax "/" special char in the URL and to
    decode the encoded solidus character in the URL.
*/


import org.apache.catalina.connector.Connector;
import org.apache.tomcat.util.buf.EncodedSolidusHandling;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TomcatConfig {
    private static final Logger logger = LoggerFactory.getLogger(TomcatConfig.class);

    @Bean
    public TomcatConnectorCustomizer connectorCustomizer() {
        logger.info("Relaxing forward slash in the URL");
        return (Connector connector) -> connector.setEncodedSolidusHandling(EncodedSolidusHandling.PASS_THROUGH.getValue());
    }
}

