package com.sap.ariba.erpintegration.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import com.sap.ariba.erpintegration.mdi.common.util.JSONUtil;
import com.sap.ariba.mdsclient.connection.SimpleResponseHandler;
import jakarta.servlet.http.HttpServletRequest;


import com.sap.ariba.erpintegration.mdi.cap.oauth.BasicAuthTokenManager;
import com.sap.ariba.erpintegration.mdi.common.util.TracingHelper;
import com.sap.ariba.erpintegration.onemds.storage.StorageServiceImpl;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.hc.client5.http.HttpResponseException;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.core5.http.ClassicHttpRequest;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpHeaders;
import org.apache.hc.core5.http.HttpStatus;
import org.apache.hc.core5.http.io.HttpClientResponseHandler;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.json.simple.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.HttpClientConfiguration;
import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.ConfigRepository;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.persistence.model.IntegrationConfig;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.PublishService;
import com.sap.ariba.erpintegration.service.cap.MdniToMdsCapPublishService;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.service.mds.MDNIToMDSPublishService;
import com.sap.ariba.erpintegration.service.mds.MDSPublishStatus;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isEmpty;

public class HandlerUtil
{
    private static final Logger logger = LoggerFactory.getLogger(HandlerUtil.class);
    private static final String KeyQueryStringForDataPost = "publishMasterData";
    private static final String[] incrementalLoadObjects = { "WBSElement", "GLAccount", "User",
                                                             "Product", "CostCentre" };

    public static final String KeyAuthorization = "Authorization";
    public static final String KeyCallbackURL = "CallbackURL";
    public static final String KeyHttpRequest = "HTTP.REQUEST";
    public static final String KeyOperation = "operation";
    public static final String KeyObjectName = "object";
    public static final String KeyGetConfig = "getConfig";
    private static final String lastBaseIdFetchedFromQueryKey = "lastBaseIdFetchedFromQuery";
    public static final String lastBaseIdSentFromClientKey = "baseId";
    public static final String userUniqueNameSentFromClientKey = "userUniqueName";
    public static final String CIGSource = "cigSource";
    private static final String CIGQueryParam = "&cigSource=true";
    private static final String lastBaseIdKey = "lastBaseId";
    private static final String MDIQueryParam = "mdiSource=true";

    public static final int KeyBatchSize = 1000;

    public static final String[] dateFormats = { "yyyy-MM-dd'T'HH:mm:ss'Z'",
                                                 "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                                                 "yyyy-MM-dd'T'HH:mm:ssZ",
                                                 "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
                                                 "yyyy-MM-dd"};

    private static HttpClientConfiguration httpComm;

    public static final String ENVIRONMENT_MDCS = "environment.mdcs";
    public static final String MDCS_BASIC_AUTH_ENABLED = "mdcs.erpintegration.basic.auth.enabled";
    public static final String MDCS_CIG_CERT = "mdcs.cig.cert";
    public static final String ADVANCED_STORAGE_OPTION = "advanced.storage.option";
    public static final String MDCS_MDS_HANA_USERNAME = "mdcs.mds.hana.username";
    public static final String MDCS_MDS_HANA_PASSWORD = "mdcs.mds.hana.password";
    public static final String BEARER_CAP = "Bearer ";
    public static final String BASIC = "Basic ";

    public static final String BEARER_SMALL = "bearer ";
    public static final String MDCS = "mdcs";
    public static final String DASH = "-";
    public static final String STORE = "store";
    public static final String CLOUD_STORAGE_PATH = "data";
    public static final String SLASH = "/";
    private static final int RANDOM_NUMBER_UPPER_BOUND = 1000;
    public static final String SOAPAction_ANID = "SOAPAction";
    private static final String FALSE_FLAG = "false";

    public static String getANId (SoapMessage message)
    {
        String anId = null;
        if (message != null) {
            HttpServletRequest request = (HttpServletRequest) message.get(KeyHttpRequest);
            if (request != null) {
                anId = request.getParameter(Constants.KeyTenantId);
            }
        }
        return anId;
    }

    /**
     * @param message
     * @return the query parameter value of 'cigSource' specifying if the
     * request originated from CIG. default value is false.
     */
    public static boolean isCigSource (SoapMessage message)
    {
        boolean isCigSource = false;
        if (message != null) {
            HttpServletRequest request = null;
            try {
                request = (HttpServletRequest) message.get(KeyHttpRequest);
                if (request != null) {
                    isCigSource = Boolean.parseBoolean(request.getParameter(CIGSource));
                }
            } catch (Exception e) {
                logger.info("HandlerUtil: isCigSource: exception ", e);
            }
        }
        return isCigSource;
    }

    public static String getAuthorizationToken (SoapMessage message)
    {
        String authorizationToken = null;
        if (message != null) {
            HttpServletRequest request = (HttpServletRequest) message.get(KeyHttpRequest);
            if (request != null) {
                authorizationToken = request.getHeader(KeyAuthorization);
            }
        }
        return authorizationToken;
    }

    public static String getConfigCallbackURL (String anId)
    {
        long tenantId = Utility.getTenantId(anId);
        String url = null;
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        ConfigRepository repository = (ConfigRepository) factory.getMiscDAO(ObjectTypes.IntegrationConfig.getValue());
        IntegrationConfig config = repository.findOne(tenantId, KeyCallbackURL);
        if (config != null) {
            url = config.getValue();
            OAuthTokenManager oAuthTokenManager;
            if (ApplicationContextProvider.getApplicationContext() != null) {
                oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(
                    OAuthTokenManager.class);
                if (oAuthTokenManager.proxyURL != null && !oAuthTokenManager.proxyURL.isEmpty()) {
                    url = addProxyInfo(url, oAuthTokenManager.proxyURL);
                }
            }
        }
        return url;
    }

    public static Map<String, Object> getMdcsAuthCredentials (String anId)
    {
        if(HandlerUtil.isMdcsCIGBasicAuthEnabled()) {
            return BasicAuthTokenManager.getAuthCredentials();
        }else {
            return null;
        }
    }

    public static String addProxyInfo (String urlStr, String proxyURL)
    {
        String path = null;
        String query = null;
        String authority = null;
        StringBuilder modifiedURL = new StringBuilder();

        try {
            URL url = new URL(urlStr);
            authority = url.getAuthority();
            path = url.getPath();
            query = url.getQuery();
            modifiedURL.append(proxyURL).append("/").append(authority).append(path).append("?").append(
                query);
            logger.info("Config URL with proxy info {}", modifiedURL);

        } catch (MalformedURLException e) {
            logger.warn("Exception- {} while adding proxy info to the URL - {}",
                        ErrorUtil.getCompleteCausedByErrors(e),
                        modifiedURL);
            return urlStr;
        }

        return modifiedURL.toString();
    }

    public static Map getConfiguredCredentials (String anId) throws IntegrationServiceException
    {
        return postRequest(HandlerUtil.getConfigCallbackURL(anId), anId, false, -1, null);
    }
    
    public static Map getXSUAAConfiguredCredentials (String anId) throws IntegrationServiceException
    {
        String urlStr = HandlerUtil.getConfigCallbackURL(anId);
        // To check if there are any query parameters already.
        int index = urlStr.indexOf('?');
        String stringToAppend = "";
        stringToAppend = (index == -1) ? "?".concat(MDIQueryParam) : "&"+MDIQueryParam;
        urlStr = urlStr.concat(stringToAppend);
        return postRequest(urlStr, anId, false, -1, null);
    }

    public static Map getConfiguredCertificate (String anId, boolean cigSource) throws
        IntegrationServiceException
    {
        String urlStr = HandlerUtil.getConfigCallbackURL(anId);
        if (cigSource) {
            // To check if there are any query parameters already.
            int index = urlStr.indexOf('?');
            String stringToAppend = "";
            stringToAppend = (index == -1) ? "?".concat(CIGQueryParam) : CIGQueryParam;
            urlStr = urlStr.concat(stringToAppend);
        }
        return postRequest(urlStr, anId, false, -1, null);
    }

    public static String getMDCSConfiguredCIGCertificate () throws
            IntegrationServiceException
    {
        Environment env = ApplicationContextProvider.getApplicationContext().getEnvironment();
        String cert = null;
        logger.debug("Print the certificate : {}", env.getProperty(MDCS_CIG_CERT));
        try {
            String base64Cert = env.getProperty(MDCS_CIG_CERT);
            byte[] decoder = Base64.getDecoder().decode(base64Cert);
            cert = new String(decoder, StandardCharsets.UTF_8);
        } catch (Exception e) {
            logger.error("Exception in decoding the public certificate" ,e );
           throw new IntegrationServiceException("Exception in decoding the public certificate",e);
        }
        return cert;
    }
    public static Map postDataToApp (JSONArray dataArray,
                                     String anId,
                                     int operation,
                                     String objectName,
                                     String senderBusinessSystemId, StageXMLData stageXMLData) throws
    IntegrationServiceException
    {
        Map responseAsMap = null;
        PublishService publishService;
        if (HandlerUtil.isMDCS()) {
            publishService = ApplicationContextProvider.getApplicationContext().getBean(
                MdniToMdsCapPublishService.class);
        }
        else {
            publishService = ApplicationContextProvider.getApplicationContext().getBean(
                MDNIToMDSPublishService.class);
        }

        // MDS Publish Entities
        if (publishService.isMDSPublishEnabled(anId, objectName, stageXMLData)) {
            Map<String, Object> mdsResponse = publishService.publish(dataArray,
                anId,
                operation,
                objectName,
                senderBusinessSystemId, stageXMLData);
                // Based on response from MDS
                if (canPostDataToApp(mdsResponse)) {
                    // Excluded Entities
                    if (!publishService.isAppPublishExcuded(anId, objectName)) {
                        // Buyer Publish Feature disabled?
                        if (!publishToBuyerDisabled(anId)) {
                            //publish to buyer is not
                            // disabled, so publish to Buyer/S4 also
                            Map appResponse = postDataToAppInternal(
                                dataArray,
                                anId,
                                operation,
                                objectName);
                            responseAsMap = mergeResponses(mdsResponse, appResponse);
                        }
                        else {
                            responseAsMap = mdsResponse;
                        }
                    }
                    else {
                        responseAsMap = mdsResponse;
                    }
                }
                else {
                    // Excluded Entities
                    if (!publishService.isAppPublishExcuded(anId, objectName)) {
                        logger.error("[MDNI_CRITICAL][ARIBA][Publish] Tenant ID - {}, Object name - {}, SenderBusinessSystemId - {}, Will not publish '{}' entities to Buyer/S4 as publish to MDS has failed",
                                     anId,
                                     objectName,
                                     senderBusinessSystemId,
                                     objectName);
                    }
                    responseAsMap = mdsResponse;
                }                      
        }
        // Excluded Entities
        else if (!publishService.isAppPublishExcuded(anId, objectName)) {
            responseAsMap = postDataToAppInternal(dataArray, anId, operation, objectName);
        }
        return responseAsMap;
    }

    public static Map postDataToAppInternal (JSONArray dataArray,
                                              String anId,
                                              int operation,
                                              String objectName) throws IntegrationServiceException
    {
        String urlStr = HandlerUtil.getConfigCallbackURL(anId);
        urlStr = HandlerUtil.modifyURLForPostData(urlStr, objectName, operation);
        return postRequest(urlStr, anId, true, operation, dataArray);
    }

    public static Map postRequest (String urlStr,
                                   String anId,
                                   boolean isPostRequest,
                                   int operation,
                                   JSONArray dataArray) throws IntegrationServiceException
    {
        Map responseAsMap;
        ClassicHttpRequest method;
        try {
            httpComm = ApplicationContextProvider.getApplicationContext().getBean(
                    HttpClientConfiguration.class);
            httpComm.printConnectionStats();

            if (isPostRequest) {
                HttpPost request = new HttpPost(urlStr);
                try (StringEntity params = new StringEntity(dataArray.toJSONString(),
                                                            ContentType.APPLICATION_JSON)) {
                    request.setEntity(params);
                }
                method = request;
            }
            else {
            	method = new HttpGet(urlStr);
            }

            setOAuthHeader(method, anId);

            method.setHeader(TracingHelper.TRACE_ID, getTraceId());

            logger.info("Start : Method name : postRequest() ,Connecting with uri string - {}, An ID - {}.",
                        urlStr,
                        anId);

            String responseData = httpComm.getHttpClient().execute(method, new SimpleResponseHandler());
            if (isEmpty(responseData)) {
                logger.warn("[MDNI_CRITICAL][ARIBA][Publish] Tenant ID - {}, Error/empty response received from Application URL: {}",
                             anId,
                             urlStr);
                throw new IntegrationServiceException(
                                "Post Request to Application was not OK");
            }
            responseAsMap = getRequestDataAsMap(responseData);
        }
        catch (HttpResponseException hre) {
            logger.error("[MDNI_CRITICAL][ARIBA][Publish] Tenant- {} ,Error, while posting Data to Application, Status- {} ,isPostRequest- {} ,URL- {},Reason Phrase- {}",
                         anId,
                         hre.getStatusCode(),
                         isPostRequest,
                         urlStr,
                         hre.getReasonPhrase());
            throw new IntegrationServiceException(
                            "Post Request to Application was not OK for for ANId " + anId + " "
                                            + hre.getReasonPhrase(),
                            hre);
        }
        catch (IOException | GeneralSecurityException e) {
            logger.error("[MDNI_CRITICAL][ARIBA][Publish] Tenant ID - {} Exception - {} while posting data to Application",
                        anId,
                        ErrorUtil.getCompleteCausedByErrors(e));
            throw new IntegrationServiceException(e);
        }
        finally {
            try {
                httpComm.printConnectionStats();
            }
            catch (Exception e) {
                logger.error("Error while trying to print connection statistics.", e);
            }
        }

        return responseAsMap;
    }

    public static Map getRequestDataAsMap (String requestData) throws IntegrationServiceException
    {
        Map mapData;
        try {
            mapData = JSONUtil.getMapper().readValue(requestData, Map.class);
        } catch (IOException ioe) {
            logger.warn("Error while extracting info from request stream.",ioe);
            throw new IntegrationServiceException(ioe);
        }
        return mapData;
    }

    private static void setOAuthHeader (ClassicHttpRequest method, String anId) throws
    GeneralSecurityException,
    IOException
    {
        String token = getOAuthToken(anId);
        method.setHeader(HttpHeaders.AUTHORIZATION, token);
    }
    
    private static String getOAuthToken (String anId)
    {
        OAuthTokenManager oAuthTokenManager;
        oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(
            OAuthTokenManager.class);
        return OAuthTokenManager.getAccessTokenFromTokenMap(oAuthTokenManager.getTokens(
            anId,
            null));
    }

    public static String modifyURLForPostData (String urlStr, String objectName, int operation)
    {
        String modifiedURL = null;
        modifiedURL = urlStr.replace(KeyGetConfig, KeyQueryStringForDataPost);
        modifiedURL = modifiedURL + "&" + KeyOperation + "=" + operation;
        modifiedURL = modifiedURL + "&" + KeyObjectName + "=" + objectName;
        return modifiedURL;
    }

    public static boolean isIncrementalLoadObject (String objectName)
    {
        return Arrays.asList(incrementalLoadObjects).contains(objectName);
    }

    /**
     * This method determines if data can be published to Buyer/S4 based on
     * the response received from MDS
     */
    private static boolean canPostDataToApp (Map<String, Object> mdsResponse)
    {
        if (MapUtils.isEmpty(mdsResponse)) {
            // No response from MDS, so cannot post to Buyer/S4
            return false;
        }
        if (MDSPublishStatus.FAILURE
            == mdsResponse.get(IntegrationJobResponseProcessor.MDSPublishStatus)) {
            // MDS publish failed, so cannot post to Buyer/S4
            return false;
        }
        // can post to Buyer/S4
        return true;
    }
    
    /**
     * This method checks if publishing data to Buyer has been disabled
     */
    private static boolean publishToBuyerDisabled (String anId)
    {
        DisableMDNIPublishToBuyerFeatureCheck disableMDNIPublishToBuyerFeatureCheck = ApplicationContextProvider.getApplicationContext().getBean(
            DisableMDNIPublishToBuyerFeatureCheck.class);
        // If publish to buyer is disabled, should not post to buyer.
        if (disableMDNIPublishToBuyerFeatureCheck.isDisableMDNIPublishToBuyerFeatureEnabled(
            anId))
        {
            logger.info("DisableMDNIPublishToBuyerFeature toggle is enabled on Buyer");
            return true;
        }
        logger.info("DisableMDNIPublishToBuyerFeature toggle is disabled on Buyer");
        return false;
    }

    private static Map mergeResponses (Map<String, Object> mdsResponse, Map appResponse)
    {
        // If the same key is present in both the maps,
        // the value from 'appResponse' will take precedence
        // over the value from 'mdsResponse'
        Map result = new HashMap();
        if (!MapUtils.isEmpty(mdsResponse)) {
            mdsResponse.forEach((key, value) -> result.put(key, value));
        }
        if (!MapUtils.isEmpty(appResponse)) {
            appResponse.forEach((key, value) -> result.put(key, value));
        }
        return result;
    }

    public static org.json.JSONArray getDataFromBuyer (String anID,
                                                       String urlReplacementStringForObject) throws
        IntegrationServiceException,
        IOException,
        GeneralSecurityException
    {
        ClassicHttpRequest method;
        String responseData;
        String urlStr = "";
        try {
            httpComm = ApplicationContextProvider.getApplicationContext().getBean(
                HttpClientConfiguration.class);
             httpComm.printConnectionStats();
             urlStr = getURL(anID, urlReplacementStringForObject);
    
            method = new HttpGet(urlStr);
     
            setOAuthHeader(method, anID);

            logger.info("Start : Connecting with uri string - {}, AnID- {},Method name : getDataFromBuyer() ",
                        urlStr,
                        anID);
    
            AuditClientDataService auditClientDataService;
            auditClientDataService = ApplicationContextProvider.getApplicationContext().getBean(AuditClientDataService.class);

            responseData = httpComm.getHttpClient().execute(method, new SimpleResponseHandler());
            if (isEmpty(responseData)) {
                auditClientDataService.auditFetchApi(anID,
                                                     urlStr,
                                                     "Post Request to Application was not OK while fetching the Data from Buyer.");
                throw new IntegrationServiceException(
                                "Post Request to Application was not OK while fetching the Data from Buyer, anID-"
                                                + anID);
            }
            auditClientDataService.auditFetchApi(anID, urlStr, null);
        }
        catch (HttpResponseException hre) {
            logger.error("[MDNI_CRITICAL][ARIBA] AnID- {} ,Error - {}, while getting the Data from Buyer, Status- {} ,URL- {},Reason Phrase- {}",
                         anID,
                         hre.getMessage(),
                         hre.getStatusCode(),
                         urlStr,
                         hre.getReasonPhrase());
            throw new IntegrationServiceException(
                            "Error while getting the Data from Buyer for ANId : " + anID
                                            + " and message :" + hre.getReasonPhrase(),
                            hre);
        }
        catch (IOException e) {
            logger.warn("[MDNI_CRITICAL][ARIBA] Tenant ID - {} Exception -{} while parsing the data while getting the data from Buyer.",
                        anID,
                        ErrorUtil.getCompleteCausedByErrors(e));
            throw new IntegrationServiceException(e);
        }
        return new org.json.JSONArray(responseData);
    }

    public static org.json.JSONArray getDataFromBuyerForUser (String anID,
                                                              String lastBaseIdSentFromClient,
                                                              String userUniqueNameSentFromClient,
                                                              String urlReplacementStringForObject,
                                                              Map<String, String> responseHeaderMap)
        throws IntegrationServiceException,
        IOException,
        GeneralSecurityException
    {
        ClassicHttpRequest method;
        String responseData;
        String urlStr = null;
        try {
            httpComm = ApplicationContextProvider.getApplicationContext().getBean(
                HttpClientConfiguration.class);
            urlStr = getURL(anID, urlReplacementStringForObject);
     
            if (!isEmpty(lastBaseIdSentFromClient)) {
                urlStr = urlStr + "&" + lastBaseIdSentFromClientKey + "=" + encodeParams(lastBaseIdSentFromClient);
            }
    
            if (!isEmpty(userUniqueNameSentFromClient)) {
                urlStr = urlStr + "&" + userUniqueNameSentFromClientKey + "="
                    + userUniqueNameSentFromClient;
            }
    
            method = new HttpGet(urlStr);
            
            setOAuthHeader(method, anID);

            logger.info("Start : Connecting with uri string - {}, An ID - {},Method name : getDataFromBuyerForUser.",
                        urlStr,
                        anID);
    
            httpComm.printConnectionStats();
            
            AuditClientDataService auditClientDataService;
            auditClientDataService = ApplicationContextProvider.getApplicationContext().getBean(AuditClientDataService.class);

            String finalUrlStr = urlStr;
            HttpClientResponseHandler<String> responseHandler = response -> {
                int statusCode = response.getCode();
                String reasonPhrase = response.getReasonPhrase();
                String responseContent = ObjectUtils.isEmpty(response) ? null : EntityUtils.toString(response.getEntity(),
                                                                                   StandardCharsets.UTF_8);
                logger.debug("getDataFromBuyerForUser() method, AnId - {},Response Status Code - {}. Response received from Server : {}, Reason Phrase - {}",
                            anID,
                            statusCode,
                            responseContent,
                            reasonPhrase);
                if (statusCode >= 300) {
                    auditClientDataService.auditFetchApi(anID,
                                                         finalUrlStr, "Post Request to Application was not OK" + reasonPhrase);
                    logger.warn("Response Status Code - {}. Response received from Server : {}, AN Id- {}",
                                statusCode,
                                responseContent,
                                anID);
                    throw new HttpResponseException(statusCode,reasonPhrase);
                } else {
                    Header header = response.getFirstHeader(
                                    lastBaseIdFetchedFromQueryKey);

                    if (header != null) {
                        String lastBaseIdFromBuyer = header.getValue();
                        if (!isEmpty(lastBaseIdFromBuyer)) {
                            responseHeaderMap.put(lastBaseIdKey, lastBaseIdFromBuyer);
                        }
                        else {
                            responseHeaderMap.put(lastBaseIdKey, "");
                        }
                    }
                    return responseContent;
                }
            };
            responseData = httpComm.getHttpClient().execute(method,responseHandler);
            if (isBlank(responseData)) {
                auditClientDataService.auditFetchApi(anID, urlStr,  "Post Request to Application was not OK");
                throw new IntegrationServiceException(
                                "Post Request to Application was not OK");
            }
            auditClientDataService.auditFetchApi(anID, urlStr, null);
        }
        catch (HttpResponseException hre) {
            logger.error("[MDNI_CRITICAL][ARIBA] AnID- {} ,Error, while getting the Data from Buyer for User, Status code- {}, URL- {},Reason Phrase- {},Error message - {}",
                         anID,
                         hre.getStatusCode(),
                         urlStr,
                         hre.getReasonPhrase(),
                         hre.getMessage());
            throw new IntegrationServiceException(
                            "Error while getting the Data from Buyer for user ,ANId : " + anID
                                            + " and message :" + hre.getReasonPhrase());
        }
        catch (IOException e) {
            logger.warn("[MDNI_CRITICAL][ARIBA] Tenant ID - {} Exception -{} while parsing the data for getDataFromBuyerForUser. ",
                        anID,
                        ErrorUtil.getCompleteCausedByErrors(e));
            throw new IntegrationServiceException("Post Request to Application was not OK " + e);
        }
        return new org.json.JSONArray(responseData);
    }

    public static String getURL (String anID, String urlReplacementStringForObject) throws
        IntegrationServiceException
    {
        String urlStr = getConfigCallbackURL(anID);

        if (urlStr == null) {
            logger.error("[MDNI_CRITICAL][ARIBA][Configuration] Tenant - {} does not have CallBack URL configured in CONFIG_TAB Table",
                         anID);
            throw new IntegrationServiceException("Tenant  Not recognized");
        }
        logger.debug("urlStr: {}", urlStr);

        return urlStr.replace(KeyGetConfig, urlReplacementStringForObject);
    }

    public static Date parseDate (String dateString)
    {
        Date date = null;
        if (dateString != null) {
            for (String parse : dateFormats) {
                SimpleDateFormat sdf = new SimpleDateFormat(parse);
                try {
                    date = sdf.parse(dateString);
                    return date;
                } catch (java.text.ParseException e) {
                    logger.debug("Exception while parsing date {}", e.getMessage());
                }
            }
        }
        return date;
    }

    public static boolean isCurrentPayloadSourceCreationDateOlder (String objectName,
                                                                   long tenantId,
                                                                   String senderBusinessSystemId,
                                                                   Timestamp sourceCreationTimeStamp)
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        StageXMLDataRepository dao = (StageXMLDataRepository) factory.getGenericDAOStageData(
            ObjectTypes.XmlPayload.getValue());
        return dao.olderSourceCreationDateExists(objectName, tenantId,
                senderBusinessSystemId, sourceCreationTimeStamp);
    }

    public static boolean isObjectFMDType (String objectName)
    {
        boolean retVal;
        String object = EventNameToObjectMap.getObjectName(objectName);
        if (isEmpty(object)) {
            retVal = true;
        }
        else {
            retVal = false;
        }
        return retVal;
    }

    public static String getHashCode (Long tenantId,
                                      String senderBusinessSystemId,
                                      String objectName,
                                      String key) throws IntegrationServiceException
    {
        byte[] hashedBytes;
        StringBuilder concatenatedValue = new StringBuilder();
        try {
            concatenatedValue.append(tenantId).append(objectName).append(key);
            if (!isEmpty(senderBusinessSystemId)) {
                concatenatedValue.append(senderBusinessSystemId);
            }
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            hashedBytes = digest.digest(concatenatedValue.toString().getBytes("UTF-8"));

        } catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {
            logger.error("[MDNI_CRITICAL][ARIBA][Hash] Tenant ID - {}, Object name - {}, Exception {} while Hash Calculation ",
                         tenantId,
                         objectName,
                         ErrorUtil.getCompleteCausedByErrors(ex));
            throw new IntegrationServiceException(ex);
        }
        return convertByteArrayToHexString(hashedBytes);
    }

    private static String convertByteArrayToHexString (byte[] arrayBytes)
    {
        StringBuilder value = new StringBuilder();
        for (int i = 0; i < arrayBytes.length; i++) {
            value.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16).substring(1));
        }

        return value.toString();
    }

    public static String decodeParams (String param)
    {
        try {
            return URLDecoder.decode(param, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException uex) {
            logger.error("[MDNI_CRITICAL][ARIBA][Decoding] Exception {} while decoding : {} ",
                         ErrorUtil.getCompleteCausedByErrors(uex),
                         param);
            return param; // return param
        }
    }

    public static String encodeParams (String param)
    {
        try {
            return URLEncoder.encode(param, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException uex) {
            logger.error("[MDNI_CRITICAL][ARIBA][Encoding] Exception {} while encoding : {}  ",
                         ErrorUtil.getCompleteCausedByErrors(uex),
                         param);
            return param; // return param
        }
    }

    /**
     * Returns true if the specified <code>statusCode</code> indicates a
     * transient HTTP error <br/>
     * 502, 503 and 504 status codes are considered as transient errors
     */
    public static boolean isTransientHttpErrorCode (final int statusCode)
    {
        switch (statusCode) {
        case HttpStatus.SC_GATEWAY_TIMEOUT,HttpStatus.SC_BAD_GATEWAY,HttpStatus.SC_SERVICE_UNAVAILABLE:
            return true;
        default:
            return false;
        }
    }

    public static boolean isMDCS ()
    {
        Environment env = ApplicationContextProvider.getApplicationContext().getEnvironment();
        return Boolean.parseBoolean(env == null ?
                                                    FALSE_FLAG :
            env.getProperty(ENVIRONMENT_MDCS) == null ?
                            FALSE_FLAG :
                env.getProperty(ENVIRONMENT_MDCS));
    }

    public static boolean isMdcsCIGBasicAuthEnabled ()
    {
        Environment env = ApplicationContextProvider.getApplicationContext().getEnvironment();
        return Boolean.parseBoolean(env == null ?
                                                    FALSE_FLAG :
            env.getProperty(MDCS_BASIC_AUTH_ENABLED) == null ?
                            FALSE_FLAG :
                env.getProperty(MDCS_BASIC_AUTH_ENABLED));
    }


    public static boolean isAdvancedStorageOptionEnabled ()
    {
        Environment env = ApplicationContextProvider.getApplicationContext().getEnvironment();
        return Boolean.parseBoolean(env == null ?
                                                    FALSE_FLAG :
                env.getProperty(ADVANCED_STORAGE_OPTION) == null ?
                                FALSE_FLAG :
                        env.getProperty(ADVANCED_STORAGE_OPTION));
    }

    public static String getMdsHanaUsername ()
    {
        Environment env = ApplicationContextProvider.getApplicationContext().getEnvironment();
        return env.getProperty(MDCS_MDS_HANA_USERNAME);
    }

    public static String getMdsHanaPassword ()
    {
        Environment env = ApplicationContextProvider.getApplicationContext().getEnvironment();
        return env.getProperty(MDCS_MDS_HANA_PASSWORD);
    }

    public static String getTokenFromBearer(String bearerToken) {
        if (bearerToken != null && (bearerToken.startsWith(BEARER_CAP) || bearerToken.startsWith(BEARER_SMALL))) {
            bearerToken = bearerToken.substring(7, bearerToken.length());
        }
        return bearerToken;
    }

    public static String getTokenFromBasic (String baiscToken)
    {
        if (baiscToken != null && (baiscToken.startsWith(BASIC))) {
            baiscToken = baiscToken.substring(6, baiscToken.length());
        }
        return baiscToken;
    }

    public static String constructCloudStorageObjectName(String anId,String objectName, String senderBusinessSystemID
            , String UUID){
        StringBuilder stringBuilder = new StringBuilder();
        if (!isEmpty(senderBusinessSystemID)) {
            stringBuilder.append(anId).append(SLASH).append(CLOUD_STORAGE_PATH)
                    .append(SLASH).append(objectName).append(DASH).
                    append(senderBusinessSystemID).append(DASH).append(UUID).append(DASH).
                    append(getCurrentTime()).append(XMLUtil.XML_PATH_EXT);
            return stringBuilder.toString();
        } else {
            stringBuilder.append(anId).append(SLASH).append(CLOUD_STORAGE_PATH)
                    .append(SLASH).append(objectName).append(DASH)
                    .append(UUID).append(DASH).append(getCurrentTime()).append(XMLUtil.XML_PATH_EXT);
            return stringBuilder.toString();
        }
    }

    public static String constructCloudStorageObjectName(String anId, String objectName,
                                                         String senderBusinessSystemID) {
        StringBuilder stringBuilder = new StringBuilder();
        if (!isEmpty(senderBusinessSystemID)) {
            stringBuilder.append(anId).append(SLASH).append(CLOUD_STORAGE_PATH).
                    append(SLASH).append(objectName).append(DASH).
                    append(senderBusinessSystemID).append(DASH).
                    append(getCurrentTime()).append(XMLUtil.JSON_PATH_EXT);
            return stringBuilder.toString();
        } else {
            stringBuilder.append(anId).append(SLASH).append(CLOUD_STORAGE_PATH)
                    .append(SLASH).append(objectName).append(DASH)
                    .append(getCurrentTime()).append(XMLUtil.JSON_PATH_EXT);
            return stringBuilder.toString();
        }
    }
    public static String constructMDICloudStorageObjectName(String anId, String objectName,
                                                         String senderBusinessSystemID) {
        StringBuilder stringBuilder = new StringBuilder();
        if (!isEmpty(senderBusinessSystemID)) {
            stringBuilder.append(StorageServiceImpl.MDI_DIRECTORY).append(SLASH).append(anId).append(SLASH).append(CLOUD_STORAGE_PATH).
                    append(SLASH).append(objectName).append(DASH).
                    append(senderBusinessSystemID).append(DASH).
                    append(getCurrentTime()).append(XMLUtil.JSON_PATH_EXT);
            return stringBuilder.toString();
        } else {
            stringBuilder.append(StorageServiceImpl.MDI_DIRECTORY).append(SLASH).append(anId).append(SLASH).append(CLOUD_STORAGE_PATH)
                    .append(SLASH).append(objectName).append(DASH)
                    .append(getCurrentTime()).append(XMLUtil.JSON_PATH_EXT);
            return stringBuilder.toString();
        }
    }
    public static String getCurrentTime() {
        return String.valueOf(System.nanoTime()) + ThreadLocalRandom.current().nextInt(RANDOM_NUMBER_UPPER_BOUND);
    }
    private static String getTraceId ()
    {
        TracingHelper tracingHelper = ApplicationContextProvider.getApplicationContext().getBean(TracingHelper.class);
        String tracingId = tracingHelper.getTraceId();
        return tracingId;
    }

    /**
     * <p>
     * if user UUID contain forward slash '/' that is breaking the file creation so as per the Fix
     * we are replacing the forward slash '/' with tilde '~'
     * </p>
     * <blockquote><pre>
     *     String uuid = "abc/abc" -> abc~abc
     *     String uuid = "abc" -> abc
     *     String uuid = "/abc" -> ~abc
     *     </pre></blockquote>
     *
     * @param : UUID - the user uuid regular expression to which this string is to be matched (check User.rng file )
     * @return the resulting uuid string if it has forward slashed '/' else return same
//     * @see User.rng
     */
    public static String replaceForwardSlashFromUUIDForFileName (String UUID)
    {
        if (!isEmpty(UUID) && UUID.contains("/")) {
            return UUID.replaceAll("/",
                                   "~");
        }
        else {
            return UUID;
        }
    }

    /**
     * Method used to get anId from soap message
     * @param message
     * @return
     */
    public static String getANIdFromSoapMsg (SoapMessage message)
    {
        String anId = HandlerUtil.getANId(message);
        if (anId == null) {
            anId = (String) message.get(SOAPAction_ANID);
        }
        return anId;
    }

    /**
     * method used to get the url from the soap message
     * @param message
     * @return
     */
    public static String getRequestUrl (SoapMessage message) {
        String urlPath = null;
        HttpServletRequest request = (HttpServletRequest) message.get(KeyHttpRequest);
        if (request != null && request.getRequestURL() != null) {
            urlPath = request.getRequestURL().toString();
        }
        return  urlPath;
    }
}
