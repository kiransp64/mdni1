package com.sap.ariba.erpintegration.scheduler;

import java.io.IOException;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;
import com.sap.ariba.erpintegration.SchedulerConfig;
import com.sap.ariba.erpintegration.encryption.EncryptionHelperFactory;
import com.sap.ariba.erpintegration.encryption.SecurityInitializationException;

/**
 * Created by c5259108 on 12/10/17.
 */
@Component
@DisallowConcurrentExecution
@ConditionalOnExpression(    
    "${isInternal:false} == false and ${environment.mdcs} == false"
)
public class AppStartupRunnerJob implements Job {

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.scheduler.AppStartupRunnerJob";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);

    @Value("${appStartupRunnerJob.cronExpression}")
    private String cronExpression;

    @Bean(name = "appStartupRunnerJobBean")
    public JobDetailFactoryBean appStartupRunnerJob ()
    {
        logger.info("Creating appStartupRunnerJobBean");
        return SchedulerConfig.createJobDetail(this.getClass());
    }

    @Bean(name = "appStartupRunnerJobBeanTrigger")
    public CronTriggerFactoryBean appStartupRunnerJobBeanTrigger (@Qualifier("appStartupRunnerJobBean") JobDetail jobDetail)
    {
        if (logger.isDebugEnabled())
            logger.debug("Creating appStartupRunnerJobBeanTrigger");
        return SchedulerConfig.createCronTrigger(jobDetail, cronExpression);
    }

    @Override
    public void execute (JobExecutionContext jobExecutionContext)
        throws JobExecutionException
    {
        logger.info("AppStartupRunnerJob started");
        try {
            logger.info("Initializing security information");
            EncryptionHelperFactory.initializeEncryptionHelpers();
            logger.info("Security information initialization complete");
        }
        catch (SecurityInitializationException | IOException ex) {
            logger.error("Error occured while initializing security information: ", ex);
        }
        finally {
            logger.info("Removing AppStartupRunnerJob from the Scheduler List ");
            try {
                jobExecutionContext.getScheduler().deleteJob(
                    jobExecutionContext.getJobDetail().getKey());
            }
            catch (SchedulerException ex) {
                logger.error(
                    "Exception occured while removing AppStartupRunnerJob from the scheduler list:",
                    ex);
            }
        }
        logger.info("AppStartupRunnerJob ended");
    }
}
