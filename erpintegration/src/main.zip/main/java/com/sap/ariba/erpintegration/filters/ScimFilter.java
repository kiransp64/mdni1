package com.sap.ariba.erpintegration.filters;

import com.sap.ariba.erpintegration.mdi.common.resource.request.RequestUtil;
import com.sap.ariba.erpintegration.mdi.common.util.URLUtil;
import com.sap.ariba.erpintegration.mdi.meta.customer.AribaCustomerMeta;
import com.sap.ariba.erpintegration.mdi.meta.customer.CustomerIdentifierType;
import com.sap.ariba.erpintegration.mdi.meta.customer.Destination;
import com.sap.ariba.erpintegration.mdi.scim.entity.EntityUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import jakarta.servlet.Filter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

import static com.sap.ariba.erpintegration.filters.ScimUtils.ACCEPT_TYPE;
import static com.sap.ariba.erpintegration.filters.ScimUtils.isScimCall;
import static com.sap.ariba.erpintegration.mdi.scim.entity.EntityUtil.*;

/**
 * This Filter introduced from SCIM related logic.
 */
@Order(0)
@Component
public class ScimFilter implements Filter {

    @Autowired
    @Lazy
    private AribaCustomerMeta meta;
    private static final Logger logger =
            LoggerFactory.getLogger(ScimFilter.class);

    /**
     * Allowed special character part of user/group name
     */
    @Value("${server.tomcat.relaxed-path-chars}")
    private String[] relaxPathCharacters;

    /**
     * Sap Variable an-id enable flag check
     */
    @Value("${scim.sapVariantCheck}")
    private boolean sapVariantEnable;

    /**
     * feature enable check for scim user/group name contain special char
     */
    @Value("${scim.specialChar.check}")
    private boolean specialCharEnable;

    @Override
    public void init(FilterConfig filterConfig) {
    }

    private static final String GROUPS_PATH = "/Groups/";

    @Override
    public void doFilter(ServletRequest req,
                         ServletResponse res,
                         FilterChain chain) throws IOException, ServletException
    {
        logger.debug("{} , From SCIM Variant filter.",
                SCIM_FILTER);
        HttpServletRequest request = (HttpServletRequest) req;
        logger.info("Request URL, {}" , request.getRequestURL());
        try {
            if (isScimCall(request)) {
                if ((StringUtils.isEmpty(request.getContentType())
                                && StringUtils.isEmpty(request.getHeader(ACCEPT_TYPE)))) {
                    logger.error("ContentType and Accept header is missing.");
                    ScimUtils.writeScimErrorResponse("ContentType and Accept header is missing.",
                                                     400,
                                                     (HttpServletResponse)res);
                    return;
                }
                String anIdHeader = ((HttpServletRequest) req).getHeader(RequestUtil.TENANT_ID_PARAM);
                if (!StringUtils.isEmpty(anIdHeader)) {
                    if (sapVariantEnable && !request.getMethod().equals(HttpMethod.GET.name()) && verifyRealmForBuyer(anIdHeader) && isNotSAPVariant(anIdHeader)) {
                        logger.error("SAP Variant Check enabled. Only vsap variant is allowed while creating/updating User/Group. Received a different Realm variant");
                        ScimUtils.writeScimErrorResponse("Only sap variant is allowed for ANID: "+ anIdHeader + " when creating or updating User or group", 400, (HttpServletResponse) res);
                        return;
                    }
                    //This condition added to check if Scim Request url group id or user id path contains Special character.
                    if (specialCharEnable && !request.getMethod().equals(HttpMethod.POST.name())
                                    && isGroupOrUserContainsSpecialChar(request)) {
                        logger.debug("Scim User/Group path name contains special character.");
                        String requestURL = URLUtil.encodedUrlPath(request.getRequestURL().toString());
                        if (StringUtils.isNotEmpty(requestURL)) {
                            ScimModifyRequestWrapper modifyRequest = new ScimModifyRequestWrapper(request);
                            modifyRequest.setEncodeURL(new StringBuffer(requestURL));
                            logger.debug("Request URL after encoding : {}", request.getRequestURL());
                            request = modifyRequest;
                        }
                    }
                    else{
                        if(!request.getMethod().equals(HttpMethod.POST.name())){
                            //encoding Group ID
                            String requestURL = request.getRequestURL().toString();
                            int index = requestURL.indexOf(GROUPS_PATH);
                            if (index != -1) {
                                String prefix = requestURL.substring(0, index + GROUPS_PATH.length());
                                String suffix = requestURL.substring(index + GROUPS_PATH.length());
                                String encodedSuffix = URLUtil.encodeVal(suffix);

                                if (StringUtils.isNotEmpty(prefix) && StringUtils.isNotEmpty(encodedSuffix)) {
                                    String encodedIdUrl = prefix.concat(encodedSuffix);
                                    ScimModifyRequestWrapper modifyRequest = new ScimModifyRequestWrapper(request);
                                    modifyRequest.setEncodeURL(new StringBuffer(encodedIdUrl));
                                    request = modifyRequest;
                                    logger.debug("Request URL after encoding ID: {}", request.getRequestURL());
                                }
                            }
                        }
                    }
                } else{
                    logger.error("AN_ID is  empty or null.");
                    ScimUtils.writeScimErrorResponse("AN_ID is  empty or null.", 400, (HttpServletResponse) res);
                    return;
                }
            }
        } catch (Exception e) {
            logger.error("{} , RequestUri - {} , Exception while processing the request from SCIM Filter .",
                         SCIM_CRITICAL_FILTER,
                    request.getRequestURI(), e);
            ScimUtils.writeScimErrorResponse("Error while processing the request. Check Logs.",
                                             HttpStatus.INTERNAL_SERVER_ERROR.value(), (HttpServletResponse) res);
            return;
        }
        chain.doFilter(request, res);
    }

    public boolean isNotSAPVariant(String anIdHeader) {
        return !EntityUtil.SAP_VARIANT.equals(getVariant(anIdHeader));
    }

    protected String getVariant(String anId) {
        return meta.getVariantNameByAnID(anId);
    }

    @Override
    public void destroy() {
    }

    public void setMeta(AribaCustomerMeta meta){
        this.meta = meta;
    }

    public boolean verifyRealmForBuyer(String anIdHeader){
        return meta.getSubscribingApps(CustomerIdentifierType.AN_ID, anIdHeader).contains(Destination.BUYER);
    }

    /**
     * This will check if request url/path having special character
     *
     * @param request incoming Http request
     * @return true or false ,if it matches with provided special char
     */
    private boolean isGroupOrUserContainsSpecialChar (HttpServletRequest request)
    {
        if (!StringUtils.isEmpty(request.getPathInfo())) {
            return Arrays.stream(relaxPathCharacters).anyMatch(request.getPathInfo()::contains);
        }
        return false;
    }

    /**
     * Servlet Request Wrapper class for modifying scim related request. i.e. request path, url etc..
     */
    public class ScimModifyRequestWrapper extends HttpServletRequestWrapper
    {
        private StringBuffer encodeURL;

        public ScimModifyRequestWrapper (HttpServletRequest request)
        {
            super(request);
        }

        @Override
        public StringBuffer getRequestURL ()
        {
            return encodeURL;
        }

        public void setEncodeURL (StringBuffer encodeURL)
        {
            this.encodeURL = encodeURL;
        }
    }
}
