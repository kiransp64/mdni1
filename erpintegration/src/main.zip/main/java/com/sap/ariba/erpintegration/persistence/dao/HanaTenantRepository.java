package com.sap.ariba.erpintegration.persistence.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.sap.ariba.erpintegration.persistence.model.HanaTenant;

/**
 * Created by i318483 on 19/06/17.
 */
@Component("HanaTenantRepositoryComponent")
public interface HanaTenantRepository extends CrudRepository<HanaTenant, Long>
{
    @Query("select C from HanaTenant C where C.anId = :anId")
    HanaTenant findOne (@Param("anId") String anId);

    @Query("select C from HanaTenant C where C.anId like %:anId%")
    List<HanaTenant> findAll (@Param("anId") String anId);

    @Query("select C from HanaTenant C where C.parentAnId = :parentAnId")
    List<HanaTenant> findAllChildren (@Param("parentAnId") String parentAnId);

    @Query("select C from HanaTenant C")
    List<HanaTenant> findAll ();

    @Query("select C from HanaTenant C where (C.anId = :tenantIdentifier or C.realm = :tenantIdentifier) and status = :status")
    HanaTenant findOne (@Param("tenantIdentifier") String tenantIdentifier,
                    @Param("status") int status);
}
