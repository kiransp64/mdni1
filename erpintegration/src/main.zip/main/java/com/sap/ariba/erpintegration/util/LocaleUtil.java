package com.sap.ariba.erpintegration.util;

import org.apache.commons.lang3.LocaleUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

public class LocaleUtil
{
    private static final Logger logger = LoggerFactory.getLogger(LocaleUtil.class);

    public static final String LANGUAGE_CODE = "languageCode";
    /**
     * <pre>
     * S/4 HANA Systems send Locale/Language as per standards in
     * the format languageCode-CountryCode.
     *
     * Ariba systems expect the locale to be in a different format.
     * languageCode_CountryCode
     *
     * This method checks if the input locale string has a hyphen,
     * Locale object is constructed from the string.
     *
     * If <code>String</code> is empty or hyphen is not present, <code>String</code> is returned as is.
     * else toString() is called on Locale which Ariba systems use.
     * </pre>
     * @param inputLocale - Locale coming from S4 HANA systems.
     * @return Locale String expected by Ariba Systems
     */
    public static String getAribaLocale (String inputLocale)
    {
        if (!HandlerUtil.isMDCS() && !StringUtils.isEmpty(inputLocale)
            && inputLocale.indexOf("-") > -1)
        {
            Locale locale = Locale.forLanguageTag(inputLocale);
            if (locale != null) {
                return locale.toString();
            }
            else {
                logger.info(
                    "Unable to get Locale value for input tag - {}. Returning input as is.",
                    inputLocale);
            }

        }
        return inputLocale;
    }

    public static final String getAribaLocaleFromXMLAttribute (String attributeName,
                                                               String attributeValue)
    {
        return LANGUAGE_CODE.equals(attributeName) ?
            getAribaLocale(attributeValue) :
            attributeValue;
    }

    /**
     *
     * S/4 HANA Systems send Locale/Language as per standards in
     * the format languageCode-CountryCode.
     * This method returns the languageCode
     * @param inputLocale - Locale coming from S4 HANA systems.
     * @return - language for a locale
     */
    public static String getLanguageCode (String inputLocale)
    {
        String language = null;
        try {
            if (!StringUtils.isEmpty(inputLocale)) {
                if (inputLocale.indexOf("_") > -1) {
                    Locale locale = LocaleUtils.toLocale(inputLocale);
                    language = locale.getLanguage();
                }
                else {
                    Locale localeWithLangTag = Locale.forLanguageTag(inputLocale);
                    if (localeWithLangTag != null) {
                        language = localeWithLangTag.getLanguage();
                    }
                }
            }
        } catch (IllegalArgumentException ile) {
            logger.info(
                "Exception while getting Language value for input tag - {}. Returning input as is.",
                inputLocale);
        }
        if (language != null) {
            return language;
        }
        else {
            logger.info(
                "Unable to get Language value for input tag - {}. Returning input as is.",
                inputLocale);
            return inputLocale;
        }
    }
}
