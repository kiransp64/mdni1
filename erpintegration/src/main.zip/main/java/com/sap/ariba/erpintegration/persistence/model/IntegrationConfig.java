package com.sap.ariba.erpintegration.persistence.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="CONFIGTAB")
public class IntegrationConfig implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="ID")
    private String id;

    @Column(name="TENANT_ID")
    private long tenantId;

    @Column(name="DATE_CREATED")
    private Date dateCreated;

    @Column(name="DATE_UPDATED")
    private Date dateUpdated;

    @Column(name="IS_ACTIVE")
    private int isActive;

    @Column(name="KEY")
    private String key;

    @Column(name="VALUE")
    private String value;

    public void setId(String id) { this.id = id;}

    public String getId() {
        return id;
    }

    public long getTenantId() {
        return tenantId;
    }

    public void setTenantId(long tenantId) {
        this.tenantId = tenantId;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("IntegrationConfig{");
        sb.append("id='").append(id).append('\'');
        sb.append(", tenantId=").append(tenantId);
        sb.append(", dateCreated=").append(dateCreated);
        sb.append(", dateUpdated=").append(dateUpdated);
        sb.append(", isActive=").append(isActive);
        sb.append(", key='").append(key).append('\'');
        sb.append(", value='").append(value).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
