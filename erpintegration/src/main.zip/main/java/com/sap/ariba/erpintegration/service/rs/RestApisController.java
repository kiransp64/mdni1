package com.sap.ariba.erpintegration.service.rs;

import com.sap.ariba.erpintegration.audit.AuditManagerImpl;
import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.mdi.api.APIUtil;
import com.sap.ariba.erpintegration.util.XMLUtil;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.encryption.MDNIEncryptionService;
import com.sap.ariba.erpintegration.handlers.StagingTableStatus;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.ConfigRepository;
import com.sap.ariba.erpintegration.persistence.dao.SchemaRepository;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.persistence.dao.TenantRepository;
import com.sap.ariba.erpintegration.persistence.model.IntegrationConfig;
import com.sap.ariba.erpintegration.persistence.model.Schema;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.model.Tenant;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.processor.XMLSchemaValidator;
import com.sap.ariba.erpintegration.util.IntegrationJobLogUtil;
import erpintegrationsvc.src.main.java.com.sap.ariba.erpintegration.service.rs.model.ui.SchemaWrapper;
import erpintegrationsvc.src.main.java.com.sap.ariba.erpintegration.service.rs.model.ui.SubmittedJob;
import erpintegrationsvc.src.main.java.com.sap.ariba.erpintegration.service.rs.model.ui.TenantConfig;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jakarta.persistence.EntityManager;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.sql.Blob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

@RestController
@RequestMapping(value = "/inspectorapi")
public class RestApisController
{

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.service.rs.RestApisController";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    private static EntityManager em;
    private static final String defaultSchemasDirContentsPath = XMLSchemaValidator.RNGFilesDirectory +  "/*";
    private static final String defaultSchemasDir = XMLSchemaValidator.RNGFilesDirectory + "/" ;
    private static final String SCHEMA = "/schema/";
    private static final String WSDL = "/wsdl/";
    private static final String FORWARD_SLASH = "/";
    private static final String DOUBLE_HASH = "##";
    private static final String WSDL_EXTENSION = ".wsdl";
    private static final String XSD_EXTENSION = ".xsd";
    private static final String UNDERSCORE = "_";
    private static final String WSDLFilesDirectory = "WSDL";
    private static final String defaultWsdlDirContentsPath = WSDLFilesDirectory + "/*";
    private static final String defaultWsdlDir = WSDLFilesDirectory + "/";
    private static final Set<String> EncryptableObjects = new HashSet<>();
    private static final String ENCRYPTED_FILE_DIRECTORY = "/common/"; 

    @Autowired
    private JdbcTemplate template;
    
    @Autowired
    private OAuthTokenManager oAuthTokenManager;
    
    @Value("${kmsEnabled}")
    private boolean kmsEnabled;

    public void setAuditClientDataService(AuditClientDataService auditClientDataService) {
        this.auditClientDataService = auditClientDataService;
    }

    @Autowired
    private AuditClientDataService auditClientDataService;
    
    @Autowired(required = false)
    MDNIEncryptionService encryptionService;

    static {
        // Add 'User' object to encryptable objects list
        EncryptableObjects.add("User");
    }

    
    @RequestMapping(value = {"/submittedJobs/{tenantId}",
                             "/submittedJobWithJobId/{tenantId}/{jobId}"}, method = RequestMethod.GET, produces = "application/json")
    public List<SubmittedJob> getSubmittedJobs(@PathVariable("tenantId") Long tenantId,
                                           @PathVariable("jobId") Optional<String> jobId,
                                           @RequestParam("start") Optional<String> start, 
                                           @RequestParam("end") Optional<String> end,
                                           @RequestParam("status") Optional<Integer> status,
                                           @RequestParam("pageSize") Optional<Integer> pageSize,
                                           @RequestParam("pageIndex") Optional<Integer> pageIndex) throws Exception{
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        StageXMLDataRepository dao = (StageXMLDataRepository)factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
        List<SubmittedJob> objects = null;
        List<SubmittedJob> jobList = new ArrayList<SubmittedJob>();
        if(jobId.isPresent()) {           
           StageXMLData job = IntegrationJobLogUtil.getStageXmlDataForJobId(jobId.get(), tenantId.longValue());
           if(job == null || job.getTenantId() != tenantId.longValue()) {
               logger.error("No job found with the provided Job Id: "+ APIUtil.sanitizeInput(String.valueOf(jobId)) + "for the selected tenant");
               return jobList;
           }
           
           SubmittedJob jobWithJobID = new SubmittedJob(job, 1);
           jobList.add(jobWithJobID);
           return jobList;
        }
        
        Date st = new SimpleDateFormat("yyyy-MM-dd").parse(start.get());
        Date ed = new SimpleDateFormat("yyyy-MM-dd").parse(end.get());
        
        int index = pageIndex.isPresent()?pageIndex.get() : 0;
        int pagesize = pageSize.isPresent()? pageSize.get() : 10;
        PageRequest pageRequest =  PageRequest.of(index, pagesize);
        if(status.isPresent()) {
            Page<StageXMLData> data =  dao.findRecordsInRangeForStatus(tenantId, st, ed, status.get(), pageRequest);
            objects = SubmittedJob.convertToSubmittedJob(data.getContent(),data.getTotalElements());
        }else {
            Page<StageXMLData> data = dao.findRecordsInRange(tenantId, st, ed, pageRequest);
            objects = SubmittedJob.convertToSubmittedJob(data.getContent(), data.getTotalElements());
        }
        return objects;
    }
    
    
    
    @RequestMapping(value = "/schemaConfigs/{tenantId}", method = RequestMethod.GET, produces = "application/json")
    public List<SchemaWrapper> getSchemaConfigrations(@PathVariable("tenantId") Long tenantId)
        throws IOException{
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        SchemaRepository schemaRepo = (SchemaRepository)factory.getMiscDAO(ObjectTypes.Schema.getValue());
        List<Schema> schemas = schemaRepo.find(tenantId);
        
        List<SchemaWrapper> schemaConfigs = new ArrayList<SchemaWrapper>();

        String wsdlFilePath = null;
        File wsdlFileFolder = null;
        String[] wsdlFileList = null;

        //Loop through schema from the db and wsdl files from nfs and construct schema config for inspector
        if(schemas != null) {
            for(Schema schema: schemas) {
                //Getting list of Wsdl files
                wsdlFilePath = schema.getPath();
                if(wsdlFilePath == null) {
                    continue;
                }
                wsdlFilePath = wsdlFilePath.replace(SCHEMA, WSDL);
                if(!wsdlFilePath.contains(WSDL)) {
                    continue;
                }
                wsdlFilePath = wsdlFilePath.substring(0, wsdlFilePath.lastIndexOf(FORWARD_SLASH) + 1);
                wsdlFileFolder = new File(wsdlFilePath);
                if(!wsdlFileFolder.exists()){
                    continue;
                }
                wsdlFileList = wsdlFileFolder.list();

                //Loop through the wsdl files for constructing schema list.
                if(wsdlFileList != null) {
                    for (String fileName : wsdlFileList) {
                        if(fileName == null) {
                            continue;
                        }
                        if (fileName.contains(schema.getObjectName())) {
                            SchemaWrapper wrap = null;
                            //check whether wsdl file has business sender id appended.
                            boolean businessIdPresent = false;
                            String senderBusinessId = null;
                            int businessIdPositionStart = fileName.indexOf(UNDERSCORE);
                            if (businessIdPositionStart != -1) {
                                businessIdPresent = true;
                            }
                            int businessIdPositionEnd = 0;
                            if (businessIdPresent) {
                                businessIdPositionEnd = fileName.indexOf(DOUBLE_HASH);
                                if (businessIdPositionEnd == -1) {
                                    businessIdPositionEnd = fileName.indexOf(WSDL_EXTENSION);
                                }
                            }
                            if (businessIdPresent) {
                                senderBusinessId = fileName.substring(businessIdPositionStart + 1, businessIdPositionEnd);
                            }

                            if (businessIdPresent && schema.getSenderBusinessSystemId() != null && senderBusinessId.equals(schema.getSenderBusinessSystemId())) {
                                wrap = constructSchemaConfig(schema, fileName);
                            } else if (!businessIdPresent && schema.getSenderBusinessSystemId() == null) {
                                wrap = constructSchemaConfig(schema, fileName);
                            }
                            if (wrap != null) {
                                schemaConfigs.add(wrap);
                            }
                        }
                    }
                }
            }
        }

        //default schemas configs        
        PathMatchingResourcePatternResolver scanner = new PathMatchingResourcePatternResolver();
        Resource[] resources = scanner.getResources(defaultWsdlDirContentsPath);

        for(Resource wsdlFile: resources) {
            SchemaWrapper wsdl = new SchemaWrapper();
            String wsdlFileName = wsdlFile.getFilename();
            wsdl.setFileName(wsdlFileName);
            int wsdlFilePosition = wsdlFileName.indexOf(WSDL_EXTENSION);;
            if(wsdlFilePosition == -1) {
                wsdlFilePosition = wsdlFileName.indexOf(".WSDL");
            }
            if(wsdlFilePosition == -1) {
                continue;
            }
            wsdl.setObjectName(wsdlFileName.substring(0, wsdlFilePosition));
            wsdl.setSchemaPath(defaultWsdlDir+wsdlFileName);
            wsdl.setSchemaConfigType("Default");
            schemaConfigs.add(wsdl);
        }
        return schemaConfigs;   
    }

    //Is used to construct schemaConfiguration used for inspector
    private SchemaWrapper constructSchemaConfig(Schema schema, String fileName) {
        SchemaWrapper wrap = new SchemaWrapper();
        wrap.setSchemaConfigType("Uploaded");
        wrap.setObjectName(schema.getObjectName());
        wrap.setSchemaPath(schema.getPath());
        wrap.setSenderBusinessSystemId(schema.getSenderBusinessSystemId());
        wrap.setTenantId(schema.getTenantId());
        wrap.setFileName(fileName);
        if (fileName.contains(DOUBLE_HASH)) {
            String[] fileSplit = fileName.split(DOUBLE_HASH);
            String timeStamp = fileSplit[fileSplit.length - 1];
            timeStamp = timeStamp.substring(0, timeStamp.indexOf(WSDL_EXTENSION));
            wrap.setTimeStamp(timeStamp);
        }
        return wrap;
    }


    
    @RequestMapping(value = { "/downloadPayload/{jobId}" }, 
        method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<Resource> downloadPayload (@PathVariable("jobId") String jobId,
                                                     HttpServletRequest request)
        throws Exception
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        StageXMLDataRepository dao = (StageXMLDataRepository)factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue()); 
        StageXMLData job = dao.findOne(jobId);
        if(job == null) {
            throw new Exception("Couldnt find job details for the ID: "+jobId);
        }        
        String payloadsavedPath = job.getDataPath();
        //audit log for download payload PL-27930
        String anid = Utility.getANId(job.getTenantId());
        String auditMesg = "Download payload action clicked on inspector for jobid: "
        + job.getId() + " , tenant: " + anid +
        " for object " + job.getObjectName();    
        logger.info(auditMesg);
        AuditManagerImpl.getInstance().logAudit(
            Utility.getANId(job.getTenantId()),
            Operation.DOWNLOAD_PAYLOAD_INSPECTOR_ACTION,
            auditMesg);
        return downloadUploadedFile(
            request,
            payloadsavedPath,
            job.getTenantId());
    }
    
    
    @RequestMapping(value = {"/downloadSchema/{schemaType}/{tenantId}/{objectName}",
                             },
        method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<Resource> downloadUploadedSchema(@PathVariable("tenantId") Long tenantId,
                                                   @PathVariable("schemaType") String schemaType,
                                                   @PathVariable("objectName") String objectName,
                                                   @RequestParam(name = "senderBusinessSystemId", required=false) String senderBusinessSystemId,
                                                   @RequestParam(name = "wsdlTimeStamp", required = false) String wsdlTimeStamp,
                                                   HttpServletRequest request)
                                                       throws Exception {
        
        if(schemaType.equals("Default")) {
            //default schema download for given object
            String defaultSchemaFilePath = defaultWsdlDir + objectName + WSDL_EXTENSION;
            return downloadDefaultSchemaFile(request, defaultSchemaFilePath, tenantId);
        }
        
        String uploadPath = "";
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        SchemaRepository schemaRepo = (SchemaRepository)factory.getMiscDAO(ObjectTypes.Schema.getValue());
        Schema schema = null;
        if(senderBusinessSystemId!=null) {
            schema = schemaRepo.findOne(tenantId, objectName, senderBusinessSystemId);
        }else {
            schema = schemaRepo.findOne(tenantId, objectName);
        }
        if(schema == null) {
            logger.error("No schema uploaded for the given tenant,Object and senderBusinessSystemId");
            return ResponseEntity.notFound().build();  
        }
        uploadPath = schema.getPath();
        uploadPath = uploadPath.replace("/schema/", "/wsdl/");
        uploadPath = uploadPath.replaceAll(".xsd", ".wsdl");
        StringBuilder sb = new StringBuilder(uploadPath);
        if(wsdlTimeStamp != null) {
            int position = uploadPath.indexOf(".wsdl");
            sb.insert(position, "##" + wsdlTimeStamp);
        }
        return downloadUploadedFile(request, sb.toString(), tenantId);
    }
    
    public ResponseEntity<Resource> downloadDefaultSchemaFile (HttpServletRequest request,
                                                  String uploadPath, Long tenantId)
       throws MalformedURLException,
       IOException
   {
       PathMatchingResourcePatternResolver scanner = new PathMatchingResourcePatternResolver();
       Resource resource = scanner.getResource(uploadPath);
       if(!resource.exists()) 
       {
           String errorMessage =  "Error downloading default schema file : "+uploadPath;
          logger.error(APIUtil.sanitizeInput(errorMessage));
          auditClientDataService.auditFileDownLoad(tenantId, uploadPath, resource.getFilename(), errorMessage);
          return ResponseEntity.notFound().build();
       }
       auditClientDataService.auditFileDownLoad(tenantId, uploadPath, resource.getFilename(), null);
       String mediaType  = request.getServletContext().getMimeType(uploadPath);
       mediaType = (mediaType == null)? "application/octet-stream" : mediaType;
       return ResponseEntity.ok()
           .contentType(MediaType.parseMediaType(mediaType))
           .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + resource.getFilename())
           .body(resource);
   }
    
   public ResponseEntity<Resource> downloadUploadedFile (HttpServletRequest request,
                                                         String uploadPath,
                                                         Long tenantId)
       throws Exception
   {
       if (isFileKMSEncrypted(uploadPath) && kmsEnabled) {
           return decryptUnzipAndDownload(request, uploadPath, tenantId);
       }
       else {
           return downloadFile(
               request,
               uploadPath,
               tenantId);
       }
   }

   public ResponseEntity<Resource> downloadFile (HttpServletRequest request, String uploadPath, Long tenantId)
            throws Exception {
       String errorMsg;
       Resource resource = getResource(uploadPath);
       if(!resource.exists())
       {
           errorMsg = "Error downloading file as it is not found at the provided path: "+resource.getFile().getName();
           logger.error(errorMsg);
           auditClientDataService.auditFileDownLoad(tenantId, uploadPath, resource.getFilename(), errorMsg);
           return ResponseEntity.notFound().build();
          
       }
       String mediaType  = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
       mediaType = (mediaType == null)? "application/octet-stream" : mediaType;
       //If we find a zipfile to download, we need to unzip the file on the fly and download it.
       if(mediaType.equals("application/zip")) {
           InputStreamResource is = unzipAndDownload(resource, uploadPath);
           if(is == null) {
               errorMsg = "Error while unzipping the file and downloading";
               auditClientDataService.auditFileDownLoad(tenantId, uploadPath, resource.getFilename(), errorMsg);
               throw new Exception(errorMsg);
           }
           auditClientDataService.auditFileDownLoad(tenantId, uploadPath, resource.getFilename(), null);
           return ResponseEntity.ok()
                   .contentType(MediaType.parseMediaType(mediaType))
                   .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + resource.getFilename().replace(XMLUtil.ZIP_PATH_EXT, XMLUtil.XML_PATH_EXT))
                   .body(is);
       }
       auditClientDataService.auditFileDownLoad(tenantId, uploadPath, resource.getFilename(), null);
       return ResponseEntity.ok()
           .contentType(MediaType.parseMediaType(mediaType))
           .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + resource.getFilename())
           .body(resource);
   }
   
   private InputStreamResource unzipAndDownload(Resource resource, String uploadPath) {
       ZipFile zf = null;
       try {
           //Since the upload path is saved as .xml in the DB, but the file available is zip. so converting the filepath to zip
           zf = new ZipFile(uploadPath.replace(XMLUtil.XML_PATH_EXT, XMLUtil.ZIP_PATH_EXT));
       } catch (IOException e) {
           logger.error("Error in converting the file path from xml to zip", e);
           return null;
       }
       Enumeration e = zf.entries();
       ZipEntry entry = (ZipEntry) e.nextElement();
       try {
           return new InputStreamResource(zf.getInputStream(entry));
       } catch (IOException e1) {
           logger.error("Error in the input stream for reading the contents of the file ",e1);
       }
       return null;
   }
   //If we download xml data, first it checks for the zip file, if the zip file exists then it is going to give the zip resource
    //else it will give the filePath resource.
   private Resource getResource(String filePath) throws MalformedURLException {
       Path location = Paths.get(filePath).toAbsolutePath().normalize();
       Resource resource = new UrlResource(location.toUri());
       //Checks whether if it is from wsdl folder
       if(filePath.contains("wsdl") && resource.exists()) {
           return resource;
       } else {
           //Convert the file type and Check zip file of xml data available
           Path zipLocation = Paths.get(filePath.replace(XMLUtil.XML_PATH_EXT, XMLUtil.ZIP_PATH_EXT)).toAbsolutePath().normalize();
           Resource zipResource = new UrlResource(zipLocation.toUri());
           if(zipResource.exists()) {
               return zipResource;
           } else {
               return resource;
           }
       }
    }
    
    /**
     * api to get the tenant configuration details
     * @return tenant configuration
     */
    @RequestMapping(value = "/tenantConfiguration/{anId}", method = RequestMethod.GET, produces = "application/json")
    public List<TenantConfig> getTenantConfiguration (@PathVariable("anId") String anId,
                                    HttpServletRequest request)
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository tenantRepo = (TenantRepository)factory.getMiscDAO(
            ObjectTypes.Tenant.getValue());
        ConfigRepository configRepo = (ConfigRepository)factory.getMiscDAO(
            ObjectTypes.IntegrationConfig.getValue());
        Tenant tenant = tenantRepo.findOne(anId);
        long tenantId = tenant.getTenantId();
        IntegrationConfig config = configRepo.findOne(tenantId, "CallbackURL");
        TenantConfig tenantConfig = new TenantConfig();
        tenantConfig.setAnId(anId);
        tenantConfig.setCallBackUrl(config.getValue());
        tenantConfig.setDateCreated(tenant.getDateCreated());
        tenantConfig.setDateUpdated(tenant.getDateUpdated());
        tenantConfig.setRealmName(tenant.getRealmName());
        tenantConfig.setParentAnid(tenant.getParentAnId());
        tenantConfig.setWeight(tenant.getWeight());
        List<TenantConfig> configs = new ArrayList<TenantConfig>();
        configs.add(tenantConfig);
        return configs;      
    }
    
    

    /**
     * api to get the tenants from tenant repository
     * 
     * @return list of tenants
     */
    @RequestMapping(value = "/jobStatuses", method = RequestMethod.GET, produces = "application/json")
    public List<String> getJobStatuses (@RequestHeader HttpHeaders headers)
    {
        StagingTableStatus[] statuses = StagingTableStatus.values();
        List<String> statusList = new ArrayList<String>();
        for(StagingTableStatus stat: statuses) {
            statusList.add(stat.getDescription());
        }
        return statusList;
    } 
    
    /**
     * api to get the statuses from staging table
     * 
     * @return list of tenants
     */
    @RequestMapping(value = "/tenants", method = RequestMethod.GET, produces = "application/json")
    public List<Tenant> getTenants (@RequestHeader HttpHeaders headers)
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository)factory.getMiscDAO(
            ObjectTypes.Tenant.getValue());
        return (List<Tenant>)dao.findAll();
    }

    /**
     * api to execute custom sql queries
     * 
     * @param query query custom sql query
     * @param size number of rows to return
     * @return
     */
    @RequestMapping(value = "/executeCustomQuery/{query}/{size}", method = RequestMethod.GET, produces = "application/json")
    public Response executeCustomQuery (@PathVariable("query") String query,
                                                                   @PathVariable("size") int size) throws Exception
    {
        if(!query.matches("^\\s*\\b(?i)select\\b.*")){
              throw new Exception("Only select queries allowed");
        }
        
        if (size >= 0) {
            template.setMaxRows(size);
        }
        else {
            template.setMaxRows(1000);
        }
        List<Map<String, Object>> results;
        try {
            results = template.queryForList(query);

            List<LinkedHashMap<String, Object>> rows = 
                (List<LinkedHashMap<String, Object>>)results.stream().map(
                val -> new LinkedHashMap<String, Object>(val)).collect(
                    Collectors.toList());

            JSONArray res = new JSONArray();
            Iterator iter = rows.iterator();
            while (iter.hasNext()) {
                Map item = (Map)iter.next();
                Iterator it = item.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry)it.next();
                    Object value = pair.getValue();
                    JSONObject row = new JSONObject();
                    row.put((String)pair.getKey(), pair.getValue());
                    res.add(row);

                    if (value != null
                        && (value instanceof byte[] || value instanceof Blob))
                    {
                        byte[] blob = (byte[])pair.getValue();
                        if (blob != null) {
                            String objectData;
                            objectData = new String(blob);
                            pair.setValue(objectData);
                        }
                    }
                }
            }
            return Response.status(HttpServletResponse.SC_OK).entity(
                rows.toArray()).build();
        }
        catch (Exception e) {
            logger.error("[MDNI INSPECTOR QUERY] Data Query execution failed due to error. " , e);
            throw new Exception(
                "Query execution failed due to "
                    + com.sap.ariba.erpintegration.util.ErrorUtil.getCompleteCausedByErrors(e));
        }  
    }

    /**
     * api to get the refresh  token details
     * @return tenant configuration
     */
    @RequestMapping(value = "/refreshToken", method = RequestMethod.GET, produces = "application/json")
    public String getRefreshToken (HttpServletRequest request)
    {       
        Map<String, String> tokenMap = oAuthTokenManager.getTokens("system", null);
        JSONObject jsonToken = new JSONObject();
        
        tokenMap.entrySet().forEach((entry) -> {
            jsonToken.put(entry.getKey(), entry.getValue());
        });        
        String encodedToken = Base64.getEncoder().encodeToString(jsonToken.toString().getBytes());
        return encodedToken;
    }
    
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = Exception.class)
    public String handleException (Exception e)
    {
        return e.getMessage();
    }
    
    private Boolean isFileKMSEncrypted( String uploadPath ) {
        if(uploadPath.contains(ENCRYPTED_FILE_DIRECTORY)) {
            return true;
        }
        return false;
    }
    
    private ResponseEntity<Resource> decryptUnzipAndDownload (HttpServletRequest request,
                                                              String uploadPath,
                                                              Long tenantId) throws IOException
    {
        String errorMsg;
        Resource resource = getResource(uploadPath);
        if (!resource.exists()) {
            errorMsg = "Error downloading file as it is not found at the provided path: "
                + resource.getFile().getName();
            logger.error(errorMsg);
            auditClientDataService.auditFileDownLoad(
                tenantId,
                uploadPath,
                resource.getFilename(),
                errorMsg);
            return ResponseEntity.notFound().build();

        }
        String mediaType = request.getServletContext().getMimeType(
            resource.getFile().getAbsolutePath());
        // First Decrypt, then unzip and then download
        PipedInputStream pipedDecrInput = new PipedInputStream();
        PipedOutputStream pipedDecrOutput = new PipedOutputStream(pipedDecrInput);
        new Thread(new Runnable() {
            public void run() {
                try (InputStream encryptedInputStream = new FileInputStream(new File(uploadPath));
                    InputStream decrInputStream = encryptionService.getEncryptionService().getDecryptingInputStream(
                        encryptedInputStream);)
                {
                    logger.info("Begin KMS decryption");
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = decrInputStream.read(buffer)) != -1) {
                        pipedDecrOutput.write(buffer, 0, len);
                    }
                    pipedDecrOutput.close();
                    logger.info("finished KMS decryption");

                }
                catch (GeneralSecurityException | IOException e) {
                    logger.error(
                        "Exception while decrypting {} {} : ",
                        uploadPath,
                        e.getMessage());
                }
            }          
        }).start();
        // unzipping the decrypted input stream
        ZipInputStream unzippedStream = new ZipInputStream(pipedDecrInput);
        try {
            unzippedStream.getNextEntry();
        }
        catch (IOException e) {
            logger.info("IOException {}", e.getMessage());
        }
        InputStream is = unzippedStream;
        InputStreamResource res = new InputStreamResource(is);
        return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(mediaType))
            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + resource.getFilename().replace(XMLUtil.ZIP_PATH_EXT, XMLUtil.XML_PATH_EXT))
            .body(res);
    }
    
    private Boolean isEncryptableObject(String objectName) {
        if (EncryptableObjects.contains(objectName)) {
            return true;
        }
        return false;
    }
        
}
