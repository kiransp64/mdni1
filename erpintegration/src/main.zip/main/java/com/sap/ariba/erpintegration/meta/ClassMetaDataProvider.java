package com.sap.ariba.erpintegration.meta;

import com.sap.ariba.erpintegration.util.XMLUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by i318483 on 07/06/17.
 */
public class ClassMetaDataProvider
{

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.AutheticateRequestHandler";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);

    static {populateClassMeta();}

    static Extention extention;

    /**
     * classmeta.xml defines the following -
     * 1. Business lookup key for each module(i.e object)
     * 2. Any referenced Object for each module.
     * Reads the classmeta file and pre load all the objects lookup key and relationships(i.e references)
     */
    private static void populateClassMeta ()
    {
        if (logger.isDebugEnabled())
            logger.debug("populateClassMeta Started");

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        ClassPathResource classPathResource = new ClassPathResource("classmeta.xsd");
        try (InputStream inputStream = classPathResource.getInputStream()) {
            if (inputStream == null) {
                throw new FileNotFoundException("File classmeta.xsd not found under resources");
            }
            File f = XMLUtil.convertStreamToFile(inputStream,
                                                 "classmeta",
                                                 "xsd");
            Schema schema = sf.newSchema(f);
            classPathResource = new ClassPathResource("classmeta.xml");
            try (InputStream is = classPathResource.getInputStream()) {
                if (is == null) {
                    throw new FileNotFoundException("File classmeta.xml not found under resources");
                }
                f = XMLUtil.convertStreamToFile(is,
                                                "classmeta",
                                                "xml");
                JAXBContext jsxbContext = JAXBContext.newInstance(Extention.class);
                Unmarshaller unmarshaller = jsxbContext.createUnmarshaller();
                unmarshaller.setSchema(schema);
                extention = (Extention)unmarshaller.unmarshal(f);
            }
            catch (JAXBException | IOException ex) {
                logger.error("Exception while loading class meta , exception details - {} ",
                             ex.getMessage(),
                             ex);
            }
            if (logger.isDebugEnabled()) {
                logger.debug("populateClassMeta Ended");
            }
        } catch (IOException | SAXException ex) {
            logger.error("Exception while loading class meta , exception details - {} ",ex.getMessage(), ex);
        }
        
    }

    /**
     * returns all the modules defined in classmeta.xml file
     * @return
     */
    public static List<Module> getModules ()
    {
        return extention.getModule();
    }

    /**
     * For the passed moduleName return the definition
     * @param moduleName
     * @return
     */
    public static Module getModule (String moduleName)
    {
        List<Module> modules = getModules();
        for (Module module: modules) {
            String objectName = module.getName().substring(module.getName().lastIndexOf('.') + 1).trim();

            if (objectName.equals(moduleName))
                return module;
        }

        return null;
    }

    /**
     * Return the lookup key for those modules which involve composite key (like <lookupKey externalLookupKey..)
     * @param moduleName
     * @return
     */
    public static String getExternalLookupKeyForObject (String moduleName)
    {
        Module module = getModule(moduleName);
        if (module != null) {
            if (module.getLookupKey().getExternalLookupKey() != null) {
                return module.getLookupKey().getExternalLookupKey();
            }
            else {
                return module.getLookupKey().getLookupKey();
            }
        }

        return null;
    }

    /**
     * Return the lookupKey tag for the passed moduleName
     * @param moduleName
     * @return
     */
    public static String getLookupKeysForObject (String moduleName)
    {
        Module module = getModule(moduleName);
        if (module != null)  {
            return module.getLookupKey().getLookupKey();
        }

        return null;
    }

    /**
     * Returns the relation object for the moduleName passed.
     * @param moduleName
     * @return
     */
    public static List<Relation> getRelationsForObject (String moduleName)
    {
        Module module = getModule(moduleName);
        if (module != null) {
            Relationship relationship = module.getRelationship();
            if (relationship != null) {
                List<Relation> relations = relationship.getRelation();
                return relations;
            }
        }

        return null;
    }

}
