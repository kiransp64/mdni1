package com.sap.ariba.erpintegration.validation;

import java.util.Arrays;
import java.util.Optional;

/**
 * This enum contains a list of entities for which RNG based
 * payload validation will be skipped. This is usually done when
 * the WSDL present in the system is significantly different from the WSDL
 * configured in the source system (like S/4 HANA)
 */
public enum ValidationSkipEntities
{
    Product("Product", "ItemMaster");

    private String entityName;
    private String mdsEntityName;

    ValidationSkipEntities (String entityName, String mdsEntityName)
    {
        this.entityName = entityName;
        this.mdsEntityName = mdsEntityName;
    }

    public static boolean contains (String otherEntityName)
    {
        return Arrays.stream(ValidationSkipEntities.values()).anyMatch(entity -> entity.entityName.equals(
            otherEntityName));
    }

    public static String getMDSEntityName (String entityName)
    {
        Optional<ValidationSkipEntities> entity = Arrays.stream(ValidationSkipEntities.values()).filter(
            e -> e.entityName.equals(entityName)).findAny();
        if (entity.isPresent()) {
            return entity.get().mdsEntityName;
        }
        return "";
    }
}
