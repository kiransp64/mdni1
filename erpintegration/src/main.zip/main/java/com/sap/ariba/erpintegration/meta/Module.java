package com.sap.ariba.erpintegration.meta;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * Created by i318483 on 07/06/17.
 */
public class Module
{
    private String name;
    private LookupKey lookupKey;
    private Relationship relationship;

    @XmlAttribute
    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    @XmlElement
    public LookupKey getLookupKey ()
    {
        return lookupKey;
    }

    public void setLookupKey (LookupKey lookupKey)
    {
        this.lookupKey = lookupKey;
    }

    @XmlElement
    public Relationship getRelationship ()
    {
        return relationship;
    }

    public void setRelationship (Relationship relationship)
    {
        this.relationship = relationship;
    }
}
