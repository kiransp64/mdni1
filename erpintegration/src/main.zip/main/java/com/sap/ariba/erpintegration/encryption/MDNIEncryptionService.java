package com.sap.ariba.erpintegration.encryption;

import com.sap.ariba.security.encryption.EncryptionException;
import com.sap.ariba.security.encryption.EncryptionService;
import com.sap.ariba.security.encryption.EncryptionServiceFactory;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.Properties;

@Service
@ConditionalOnProperty(name = "kmsEnabled", havingValue="true")
public class MDNIEncryptionService
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.encryption.MDNIEncryptionService";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);
    private static final String APP_UUID ="APP_UUID_NO_HASH";

    @Autowired
    private KMSConfiguration kmsConfiguration;

    @Autowired
    private Environment env;

    @Value(value = "${encryption.servicename}")
    private String serviceName;

    private EncryptionService encryptionService;

    @PostConstruct
    public void initEncryptionService ()
    {
        try {
            Properties kmsProperties = kmsConfiguration.getEncryptionVaultConfigAsProperties();
            try {
                encryptionService = EncryptionServiceFactory.INSTANCE.newService(
                    kmsProperties);
            }
            catch (EncryptionException e) {
                logger.warn("EncryptionException while getting Encryption Service !!");
                encryptionService = EncryptionServiceFactory.INSTANCE.getService(
                    env.getProperty(APP_UUID) + "_" + serviceName);
            }
            logger.info(
                "initEncryptionService() encryptionService: {}",
                encryptionService);
        }
        catch (Exception e) {
            throw new IllegalStateException(
                "Unable to initialize encryption service.",
                e);
        }
        logger.info("Finished Initializing Encryption Service");
    }

    public EncryptionService getEncryptionService ()
    {
        return encryptionService;
    }

    public KMSConfiguration getKmsConfiguration() {
        return kmsConfiguration;
    }
}