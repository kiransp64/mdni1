/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.passport;

import com.sap.ariba.erpintegration.monitor.exception.PassportDAOException;
import com.sap.ariba.erpintegration.monitor.exception.PassportException;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.util.IMConstants;
import com.sap.ariba.erpintegration.monitor.passport.context.ContextHandlerImpl;
import com.sap.ariba.erpintegration.monitor.passport.context.ContextHolder;
import com.sap.ariba.erpintegration.monitor.passport.context.EventContext;
import com.sap.ariba.erpintegration.monitor.passport.core.persistance.Passport;
import com.sap.ariba.erpintegration.monitor.passport.dao.PassportDAO;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.integrationmonitoring.bean.PassportBean;
import com.sap.ariba.integrationmonitoring.logger.PassportManager;
import com.sap.ariba.integrationmonitoring.util.PassportBeanBuilder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.UUID;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.IM_CRITICAL_PASSPORT;

/**
 * This class will handle Passport related activity.
 */
@Slf4j
@Component(value = "passportHandler")
@ConditionalOnExpression(IMConstants.INTEGRATION_MONITORING_ENABLE)
public class PassportHandlerImpl implements PassportHandler
{

    @Autowired
    protected PassportDAO passportDAO;

    @Lazy
    @Autowired
    private ContextHandlerImpl contextHandler;

    /**
     * Based on sap-passport token it will decode the token and form PassportBean java object.
     *
     * @param sapPassportToken
     * @return PassportBean having all the passport related information .
     * @throws PassportException
     * @see com.sap.ariba.integrationmonitoring.logger.PassportManager
     * @see com.sap.ariba.integrationmonitoring.bean.PassportBean
     */
    @Override
    public PassportBean getPassportFromToken (String sapPassportToken) throws PassportException
    {
        try {
            if (StringUtils.isNotEmpty(sapPassportToken) && !sapPassportToken.trim().isEmpty()) {
                return PassportManager.getPassport(sapPassportToken.trim());
            }
        }
        catch (Exception exp) {
            log.error("{} , Exception - {} while forming PassportBean from sap passport token ",
                      IM_CRITICAL_PASSPORT,
                      ErrorUtil.getCompleteCausedByErrors(exp));
            throw new PassportException("Exception while forming PassportBean from sap passport token ",
                                        exp);
        }
        return null;
    }

    /**
     * This method will convert passport bean to passport token
     *
     * @param passportBean
     * @return
     * @throws PassportException
     */
    @Override
    public String getPassportTokenFromPassportBean (PassportBean passportBean)
                    throws PassportException
    {
        if (ObjectUtils.isEmpty(passportBean)) {
            return "";
        }
        return PassportManager.getInitialSAPPassport(passportBean);
    }

    /**
     * This method will take care to construct sap passport token for inbound to outbound connection by changing the previous system id ,connection counter id etc.
     * As part of inBound connection , System have to change prev System ID ,Connection counter before sending to another system
     *
     * @param sapPassportToken
     * @return updated outbound sap-passport token.
     * @see com.sap.ariba.integrationmonitoring.logger.PassportManager
     */
    @Override
    public String getOutBoundSAPPassportToken (String sapPassportToken) throws PassportException
    {
        try {
            if (StringUtils.isNotEmpty(sapPassportToken) && !sapPassportToken.trim().isEmpty()) {
                return PassportManager.getOutboundSAPPassport(sapPassportToken.trim(),
                                                              "");
            }
        }
        catch (Exception exp) {
            log.error("{} , Exception - {} while forming outbound sap passport token for inbound sap passport token ",
                      IM_CRITICAL_PASSPORT,
                      ErrorUtil.getCompleteCausedByErrors(exp));
            throw new PassportException("Exception while forming outbound sap passport token for inbound sap token ",
                                        exp);
        }
        return "";
    }

    /**
     * To Form/generate our own sap Passport token  with necessary field.
     *
     * @return Sap passport token.
     */
    @Override
    public String createInitialPassport (IntegrationContext integrationContext)
    {
        UUID rootContextId = UUID.randomUUID();
        UUID connectionId = UUID.randomUUID();
        String transactionId = UUID.randomUUID().toString().replace("-",
                                                                    "");
        PassportBean passportBean = new PassportBeanBuilder().setSystemId(integrationContext.getSystem())
                        .setPrevSystemId(integrationContext.getPrevSystemId())
                        .setTransId(transactionId).setRootContextId(rootContextId)
                        .setConnectionId(connectionId).build();
        // Convert passportBean to passport token
        return PassportManager.getInitialSAPPassport(passportBean);
    }

    @Override
    public void savePassportTokenBasedOnJobID (String jobId) throws PassportException
    {
        try {
            //fetching current thread request information i.e Sap passport token
            EventContext context = ContextHolder.getContext();
            if (context != null) {
                String sapPassportToken = context.getSapPassportToken();
                if (StringUtils.isNotEmpty(jobId) && StringUtils.isNotEmpty(sapPassportToken)) {
                    Passport passport = new Passport(jobId,
                                                     sapPassportToken);
                    passport.setSourceEventId(context.getSourceEventId());
                    passportDAO.savePassportToken(passport);
                }
            }
        }
        catch (PassportDAOException e) {
            log.error("{} , Job ID - {} ,Exception - {} while saving sap passport token info.",
                      IM_CRITICAL_PASSPORT,
                      jobId,
                      ErrorUtil.getCompleteCausedByErrors(e));
            throw new PassportException(
                            "Error while saving sap passport token info for particular job id - "
                                            + jobId,
                            e);
        }
    }

    /**
     * Method to save sap-passport-token with source-event-id
     *
     * @param jobId
     * @throws PassportException
     */
    @Override
    public void savePassportTokenAndSourceEventIdBasedOnJobId (String jobId,
                                                               String sourceEventId)
                    throws PassportException
    {
        try {
            //fetching current thread request information i.e Sap passport token
            EventContext eventContext = contextHandler.fetchCurrentEventContextThreadDetails();
            if (eventContext != null) {
                String sapPassportToken = eventContext.getSapPassportToken();
                if (StringUtils.isNotEmpty(jobId) && StringUtils.isNotEmpty(sapPassportToken)) {
                    Passport passport = new Passport(jobId,
                                                     sapPassportToken);
                    passport.setSourceEventId(sourceEventId);
                    passportDAO.savePassportToken(passport);
                }
            }
        }
        catch (PassportDAOException e) {
            log.error("{} , Job ID - {} ,Exception - {} while saving sap passport token info.",
                      IM_CRITICAL_PASSPORT,
                      jobId,
                      ErrorUtil.getCompleteCausedByErrors(e));
            throw new PassportException(
                            "Error while saving sap passport token info for particular job id - "
                                            + jobId,
                            e);
        }
    }

    /**
     * Cleaning up  Passport entry from DB
     *
     * @param jobId
     * @throws PassportException
     */
    @Override
    public void deletePassportTokenBasedOnJobID (String jobId) throws PassportException
    {
        try {
            if (StringUtils.isNotEmpty(jobId)) {
                //fetch sap passport taken for job id
                Passport passport = passportDAO.getPassportTokenByJobId(jobId);
                if (ObjectUtils.isNotEmpty(passport)) {
                    passportDAO.deletePassportEntry(passport);
                }
            }
        }
        catch (PassportDAOException e) {
            log.error("{} , Job ID - {} ,Exception - {} while deleting sap passport token info from DB.",
                      IM_CRITICAL_PASSPORT,
                      jobId,
                      ErrorUtil.getCompleteCausedByErrors(e));
            throw new PassportException(
                            "Error while deleting sap passport token entry info for particular job id - "
                                            + jobId,
                            e);
        }
    }

    /**
     * Get outbound sap-passport token by fetching from DB based on job-id that has been created by XmlPayloadHandler class
     *
     * @param jobId
     * @return sap-passport token .
     * @throws PassportDAOException
     * @see com.sap.ariba.erpintegration.handlers.XMLPayloadHandler
     * @see com.sap.ariba.erpintegration.handlers.IntegrationDataPayloadProcessor
     * @see com.sap.ariba.erpintegration.monitor.passport.core.persistance.Passport
     * @see com.sap.ariba.integrationmonitoring.logger.PassportManager
     */
    @Override
    public String getOutBoundPassportTokenBasedOnJobID (String jobId) throws PassportException
    {
        String token;
        try {
            Passport passport = passportDAO.getPassportTokenByJobId(jobId);
            token = passport != null ? passport.getPassportToken() : "";
            if (StringUtils.isNotEmpty(token)) {
                //forming outbound passport by changing the system id , connection counter id etc.
                return getOutBoundSAPPassportToken(token);
            }
        }
        catch (PassportDAOException | PassportException e) {
            log.error("{} , Job ID - {} , Exception : {} , while fetching sap Passport token for particular Job ID .",
                      IM_CRITICAL_PASSPORT,
                      jobId,
                      ErrorUtil.getCompleteCausedByErrors(e));
            throw new PassportException(
                            "Error while fetching outbound sap passport token for particular job id - "
                                            + jobId,
                            e);
        }
        return token;
    }

    /**
     * @param jobId
     * @return
     * @throws PassportException
     */
    @Override
    public Passport getPassportTokenBasedOnJobID (String jobId) throws PassportException
    {
        try {
            return passportDAO.getPassportTokenByJobId(jobId);
        }
        catch (PassportDAOException e) {
            log.error("{} , Job ID - {} , Exception : {} , while fetching sap Passport token for particular Job ID .",
                      IM_CRITICAL_PASSPORT,
                      jobId,
                      ErrorUtil.getCompleteCausedByErrors(e));
            throw new PassportException(
                            "Error while fetching outbound sap passport token for particular job id - "
                                            + jobId,
                            e);
        }
    }

    /**
     * Will return list of all passport from Passport table.
     * @return list of passport .
     */
    @Override
    public List<Passport> getAllPassportData () throws PassportException
    {
        try {
            return passportDAO.getAllPassportData();
        }
        catch (PassportDAOException e) {
            log.error("{} , Exception : {} , while trying to fetch all Passport table data  .",
                      IM_CRITICAL_PASSPORT,
                      ErrorUtil.getCompleteCausedByErrors(e));
            throw new PassportException(
                            "Error while fetching outbound sap passport token for particular job id - ",
                            e);
        }
    }
}
