package com.sap.ariba.erpintegration.storage;

import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.sap.ariba.erpintegration.storage.exception.CloudStorageException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;

@Service
@Qualifier("AzureBlobStorage")
@ConditionalOnExpression(value = "${advanced.storage.option}")
public class AzureBlobStorage implements CloudStorage {

    private Logger logger = LoggerFactory.getLogger(AzureBlobStorage.class);

    @Value("${vcap.services.objectstore.credentials.container_name}")
    private String containerName;

    @Value("${vcap.services.objectstore.credentials.container_uri}")
    private String containerUri;

    @Value("${vcap.services.objectstore.credentials.sas_token}")
    private String sasToken;

    private static final String SLASH = "/";
    private static final String QUESTION = "?";

    @Override
    public void put(String path, String content) throws CloudStorageException {
        try {
            CloudBlockBlob cloudBlockBlob = this.getCloudBlockBlob(path);
            InputStream inputStream = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
            cloudBlockBlob.upload(inputStream, content.length());
            logger.info("Object {} successfully uploaded to container URI {}", path, containerUri);
        } catch (StorageException | IOException | URISyntaxException e) {
            logger.error("Exception while putting the object from Azure Storage", e);
            throw new CloudStorageException(e);
        }
    }

    @Override
    public String getContent(String path) throws CloudStorageException {
        try {
            CloudBlockBlob cloudBlockBlob = this.getCloudBlockBlob(path);
            return cloudBlockBlob.downloadText();
        } catch (StorageException | IOException | URISyntaxException e) {
            logger.error("Exception while getting the object from Azure Storage", e);
            throw new CloudStorageException(e);
        }
    }

    @Override
    public CloudStorageResponse getStream(String path) throws CloudStorageException {
        try {
            CloudBlockBlob cloudBlockBlob = this.getCloudBlockBlob(path);
            return new CloudStorageResponse(null,cloudBlockBlob.openInputStream());
        } catch (StorageException | URISyntaxException e) {
            logger.error("Exception while getting the object from Azure Storage", e);
            throw new CloudStorageException(e);
        }
    }

    @Override
    public void remove(String path) throws CloudStorageException {
        try {
            CloudBlockBlob cloudBlockBlob = this.getCloudBlockBlob(path);
            cloudBlockBlob.deleteIfExists();
        } catch (StorageException | URISyntaxException e) {
            logger.error("Exception while deleting the object from Azure Storage", e);
            throw new CloudStorageException(e);
        }
    }

    public CloudBlockBlob getCloudBlockBlob(String path) throws URISyntaxException, StorageException {
        return new CloudBlockBlob(new URI(containerUri + SLASH + path + QUESTION + sasToken));
    }

    @Override
    public void closeCloudObject (CloudStorageResponse responseStream)
    {
        /* we have to handle this in future */
    }
}
