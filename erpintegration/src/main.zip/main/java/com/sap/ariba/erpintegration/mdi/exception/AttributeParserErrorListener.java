package com.sap.ariba.erpintegration.mdi.exception;

import org.antlr.v4.runtime.BaseErrorListener;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.Recognizer;

/**
 * Antlr Grammar Error Listener class that will listen the grammar syntax
 * and token exception and throw Run time exception
 */
public class AttributeParserErrorListener extends BaseErrorListener
{
    @Override
    public void syntaxError (Recognizer<?, ?> recognizer,
                             Object offendingSymbol,
                             int line,
                             int charPositionInLine,
                             String msg,
                             RecognitionException e)
    {
        throw new ResourceParseException("Antlr grammar syntax error : " + msg + " for grammar file : "
                                                         + recognizer.getGrammarFileName());
    }
}
