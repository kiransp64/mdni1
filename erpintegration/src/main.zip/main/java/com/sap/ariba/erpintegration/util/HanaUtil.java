package com.sap.ariba.erpintegration.util;

import com.sap.ariba.mdsclient.util.JSONUtil;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.Assert;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class HanaUtil

{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.IntegrationDataPayloadProcessor";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private static final String PROP_FILE_NAME = "hana.properties";
    private static final String HANA_URL = "hana.url";
    private static final String HANA_TRANSFORMATION_MAPPING = "hana.transformation.mapping";
    private static final String HANA_OBJECTNAME_MAPPING = "hana.objectname.mapping";
    private static final String HANA_ADAPTER_MAPPING = "hana.adapter.mapping";
    private static final String HANA_INSTANCE_LIST = "hana.instance.list";

    private static String hanaURL;
    private static Map<String, Object> hanaTransfermationMapping;
    private static Map<String, String> hanaObjectNameMapping;
    private static Map<String, Object> hanaAdapterMapping;
    private static List<Map<String, Object>> hanaInstanceList;

    static {
        Properties hanaProperties = new Properties();
        InputStream input = null;

        try {
            ClassPathResource classPathResource = new ClassPathResource(PROP_FILE_NAME);

            hanaProperties.load(classPathResource.getInputStream());

            Assert.notNull(hanaProperties.get(HANA_URL));
            Assert.notNull(HANA_TRANSFORMATION_MAPPING);
            Assert.notNull(HANA_OBJECTNAME_MAPPING);
            Assert.notNull(HANA_ADAPTER_MAPPING);
            Assert.notNull(HANA_INSTANCE_LIST);

            hanaURL = (String)hanaProperties.get(HANA_URL);
            hanaTransfermationMapping = JSONUtil.getMapFromJSON(
                (String)hanaProperties.get(HANA_TRANSFORMATION_MAPPING));

            hanaObjectNameMapping = JSONUtil.getStringMapFromJSON(
                (String)hanaProperties.get(HANA_OBJECTNAME_MAPPING));

            hanaAdapterMapping = JSONUtil.getMapFromJSON(
                (String)hanaProperties.get(HANA_ADAPTER_MAPPING));

            hanaInstanceList = JSONUtil.getListFromJSON(
                (String)hanaProperties.get(HANA_INSTANCE_LIST));

        }
        catch (IOException ex) {
            logger.error("Exception while reading the property file", ex);
        }
        finally {
            if (input != null) {
                try {
                    input.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private static void addPartitionNumberAndSystemId (JSONArray dataArray,
                                                long tenantid,
                                                String senderBusinessSystemId)
    {
        if (dataArray != null && dataArray.size() > 0) {
            for (int i = 0; i < dataArray.size(); i++) {
                JSONObject data = (JSONObject)dataArray.get(i);
                data.put("PartitionNumber", tenantid);
                data.put("SystemId", senderBusinessSystemId);
            }
        }
    }

    private static long getPartitionNumber (long tenantid)
    {
        return tenantid;
    }

    public static String getHanaLangKey (String objectName, String key)
    {
        Map<String, Object> config = (Map<String, Object>)hanaAdapterMapping.get(
            objectName);
        if (config == null) {
            logger.error("Invalid object name {}", objectName);
            return null;
        }
        Map<String, Object> langAssociation = (Map<String, Object>)config.get(
            "LangAssociation");
        if (langAssociation == null) {
            logger.warn("langAssociation not found for object name {}", objectName);
            return null;
        }
        String hanaKey = (String)langAssociation.get(key);
        return hanaKey;
    }

    public static Map<String, Object> getKeyFieldConfig (String objectName, String key)
    {
        Map<String, Object> config = (Map<String, Object>)hanaAdapterMapping.get(
            objectName);
        if (config == null) {
            logger.error("Invalid object name {}", objectName);
            return null;
        }
        Map<String, Object> keyFields = (Map<String, Object>)config.get("KeyFields");
        if (keyFields == null) {
            logger.warn("keyFields not found for object name {}", objectName);
            return null;
        }
        Map<String, Object> keyConfig = (Map<String, Object>)keyFields.get(key);
        return keyConfig;
    }

    public static Map<String, Object> getMapAssociationConfig (String objectName,
                                                                String key)
    {
        Map<String, Object> config = (Map<String, Object>)hanaAdapterMapping.get(
            objectName);
        if (config == null) {
            logger.error("Invalid object name {}", objectName);
            return null;
        }
        Map<String, Object> mapAssociation = (Map<String, Object>)config.get(
            "MapAssociation");
        if (mapAssociation == null) {
            logger.warn("mapAssociation not found for object name {}", objectName);
            return null;
        }
        Map<String, Object> keyConfig = (Map<String, Object>)mapAssociation.get(key);
        return keyConfig;
    }

    public static Map<String, Object> getSetAssociationConfig (String objectName,
                                                                String key)
    {
        Map<String, Object> config = (Map<String, Object>)hanaAdapterMapping.get(
            objectName);
        if (config == null) {
            logger.error("Invalid object name {}", objectName);
            return null;
        }
        Map<String, Object> setAssociation = (Map<String, Object>)config.get(
            "SetAssociation");
        if (setAssociation == null) {
            logger.warn("setAssociation not found for object name {}", objectName);
            return null;
        }
        Map<String, Object> keyConfig = (Map<String, Object>)setAssociation.get(key);
        return keyConfig;
    }

    public static List<Map<String, Object>> getHanaPodList ()
    {
        return hanaInstanceList;
    }

    public static String getHanaUrl ()
    {
        return hanaURL;
    }

    public static int getPodLimit (Integer key)
    {
        for (Map<String, Object> map : hanaInstanceList) {
            if ((Integer)map.get("pod") == key) {
                return (Integer)map.get("limit");
            }
        }
        return 0;
    }

}
