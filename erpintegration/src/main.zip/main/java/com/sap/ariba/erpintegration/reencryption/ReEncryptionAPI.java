package com.sap.ariba.erpintegration.reencryption;

import com.sap.ariba.erpintegration.mdi.common.util.TracingHelper;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.security.encryption.Constants;
import com.sap.ariba.security.tool.keyrotation.v1.model.AppTenantLevels;
import com.sap.ariba.security.tool.keyrotation.v1.model.EncryptionJobResponse;
import com.sap.ariba.security.tool.keyrotation.v1.model.TenantLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Arrays;

@Component
@ConditionalOnExpression("${environment.mdcs:false} == false && ${isInternal:false} == false && ${kmsEnabled:false} == true && ${reEncryption:false} == true")
public class ReEncryptionAPI
{
    private static final Logger logger = LoggerFactory.getLogger(ReEncryptionAPI.class);
    public static final String TRACKING_ID = "TrackingID";

    @Autowired
    @Qualifier("contractReEncryptionService")
    @Lazy
    private ReEncryptionLibContractService reEncryptionService;

    @Autowired
    private TracingHelper tracingHelper;

    @GET
    @Path("/tenants")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTenants ()
    {
        try {
            logger.info("[Re-Encryption][GetTenants] Request Received.");
            final AppTenantLevels appTenantLevels = new AppTenantLevels();
            appTenantLevels.setApplicationId(reEncryptionService.getAppName());
            appTenantLevels.setSupportedTenantLevel(Constants.SYSTEM);
            final TenantLevel tenantLevel = new TenantLevel();
            tenantLevel.setName(Constants.SYSTEM);
            tenantLevel.setId("0");
            appTenantLevels.setTenantLevels(Arrays.asList(tenantLevel));
            return Response.ok().entity(appTenantLevels)
                           .header(TRACKING_ID, tracingHelper.getTraceId())
                           .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                           .build();
        }
        catch (Exception e) {
            logger.error("[Re-Encryption] Error while trying to get all tenant levels.",
                         e);
            throw new WebApplicationException(ErrorUtil.getCompleteCausedByErrors(e),
                                              Response.Status.INTERNAL_SERVER_ERROR);
        }

    }

    @POST
    @Path("/jobs/schedule")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response schedule (AppTenantLevels appTenantLevels)
    {
        try {
            logger.info("[Re-Encryption][schedule]  Request Received. Input - {}.",
                        appTenantLevels.toPrettyJson());
            validateInput(appTenantLevels);
            return buildOkResponse(reEncryptionService.submitJob(appTenantLevels));
        }
        catch (Exception e) {
            logger.error(
                "[Re-Encryption][schedule] Error while to trying to schedule a job for request - {}",
                appTenantLevels.toPrettyJson(), e);
            if (e instanceof WebApplicationException exception) {
                throw exception;
            }
            else {
                throw new WebApplicationException(ErrorUtil.getCompleteCausedByErrors(e),
                                                  Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
            }
        }
    }

    @POST
    @Path("/jobs/start")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response start (AppTenantLevels appTenantLevels)
    {
        try {
            logger.info("[Re-Encryption][Start] Request Received. Input - {}.",
                        appTenantLevels.toPrettyJson());
            validateInput(appTenantLevels);
            return buildOkResponse(reEncryptionService.submitJob(appTenantLevels));
        }
        catch (Exception e) {
            logger.error(
                "[Re-Encryption][Start] Error while to trying to schedule a job for request - {}",
                appTenantLevels.toPrettyJson(), e);

            if (e instanceof WebApplicationException exception) {
                throw exception;
            }
            else {
                throw new WebApplicationException(ErrorUtil.getCompleteCausedByErrors(e),
                                                  Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
            }
        }
    }

    @POST
    @Path("/jobs/report")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response report (AppTenantLevels appTenantLevels)
    {
        try {
            logger.info("[Re-Encryption][Report] Request Received. Input - {}.",
                        appTenantLevels.toPrettyJson());
            validateInput(appTenantLevels);
            return buildOkResponse(reEncryptionService.getStatusReport(appTenantLevels));
        }
        catch (Exception e) {
            logger.error(
                "[Re-Encryption][Report] Error while trying to job status report for request - {}.",
                appTenantLevels.toPrettyJson(), e);
            if (e instanceof WebApplicationException exception) {
                throw exception;
            }
            else {
                throw new WebApplicationException(ErrorUtil.getCompleteCausedByErrors(e),
                                                  Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
            }
        }
    }

    @PUT
    @Path("/jobs/pause")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response pause (AppTenantLevels appTenantLevels)
    {
        try {
            logger.info("[Re-Encryption][Pause] Request Received. Input - {}.",
                        appTenantLevels.toPrettyJson());
            validateInput(appTenantLevels);
            return buildOkResponse(reEncryptionService.pauseJob(appTenantLevels));
        }
        catch (Exception e) {
            logger.error(
                "[Re-Encryption][Pause] Error while trying to pause job for request - {}.",
                appTenantLevels.toPrettyJson(), e);
            if (e instanceof WebApplicationException exception) {
                throw exception;
            }
            else {
                throw new WebApplicationException(ErrorUtil.getCompleteCausedByErrors(e),
                                                  Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
            }
        }
    }

    @PUT
    @Path("/jobs/resume")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response resume (AppTenantLevels appTenantLevels)
    {
        try {
            logger.info("[Re-Encryption][Resume] Request Received. Input - {}.",
                        appTenantLevels.toPrettyJson());
            validateInput(appTenantLevels);
            return buildOkResponse(reEncryptionService.resumeJob(appTenantLevels));
        }
        catch (Exception e) {
            logger.error(
                "[Re-Encryption] Error while trying to pause job for request - {}.",
                appTenantLevels.toPrettyJson(), e);
            if (e instanceof WebApplicationException exception) {
                throw exception;
            }
            else {
                throw new WebApplicationException(ErrorUtil.getCompleteCausedByErrors(e),
                                                  Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
            }
        }
    }

    @PUT
    @Path("/jobs/abort")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response abort (AppTenantLevels appTenantLevels)
    {
        try {
            logger.info("[Re-Encryption][Abort] Request Received. Input - {}.",
                        appTenantLevels.toPrettyJson());
            validateInput(appTenantLevels);
            return buildOkResponse(reEncryptionService.abortJob(appTenantLevels));
        }
        catch (Exception e) {
            logger.error(
                "[Re-Encryption] Error while trying to pause job for request - {}.",
                appTenantLevels.toPrettyJson(), e);
            if (e instanceof WebApplicationException exception) {
                throw exception;
            }
            else {
                throw new WebApplicationException(ErrorUtil.getCompleteCausedByErrors(e),
                                                  Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
            }
        }
    }

    private Response buildOkResponse (EncryptionJobResponse encryptionJobResponse)
    {
        logger.info("[Re-Encryption] Response sent - {}", encryptionJobResponse != null ?
            encryptionJobResponse.toPrettyJson() :
            "Blank");
        return Response.ok(encryptionJobResponse)
                       .header(TRACKING_ID, tracingHelper.getTraceId())
                       .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                       .build();
    }

    private void validateInput (AppTenantLevels appTenantLevels)
    {
        if (appTenantLevels == null || appTenantLevels.getTenantLevels() == null
            || appTenantLevels.getTenantLevels().size() == 0)
        {
            throw new BadRequestException("Request input is blank");
        }
    }

}
