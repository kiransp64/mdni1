package com.sap.ariba.erpintegration.audit;

/**
 * This class hold the data from application for audit request. These objects
 * are the input to the <code>AuditProcessor</code> to be processed and
 * persisted to the database.
 * 
 * @author i339952
 */
public class AuditTask
{
    private String tenantId;
    private Operation operation;
    private String comment;

    public AuditTask (String tenantId, Operation operation, String comment)
    {
        this.tenantId = tenantId;
        this.operation = operation;
        this.comment = comment;

    }

    public String getTenantId ()
    {
        return tenantId;
    }

    public void setTenantId (String tenantId)
    {
        this.tenantId = tenantId;
    }

    public Operation getOperation ()
    {
        return operation;
    }

    public void setOperation (Operation operation)
    {
        this.operation = operation;
    }

    public String getComment ()
    {
        return comment;
    }

    public void setComment (String comment)
    {
        this.comment = comment;
    }

}
