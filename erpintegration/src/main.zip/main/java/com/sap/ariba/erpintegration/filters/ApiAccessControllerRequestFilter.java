package com.sap.ariba.erpintegration.filters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.service.rs.config.InspectorConfig;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
@Order(1)
/**
 * to control the access to apis to mdni app
 * if sent via internal app, then restrict
 * if sent via external app, then let it pass through
 * @author i340151
 *
 */
public class ApiAccessControllerRequestFilter implements Filter
{    
    
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.filters.UIApiControllerRequestFilter";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    
    @Autowired
    private InspectorConfig insConfig;

    @Override
    public void init (FilterConfig filterConfig) throws ServletException
    {
        
    }

    @Override
    public void doFilter (ServletRequest req,
                          ServletResponse res,
                          FilterChain chain)
        throws IOException,
        ServletException
    {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String requestUri = request.getRequestURI();
        if(!insConfig.isInternal()){
            //if external app, let is pass through
            chain.doFilter(req, res);
        }else {
            // if internal, allow only inspector apis and the integration job status api
            String reqUrl = request.getRequestURL().toString();
            if(reqUrl.contains("/main/")
                || reqUrl.contains("/api/integrationJobs")
                || reqUrl.contains("/api/health")) {
                chain.doFilter(req, res);
            }
            else {
                writeErrorResponse(insConfig.getInternalServiceApiRestrictmessage(),
                    HttpStatus.SC_FORBIDDEN, response, requestUri);
            }
        }           
    }
    
    private void writeErrorResponse(String errResponse,
                                    int status,
                                    HttpServletResponse response,
                                    String url)
                                        throws IOException {
        
        response.setContentType("application/json");
        ObjectMapper mapper = new ObjectMapper();
        String errorResponse =  mapper.writeValueAsString(errResponse);
        response.setStatus(status);
        logger.error("Request to the api "+ url + " failed due to the reason: "+errorResponse);
		ServletOutputStream out = response.getOutputStream();
		out.write(errResponse.getBytes());
		out.flush();
		out.close();
    }

    @Override
    public void destroy ()
    {
        
    }
}
