/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.filters;

import com.sap.ariba.erpintegration.mdi.common.resource.request.RequestUtil;
import com.sap.ariba.erpintegration.monitor.exception.PassportException;
import com.sap.ariba.erpintegration.monitor.im.helper.IMHelper;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.util.IntegrationContextBuilder;
import com.sap.ariba.erpintegration.monitor.passport.PassportHandler;
import com.sap.ariba.erpintegration.monitor.passport.context.ContextHandler;
import com.sap.ariba.erpintegration.monitor.passport.context.ContextHolder;
import com.sap.ariba.erpintegration.monitor.passport.context.EventContext;
import com.sap.ariba.erpintegration.monitor.passport.core.persistance.Passport;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import static com.sap.ariba.erpintegration.handlers.IntegrationDataPayloadProcessor.KeyRecordId;
import static com.sap.ariba.erpintegration.handlers.IntegrationDataPayloadProcessor.KeyTenantId;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INTEGRATION_MONITORING_ENABLE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.JOB_ID;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI_CRITICAL_MONITORING_FILTER;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.MDNI_IM_INTEGRATION;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.PROCESS_XML_PAYLOAD_URI;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.SAP_PASSPORT;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.SCIM_GROUPS;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.SCIM_USERS;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.TENANT_ID;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.UPLOAD_XML_URI;

/**
 * This filter will be invoked for every incoming request after SimpleCORSFilter
 * to pre-process some logic related to integration monitoring
 */
@Slf4j
@Component
@ConditionalOnExpression(INTEGRATION_MONITORING_ENABLE)
@Order(0)
public class MonitoringFilter implements Filter
{
    @Autowired
    private ContextHandler contextHandler;

    @Autowired
    @Qualifier("passportHandler")
    private PassportHandler passportHandler;

    @Override
    public void init (FilterConfig filterConfig) throws ServletException
    {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter (ServletRequest req,
                          ServletResponse res,
                          FilterChain chain) throws IOException, ServletException
    {
        log.info("{} , From Monitoring filter.",
                 MDNI_IM_INTEGRATION);
        HttpServletRequest request = (HttpServletRequest)req;
        HttpServletResponse response = (HttpServletResponse)res;
        String requestUri = "";
        try {
            requestUri = request.getRequestURI();
            if (StringUtils.isNotEmpty(requestUri)) {
                if (requestUri.contains(UPLOAD_XML_URI)) {
                    this.setRequestContextToCurrentThread(request);
                }
                else if (requestUri.contains(PROCESS_XML_PAYLOAD_URI)) {
                    this.addingSAPPassportForDataPayloadProcessorJobID(request);
                }

                logCurrentContextDetail(requestUri);
            }
        }
        catch (Exception e) {
            log.error("{} , RequestUri - {} , Exception - {} , while processing the request from MDNI Monitoring Filter .",
                      MDNI_CRITICAL_MONITORING_FILTER,
                      requestUri,
                      ErrorUtil.getCompleteCausedByErrors(e));
        }
        finally {
            chain.doFilter(req,
                           res);
            ContextHolder.removeContext();
        }
    }

    /**
     * Setting sap-passport token for /processXMLPayload uri in current thread local.
     *
     * @param request
     */
    private void addingSAPPassportForDataPayloadProcessorJobID (HttpServletRequest request)
    {
        Map<String, String> headerMap = new HashMap<>();
        try {
            ContextHolder.removeContext();
            String recordId = HandlerUtil.decodeParams(request.getParameter(KeyRecordId));
            String tenantId = HandlerUtil.decodeParams(request.getParameter(KeyTenantId));

            //will fetch the Sap passport with source event ID and add to the Thread local for Inbound scuccess flow .
            Passport passport = passportHandler.getPassportTokenBasedOnJobID(recordId);
            //Setting sap passport token to http request so that we can extract the value in /processXMLPayload API and log the outbound event
            if (ObjectUtils.isEmpty(passport) || StringUtils.isEmpty(passport.getPassportToken())) {
                log.warn("{} ,For incoming request api - {} , We did not receive sap-passport as part of request header.",
                         MDNI_IM_INTEGRATION,
                         PROCESS_XML_PAYLOAD_URI);
                return;
            }
            headerMap.put(SAP_PASSPORT,
                          passport.getPassportToken());
            headerMap.put(JOB_ID,
                          recordId);
            headerMap.put(TENANT_ID,
                          tenantId);
            EventContext eventContext = contextHandler.constructRequestContext(headerMap);
            eventContext.setSourceEventId(passport.getSourceEventId());//setting source event id to current Thread.
            contextHandler.setContextInThread(eventContext);
        }
        catch (Exception exp) {
            log.error("{} , Error while setting the context details to Thread local like sap-passport token , tenant id etc : {}",
                      MDNI_CRITICAL_MONITORING_FILTER,
                      ErrorUtil.getCompleteCausedByErrors(exp));
        }
    }

    /**
     * This method will set sap passport and necessary parameter in Current thread context holder
     *
     * @param request
     */
    protected void setRequestContextToCurrentThread (HttpServletRequest request)
    {
        String tenantId;
        Map<String, String> headerMap = new HashMap<>();
        try {
            ContextHolder.removeContext();
            String requestUri = request.getRequestURI();
            String sapPassport = request.getHeader(SAP_PASSPORT);
            tenantId = request.getParameter(TENANT_ID);
            //if request is for scim flow, and we did not receive any sap-passport token then we will generate the passport token.
            if (StringUtils.isEmpty(sapPassport) && (requestUri.contains(SCIM_USERS)
                            || requestUri.contains(SCIM_GROUPS))) {
                log.info("{},Request Uri - {} , Missing sap-passport token as part of request header.",
                         MDNI_IM_INTEGRATION,
                         requestUri);
                tenantId = request.getHeader(RequestUtil.TENANT_ID_PARAM);
                //For scim Inbound we don't have any previous system so setting MDNI as current system.
                IntegrationContext integrationContext = IntegrationContextBuilder.builder()
                                .withSystem(MDNI).withPrevSystemId("").build();
                sapPassport = passportHandler.createInitialPassport(integrationContext);
            }
            if (StringUtils.isEmpty(sapPassport)) {
                log.warn("{} ,Request Uri - {} ,sap-passport token either Missing or Not able to form application.",
                         MDNI_IM_INTEGRATION,
                         requestUri);
                return;
            }
            headerMap.put(SAP_PASSPORT,
                          sapPassport);
            headerMap.put(TENANT_ID,
                          tenantId);
            EventContext eventContext = contextHandler.constructRequestContext(headerMap);
            if (eventContext != null) {
                contextHandler.setContextInThread(eventContext);
            }
        }
        catch (PassportException pe) {
            log.error("{} , Error - {} , while creating sap-passport token.",
                      MDNI_CRITICAL_MONITORING_FILTER,
                      ErrorUtil.getCompleteCausedByErrors(pe));
        }
        catch (Exception e) {
            log.error("{} , Error - {} , while setting the context details to Thread local, ex. sap-passport token,tenant id etc.",
                      MDNI_CRITICAL_MONITORING_FILTER,
                      ErrorUtil.getCompleteCausedByErrors(e));
        }
    }

    /**
     * Logging context detail for particular request if sap-passport is available.
     *
     * @param requestUri
     */
    protected void logCurrentContextDetail (String requestUri)
    {
        EventContext context = contextHandler.fetchCurrentEventContextThreadDetails();
        if (IMHelper.isPassportAvailableAsPartOfCurrentRequestThread()) {
            log.info("{} , incoming request :: {} , context details :: {} ",
                     MDNI_IM_INTEGRATION,
                     requestUri,
                     context);
        }
    }

    @Override
    public void destroy ()
    {
        Filter.super.destroy();
    }

}
