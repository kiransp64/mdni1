package com.sap.ariba.erpintegration.scheduler;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.SchedulerConfig;
import com.sap.ariba.erpintegration.common.metrics.MDNIMetrics;
import com.sap.ariba.erpintegration.common.metrics.MDNIServiceRegistry;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.handlers.IntegrationDataPayloadProcessor;
import com.sap.ariba.erpintegration.handlers.IntegrationOperationType;
import com.sap.ariba.erpintegration.handlers.StagingTableStatus;
import com.sap.ariba.erpintegration.mdi.api.APIUtil;
import com.sap.ariba.erpintegration.mdi.cap.oauth.MdcsOAuthManager;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.scheduler.exception.IntegrationJobProcessingException;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.erpintegration.util.IntegrationJobLogUtil;
import com.sap.ariba.erpintegration.util.MasterDataDependencyProvider;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by i318483 on 17/05/17.
 */
@Component
@DisallowConcurrentExecution
@ConditionalOnExpression(    
    "${isInternal:false} == false"
)
public class IntegrationDataProcessorJob implements Job {

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.scheduler.IntegrationDataProcessorJob";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private OAuthTokenManager oAuthTokenManager;

    @Autowired
    MDNIServiceRegistry mdniServiceRegistry;

    @Autowired(required = false)
    @Lazy
    private MdcsOAuthManager mdcsOAuthManager;
    private static final int pagesize = 10;
    private Map<String, List<Long>> mapOfObjectNameSenderBusinessIdToTenantId = new HashMap<>();

    private List<String> excludeTenantIdSenderBusinessIdList = new ArrayList();

    @Value("${enableMDNIthrottling:true}")
    private boolean enableMDNIthrottling;
    private static final List<String> objectDependencyOrderList = Arrays.asList(
            "Region",
            "Currency",
            "UnitOfMeasurement",
            "ExchangeRate",
            "IncoTerms",
            "TaxCode",
            "PaymentMethod",
            "PurchaseDocumentItemCategory",
            "CompanyCode",
            "PaymentTerms",
            "CostCentre",
            "WBSElement",
            "Plant",
            "InternalOrder",
            "FixedAsset",
            "GLAccount",
            "PurchasingOrg",
            "PurchasingGroup",
            "MaterialGroup",
            "AccountAssignmentCategory",
            "PlantPurchasingOrg",
            "User");

    private List<StageXMLData> stageXMLDataRecordFilteredList = new ArrayList<>();
    private volatile boolean stopQuartzCurrentExecution = false;
    @Value("${integrationDataProcessorJob.cronExpression}")
    private String cronExpression;

    @Value("${processXMLURL}")
    String processXMLURL;

    @Value("${MaxParallelRecordsToProcess}")
    int maxParallelRecordsToProcess;

    @Value("${MaxProcessingTimeForRecord}")
    int numberofRecordsInProcessingStatus;

    @Bean(name = "integrationDataProcessorJobBean")
    public JobDetailFactoryBean integrationDataProcessorJobBean() {
        logger.info("Creating integrationDataProcessorJobBean");
        return SchedulerConfig.createJobDetail(this.getClass());
    }

    @Bean(name = "integrationDataProcessorJobTrigger")
    public CronTriggerFactoryBean integrationDataProcessorJobTrigger(@Qualifier("integrationDataProcessorJobBean") JobDetail jobDetail) {
        if (logger.isDebugEnabled())
            logger.debug("Creating integrationDataProcessorJobTrigger");
        return SchedulerConfig.createCronTrigger(jobDetail, cronExpression);
    }

    /**
     * This Scheduler checks STAGEXMLDATATAB Table for records in STATUS = 0 and
     * makes an internal REST API call to IntegrationDataPayloadProcessor,giving
     * input as the recordId and tenantId. Before posting STATUS is made as
     * IN_PROCESS(STATUS =1). After successful processing
     * IntegrationDataPayloadProcessor will update it to COMPLETED(STATUS =2)
     *
     * @param jobExecutionContext
     * @throws JobExecutionException
     */
    @Override
    public void execute(JobExecutionContext jobExecutionContext)
            throws JobExecutionException {
        long tenantId = -1;

        String anId = null;
        String recordId = null;

        Properties prop = null;
        DAOFactory factory = null;
        GenericDAOStageData dao = null;

        List<StageXMLData> recordsInProcessingStatus = null;
        List<StageXMLData> stageXMLDataRecordIdSubList = null;

        Page<StageXMLData> pageData = null;
        InputStream inputStream = null;
        ClassLoader classLoader = null;

        try {
            factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());

            recordsInProcessingStatus = dao.findRecordsInProcessingStatus();

            if (logger.isDebugEnabled() && recordsInProcessingStatus != null) {
                logger.debug(
                        "No. of records in InProcessing status is {}",
                        recordsInProcessingStatus.size());
            }

            for (StageXMLData stageXMLData : recordsInProcessingStatus) {

                if (logger.isDebugEnabled()) {
                    logger.debug(
                            "Adding exclude entry for senderBusinessSystemId : {}, tenantId : {}",
                            stageXMLData.getSenderBusinesssytemId(),
                            stageXMLData.getTenantId());
                }

                excludeTenantIdSenderBusinessIdList.add(
                        stageXMLData.getTenantId() + "_"
                                + stageXMLData.getSenderBusinesssytemId());
            }

            if (recordsInProcessingStatus != null
                    && recordsInProcessingStatus.size() < maxParallelRecordsToProcess) {

                numberofRecordsInProcessingStatus = recordsInProcessingStatus.size();
                logger.info("Number of StageXML InProcessing Jobs : {}", numberofRecordsInProcessingStatus);

                List<StageXMLData> unprocessedRecords;
                if(enableMDNIthrottling){
                    unprocessedRecords = getStageXMLData(dao);
                } else{
                    unprocessedRecords = dao.findAllUnprocessedRows();
                }
                logger.info("Number of StageXML Pending Jobs : {}", unprocessedRecords.size());
                mdniServiceRegistry.sendMetricsForGauge(MDNIMetrics.STAGEXML_PENDING_JOBS, unprocessedRecords.size());

                populateFilteredList(unprocessedRecords, MasterDataDependencyProvider.getObjectDependencyOrderList());

                stageXMLDataRecordIdSubList = stageXMLDataRecordFilteredList;

                if (stageXMLDataRecordFilteredList != null) {
                    if (stageXMLDataRecordFilteredList.size() > (maxParallelRecordsToProcess
                            - numberofRecordsInProcessingStatus)) {
                        stageXMLDataRecordIdSubList = stageXMLDataRecordFilteredList.subList(
                                0,
                                maxParallelRecordsToProcess
                                        - numberofRecordsInProcessingStatus);
                    }

                    if (logger.isDebugEnabled()) {
                        logger.debug(
                                "No. of records for processing : {}",
                                stageXMLDataRecordIdSubList.size());
                    }

                    for (StageXMLData stagedXMLData : stageXMLDataRecordIdSubList) {

                        if (stopQuartzCurrentExecution) {
                            logger.error("Post processXML encountered an unexpected failure. Halting current IntegrationDataProcessorJob execution.");
                            throw new IntegrationJobProcessingException("Halting current IntegrationDataProcessorJob execution.");
                        }

                        if (logger.isDebugEnabled()) {
                            logger.debug(
                                    "Processing started for recordId : {} , object : {} ,senderBusinessSystemId : {}, tenantId : {} ",
                                    stagedXMLData.getId(),
                                    stagedXMLData.getObjectName(),
                                    stagedXMLData.getSenderBusinesssytemId(),
                                    stagedXMLData.getTenantId());
                        }

                        tenantId = stagedXMLData.getTenantId();
                        anId = Utility.getANId(tenantId);
                        recordId = stagedXMLData.getId();
                        stagedXMLData.setStatus(StagingTableStatus.PROCESSING.getValue());
                        stagedXMLData.setDateUpdated(new Date());

                        dao.save(stagedXMLData);

                        postRecordForProcessing(tenantId, anId, recordId, processXMLURL);

                        if (logger.isDebugEnabled()) {
                            logger.debug(
                                    "Processing ended for recordId : {} , object : {} ,senderBusinessSystemId : {}, tenantId : {} ",
                                    stagedXMLData.getId(),
                                    stagedXMLData.getObjectName(),
                                    stagedXMLData.getSenderBusinesssytemId(),
                                    stagedXMLData.getTenantId());
                        }
                    }
                } else {
                    if (logger.isDebugEnabled()) {
                        logger.debug(
                                "Nothing to processes, as all tenants are occupied. excludeTenantIdSenderBusinessIdList : {}",
                                excludeTenantIdSenderBusinessIdList);
                    }
                }
            }
        } catch (UnsupportedOperationException | ClassCastException | NullPointerException | IllegalArgumentException ex) {
            logger.error(
                    """
                    Exception occurred for recordId : {}, tenantId: {} , anId:  {},\
                    exception details - {} \
                    """,
                    recordId,
                    tenantId,
                    anId,
                    ex.getMessage(),
                    ex);
            mdniServiceRegistry.sendMetricsForCounter(MDNIMetrics.STAGEXML_JOB_DISTRIBUTION_ERROR);
        } catch(Exception ex) {
            logger.error(
                """
                Exception occurred for recordId : {}, tenantId: {} , anId:  {},\
                exception details - {} \
                """,
                recordId,
                tenantId,
                anId,
                ex.getMessage(),
                ex);
            mdniServiceRegistry.sendMetricsForCounter(MDNIMetrics.STAGEXML_JOB_DISTRIBUTION_ERROR);
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException ex) {
                    logger.warn(ex.getMessage());
                }
            }
        }
    }

    public void setenableMDNIthrottling(boolean enableMDNIthrottling) {
        this.enableMDNIthrottling = enableMDNIthrottling;
    }
    List<StageXMLData> getStageXMLData(GenericDAOStageData dao) {
            long startTime = System.currentTimeMillis();
            List<StageXMLData> unprocessedJobs = dao.getAllUnprocessedJobs(IntegrationDataPayloadProcessor.MAXRETRYCOUNT, maxParallelRecordsToProcess);
            logger.info("Time taken to fetch the jobs for processing is: "+(System.currentTimeMillis() - startTime) + " ms");
            return unprocessedJobs;
    }

    private void populateFilteredList(List<StageXMLData> unprocessedRecords,
                                      List<String> objectDependencyOrderList) {

        for (int i = 0; i < unprocessedRecords.size(); i++) {
            StageXMLData stageXMLData = unprocessedRecords.get(i);

            Long tenantId = stageXMLData.getTenantId();
            String senderBusinessSystemId = stageXMLData.getSenderBusinesssytemId();

            /*
             * Load the static requests. If tenantId is 0 and
             * senderBusinessSystemId is null
             */
            if (tenantId == 0 && senderBusinessSystemId == null) {
                stageXMLDataRecordFilteredList.add(stageXMLData);
                continue;
            }

            String tenantIdAndSenderBusinessSystemId = tenantId + "_"
                    + senderBusinessSystemId;

            if (excludeTenantIdSenderBusinessIdList.contains(
                    tenantIdAndSenderBusinessSystemId)) {
                continue;
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug(
                            "Considerting the tenantid {} and senderBusinessSystemId {} . As no process is running. excludeTenantIdSenderBusinessIdList : {}",
                            tenantId,
                            senderBusinessSystemId,
                            excludeTenantIdSenderBusinessIdList);
                }
            }

            outerloop:
            for (String object : objectDependencyOrderList) {
                for (int j = 0; j < unprocessedRecords.size(); j++) {
                    StageXMLData stageXMLData1 = unprocessedRecords.get(j);
                    // find the lowest object for the same tenant id and system
                    // id
                    if (stageXMLData1.getTenantId() == tenantId) {
                        StageXMLData stageXMLDataLatestUpdated = stageXMLData1;
                        if (stageXMLData1.getSenderBusinesssytemId() != null
                                && stageXMLData1.getSenderBusinesssytemId().equalsIgnoreCase(
                                senderBusinessSystemId)) {
                            if (stageXMLData1.getObjectName().equalsIgnoreCase(object) ||
                                (object.equalsIgnoreCase("FMD") &&  HandlerUtil.isObjectFMDType(stageXMLData1.getObjectName()))
                               )
                               {
                                if (logger.isDebugEnabled())
                                    logger.debug(
                                            "Request found for tenantId {}, senderBusinessSystemId {} of object {} and Requst Id {}. So will be processing that.",
                                            stageXMLData1.getTenantId(),
                                            stageXMLData1.getSenderBusinesssytemId(),
                                            stageXMLData1.getObjectName(),
                                            stageXMLData1.getId());

                                excludeTenantIdSenderBusinessIdList.add(
                                        tenantIdAndSenderBusinessSystemId);

                                if (isRecordFullLoad(stageXMLData1)) {
                                    stageXMLDataLatestUpdated = processFullLoad(unprocessedRecords, stageXMLData1,false);
                                }

                                stageXMLDataRecordFilteredList.add(stageXMLDataLatestUpdated);
                                break outerloop;
                            }
                        } else if (stageXMLData1.getSenderBusinesssytemId() == null
                                && senderBusinessSystemId == null) {
                            if (stageXMLData1.getObjectName().equalsIgnoreCase(object) ||
                                (object.equalsIgnoreCase("FMD") &&  HandlerUtil.isObjectFMDType(stageXMLData1.getObjectName()))
                               ) {
                                if (logger.isDebugEnabled())
                                    logger.debug(
                                            "Request found for tenantId {}, senderBusinessSystemId {} of object {} and Requst Id {}. So will be processing that.",
                                            stageXMLData1.getTenantId(),
                                            stageXMLData1.getSenderBusinesssytemId(),
                                            stageXMLData1.getObjectName(),
                                            stageXMLData1.getId());

                                excludeTenantIdSenderBusinessIdList.add(
                                        tenantIdAndSenderBusinessSystemId);

                                if (isRecordFullLoad(stageXMLData1)) {
                                    stageXMLDataLatestUpdated = processFullLoad(unprocessedRecords, stageXMLData1,true);
                                }
                                stageXMLDataRecordFilteredList.add(stageXMLDataLatestUpdated);
                                break outerloop;
                            }
                        }

                    }
                }
                if (logger.isDebugEnabled())
                    logger.debug(
                            "Request not found for tenantId {}, senderBusinessSystemId {} of object {}. So will try for the next object.",
                            tenantId,
                            senderBusinessSystemId,
                            object);
            }

        }
    }

    public void postRecordForProcessing(long tenantId,
                                        String anId,
                                        String recordId,
                                        String processXMLURL) {
        String token = null;
        HttpHeaders headers = null;
        List<MediaType> acceptMediaTypes = null;
        MultiValueMap<String, String> parameters = null;

        acceptMediaTypes = new ArrayList<>();
        acceptMediaTypes.add(MediaType.APPLICATION_JSON);

        headers = new HttpHeaders();
        if(HandlerUtil.isMDCS()){
            token = mdcsOAuthManager.fetchToken(false);
        }else {
            token = getOAuthToken(anId);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("oAuth Token value : {} ", APIUtil.sanitizeInput(token));
        }

        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setAccept(acceptMediaTypes);
        headers.add("Authorization", token);

        parameters = new LinkedMultiValueMap<>();

        final HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<MultiValueMap<String, String>>(
                parameters,
                headers);
        // Issue POST requests asynchronously
        new Thread(() -> {
            try {
                logger.debug(
                        "Calling  postForLocation for recordId : {} , URL : {}",
                        recordId,
                        processXMLURL);
                logger.info("URL for posting processXML:" + getURL(tenantId, recordId, processXMLURL));
                logger.info("Request entity for posting processXML:" + requestEntity);
                new RestTemplate().postForLocation(
                        getURL(tenantId, recordId, processXMLURL),
                        requestEntity,
                        StageXMLData.class);
                logger.info("URL for posting new processXML:" + getURL(tenantId, recordId, processXMLURL));
                logger.info("Request entity for posting new processXML:" + requestEntity);
            }
            catch (RestClientException restClientException) {
                if (restClientException instanceof HttpStatusCodeException httpException) {
                    HttpHeaders responseHeaders = httpException.getResponseHeaders();
                    String isProcessingFailure = responseHeaders != null ?
                            responseHeaders.getFirst(ErrorUtil.X_PROCESSING_FAILURE) : null;
                    if (Boolean.valueOf(isProcessingFailure)) {
                        logger.error(" Failed to process integration data payload for recordId: {}, tenantId: {}, anId: {}",
                                recordId, tenantId, anId, restClientException);
                        return;
                    }
                }
                handleProcessXMLFailure(recordId, tenantId, anId, restClientException);
            }
        }).start();
    }

    private void handleProcessXMLFailure(String recordId, long tenantId, String anId, Exception e) {
        logger.error("Attempt to post processXML for recordId: {}, tenantId: {}, anId: {} failed. Setting the job to be processed again.",
                recordId, tenantId, anId, e);
        try {
            DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            GenericDAOStageData dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
            dao.updateStatus(recordId, StagingTableStatus.PENDING.getValue(), new Date());
        } catch (Exception daoException) {
            logger.error("Error updating record status in the database for recordId: {}, tenantId: {}, anId: {}.",
                    recordId, tenantId, anId, daoException);
        } finally {
            stopQuartzCurrentExecution = true;
        }
    }

    private String getURL(long tenantId, String recordId, String processXMLURL)
    {
         return new StringBuffer(
            processXMLURL + "?" + "RecordId=" + HandlerUtil.encodeParams(recordId)
                + "&TenantId=" + HandlerUtil.encodeParams(
                Long.toString(tenantId))).toString();
    }

    private String getOAuthToken(String anId) {
        oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(
                OAuthTokenManager.class);
        String token = OAuthTokenManager.getAccessTokenFromTokenMap(
                oAuthTokenManager.getTokens(anId, null));
        return token;
    }

    public void setMaxParallelRecordsToProcess(int maxParallelRecordsToProcess) {
        this.maxParallelRecordsToProcess = maxParallelRecordsToProcess;
    }

    public void setNumberofRecordsInProcessingStatus(int numberofRecordsInProcessingStatus) {
        this.numberofRecordsInProcessingStatus = numberofRecordsInProcessingStatus;
    }

    private StageXMLData processFullLoad(List<StageXMLData> unprocessedRecords, StageXMLData stageXMLDataToBeProcessed,boolean businessSystemIdNull) {
        StageXMLData stageXMLData =null;
        List<StageXMLData> listOfDuplicaRecords = findDuplicateRecordsForFullLoad(unprocessedRecords, stageXMLDataToBeProcessed,businessSystemIdNull);
        if (listOfDuplicaRecords.size() == 1) {
            stageXMLData = stageXMLDataToBeProcessed;
        } else if (listOfDuplicaRecords.size() > 1){
            stageXMLData = getLatestUpdatedRecord(listOfDuplicaRecords);
            logger.debug("Latest record {} picked for processing",stageXMLData.getId());
            //Mark the other records as Duplicate so that these are not picked for further processing
            updateStageXmlDataTabRecords(listOfDuplicaRecords.subList(0, listOfDuplicaRecords.size() - 1));
        }
        else{
            stageXMLData = stageXMLDataToBeProcessed;
            logger.info("Record {} was the most latest record for Full Load for object {}",stageXMLData.getId(),stageXMLData.getObjectName());
        }
        return stageXMLData;
    }


    private List<StageXMLData> findDuplicateRecordsForFullLoad(List<StageXMLData> unprocessedRecords, StageXMLData stageXMLDataToBeProcessed,boolean businessSystemIdNull) {
        List<StageXMLData> listOfDuplicateRecords = new ArrayList<StageXMLData>();
        for (StageXMLData unprocessedStageXMLData : unprocessedRecords) {
            if (isObjectsEqual(stageXMLDataToBeProcessed, unprocessedStageXMLData,businessSystemIdNull)) {
                listOfDuplicateRecords.add(unprocessedStageXMLData);
            }
        }
        return listOfDuplicateRecords;
    }

    private void updateStageXmlDataTabRecords(List<StageXMLData> listOfDuplicates) {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        GenericDAOStageData dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
        
        StageXMLData duplicateRecord = listOfDuplicates.get(0);
        String warnings = "Duplicate records found for full load of this object: "
            + duplicateRecord.getObjectName() + " for the given senderBusinessSystemID: "
            + duplicateRecord.getSenderBusinesssytemId() + " and tenantId: "
            + duplicateRecord.getTenantId()
            + " .Hence marking this job as duplicate and skipping"
            + " records from processing";
        List<String> warningsList = new ArrayList<String>();
        warningsList.add(warnings);
        			
        for (StageXMLData stageXMLData : listOfDuplicates) {
            logger.debug("Marking record {} as duplicate",stageXMLData.getId());
            stageXMLData.setStatus(StagingTableStatus.DUPLICATE.getValue());
            stageXMLData.setDateUpdated(new Date());
            dao.save(stageXMLData);            
            
            // create entry in integration job log table too
            IntegrationJobLogUtil.createIntegrationJobLogEntry(
                Utility.getANId(stageXMLData.getTenantId()),
                stageXMLData.getTenantId(),
                stageXMLData.getId(),
                stageXMLData.getSenderBusinesssytemId(),
                stageXMLData.getObjectName(),
                StagingTableStatus.DUPLICATE.getValue(),
                warningsList);
        }
    }

    private boolean isRecordFullLoad(StageXMLData stageXMLData) {
        return stageXMLData.getOperation() == IntegrationOperationType.FULLLOAD.getValue();
    }

    private StageXMLData getLatestUpdatedRecord(List<StageXMLData> listOfDuplicates) {
        return listOfDuplicates.get(listOfDuplicates.size() - 1);
    }

    private boolean isObjectsEqual(StageXMLData stageXMLDataToBeProcessed, StageXMLData unprocessedStageXMLData, boolean businessSystemIdNull) {
        boolean objectsEqual = false;
        if (stageXMLDataToBeProcessed.getTenantId() == unprocessedStageXMLData.getTenantId()) {
            if (!businessSystemIdNull) {
                if (stageXMLDataToBeProcessed.getSenderBusinesssytemId() != null
                        && stageXMLDataToBeProcessed.getSenderBusinesssytemId().equalsIgnoreCase(
                        unprocessedStageXMLData.getSenderBusinesssytemId())) {

                    if (stageXMLDataToBeProcessed.getObjectName().equalsIgnoreCase(unprocessedStageXMLData.getObjectName())) {
                        objectsEqual = true;
                    }
                }
            } else if (businessSystemIdNull &&
                    stageXMLDataToBeProcessed.getSenderBusinesssytemId() == null
                    && unprocessedStageXMLData.getSenderBusinesssytemId() == null) {
                  if (stageXMLDataToBeProcessed.getObjectName().equalsIgnoreCase(unprocessedStageXMLData.getObjectName())) {
                    objectsEqual = true;
                  }
            }
        }
        return objectsEqual;
    }

    public void setMdniServiceRegistry(MDNIServiceRegistry mdniServiceRegistry) {
        this.mdniServiceRegistry = mdniServiceRegistry;
    }
}
