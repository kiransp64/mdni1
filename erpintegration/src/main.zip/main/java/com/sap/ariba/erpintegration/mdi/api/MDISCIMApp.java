package com.sap.ariba.erpintegration.mdi.api;

import com.sap.ariba.erpintegration.mdi.scim.resource.manager.SCIMGroupEntityManager;
import com.sap.ariba.erpintegration.mdi.scim.resource.manager.SCIMUserEntityManager;
import com.sap.scimono.SCIMApplication;
import com.sap.scimono.callback.groups.GroupsCallback;
import com.sap.scimono.callback.schemas.SchemasCallback;
import com.sap.scimono.callback.users.UsersCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component(value = "scimApplication")
public class MDISCIMApp extends SCIMApplication
{
    @Autowired
    @Qualifier("scimSchemasCallback")
    private SchemasCallback scimSchemasCallback;

    @Autowired
    private SCIMUserEntityManager scimUsersCallback;

    @Autowired
    private SCIMGroupEntityManager scimGroupsCallback;

    @Override
    public SchemasCallback getSchemasCallback ()
    {
        return scimSchemasCallback;
    }

    @Override
    public UsersCallback getUsersCallback ()
    {
        return scimUsersCallback;
    }

    @Override
    public GroupsCallback getGroupsCallback ()
    {
        return scimGroupsCallback;
    }

}
