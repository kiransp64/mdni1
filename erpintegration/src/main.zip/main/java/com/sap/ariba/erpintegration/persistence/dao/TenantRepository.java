package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.Tenant;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by i318483 on 19/06/17.
 */
@Component("TenantRepositoryComponent")
public interface TenantRepository extends GenericDataDao<Tenant>
{
    @Query("select C from Tenant C where C.anId = :anId")
    Tenant findOne(@Param("anId") String anId);

    @Query("select C from Tenant C where C.tenantId = :tenantId")
    Tenant findOne(@Param("tenantId") long tenantId);

    @Query("select C from Tenant C where C.status = :status")
    List<Tenant> findAll (@Param("status") int status);
    
    @Query("select id,dateCreated,dateUpdated from Tenant s where tenantId = :tenantId order by id desc")
    public Page<Tenant> findKeyFieldsOfAllRecords(@Param("tenantId") long tenantId, Pageable pageable);

    @Modifying
    @Transactional(readOnly = false)
    @Query("Update Tenant t SET t.isActive = 0 where t.tenantId IN (:tenantIds)")
    public int deactivateTenants(@Param("tenantIds") List<Long> tenantIds);

    @Query("select t.tenantId from Tenant t where t.anId IN (:anIds)")
    List<Long> getTenantIds (@Param("anIds") List<String> anIds);
    
    @Query("select C from Tenant C where C.mdiEnabled = :mdiEnabled")
    List<Tenant> findAllMdiEnabledTenants (@Param("mdiEnabled") String mdiEnabled);
    
    @Query("select C from Tenant C where C.mdiEnabled = :mdiEnabled and C.isActive = :isActive ORDER BY C.mdiProcessTime ASC")
    List<Tenant> findNexActivetMDITenantsToBeProcessed (@Param("mdiEnabled") String mdiEnabled, @Param("isActive") int isActive, Pageable pageRequest);

    @Query("SELECT c FROM Tenant c WHERE c.purgeStatus IN (:purgeStatuses) ORDER BY c.dateUpdated ASC")
    List<Tenant> findTenantsWithPurgeStatuses (@Param("purgeStatuses") List<String> purgeStatuses, Pageable pageable);

    @Transactional
    long deleteByTenantId(long tenantId);
}
