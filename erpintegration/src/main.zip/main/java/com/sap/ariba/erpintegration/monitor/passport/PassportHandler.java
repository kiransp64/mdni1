/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.monitor.passport;

import com.sap.ariba.erpintegration.monitor.exception.PassportException;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.passport.core.persistance.Passport;
import com.sap.ariba.integrationmonitoring.bean.PassportBean;
import java.util.List;

/**
 * This interface will help to handle Passport related logic.
 */
public interface PassportHandler
{
    PassportBean getPassportFromToken (String sapPassportToken) throws PassportException;

    String getPassportTokenFromPassportBean (PassportBean passportBean) throws PassportException;

    String getOutBoundSAPPassportToken (String sapPassportToken) throws PassportException;

    String createInitialPassport (IntegrationContext integrationContext) throws PassportException;

    void savePassportTokenBasedOnJobID (String jobId) throws PassportException;

    void savePassportTokenAndSourceEventIdBasedOnJobId (String jobId,String sourceEventId) throws PassportException;

    void deletePassportTokenBasedOnJobID (String jobId) throws PassportException;

    String getOutBoundPassportTokenBasedOnJobID (String jobId) throws PassportException;

    Passport getPassportTokenBasedOnJobID (String jobId) throws PassportException;

    List<Passport> getAllPassportData() throws PassportException;
}
