package com.sap.ariba.erpintegration.service.ws;

import com.sap.ariba.erpintegration.persistence.model.UserExport.UserExportData;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import jakarta.annotation.Resource;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.xml.ws.WebServiceContext;
import jakarta.xml.ws.handler.MessageContext;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by c5259108 on 04/12/17.
 */
public class UserIntegrationServiceImpl implements UserIntegrationService {

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.service.ws.UserIntegrationServiceImpl";
    private static final Logger logger = LoggerFactory.getLogger(
        nameOfLogger);
    private static final String urlReplacementStringForObject = "getUsers";
    private static final String lastBaseIdKey = "lastBaseId";

    @Resource
    private WebServiceContext ctx;

    public List<UserExportData> getUsers() throws IntegrationServiceException {

        HttpServletRequest request = (HttpServletRequest) ctx.getMessageContext().get(MessageContext.SERVLET_REQUEST);
        HttpServletResponse response = (HttpServletResponse) ctx.getMessageContext().get(MessageContext.SERVLET_RESPONSE);
        String anID = request.getParameter(Constants.KeyTenantId);
        Map<String, String> responseHeaderMap = new HashMap<>();

        if (anID == null || anID.length() == 0) {
            logger.error("[MDNI_CRITICAL][ARIBA][Processing] Empty tenant Passed");
            throw new IntegrationServiceException("Empty tenant Passed");
        }

        if(!Utility.isTenantExists(anID)){
            logger.error("[MDNI_CRITICAL][ARIBA][Processing] Tenant - {}, anID not available in TENANT_TAB Table",
                         anID);
            throw new IntegrationServiceException("Tenant not recognized for " + anID);
        }

        String lastBaseIdSentFromClient = request.getParameter(HandlerUtil.lastBaseIdSentFromClientKey);
        String userUniqueNameSentFromClient = request.getParameter(HandlerUtil.userUniqueNameSentFromClientKey);

        List<UserExportData> userList = new ArrayList<UserExportData>();
        ObjectMapper mapper = new ObjectMapper();
        UserExportData user;
        JSONArray jsonUsersArray;
        try {
            responseHeaderMap.put(lastBaseIdKey, "");
            jsonUsersArray = HandlerUtil.getDataFromBuyerForUser(
                anID,
                lastBaseIdSentFromClient,
                userUniqueNameSentFromClient,
                urlReplacementStringForObject,
                responseHeaderMap);
            if (jsonUsersArray != null) {
                for (int i = 0; i < jsonUsersArray.length(); i++) {
                    if (jsonUsersArray.getJSONObject(i) instanceof JSONObject) {
                        user = mapper.readValue(jsonUsersArray.getJSONObject(i).toString(), UserExportData.class);
                        userList.add(user);
                    }
                }
            }
        } catch (IOException ex) {
            logger.warn("[MDNI_CRITICAL][ARIBA][Processing] Tenant ID - {} Exception {} while parsing User Data ",
                        anID,
                        ErrorUtil.getCompleteCausedByErrors(ex));
            throw new IntegrationServiceException(ex.getMessage());
        }
        catch (GeneralSecurityException ex){
            logger.warn("[MDNI_CRITICAL][ARIBA][Processing] Tenant ID - {} Exception {} while parsing User Data ",
                        anID,
                        ErrorUtil.getCompleteCausedByErrors(ex));
            throw new IntegrationServiceException(ex.getMessage());
        }

        if (!StringUtils.isEmpty(responseHeaderMap.get(lastBaseIdKey))) {
            response.setHeader(
                lastBaseIdKey,
                HandlerUtil.encodeParams(responseHeaderMap.get(lastBaseIdKey)));
        }
        return userList;
    }
}


