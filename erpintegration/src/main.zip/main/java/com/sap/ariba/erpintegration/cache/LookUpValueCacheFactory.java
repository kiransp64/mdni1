package com.sap.ariba.erpintegration.cache;

public class LookUpValueCacheFactory
{
    public static LookUpValueCache getLookUpValueCache ()
    {
        return new LookUpValueCacheImpl();
    }
}
