package com.sap.ariba.erpintegration.processor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.SchemaRepository;
import com.sap.ariba.erpintegration.persistence.model.Schema;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.util.XMLUtil;
import org.apache.commons.io.FilenameUtils;
import org.apache.xerces.dom.DeferredElementImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sap.ariba.erpintegration.service.exception.XMLPayloadHandlerException;
import com.thaiopensource.util.PropertyMapBuilder;
import com.thaiopensource.validate.SchemaReader;
import com.thaiopensource.validate.ValidateProperty;
import com.thaiopensource.validate.ValidationDriver;
import com.thaiopensource.validate.auto.AutoSchemaReader;
import com.thaiopensource.xml.sax.ErrorHandlerImpl;

/**
 * Created by i318483 on 11/22/16.
 */
public class XMLSchemaValidator
{
    public static final String UUID_KEY = "UUID";
    public static final String RNGFILEEXTN = ".rng";
    public static final String XMLFILEEXTN_KEY = ".xml";
    public static final String JSONFILEEXTN_KEY = ".json";
    public static final String JSONDIR_KEY = "json/";
    public static final String SCHEMADIR_KEY = "schema";
    public static final String RNGFilesDirectory = "RNGFiles";
    public static final String WSDLFilesDirectory = "WSDL";
    private String xmlPayload;
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.processor.XMLSchemaValidator";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    private String objectName = null;
    private String senderBusinessSystemID = null;
    private String anId = null;

    private static final String BASE_PATH = "/tmp/nfs/";
    private static final String SCHEMA_PATH = "/schema";
    private static final String FORWARD_SLASH = "/";

    public XMLSchemaValidator (String objectName, String senderBusinessSystemID, String xmlPayload, String anId)
    {
        this.objectName = objectName;
        this.senderBusinessSystemID = senderBusinessSystemID;
        this.xmlPayload = xmlPayload;
        this.anId = anId;
    }

    public boolean validate (ErrorHandlerImpl eh) throws XMLPayloadHandlerException
    {
        boolean isValid = false;
      //  BufferedWriter outWriter = null;
       // FileWriter fileWriter = null;
        String variantRNGPath = null;
        File rngFile = null;
        InputStream inputStream = null;
        try {
            // Get the variant rng path
            variantRNGPath = this.prepareVariantPath();
            if (logger.isDebugEnabled())
                logger.debug(
                    "varient rng path for objectName {} and anId {} is {}",
                    this.objectName,
                    this.anId,
                        variantRNGPath);

            if (!StringUtils.isEmpty(variantRNGPath) && isFileExist(variantRNGPath)) {
                if (logger.isDebugEnabled())
                    logger.debug(
                        "varient rng file found for objectName {} and anId {}",
                        this.objectName,
                        this.anId);
                // variant file is present for the tenant. We have to use file
                // configured by the customer
                String normalizedFileName = FilenameUtils.normalize(variantRNGPath);
                rngFile = new File(normalizedFileName);
                if (logger.isDebugEnabled())
                    logger.debug(
                        "Location of the file used {}",
                        rngFile.getAbsolutePath());
            }
            else {
                if (logger.isDebugEnabled())
                    logger.debug(
                        """
                        varient rng file not found for objectName {} and anId {} - \
                        Hence going to use the default file from resources/RNGFiles folder \
                        """,
                        this.objectName,
                        this.anId);
                // we can use the default file there in the application
                ClassPathResource classPathResource = new ClassPathResource(RNGFilesDirectory + FORWARD_SLASH + objectName + RNGFILEEXTN);
                inputStream = classPathResource.getInputStream();
                if(inputStream == null){
                    throw new FileNotFoundException(
                            "File " + objectName + RNGFILEEXTN + " not found under resources/"
                                    + RNGFilesDirectory);
                }

                rngFile = XMLUtil.convertStreamToFile(inputStream,objectName,RNGFILEEXTN);

                if (logger.isDebugEnabled())
                    logger.debug(
                        "Location of the file used {}",
                        rngFile.getAbsolutePath());
            }

            String normalizedXmlFileName;
            if (!StringUtils.isEmpty(this.senderBusinessSystemID)) {
                normalizedXmlFileName = FilenameUtils.normalize(this.objectName + "_" + this.senderBusinessSystemID);
            }
            else{
                normalizedXmlFileName = FilenameUtils.normalize(this.objectName);
            }
            String normalizedXmlFileExtension = FilenameUtils.normalize(XMLFILEEXTN_KEY);

            Path tempXmlFilePath = Files.createTempFile(
                normalizedXmlFileName,
                normalizedXmlFileExtension);
            File tempXmlFile = tempXmlFilePath.toFile();
            tempXmlFile.deleteOnExit();
            try (FileWriter fileWriter = new FileWriter(tempXmlFile);
                            BufferedWriter outWriter = new BufferedWriter(fileWriter)) {
                outWriter.write(xmlPayload);
                outWriter.flush();
            }

            PropertyMapBuilder properties = new PropertyMapBuilder();
            ValidateProperty.ERROR_HANDLER.put(properties, eh);

            SchemaReader sr = new AutoSchemaReader();
            ValidationDriver driver = new ValidationDriver(
                properties.toPropertyMap(),
                sr);
            InputSource inRng = ValidationDriver.fileInputSource(rngFile);

            driver.loadSchema(inRng);
            InputSource inXml = ValidationDriver.fileInputSource(tempXmlFile);

            if (driver.validate(inXml)) {
                isValid = true;
                if (logger.isDebugEnabled())
                    logger.debug("Validation passed for xml {} , validating against rng file {} ",
                            tempXmlFile.getAbsolutePath(),
                            rngFile.getAbsolutePath());

            }
            else {
                if (logger.isDebugEnabled())
                    logger.debug("Validation failed for xml {} , validating against rng file {} ",
                            tempXmlFile.getAbsolutePath(),
                            rngFile.getAbsolutePath());
            }
        }
        catch (FileNotFoundException ex) {
            logger.warn(ex.getMessage());
            throw new XMLPayloadHandlerException(ex.getMessage());
        }
        catch (IOException ex) {
            logger.warn(ex.getMessage());
            throw new XMLPayloadHandlerException(ex.getMessage());
        }
        catch (SAXException ex) {
            logger.warn(ex.getMessage());
            throw new XMLPayloadHandlerException(ex.getMessage());
        }
        return isValid;
    }

    public static String getValueForTag (String fileLocation, String tagName)
    {
        DocumentBuilder builder;
        DocumentBuilderFactory factory;
        String value = null;
        try (FileInputStream is = new FileInputStream(new File(fileLocation))) {

            factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(true);
            String FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
            factory.setFeature(FEATURE, true);

            FEATURE = "http://xml.org/sax/features/external-general-entities";
            factory.setFeature(FEATURE, false);

            FEATURE = "http://xml.org/sax/features/external-parameter-entities";
            factory.setFeature(FEATURE, false);

            FEATURE = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
            factory.setFeature(FEATURE, false);

            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            builder = factory.newDocumentBuilder();

            Document xmlDoc = builder.parse(is);
            value = getValueForTag(xmlDoc, tagName);
        }
        catch (FileNotFoundException | ParserConfigurationException | NullPointerException | UnsupportedOperationException e) {
            logger.warn(
                "Error while reading parameter " + tagName + " " + e.getMessage());
        }
        catch (Exception e) {
            logger.warn(
                "Error while reading parameter " + tagName + " " + e.getMessage());
        }

        return value;
    }

    public static String getValueForTag (Document wsdlDoc, String tagName)
    {
        Element element = wsdlDoc.getDocumentElement();
        Node node = element.getElementsByTagName(tagName).item(0);
        return ((DeferredElementImpl)node).item(0).getNodeValue();
    }

    private String prepareVariantPath ()
    {
        if (logger.isDebugEnabled()) {
            logger.debug("variant RNG file path fetch start ");
        }

        String path = null;

        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        SchemaRepository schemaRepository = (SchemaRepository) factory.getMiscDAO(ObjectTypes.Schema.getValue());
        long tenantId = Utility.getTenantId(anId);
        Schema schema = null;
        if(!StringUtils.isEmpty(this.senderBusinessSystemID)){
            if (logger.isDebugEnabled()) {
                logger.debug("Get variant RNG file for objectName {} ,considering the senderBusinessSystemId {} , passed in the request",
                        objectName,
                        senderBusinessSystemID);
            }

            schema = schemaRepository.findOne(tenantId,objectName,senderBusinessSystemID);

            if(schema ==null){
                if (logger.isDebugEnabled()) {
                    logger.debug("""
                            Entry null for objectName {} and  senderBusinessSystemId {} combination, \
                            Try fetching variant RNG file path without senderBusineddSystemId \
                            """,
                            objectName,
                            senderBusinessSystemID);
                }
                schema = schemaRepository.findOne(tenantId,objectName);
            }
        }
        else{
            if (logger.isDebugEnabled()) {
                logger.debug("""
                        SenderBusinessSystemId is null in the Request,\
                        hence fetching SCHEMA_TAB Table with only objectName for {}\
                        """,objectName);
            }
            schema = schemaRepository.findOne(tenantId,objectName);
        }

        if(schema!=null) {
            path = renameFileXSDtoRNG(schema.getPath());

            if (logger.isDebugEnabled()) {
                logger.debug("variant RNG file path for objectName {} is {}", objectName,path);
            }
        }
        else{
            if (logger.isDebugEnabled()) {
                logger.debug("Fetching the path from SCHEMA_TAB failed for objectName {} ",objectName);
            }
        }

        if (logger.isDebugEnabled()) {
            logger.debug("variant RNG file path fetch end ");
        }

       return path;
    }

    private boolean isFileExist (String path)
    {
        String normalizedFileName = FilenameUtils.normalize(path);
        File f = new File(normalizedFileName);
        return f.exists() && !f.isDirectory();
    }

    private String renameFileXSDtoRNG(String filePath){
        return filePath.replaceFirst("xsd","rng");
    }
}
