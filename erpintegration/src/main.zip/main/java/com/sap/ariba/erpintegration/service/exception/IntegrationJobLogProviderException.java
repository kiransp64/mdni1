package com.sap.ariba.erpintegration.service.exception;

/**
 * Created by i318483 on 31/05/17.
 */
public class IntegrationJobLogProviderException extends Exception
{
    private static final long serialVersionUID = 1L;

    public IntegrationJobLogProviderException (Exception e)
    {
        super(e);
    }

    public IntegrationJobLogProviderException (String message)
    {
        super(message);
    }

    public IntegrationJobLogProviderException (String message, Exception e)
    {
        super(message, e);
    }
}
