package com.sap.ariba.erpintegration.onemds.tenant;

import com.sap.ariba.erpintegration.mdi.cap.config.MDCSSecretsManager;
import com.sap.ariba.erpintegration.mdi.cap.config.ServiceBinding;
import com.sap.ariba.erpintegration.mdi.cap.util.MdcsConstants;
import com.sap.ariba.erpintegration.onemds.exception.TenantServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import javax.json.JsonObject;

@Component
@ConditionalOnExpression("${environment.mdcs:false}==true")
@Qualifier("mdcsDestinationTenantService")
public class MDCSDestinationTenantServiceImpl extends TenantServiceImpl
{
    private static final Logger logger = LoggerFactory.getLogger(
        MDCSDestinationTenantServiceImpl.class);

    @Override
    public String getAppURL (String tenantID) throws TenantServiceException
    {
        ServiceBinding serviceBinding = MDCSSecretsManager.getServiceBinding(
            MdcsConstants.DESTINATION);
        JsonObject destinationConfig = serviceBinding.getSecrets();
        return destinationConfig.getString(MdcsConstants.URI);
    }

    @Override
    public String getClientID (String tenantID) throws TenantServiceException
    {
        ServiceBinding serviceBinding = MDCSSecretsManager.getServiceBinding(
            MdcsConstants.DESTINATION);
        JsonObject destinationConfig = serviceBinding.getSecrets();
        return destinationConfig.getString(MdcsConstants.CLIENTID);

    }

    @Override
    public String getClientSecret (String tenantID) throws TenantServiceException
    {
        ServiceBinding serviceBinding = MDCSSecretsManager.getServiceBinding(
            MdcsConstants.DESTINATION);
        JsonObject destinationConfig = serviceBinding.getSecrets();
        return destinationConfig.getString(MdcsConstants.CLIENTSECRET);

    }

    @Override
    public String getAuthURL (String tenantID) throws TenantServiceException
    {
        ServiceBinding serviceBinding = MDCSSecretsManager.getServiceBinding(
            MdcsConstants.DESTINATION);
        JsonObject destinationConfig = serviceBinding.getSecrets();
        return destinationConfig.getString(MdcsConstants.URL);

    }
    /*
     * This method should always return true for MDCS use cases. This method in Base class is meant
     * for Ariba flow only to validate whether tenant configuration for this tenant in
     * Buyer exists or not .
     */

    @Override
    public boolean isTenantValid (String tenantID) throws TenantServiceException
    {
        return true;
    }


}
