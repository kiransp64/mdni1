package com.sap.ariba.erpintegration.meta;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlValue;

/**
 * Created by i318483 on 07/06/17.
 */
public class Field
{
    private String name;
    private String field;

    @XmlValue
    public String getField ()
    {
        return field;
    }

    public void setField (String field)
    {
        this.field = field;
    }

    @XmlAttribute
    public String getName ()
    {

        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }
}
