package com.sap.ariba.erpintegration.reencryption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.sap.ariba.encryption.config.KeyConfiguration;
import com.sap.ariba.erpintegration.encryption.MDNIEncryptionService;
import com.sap.ariba.security.encryption.EncryptionService;
import com.sap.ariba.security.encryption.config.ServiceConfig;

@Component
@ConditionalOnProperty(name = "reEncryption", havingValue="true")
public class ReEncryptionKeyConfiguration implements KeyConfiguration
{
    @Autowired
    MDNIEncryptionService reEncryptionService;

    @Override
    public ServiceConfig getDecryptKeyServiceConfig ()
    {
        // MDNI need not implement this and is used only for testing purpose
        return null;
    }

    @Override
    public ServiceConfig getEncryptKeyServiceConfig ()
    {
        //  MDNI need not implement this and is used only for testing purpose
        return null;
    }

    @Override
    public EncryptionService getEncryptionService ()
    {
        // Returns encryption service object
        return reEncryptionService.getEncryptionService();
    }

}
