package com.sap.ariba.erpintegration.persistence.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * This the POJO for AUDIT_TAB
 * 
 * @author i339952
 */

@Entity
@Table(name = "AUDIT_TAB")
@DiscriminatorValue("b")
public class Audit implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String objectType = "Audit";
    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "DATE_CREATED")
    private Date dateCreated;

    @Column(name = "DATE_UPDATED")
    private Date dateUpdated;

    @Column(name = "TENANT_ID")
    private long tenantId;

    @Column(name = "OPERATION_ID")
    private long operationId;

    @Column(name = "OPERATION_NAME")
    private String operationName;

    @Column(name = "AUDIT_COMMENT")
    private String comment;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public Date getDateCreated ()
    {
        return dateCreated;
    }

    public void setDateCreated (Date dateCreated)
    {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated ()
    {
        return dateUpdated;
    }

    public void setDateUpdated (Date dateUpdated)
    {
        this.dateUpdated = dateUpdated;
    }

    public long getTenantId ()
    {
        return tenantId;
    }

    public void setTenantId (long tenantId)
    {
        this.tenantId = tenantId;
    }

    public long getOperationId ()
    {
        return operationId;
    }

    public void setOperationId (long operationId)
    {
        this.operationId = operationId;
    }

    public String getOperationName ()
    {
        return operationName;
    }

    public void setOperationName (String operationName)
    {
        this.operationName = operationName;
    }

    public String getComment ()
    {
        return comment;
    }

    public void setComment (String comment)
    {
        this.comment = comment;
    }

    public String getObjectType ()
    {
        return objectType;
    }

}
