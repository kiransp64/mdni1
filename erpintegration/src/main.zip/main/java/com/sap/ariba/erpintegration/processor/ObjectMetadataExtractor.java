package com.sap.ariba.erpintegration.processor;

import com.sap.ariba.erpintegration.util.XMLUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by i318483 on 12/14/16.
 */
public class ObjectMetadataExtractor
{
    private static final String complexTypeTagName = "xsd:complexType";
    private static final String nameAttribute = "name";
    private static final String typeAttribute = "type";
    private static final String simpleTypeTagName = "xsd:simpleType";

    private List<Map<String, String>> defaultFields;
    private String metadataForObject =  null;
    private String objectName =  null;
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.processor.ObjectMetadataExtractor";
    private static final Logger logger = LoggerFactory.getLogger(
            nameOfLogger);

    public void setDefaultFields(List<Map<String, String>> defaultFields)
    {
        this.defaultFields = defaultFields;
    }

    public List<Map<String, String>> getDefaultFields ()
    {
        return this.defaultFields;
    }

    public String getObjectNameForExtractedMetadata ()
    {
        return this.metadataForObject;
    }

    public String getObjectName ()
    {
        return this.objectName;
    }

    public void generateObjectDefinitionFromSchema (String baseDir, File xsdFile, boolean writeToFile)
    {
        Node objectNode = null;
        Node actualObjectNode = null;
        FileOutputStream fs = null;
        FileInputStream is = null;

        List<String> types = new ArrayList<>();
        try {
            is = new FileInputStream(xsdFile);;
            Document xsdDoc = XMLUtil.getDocBuilder().parse(is);

            Document objectMetadataDoc = XMLUtil.getDocBuilder().newDocument();
            Element root = objectMetadataDoc.createElement("xsd:schema");
            root.setAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
            objectMetadataDoc.appendChild(root);

            Element rootElement = xsdDoc.getDocumentElement();
            if (rootElement.hasAttributes()) {
                NamedNodeMap namedNodeMap = rootElement.getAttributes();
                for (int j = 0; j < namedNodeMap.getLength(); j++) {
                    Node attrNode = namedNodeMap.item(j);
                    String attrName = attrNode.getNodeName();
                    String attrValue = attrNode.getNodeValue();
                    root.setAttribute(attrName, attrValue);
                }
            }

            Node objectRootNode = objectMetadataDoc.importNode(rootElement.getFirstChild().getNextSibling(), true);
            root.appendChild(objectRootNode);

            //Get the top level ComplexType
            logger.info(rootElement.getTagName() + " , " + rootElement.getFirstChild().getNodeName() + " , " +
                rootElement.getFirstChild().getNextSibling().getNodeName() + " , " + rootElement.getFirstChild().getNextSibling().getAttributes());
            if (rootElement.getFirstChild().getNodeName().indexOf("text") != -1) {
                objectName = rootElement.getFirstChild().getNextSibling().getAttributes().getNamedItem(
                    typeAttribute).getNodeValue();
            }
            else {
                objectName = rootElement.getFirstChild().getAttributes().getNamedItem(
                    typeAttribute).getNodeValue();
            }

            //Navigate through all complexTypes and find out the matching node for top level ComplexType
            NodeList nodeList = xsdDoc.getElementsByTagName(complexTypeTagName);
            for (int i=0; i<nodeList.getLength(); i++) {
                String value = nodeList.item(i).getAttributes().getNamedItem(
                    nameAttribute).getNodeValue();
                if (value.equals(objectName)) {
                    objectNode = nodeList.item(i);
                    objectRootNode = objectMetadataDoc.importNode(objectNode, false);
                    //Don't add it to the result doc yet as it has to hold the actual Node
                    break;
                }
            }

            if (objectNode == null) {
                nodeList = xsdDoc.getElementsByTagName(complexTypeTagName);
                for (int i=0; i<nodeList.getLength(); i++) {
                    String value = nodeList.item(i).getAttributes().getNamedItem(
                        nameAttribute).getNodeValue();
                    if (value.equals(objectName)) {
                        objectNode = nodeList.item(i);
                        objectRootNode = objectMetadataDoc.importNode(objectNode, false);
                        //Don't add it to the result doc yet as it has to hold the actual Node
                        break;
                    }
                }
            }

            logger.info("Objectname " + objectName);

            //Get the child nodes of above complexType node
            //Navigate through all child nodes and find out an element which has non-null maxOccurs attribute.
            //This node holds actual object definition

            if(objectNode != null){

                NodeList objectNodeElements = objectNode.getChildNodes();
                actualObjectNode = getNode(
                        actualObjectNode,
                        objectMetadataDoc,
                        root,
                        objectRootNode,
                        objectNodeElements);

            if (actualObjectNode == null) {

                //Get the child nodes of above complexType node
                //Navigate through all child nodes and find out an element which has non-null maxOccurs attribute.
                //This node holds actual object definition
                boolean foundMaxOccurs = false;
                objectNodeElements = objectNode.getChildNodes();
                for (int i=0; i<objectNodeElements.getLength(); i++) {
                    Node element = objectNodeElements.item(i);
                    //logger.info("Element " + element.getAttributes().getNamedItem("name"));
                    Node sequenceNode = objectMetadataDoc.importNode(element,
                        false);
                    if (element.hasChildNodes()) {
                        NodeList objectNodeChildElements = element.getChildNodes();
                        for (int j=0; j<objectNodeChildElements.getLength(); j++) {
                            Node element1 = objectNodeChildElements.item(j);
                            logger.info(element1.getNodeName());
                            //logger.info("Elements " + element1.getAttributes().getNamedItem("name"));
                            if (element1.getAttributes() != null && element1.getAttributes().getNamedItem("maxOccurs")
                                != null) {
                                actualObjectNode = element1;
                                metadataForObject =  actualObjectNode.getAttributes().getNamedItem(nameAttribute).getNodeValue();
                                Node toAdded2 = objectMetadataDoc.importNode(actualObjectNode, true);
                                objectRootNode.appendChild(sequenceNode);
                                sequenceNode.appendChild(toAdded2);
                                root.appendChild(objectRootNode);
                                foundMaxOccurs = true;
                                break;
                                } else if (element1.getAttributes() != null
                                && element1.getAttributes().getNamedItem(typeAttribute) != null
                                && element1.getAttributes().getNamedItem(nameAttribute) != null) {
                                String objectType = element1.getAttributes().getNamedItem(typeAttribute).getNodeValue();
                                objectName = element1.getAttributes().getNamedItem(nameAttribute).getNodeValue();

                                logger.info(objectType + "=====" + objectName);

                                if (objectName != null && !objectName.equals("MessageHeader")) {
                                    nodeList = xsdDoc.getElementsByTagName(complexTypeTagName);
                                    for (int k=0; k<nodeList.getLength(); k++) {
                                        Node endNode =  nodeList.item(k);
                                        logger.info(endNode.getNodeName());
                                        if (nodeList.item(k).getAttributes() == null
                                            || nodeList.item(k).getAttributes().getNamedItem(
                                            nameAttribute) == null)
                                            continue;

                                        String value = nodeList.item(k).getAttributes().getNamedItem(
                                            nameAttribute).getNodeValue();
                                        if (value.equals(objectType)) {
                                            objectNode = nodeList.item(k);
                                            objectRootNode = objectMetadataDoc.importNode(objectNode, false);
                                            objectNodeElements = objectNode.getChildNodes();

                                            actualObjectNode = getNode(
                                                actualObjectNode,
                                                objectMetadataDoc,
                                                root,
                                                objectRootNode,
                                                objectNodeElements);

                                            //Don't add it to the result doc yet as it has to hold the actual Node
                                            if (actualObjectNode != null) {
                                                foundMaxOccurs = true;
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (foundMaxOccurs) {
                        break;
                    }
                }

                }
            }

            logger.info("Objectname " + objectName);

            if (!writeToFile)
                return;

            String actualNodeName = null;
            //Get the type from above Element node. This will be the actual object definition.
            if(actualObjectNode!=null && actualObjectNode.getAttributes()!=null) {
                actualNodeName = actualObjectNode.getAttributes().getNamedItem(
                        typeAttribute).getNodeValue();
            }

            //Navigate through all the child nodes of actual object node.
            //Add them to the result doc also populate the list of simple/complex types that have to be added later to the result doc
            for (int i=0; i<nodeList.getLength(); i++) {
                if (nodeList.item(i).getAttributes().getNamedItem(nameAttribute).getNodeValue().equals(actualNodeName)) {
                    objectNode = nodeList.item(i);
                    populateChildNodes(types, objectNode, null);
                    objectRootNode = objectMetadataDoc.importNode(objectNode, true);
                    //appendDefaultNodes(objectRootNode, objectMetadataDoc);
                    root.appendChild(objectRootNode);
                    break;
                }
            }

            //Navigate through all complex types from the document
            //Add nodes with matching name with the types populated above.
            appendRequiredTypes(objectMetadataDoc, root, nodeList, types);

            nodeList = xsdDoc.getElementsByTagName(simpleTypeTagName);
            //Navigate through all the simple types from the document
            //Add nodes with matching name to the types populated above.
            appendRequiredTypes(objectMetadataDoc, root, nodeList, types);

            appendTypesForDefaultNodes(root, objectMetadataDoc);

            fs = new FileOutputStream(new File(baseDir + "/" + metadataForObject + ".xsd"));
            XMLUtil.writeToStream(objectMetadataDoc, fs);
            fs.close();
            is.close();
        } catch (IOException | TransformerFactoryConfigurationError | TransformerException e) {
            StringWriter sw = new StringWriter();
            logger.warn(e.getMessage());
        } catch(Exception e) {
            StringWriter sw = new StringWriter();
            logger.warn(e.getMessage());
        }
        finally {
            try {
                if (fs != null) {
                    fs.flush();
                    fs.close();
                }
                if (is != null) {
                    is.close();
                }
            }
            catch(IOException ex)
            {
                logger.warn(ex.getMessage());
            }
        }
    }

    private Node getNode (Node actualObjectNode,
                          Document objectMetadataDoc,
                          Element root,
                          Node objectRootNode,
                          NodeList objectNodeElements)
    {
        for (int i=0; i<objectNodeElements.getLength(); i++) {
            Node element = objectNodeElements.item(i);
            logger.info(element.getNodeName());
            //logger.info("Element " + element.getAttributes().getNamedItem("name"));
            Node sequenceNode = objectMetadataDoc.importNode(element,
                false);
            if (element.hasChildNodes()) {
                NodeList objectNodeChildElements = element.getChildNodes();
                for (int j=0; j<objectNodeChildElements.getLength(); j++) {
                    Node element1 = objectNodeChildElements.item(j);
                    //logger.info("Elements " + element1.getAttributes().getNamedItem("name"));
                    if (element1.getAttributes() != null && element1.getAttributes().getNamedItem("maxOccurs")
                        != null) {
                        actualObjectNode = element1;
                        metadataForObject =  actualObjectNode.getAttributes().getNamedItem(nameAttribute).getNodeValue();
                        Node toAdded2 = objectMetadataDoc.importNode(actualObjectNode, true);
                        objectRootNode.appendChild(sequenceNode);
                        sequenceNode.appendChild(toAdded2);
                        root.appendChild(objectRootNode);
                        break;
                    }
                }
            }
        }
        return actualObjectNode;
    }

    private void populateChildNodes (List<String> types,
                                            Node node,
                                            String value)
    {
        if(node.hasChildNodes()) {
            NodeList childNodes = node.getChildNodes();
            for (int k = 0; k < childNodes.getLength(); k++) {
                Node innerNode = childNodes.item(k);
                populateChildNodes(types, innerNode, value);
                populateTypes(types, innerNode);
            }
        }
        types.remove(value);
    }

    private void appendRequiredTypes (Document resultDoc,
                                             Element root,
                                             NodeList nodeList,
                                             List<String> types)
    {
        if (nodeList == null || nodeList.getLength() == 0) {
            return;
        }

        for (int i = 0; i<nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (hasNameAttribute(node)) {
                String value = nodeList.item(i).getAttributes().getNamedItem(
                    nameAttribute).getNodeValue();

                if (types.contains(value)) {
                    populateChildNodes(types, node, value);
                    Node innerNode = nodeList.item(i);
                    Node toAdded = resultDoc.importNode(innerNode, true);
                    root.appendChild(toAdded);
                }
            }
        }
    }

    private boolean hasNameAttribute (Node node)
    {
        return node.getAttributes() != null &&
            node.getAttributes().getNamedItem(
                nameAttribute) != null &&
            node.getAttributes().getNamedItem(
                nameAttribute).getNodeValue() != null;
    }

    private void populateTypes (List<String> types, Node node)
    {
        if (node.getAttributes() != null &&
            node.getAttributes().getNamedItem(
                typeAttribute) != null &&
            node.getAttributes().getNamedItem(
                typeAttribute).getNodeValue() != null) {

            String type = node.getAttributes().getNamedItem(
                typeAttribute).getNodeValue();

            if (!types.contains(type)) {
                types.add(type);
            }

        }
    }

    private Node appendTypesForDefaultNodes (Element root, Document document)
    {
        Element topNode = document.createElement(simpleTypeTagName);
        topNode.setAttribute(nameAttribute, "datetime");

        Element restrictionNode = document.createElement("xsd:restriction");
        restrictionNode.setAttribute("base", "xsd:string");

        Element patternNode = document.createElement("xsd:pattern");
        patternNode.setAttribute("value", "[A-Z][a-z]{3} [A-Z][a-z]{3} [0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} [A_Z]{3} [0-9]{4}");

        restrictionNode.appendChild(patternNode);
        topNode.appendChild(restrictionNode);

        root.appendChild(topNode);

        return topNode;
    }
}
