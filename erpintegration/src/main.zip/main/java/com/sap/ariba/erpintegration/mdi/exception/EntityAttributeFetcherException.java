package com.sap.ariba.erpintegration.mdi.exception;

public class EntityAttributeFetcherException extends Exception
{
    private static final long serialVersionUID = 1L;

    public EntityAttributeFetcherException(String message)
    {
        super(message);
    }

    public EntityAttributeFetcherException(String message, Exception e)
    {
        super(message, e);
    }
}
