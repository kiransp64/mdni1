package com.sap.ariba.erpintegration.persistence;

import com.sap.ariba.erpintegration.persistence.dao.GenericDAO;
import com.sap.ariba.erpintegration.persistence.dao.GenericJPADAO;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;

/**
 * Created by i318483 on 31/05/17.
 */
public class SybaseDAOFactory extends DAOFactory
{
    public GenericDAO getDAO (String objectName)
    {
        return null;
    }

    public GenericDAO getMiscDAO (String objectName)
    {
        return null;
    }

    public GenericJPADAO getJPADAO (String objectName)
    {
        return null;
    }

    public GenericDAOStageData getGenericDAOStageData (String objectName)
    {
        return null;
    }

}
