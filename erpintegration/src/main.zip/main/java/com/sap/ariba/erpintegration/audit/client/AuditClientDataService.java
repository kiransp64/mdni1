package com.sap.ariba.erpintegration.audit.client;

import com.sap.ariba.audit.auditclient.api.AuditClientFactory;
import com.sap.ariba.audit.auditclient.enums.GenericAuditAction;
import com.sap.ariba.audit.auditclient.enums.IntegrationAuditAction;
import com.sap.ariba.audit.auditclient.enums.PurgeScope;
import com.sap.ariba.audit.auditclient.enums.PurposeOfAudit;
import com.sap.ariba.audit.auditclient.enums.SecurityAuditAction;
import com.sap.ariba.audit.auditclient.enums.Status;
import com.sap.ariba.audit.auditclient.message.GenericActionAuditLogMessage;
import com.sap.ariba.audit.auditclient.message.IntegrationAuditLogMessage;
import com.sap.ariba.audit.auditclient.message.SecurityAuditLogMessage;
import com.sap.ariba.erpintegration.cache.AuditPurgeScopeCache;
import com.sap.ariba.erpintegration.handlers.AuthenticateRequestHandlerBase;
import com.sap.ariba.erpintegration.handlers.IntegrationOperationType;
import com.sap.ariba.erpintegration.handlers.StagingTableStatus;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.dao.IntegrationJobLogRepository;
import com.sap.ariba.erpintegration.persistence.dao.TenantRepository;
import com.sap.ariba.erpintegration.persistence.model.IntegrationJobLog;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.model.Tenant;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.AuditFailedException;
import com.sap.ariba.erpintegration.service.exception.IntegrationJobLogProviderException;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.erpintegration.util.IntegrationJobLogUtil;
import org.apache.cxf.binding.soap.SoapMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Arrays;

/**
 * This class is used for auditing all the api's available.
 * All the successful and failed scenarios are audited
 */
@Component
public class AuditClientDataService {

    public static Logger logger = LoggerFactory.getLogger(AuditClientDataService.class);

    public static final String KeyHttpRequest = "HTTP.REQUEST";
    public static final String OPERATION_WSDL_UPLOAD = "WSDL_UPLOAD";
    public static final String OPERATION_DATA_UPLOAD = "DATA_UPLOAD";
    public static final String OPERATION_AUTHENTICATION = "AUTHENTICATION";
    public static final String OPERATION_FETCH_USERS = "FETCH_USERS";
    public static final String OPERATION_FETCH_GROUPS = "FETCH_GROUPS";
    public static final String OPERATION_WSDL_DOWNLOAD = "WSDL_DOWNLOAD";
    public static final String OPERATION_DATA_DOWNLOAD = "DATA_DOWNLOAD";
    public static final String OPERATION_FETCH_PROCUREMENT_UNITS = "FETCH_PROCUREMENT_UNITS";
    public static final String OPERATION_PROCESS_XML_DATA = "PROCESS_XML_DATA";
    public static final String OPERATION_INSPECTOR_ACCESS = "INSPECTOR_ACCESS";
    public static final String OPERATION_MDS_PUBLISH = "MDS_PUBLISH";
    public static final String OPERATION_TENANT_PURGE = "TENANT_PURGE";

    public static final String AUDIT_APP_ERPINTEGRATION = "erpintegration";

    public static final String TARGET_SYSTEM_BUYER = "Buyer";
    public static final String TARGET_SYSTEM_SOURCING = "Sourcing";
    public static final String SYSTEM = "SYSTEM";
    public static final String OBJECT_USER = "User";
    public static final String OBJECT_NAME_PARAM = "objectName";
    public static final String DOCUMENT_TYPE_XML = "XML";
    public static final String DOCUMENT_TYPE_WSDL = "WSDL";
    private static final int AUDIT_MAX_NOTES_SIZE=5000;
    private static final int AUDIT_MAX_DOCUMENTID_SIZE=1000;
    private static final int AUDIT_MAX_TENANTID_SIZE=100;
    private static final int AUDIT_MAX_USER_SIZE=500;
    public ThreadLocal<String> authenticationIdentifier = new ThreadLocal<>();

    @Value("${remote.auditService.enable}")
    private boolean auditServiceEnabled;


    @Autowired
    private AuditClientLogger auditClientLogger;

    @Autowired
    private AuditClientLoggerAsync auditClientLoggerAsync;

    @Autowired
    private AuditPurgeScopeCache auditPurgeScopeCache;

    @Value("${mdniOauthClientId}")
    private String oauthClientId;


    /**
     * This method is used for auditing uploadWsdl information
     * @param request
     * @param errorMessage
     */
    public void auditWsdlUpload(HttpServletRequest request, String errorMessage, String documentId, boolean beforeProcessing) throws IntegrationServiceException {
        if(auditServiceEnabled) {
            //Check whether we have a valid tenant
            String tenantId = request.getParameter(Constants.KeyTenantId);
            Tenant tenant = getTenantData(tenantId);
            if (tenant == null) {
                logger.error("Cannot audit for an invalid ANID: {}", Constants.KeyTenantId);
                return;
            }
            String realmName = tenant.getRealmName();
            String objectName = request.getParameter(Constants.KeyObjectName);
            String senderBusinessSystemId = request.getParameter(Constants.KeySenderBusinessSystemId);
            String notes = null;
            logger.info("Auditing for wsdl upload started for operation: {}, tenant: {}, object: {} ", OPERATION_WSDL_UPLOAD, realmName, objectName);

            try {
                IntegrationAuditLogMessage integrationAuditLogMessage = AuditClientFactory.createIntegrationLogMessage(SYSTEM, realmName, IntegrationAuditAction.DATAIMPORT);
                integrationAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.BusinessCritical);
                integrationAuditLogMessage.setTenantId(validateAuditLogSize(realmName,AUDIT_MAX_TENANTID_SIZE));
                integrationAuditLogMessage.setOperation(OPERATION_WSDL_UPLOAD);
                integrationAuditLogMessage.setDocumentType(DOCUMENT_TYPE_WSDL);
                integrationAuditLogMessage.setPurgeScope(getPurgeScope(tenant));

                if (errorMessage != null) {
                    notes = "upload wsdl failed for tenantId: " + realmName + ", Object Name: "
                            + objectName + ", Sender Business System Id: "
                            + senderBusinessSystemId + " with exception: "
                            + errorMessage;
                    integrationAuditLogMessage.setStatus(Status.FAIL);
                } else {
                    integrationAuditLogMessage.setDocumentId(validateAuditLogSize(documentId,AUDIT_MAX_DOCUMENTID_SIZE));
                    if(beforeProcessing) {
                        notes = "upload wsdl started for tenantId: " + realmName + ", Object Name: "
                                + objectName + ", Sender Business System Id: "
                                + senderBusinessSystemId;
                    } else {
                        notes = "upload wsdl successful for tenantId: " + realmName + ", Object Name: "
                                + objectName + ", Sender Business System Id: "
                                + senderBusinessSystemId;
                        integrationAuditLogMessage.setStatus(Status.SUCCESS);
                    }
                }
                integrationAuditLogMessage.setNotes(validateAuditLogSize(notes,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam1(validateAuditLogSize(tenant.getAnId(),AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam2(validateAuditLogSize(objectName,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam3(validateAuditLogSize(senderBusinessSystemId,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setTraceId(documentId);
                integrationAuditLogMessage.setEntity(objectName);
                if(beforeProcessing) {
                    auditClientLogger.pushAuditLog(integrationAuditLogMessage, OPERATION_WSDL_UPLOAD, realmName);
                } else {
                    auditClientLoggerAsync.pushAuditLogAsync(integrationAuditLogMessage, OPERATION_WSDL_UPLOAD, realmName);
                }
            }catch (AuditFailedException e) {
                logger.error(e.getMessage(), e);
                if(beforeProcessing) {
                    throw new IntegrationServiceException(e.getMessage(), e);
                }
            }catch (Exception e) {
                logger.error("Failed to Audit, ", e);
                if(beforeProcessing) {
                    throw new IntegrationServiceException("Failed to Audit, " + e.getMessage(), e);
                }
            }

        }
    }


    /**
     * This method is used for auditing failed authentication while accessing the api's
     * uploadXmlData, fetchUser, fetchGroup, fetchProcurement units
     * @param message
     * @param errorMessage
     */
    public void auditAuthentication(SoapMessage message, String errorMessage) {
        if(auditServiceEnabled) {
            String anId = HandlerUtil.getANIdFromSoapMsg(message);
            String realmName = null;
            Tenant tenant = getTenantData(anId);
            if (tenant == null) {
                logger.error("Cannot audit for an invalid ANID");
                return;
            }
            realmName = tenant.getRealmName();
            String notes = null;
            String urlPath = HandlerUtil.getRequestUrl(message);
            HttpServletRequest request = (HttpServletRequest) message.get(KeyHttpRequest);

            String objectName = request.getParameter(OBJECT_NAME_PARAM);
            try {
                SecurityAuditLogMessage securityAuditLogMessage = AuditClientFactory.createSecurityLogMessage(authenticationIdentifier.get(), realmName, SecurityAuditAction.AUTHENTICATION);
                securityAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.SecurityEvent);
                securityAuditLogMessage.setOperation(OPERATION_AUTHENTICATION);
                securityAuditLogMessage.setPurgeScope(getPurgeScope(tenant));

                if (errorMessage != null) {
                    notes = "Authentication Failed while accessing the url " + urlPath + ", with error message " + errorMessage;
                    securityAuditLogMessage.setStatus(Status.FAIL);
                } else {
                    notes = "Successfully authenticated while accessing the url " + urlPath;
                    securityAuditLogMessage.setStatus(Status.SUCCESS);
                }
                securityAuditLogMessage.setNotes(notes);
                securityAuditLogMessage.setParam1(tenant.getAnId());
                securityAuditLogMessage.setParam2(objectName);
                securityAuditLogMessage.setParam6(urlPath);
                auditClientLoggerAsync.pushAuditLogAsync(securityAuditLogMessage, OPERATION_AUTHENTICATION, realmName);
            } catch (Exception e) {
                logger.error("Audit failed for operation: {}, while accessing the url: {} with error message: {}", OPERATION_AUTHENTICATION, urlPath, e.getMessage());
            }
        }

    }

    public void auditTenantPurgeEvent(Tenant tenant)
    {
        if (tenant != null) {
            if (auditServiceEnabled) {
                try {
                    String anId = tenant.getAnId();
                    String realmName = tenant.getRealmName();
                    GenericActionAuditLogMessage genericActionAuditLogMessage = AuditClientFactory
                        .createGenericActionLogMessage(AUDIT_APP_ERPINTEGRATION, anId,
                                                       GenericAuditAction.PURGE);
                    genericActionAuditLogMessage
                        .setPurposeOfAudit(PurposeOfAudit.BusinessCritical);
                    genericActionAuditLogMessage.setPurgeScope(getPurgeScope(tenant));
                    auditClientLoggerAsync.pushAuditLogAsync(genericActionAuditLogMessage,
                                                             OPERATION_TENANT_PURGE,
                                                             realmName);
                }
                catch (Exception e) {
                    logger.error(
                        "[Tenant_Purge][Audit_Log] Error while trying to log purge audit event for tenant - {}",
                        tenant.getAnId(), e);
                }
            }
            else {
                logger.info(
                    "[Tenant_Purge][Audit_Log] Audit has been disabled while trying to purge tenant - {}",
                    tenant.getAnId());
            }
        }
        else {
            logger
                .warn("[Tenant_Purge][Audit_Log] Tenant passed is blank while logging.");
        }
    }

    /**
     * This method is used for auditing api's
     * fetchUser, fetchGroup, fetchProcurement units.
     * @param anId
     * @param queryString
     */
    public void auditFetchApi(String anId, String queryString, String errorMessage) {

        if(auditServiceEnabled) {
            String operationType = null;

            Tenant tenant = getTenantData(anId);

            if (tenant == null) {
                logger.error("Cannot audit for an invalid ANID: {}", anId);
                return;
            }

            String realmName = tenant.getRealmName();

            String notes = null;

            String targetSystem = getTargetSystem(queryString);

            try {
                IntegrationAuditLogMessage integrationAuditLogMessage = AuditClientFactory.createIntegrationLogMessage(authenticationIdentifier.get(), realmName, IntegrationAuditAction.DATAEXPORT);
                integrationAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.BusinessCritical);
                integrationAuditLogMessage.setTenantId(validateAuditLogSize(realmName,AUDIT_MAX_TENANTID_SIZE));
                integrationAuditLogMessage.setApiUrl(validateAuditLogSize(queryString,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setFormat(DOCUMENT_TYPE_XML);
                integrationAuditLogMessage.setPurgeScope(getPurgeScope(tenant));

                if (queryString.contains("getUsers")) {
                    operationType = OPERATION_FETCH_USERS;
                    integrationAuditLogMessage.setParam2("User");
                    integrationAuditLogMessage.setEntity("User");
                    integrationAuditLogMessage.setNotes("Users fetched in " + realmName + "realm using api url " + queryString);
                    integrationAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.PII);
                } else if (queryString.contains("getGroups")) {
                    operationType = OPERATION_FETCH_GROUPS;
                    integrationAuditLogMessage.setParam2("Group");
                    integrationAuditLogMessage.setEntity("Group");
                    integrationAuditLogMessage.setNotes("Groups fetched in " + realmName + "realm using api url " + queryString);
                } else if (queryString.contains("getProcurementUnits")) {
                    operationType = OPERATION_FETCH_PROCUREMENT_UNITS;
                    integrationAuditLogMessage.setParam2("ProcurementUnit");
                    integrationAuditLogMessage.setEntity("ProcurementUnit");
                    integrationAuditLogMessage.setNotes("ProcurementUnits fetched in " + realmName + "realm using api url " + queryString);
                }

                if (errorMessage == null) {
                    notes = operationType + " data successful in the realm: " + realmName;
                    integrationAuditLogMessage.setStatus(Status.SUCCESS);
                } else {
                    notes = operationType + " data failed in the realm: " + realmName + " with error details " + errorMessage;
                    integrationAuditLogMessage.setStatus(Status.FAIL);
                }
                integrationAuditLogMessage.setOperation(operationType);
                integrationAuditLogMessage.setNotes(validateAuditLogSize(notes,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam1(validateAuditLogSize(tenant.getAnId(),AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam4(validateAuditLogSize(targetSystem,AUDIT_MAX_NOTES_SIZE));
                auditClientLoggerAsync.pushAuditLogAsync(integrationAuditLogMessage, operationType, realmName);
            } catch (Exception e) {
                logger.error("Auditing Failed for operation: {}, tenantId: {}, with error message: {} ", OPERATION_DATA_UPLOAD, realmName, e.getMessage());
            }
        }
    }

    public void auditProcessXmlData(String objectName,
                                           long tenantId,
                                           StageXMLData stageXMLData, String errorMessage, boolean runAsync) throws AuditFailedException {
        if(auditServiceEnabled) {
            Tenant tenant = getTenantData(Utility.getANId(tenantId));

            if(tenant == null) {
                logger.error("Cannot audit for an invalid ANID: {}", tenantId);
                return;
            }
            String realmName = tenant.getRealmName();

            String realUser = stageXMLData.getAuthenticationType();

            //No need to audit in case if real user is null
            if(realUser == null) {
                logger.info("Cannot audit for invalid user");
                return;
            }

            String notes = null;

            String documentStatus = null;

            IntegrationJobLog integrationJobLog = getIntegrationJob(stageXMLData.getId());

            String jobInfo = null;

            String urlStr = HandlerUtil.getConfigCallbackURL(tenant.getAnId());
            String targetSystem = getTargetSystem(urlStr);

            if(errorMessage == null) {
                documentStatus = StagingTableStatus.getJobStatusDescription(stageXMLData.getStatus());
            }

            String loadType = IntegrationOperationType.getOperationTypeDescription(stageXMLData.getOperation());

            urlStr = HandlerUtil.modifyURLForPostData(urlStr, objectName, stageXMLData.getOperation());

            logger.info("Auditing for XML upload started for realmId: {}, objectName: {}", realmName, objectName);
                realUser=validateAuditLogSize(realUser,AUDIT_MAX_USER_SIZE);
                IntegrationAuditLogMessage integrationAuditLogMessage = AuditClientFactory.createIntegrationLogMessage(realUser, realmName, IntegrationAuditAction.DATAIMPORT);
                if(objectName.equals(OBJECT_USER)) {
                    integrationAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.PII);
                } else {
                    integrationAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.BusinessCritical);
                }
                integrationAuditLogMessage.setTenantId(validateAuditLogSize(realmName,AUDIT_MAX_TENANTID_SIZE));
                integrationAuditLogMessage.setOperation(OPERATION_PROCESS_XML_DATA);
                integrationAuditLogMessage.setFormat(DOCUMENT_TYPE_XML);
                integrationAuditLogMessage.setDocumentId(validateAuditLogSize(stageXMLData.getId(),AUDIT_MAX_DOCUMENTID_SIZE));
                integrationAuditLogMessage.setTraceId(stageXMLData.getId());
                integrationAuditLogMessage.setEntity(objectName);
                integrationAuditLogMessage.setParam1(validateAuditLogSize(tenant.getAnId(),AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam2(validateAuditLogSize(objectName,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam3(validateAuditLogSize(stageXMLData.getSenderBusinesssytemId(),AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam4(validateAuditLogSize(targetSystem,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam5(validateAuditLogSize(loadType,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setDocumentStatus(documentStatus);
                integrationAuditLogMessage.setDocumentType(DOCUMENT_TYPE_XML);
                integrationAuditLogMessage.setPurgeScope(getPurgeScope(tenant));

                if (errorMessage == null) {
                    if(!runAsync) {
                        notes = "process xml data going to start for realmId : " + realmName + " Object Name : "
                                + objectName;
                    } else {
                        if(stageXMLData.getStatus() == StagingTableStatus.PROCESSED.getValue()) {
                            jobInfo = constructJobInfo(integrationJobLog);
                            notes = "process xml data successful for realmId : " + realmName + " Object Name : "
                                    + objectName;
                        } else {

                            notes = "Issue in processing xml data for realmId : " + realmName + " Object Name : "
                                    + objectName;
                        }
                        integrationAuditLogMessage.setStatus(Status.SUCCESS);
                    }
                } else {
                    notes = "process xml data failed for realmId : " + realmName + " Object Name : "
                            + objectName + " with error message " + errorMessage;
                    integrationAuditLogMessage.setStatus(Status.FAIL);
                }
                integrationAuditLogMessage.setNotes(validateAuditLogSize(notes,AUDIT_MAX_NOTES_SIZE));
                if(realUser.equals(AuthenticateRequestHandlerBase.authUsingCIGCertificate)) {
                    integrationAuditLogMessage.setSourceServiceName("CIG");
                }
                if(jobInfo != null) {
                    integrationAuditLogMessage.setParam7(validateAuditLogSize(jobInfo,AUDIT_MAX_NOTES_SIZE));
                }
                if(!runAsync) {
                    auditClientLogger.pushAuditLog(integrationAuditLogMessage, OPERATION_PROCESS_XML_DATA, realmName);
                } else {
                    auditClientLoggerAsync.pushAuditLogAsync(integrationAuditLogMessage, OPERATION_PROCESS_XML_DATA, realmName);
                }
        }
    }

    public void auditMdniToMdsData(String responseInfo, String anId, String objectName, String senderBusinessSystemId, StageXMLData stageXMLData, String errorMsg) {
        if(auditServiceEnabled) {
            Tenant tenant = getTenantData(anId);
            if(tenant == null || tenant.getRealmName() == null)
                return;
            String realmName = tenant.getRealmName();
            String notes = null;
            String targetSystem = "MDS";
            String realUser = stageXMLData.getAuthenticationType();
            if(realUser == null) {
                logger.info("Cannot audit for invalid user");
                return;
            }
            String loadType = IntegrationOperationType.getOperationTypeDescription(stageXMLData.getOperation());

            logger.info("Auditing for MDS publish started for realmId: {}, objectName: {}, senderBusinessSystemId: {} ", realmName, objectName, senderBusinessSystemId);
            try {
                realUser=validateAuditLogSize(realUser,AUDIT_MAX_USER_SIZE);
                IntegrationAuditLogMessage integrationAuditLogMessage = AuditClientFactory.createIntegrationLogMessage(realUser, realmName, IntegrationAuditAction.DATAIMPORT);
                if(objectName.equals(OBJECT_USER)) {
                    integrationAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.PII);
                } else {
                    integrationAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.BusinessCritical);
                }
                integrationAuditLogMessage.setTenantId(validateAuditLogSize(realmName,AUDIT_MAX_TENANTID_SIZE));
                integrationAuditLogMessage.setOperation(OPERATION_MDS_PUBLISH);
                integrationAuditLogMessage.setDocumentId(validateAuditLogSize(stageXMLData.getId(),AUDIT_MAX_DOCUMENTID_SIZE));
                integrationAuditLogMessage.setTraceId(stageXMLData.getId());
                integrationAuditLogMessage.setEntity(objectName);
                integrationAuditLogMessage.setParam1(validateAuditLogSize(tenant.getAnId(),AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam2(validateAuditLogSize(objectName,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam4(validateAuditLogSize(targetSystem,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setParam5(validateAuditLogSize(loadType,AUDIT_MAX_NOTES_SIZE));
                integrationAuditLogMessage.setPurgeScope(getPurgeScope(tenant));

                if (errorMsg == null) {
                    notes = "Publishing data successfully to MDS for realmId : " + realmName + " Object Name : "
                            + objectName;
                    integrationAuditLogMessage.setParam7(validateAuditLogSize(responseInfo,AUDIT_MAX_NOTES_SIZE));
                    integrationAuditLogMessage.setStatus(Status.SUCCESS);
                } else {
                    notes = "Publishing data to MDS failed for realmId : " + realmName + " Object Name : "
                            + objectName + " with error message " + errorMsg;
                    integrationAuditLogMessage.setStatus(Status.FAIL);
                }
                integrationAuditLogMessage.setNotes(validateAuditLogSize(notes,AUDIT_MAX_NOTES_SIZE));
                if(realUser.equals(AuthenticateRequestHandlerBase.authUsingCertificate)) {
                    integrationAuditLogMessage.setSourceServiceName("CIG");
                }
                auditClientLoggerAsync.pushAuditLogAsync(integrationAuditLogMessage, OPERATION_MDS_PUBLISH, realmName);
            } catch (Exception e) {
                logger.error("Auditing Failed  objectName: {}, operation: {}, tenantId: {}, with error message: {} ", objectName, OPERATION_MDS_PUBLISH, realmName, e.getMessage());
            }
        }
    }

    public void auditFileDownLoad(Long tenantId,
                                  String uploadPath, String fileName, String errorMsg) {
        if(auditServiceEnabled) {
            String clientId = oauthClientId;
            Tenant tenant = getTenantData(Utility.getANId(tenantId));
            String realmName = null;
            String anId = null;
            if(tenantId == 0){
                //These are for default schemas. Default schemas are not specific to any realm.
                //Default schemas are same across all the realms. So assigning the realm and anID to System
                realmName = SYSTEM;
                //Cannot assign purge scope in case realm is SYSTEM. So skipping audit log.
                return;
            } else {
                if(tenant == null) {
                    return;
                }
                realmName = tenant.getRealmName();
                anId = tenant.getAnId();
            }
            String operation = null;
            String documentType = null;
            String notes = null;

            String[] pathArray = uploadPath.split("/");
            if (Arrays.asList(pathArray).contains(DOCUMENT_TYPE_WSDL)) {
                operation = OPERATION_WSDL_DOWNLOAD;
                documentType = DOCUMENT_TYPE_WSDL;
            } else {
                operation = OPERATION_DATA_DOWNLOAD;
                documentType = DOCUMENT_TYPE_XML;
            }

            try {
                GenericActionAuditLogMessage genericActionAuditLogMessage = AuditClientFactory.createGenericActionLogMessage(SYSTEM, realmName, GenericAuditAction.DOWNLOAD);
                if(fileName.contains(OBJECT_USER)) {
                    genericActionAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.PII);
                } else {
                    genericActionAuditLogMessage.setPurposeOfAudit(PurposeOfAudit.BusinessCritical);
                }
                genericActionAuditLogMessage.setTenantId(realmName);
                genericActionAuditLogMessage.setOperation(operation);
                genericActionAuditLogMessage.setDocumentType(documentType);
                genericActionAuditLogMessage.setDocumentId(fileName);
                genericActionAuditLogMessage.setClientId(clientId);
                genericActionAuditLogMessage.setPurgeScope(getPurgeScope(tenant));

                if (errorMsg == null) {
                    notes = "Successfully downloaded the file " + fileName;
                    genericActionAuditLogMessage.setStatus(Status.SUCCESS);
                } else {
                    notes = "Error downloading the file " + fileName + ". It is not found in the specifed loaction";
                    genericActionAuditLogMessage.setStatus(Status.FAIL);
                }
                genericActionAuditLogMessage.setNotes(notes);
                if(anId != null) {
                    genericActionAuditLogMessage.setParam1(anId);
                }
                auditClientLoggerAsync.pushAuditLogAsync(genericActionAuditLogMessage, operation, realmName);
            } catch (Exception e) {
                logger.error("Auditing Failed for operation: {}, in the realm {} for the file: {}, with error message: {} ", OPERATION_DATA_DOWNLOAD, realmName, fileName, e.getMessage());
            }
        }
    }


    /**
     * Method used to get tenant data for a given tenantId
     * @param tenantId
     * @return
     */
    public Tenant getTenantData(String tenantId) {
        Tenant tenantData = null;
        if(tenantId != null) {
            DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            TenantRepository tenantDao = (TenantRepository) factory.getMiscDAO(ObjectTypes.Tenant.getValue());
            tenantData = (Tenant) tenantDao.findOne(tenantId);
        }
        return tenantData;
    }


    private IntegrationJobLog getIntegrationJob(String jobId) {
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        IntegrationJobLogRepository dao = (IntegrationJobLogRepository)daoFactory.getMiscDAO(ObjectTypes.IntegrationJobLog.name());
        IntegrationJobLog integrationJobLog = dao.findOneWithJobId(jobId);
        return integrationJobLog;
    }

    private String constructJobInfo(IntegrationJobLog integrationJobLog ) {

        String jobInfo = null;

        if(integrationJobLog != null) {

            jobInfo = "Inserted %d records, updated %d records and deleted %d records".formatted(
                integrationJobLog.getRecordsInserted(), integrationJobLog.getRecordsUpdated(), integrationJobLog.getRecordsDeleted());

            try {
                String warnings = IntegrationJobLogUtil.convertBlobToString(
                        integrationJobLog.getWarningMessages());
                if (warnings != null && !StringUtils.isEmpty(warnings)) {
                    jobInfo += " with warning message " + warnings;
                }
            } catch (IntegrationJobLogProviderException e) {
                logger.info("Unable to convert warning message from blob to string while auditing", e);
            }
        }

        return jobInfo;
    }

    private StageXMLData getStageXmlData(String recordId) {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        GenericDAOStageData dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
        return (StageXMLData)dao.findOne(recordId);
    }

    private String validateAuditLogSize(String notes,int logSize) {
        if (notes != null) {
            if (notes.length() < logSize) {
                return notes;
            } else {
                logger.warn("Adjusting audit log size to " + logSize);
                return notes.substring(0, logSize);
            }
        }
        return notes;
    }

    //Method to fetch the target system name based on the configured URL
    public String getTargetSystem(String targetUrl) {
        String targetSystem = null;
        if(targetUrl != null) {
            if (targetUrl.contains(TARGET_SYSTEM_BUYER)) {
                targetSystem = TARGET_SYSTEM_BUYER;
            } else if (targetUrl.contains(TARGET_SYSTEM_SOURCING)) {
                targetSystem = TARGET_SYSTEM_SOURCING;
            }
        }
        return targetSystem;
    }


    public PurgeScope getPurgeScope(Tenant tenant)
    {
        PurgeScope auditPurgeScopeValue = auditPurgeScopeCache.getPurgeScopeCache(tenant.getAnId());
        if(auditPurgeScopeValue == null) {
            
            logger.info("Deriving AuditPurgeScope value from DB for tenant: {}", tenant.getAnId());
           
            String urlStr = HandlerUtil.getConfigCallbackURL(tenant.getAnId());
            String targetSystem = getTargetSystem(urlStr);
            if (targetSystem != null && targetSystem.contains(TARGET_SYSTEM_BUYER)) {
                auditPurgeScopeCache.put(tenant.getAnId(),PurgeScope.BUYER);
                return PurgeScope.BUYER;
            } else if (targetSystem != null && targetSystem.contains(TARGET_SYSTEM_SOURCING)) {
                auditPurgeScopeCache.put(tenant.getAnId(),PurgeScope.S4);
                return PurgeScope.S4;
            } else {
                auditPurgeScopeCache.put(tenant.getAnId(),null);
                return null;
            }
        }
        return auditPurgeScopeValue;
    }


}
