package com.sap.ariba.erpintegration.common.parameter;

import com.sap.ariba.erpintegration.HttpClientConfiguration;
import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.mdi.common.util.URLUtil;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.service.exception.ParameterFetcherException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.mdsclient.connection.SimpleResponseHandler;
import org.apache.commons.lang3.StringUtils;
import org.apache.hc.client5.http.HttpResponseException;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpUriRequest;
import org.apache.hc.core5.net.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.Map;


/**
 * This class is used for fetch the parameter api response.
 */
@Component
@ConditionalOnExpression("${environment.mdcs:false}==false")
public class ParameterFetcher {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParameterFetcher.class);
    @Value("${parameter.api.url}")
    private String parameterUrlConstant;
    @Value("${parameter.api.scope.buyer}")
    private String parameterBuyerScope;
    @Value("${parameter.api.scope.sourcing}")
    private String parameterSourcingScope;

    private static final String INCLUDE_META_QUERY_PARAM = "includeMetadata";
    private static final String REALM_QUERY_PARAM = "realm";

    @Autowired
    private AuditClientDataService auditClientDataService;

    @Autowired
    private ParameterOAuthToken parameterOAuthToken;

    @Autowired
    private HttpClientConfiguration httpClientConfiguration;

    @Autowired
    private ParameterAccessTokenHandler parameterAccessTokenHandler;

    /**.
     * Method is used to get the data from parameter api response
     * and return the response as Map
     */
    public String getData (String anId, String parameterKey) throws
            ParameterFetcherException
    {
        String callbackUrl = HandlerUtil.getConfigCallbackURL(anId);
        String urlStr = getUrl(callbackUrl,parameterKey,anId);
        Map response = getApiResponse(urlStr,anId);
        return String.valueOf(getValueFromMap(response)) ;
    }

    /**.
     * This method is used for fetch the parameter api response
     * and return the response as Map
     */
    public Map getApiResponse (String urlStr, String anId) throws
            ParameterFetcherException
    {
        Map responseAsMap = null;
        HttpUriRequest method = null;

        try {
            httpClientConfiguration.printConnectionStats();
            method = new HttpGet(urlStr);

            setOAuthHeader(method, anId, urlStr);
            httpClientConfiguration.printConnectionStats();
            LOGGER.info("Start : Connecting with parameter api uri string {} for anId{}",
                        urlStr , anId);
            String responseString = httpClientConfiguration.getHttpClient().execute(method, new SimpleResponseHandler());
            if (StringUtils.isEmpty(responseString)) {
                throw new ParameterFetcherException(
                                "Get Request to Parameter Api is not correct");
            }

            LOGGER.debug(
                    "End : Get Response from parameter api with url{} and An id {} ",
                    urlStr,anId);
            responseAsMap = HandlerUtil.getRequestDataAsMap(responseString);
        } catch (HttpResponseException exc) {
            LOGGER.warn("Exception - {} ,while fetching the data for anId-{}, url-{} ,Reason-{} ,Status code - {}",
                        exc.getMessage(),
                        anId,
                        urlStr,exc.getReasonPhrase(),exc.getStatusCode());
            throw new ParameterFetcherException(
                    "Exception while getting content method - getApiResponse()",
                    exc);
        } catch (IOException ioException) {
            LOGGER.warn("Exception - {} while getting content from method with anId-{}, url-{}.",
                        ioException.getMessage(),
                        anId,
                        urlStr);
            throw new ParameterFetcherException(
                            "Exception while getting content method - getApiResponse()",
                            ioException);
        } catch (IntegrationServiceException se) {
            LOGGER.warn("""
                            Exception while getting data \
                            from getRequestDataAsMap method {} with \
                            anId{}, url{}
                            """,
                    anId,urlStr,se.getMessage());
            throw new ParameterFetcherException(
                    "Exception while getting data from getRequestDataAsMap method.",
                    se);
        }
        return responseAsMap;
    }

    private String getUrl (String callbackUrl, String parameterKey, String anId)
            throws ParameterFetcherException
    {
        URIBuilder uriBuilder = new URIBuilder();
        String realmName = null;
        try {
            realmName = Utility.getRealmName(anId);
            URL url = new URL(callbackUrl);
            uriBuilder.setScheme(url.getProtocol());
            uriBuilder.setHost(url.getHost());
            if (url.getPort() > 0) {
                uriBuilder.setPort(url.getPort());
            }
            List path = appendPaths(callbackUrl,parameterKey);
            uriBuilder.setPathSegments(path);
            uriBuilder.addParameter(INCLUDE_META_QUERY_PARAM,"true");
            uriBuilder.addParameter(REALM_QUERY_PARAM,realmName);
            return uriBuilder.build().toString();
        } catch (MalformedURLException | URISyntaxException ex) {
            LOGGER.error("""
                            Exception while creating the parameter\
                             api URL with callbackUrl{},PARAMETER_QUERY_PARAM{},realmName{}\
                            """,
                    callbackUrl,INCLUDE_META_QUERY_PARAM,realmName,
                    ex.getMessage());
            throw new ParameterFetcherException(
                    "Exception while creating the parameter api URL {}",ex);

        }

    }

    /**.
     * Method used to get scopes for a given url
     */
    private String getScope (String url)
    {
        String scope = null;
        if (url.contains(auditClientDataService.TARGET_SYSTEM_BUYER)) {
            scope = parameterBuyerScope;
        } else if (url.contains(auditClientDataService.TARGET_SYSTEM_SOURCING)) {
            scope = parameterSourcingScope;
        }
        return scope;
    }

    /**.
     * Method used to set OAuthHeader for a parameter api url
     */
    private void setOAuthHeader (HttpUriRequest method, String anId, String url)
    {
        String scope = getScope(url);
        String token = getOAuthToken(anId, scope);
        method.setHeader(HttpHeaders.AUTHORIZATION, HandlerUtil.BEARER_CAP + token);
    }

    /**.
     * Method used to get OAuthToken for a given scope
     */
    public String getOAuthToken (String anId, String scope)
    {
        Map<String, String> tokenMap = null;
        tokenMap = parameterAccessTokenHandler.getAccessToken(anId,scope);
        String token = parameterOAuthToken.getAccessTokenFromTokenMap(tokenMap);
        return token;
    }

    private List<String> appendPaths  (String url, String parameterKey)
    {
        List<String> paths = null;
        String targetSystem = auditClientDataService
                .getTargetSystem(url);
        String[] pathSegment = new String[] { targetSystem, parameterUrlConstant, parameterKey };
        paths =  URLUtil.buildPaths(pathSegment);
        return paths;
    }

    private Object getValueFromMap (Map response)
    {
        return response.get("parameterValue");
    }

    private boolean convertStringToBoolean (String parameterValue)
    {
        return Boolean.parseBoolean(parameterValue);
    }

    public boolean getBoolean (String anId, String parameterKey)
            throws ParameterFetcherException
    {
        String parameterValue = getData(anId,parameterKey);
        return convertStringToBoolean(parameterValue);
    }
}
