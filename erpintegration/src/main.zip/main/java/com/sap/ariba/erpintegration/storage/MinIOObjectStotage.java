package com.sap.ariba.erpintegration.storage;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

/**
 * MinIO is a opensource object storage and it's apis are compatible with
 * Amazon S3 APIs. This implementation has been created, so that it can be
 * used for development purpose. This would help in overall cost cutting.
 * <p>
 * Application Parameter : cloud.storage.type=MINIO
 * <p>
 * To start a MinIO docker container follow the below
 * command
 * <pre>
 *     <code>
 *         docker run -p 9001:9000 --name minio minio/minio server /data
 *         docker restart minio -t 180
 *     </code>
 * </pre>
 * <p>
 * This code is configured to connect MinIO running locally at
 * 9001 port.
 */
@Service
@Qualifier("MinIOObjectStorage")
@ConditionalOnExpression(value = "${advanced.storage.option}")
public class MinIOObjectStotage extends AWSObjectStorage{

}
