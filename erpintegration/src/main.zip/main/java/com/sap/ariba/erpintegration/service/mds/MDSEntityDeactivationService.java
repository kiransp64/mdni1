package com.sap.ariba.erpintegration.service.mds;

import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.mdi.common.util.TracingHelper;
import com.sap.ariba.erpintegration.mdi.mds.client.ClientInitializer;
import com.sap.ariba.erpintegration.mdi.mds.config.GeneralConfig;
import com.sap.ariba.erpintegration.mdi.mds.config.IntegratorConfig;
import com.sap.ariba.erpintegration.mdi.mds.config.PublishConfig;
import com.sap.ariba.erpintegration.service.exception.TransientWebClientResponseException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.mdsclient.api.PropertyKey;
import com.sap.ariba.mdsclient.exception.MDSPublishException;
import com.sap.ariba.mdsclient.exception.MDSTenantServiceException;
import com.sap.ariba.mdsclient.publish.impl.ConfigHolder;
import com.sap.ariba.mdsclient.tenant.api.MDSTenantService;
import com.sap.ariba.mdsclient.util.MDSUtil;
import com.sap.ariba.security.encryption.config.PropertyName;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import jakarta.annotation.PostConstruct;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.net.ConnectException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * This service is used to deactivate entities in MDS
 */
@Service
public class MDSEntityDeactivationService
{
    private static final Logger log = LoggerFactory.getLogger(MDSEntityDeactivationService.class);
    
    @Autowired
    private MDSPublishConfiguration mdsPublishEntitiesConfiguration;
    
    @Autowired
    private PublishConfig mdsPublishEndpointConfiguration;
    
    @Autowired
    private ClientInitializer mdsClientInitializer;
    
    @Autowired
    @Lazy
    private MDSTenantService tenantService;

    @Autowired
    private GeneralConfig generalConfig;

    @Autowired
    private IntegratorConfig integratorConfig;

    @Autowired
    private TracingHelper tracingHelper;
    ;
    
    private WebClient webClient;
    
    @PostConstruct
    private void initialize ()
    {
        // create reactor netty HTTP client
        HttpClient httpClient = HttpClient.create().tcpConfiguration(tcpClient -> {
            tcpClient = tcpClient.option(
                ChannelOption.CONNECT_TIMEOUT_MILLIS,
                mdsPublishEntitiesConfiguration.getConnectTimeout());
            tcpClient = tcpClient.doOnConnected(
                conn -> conn.addHandlerLast(
                    new ReadTimeoutHandler(
                        mdsPublishEntitiesConfiguration.getReadTimeout(),
                        TimeUnit.MILLISECONDS)));
            return tcpClient;
        });
        // create a client http connector using above http client
        ClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);
        // use this configured http connector to build the web client
        webClient = WebClient.builder().clientConnector(connector).build();
    }
    
    /**
     * Deactivates all the entities of type <code>objectName</code> for the
     * specified <code>anId</code>, <code>senderBusinessSystemId</code> and
     * <code>partitionNumber</code> in MDS
     * 
     * @param objectName the entity to delete
     * @param anId
     * @param senderBusinessSystemId
     * @return response message returned from the server in case of success
     */
    @Retryable(
        value = { TransientWebClientResponseException.class },
        maxAttempts = 3, 
        backoff = @Backoff(delay = 180000))
    public Map<String, Object> deactivateExistingRecords (String objectName,
                                                          String anId,
                                                          String senderBusinessSystemId)
        throws Exception
    {
        Map<String, Object> response = new HashMap<>();
        // Make REST API call
        try {
            String responseMessage =
                       webClient.delete()
                                .uri(getDeactivationURI(objectName, anId, senderBusinessSystemId))
                                .headers(getHeaders())
                                .retrieve()
                                .bodyToMono(String.class)
                                .block();
            // Build response map
            response.put("StatusCode", HttpStatus.SC_OK);
            response.put("Message", responseMessage);
        }
        catch (Exception ex) {
            // Catch all exceptions here. In case the caught exception is a transient
            // exception (i.e HTTP status 503 or 504 or "Connection Refused" errors),
            // it is wrapped in a TransientWebClientResponseException and thrown which
            // becomes eligible for retry.
            // If it is any other exception, it is thrown back without retrying
            log.error(
                """
                Exception encountered while deactivating '{}' entities in MDS \
                for ANID '{}' and SenderBusinessSystemId '{}': {}\
                """,
                objectName,
                anId,
                senderBusinessSystemId,
                ex.getMessage());
            throwAppropriateException(ex);
        }
        return response;
    }

    private void throwAppropriateException (Exception e) throws Exception
    {
        Exception exception = e;
        if (e instanceof WebClientResponseException wcex) {
            if (HandlerUtil.isTransientHttpErrorCode(wcex.getRawStatusCode())) {
                // We have a transient exception which can be retried
                exception = new TransientWebClientResponseException(wcex);
            }
        }
        else {
            Throwable throwable = ExceptionUtils.getRootCause(e);
            if (ExceptionUtils.indexOfType(throwable, ConnectException.class) != -1) {
                // We have a transient exception which can be retried
                exception = new TransientWebClientResponseException(
                    HttpStatus.SC_SERVICE_UNAVAILABLE,
                    "Connection refused");
            }
        }
        throw exception;
    }

    private String getDeactivationURI (String objectName,
                                       String anId,
                                       String senderBusinessSystemId) throws
        MDSPublishException,
        MDSTenantServiceException
    {
        final String mdsEntityName = Entity.getEntity(objectName).getMdsName();
        final long partitionNumber = getPartitionNumber(anId);

        String isCapMode = integratorConfig.getIsCapMode();
        String baseUrl =  "true".equals(isCapMode) ? integratorConfig.getCapPublishUrl() : mdsPublishEndpointConfiguration.getURL();

        String deactivationURI = String.format(
                "%s/%s/%s?%s=%s&%s=%s&%s=%s",
                baseUrl,
                getMDSContext(mdsEntityName),
                mdsEntityName,
                "senderBusinessSystemId",
                senderBusinessSystemId,
                "systemId",
                anId,
                "partitionNumber",
                partitionNumber);

        Properties properties = new Properties();
        properties.setProperty(PropertyKey.IS_CAP_MODE.getValue(), isCapMode);

        return MDSUtil.getUrlWithPod(
                tenantService.getHanaTenantPod(anId, generalConfig.populateMERPOption(properties)),
                deactivationURI, Boolean.parseBoolean(isCapMode));
    }

    private long getPartitionNumber (String anId) throws MDSTenantServiceException
    {
        Properties properties = new Properties();
        properties.setProperty(PropertyKey.IS_CAP_MODE.getValue(), integratorConfig.getIsCapMode());
        return tenantService.getHanaTenantId(
            anId,
            generalConfig.populateMERPOption(properties));
    }
    
    private String getMDSContext (String mdsEntityName) throws MDSPublishException
    {
        return ConfigHolder.getEntityContextFromEntity(mdsEntityName);
    }
    
    private String getDeleteScope ()
    {
        return "ProductMaster";
    }
    
    private String getRequestingApp ()
    {
        return "MasterDataNativeIntegrationService";
    }

    private Consumer<HttpHeaders> getHeaders () throws Exception
    {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("DeleteScope", getDeleteScope());
        httpHeaders.add("RequestingApp", getRequestingApp());
        if(Boolean.parseBoolean(integratorConfig.useOAuth())) {
            httpHeaders.add("Authorization", MDSUtil.getHTTPAuthHeaderValue(getOauthConfig()));
        }else{
            httpHeaders.add("Authorization",
                    "Basic " + Base64.getEncoder()
                            .encodeToString((mdsClientInitializer.getMDSCredential()
                                    .getUserName() + ":"
                                    + mdsClientInitializer.getMDSCredential()
                                    .getPassword()).getBytes(StandardCharsets.UTF_8)));
        }
        if(tracingHelper.getTraceId() != TracingHelper.NOT_AVAILABLE_TRACKING_ID){
            httpHeaders.add(TracingHelper.TRACE_ID, tracingHelper.getTraceId());
        }
        return headers -> {
            if (httpHeaders != null) {
                headers.addAll(httpHeaders);
            }
        };
    }
    private Properties getOauthConfig(){
        Properties config = new Properties();
        config.put(PropertyName.OauthUrl.key(), generalConfig.getOAuthURL());
        config.put(PropertyName.OauthClientId.key(), generalConfig.getOAuthClientID());
        config.put(PropertyName.OauthClientPrivateKey.key(), generalConfig.getOAuthClientPrivateKey());
        config.put(PropertyKey.OAUTH_FLAG.getValue(), integratorConfig.useOAuth());
        config.put(PropertyKey.CAP_OauthScope.getValue(),integratorConfig.getCapScopes());
        return  config;
    }
}
