package com.sap.ariba.erpintegration.mdi.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.jakarta.rs.json.JacksonJsonProvider;
import com.sap.ariba.erpintegration.mdi.common.json.InstantRetainMilliSerializer;
import com.sap.scimono.api.API;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.Provider;
import java.time.Instant;

@Provider
@Consumes({ MediaType.APPLICATION_JSON, API.APPLICATION_JSON_SCIM, "text/json" })
@Produces({ MediaType.APPLICATION_JSON, API.APPLICATION_JSON_SCIM, "text/json" })
public class SCIMMeditaTypeJSONProvider extends JacksonJsonProvider
{

    private static ObjectMapper mapper = new ObjectMapper();

    static {
        JavaTimeModule module = new JavaTimeModule();
        module.addSerializer(Instant.class, new InstantRetainMilliSerializer());
        mapper.registerModule(module);
    }

    public SCIMMeditaTypeJSONProvider(){
        super();
        setMapper(mapper);
    }

}
