package com.sap.ariba.erpintegration;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.Proxy.Type;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "server")
public class MasterDataPublishServiceProxyConfiguration
{
    @Value("${server.proxy.isProduction}")
    private boolean isProduction;

    @Value("${server.proxy.proxyHost}")
    private String proxyHost;

    @Value("${server.proxy.proxyPort}")
    private String proxyPort;

    @Value("${server.proxy.nonProxyHosts}")
    private String nonProxyHosts;
    
    private static final Logger logger = LoggerFactory.getLogger(
        MasterDataPublishServiceProxyConfiguration.class);

    public MasterDataPublishServiceProxyConfiguration ()
    {

    }

    public boolean isProduction ()
    {
        return isProduction;
    }

    public void setProduction (boolean flag)
    {
        isProduction = flag;
    }

    public String proxyHost ()
    {
        return proxyHost;
    }

    public String proxyPort ()
    {
        return proxyPort;
    }

    public String nonProxyHosts ()
    {
        return nonProxyHosts;
    }

    @PostConstruct
    public void setProxyProperty ()
    {
        if (isProduction()) {
            System.out.println("Setting system properties for http proxy");
            System.setProperty("https.proxyHost", proxyHost);
            System.setProperty("https.proxyPort", proxyPort);
            System.setProperty("http.nonProxyHosts", nonProxyHosts);
        }
    }
    
    public HttpURLConnection openConnection (URL url) throws IOException
    {
        logger.info("Start : Connecting to URL {} ", url);
        if (isProduction() && proxyHost() != null && !proxyHost().isEmpty()
            && !proxyPort().isEmpty())
        {
            Proxy proxy = new Proxy(
                Type.HTTP,
                new InetSocketAddress(proxyHost(), Integer.valueOf(proxyPort())));
            HttpURLConnection conn = (HttpURLConnection)url.openConnection(proxy);
            logger.info(
                "Setting proxy for HttpURLConnection with proxyHost:" + proxyHost()
                    + " and proxyPort:" + proxyPort());
            return conn;
        }
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        logger.info("Https proxy HttpURLConnection usingProxy:", conn.usingProxy());
        return conn;
    }

    public RestTemplate getRestTemplate ()
    {
        if (isProduction() && proxyHost() != null && !proxyHost().isEmpty()
            && !proxyPort().isEmpty())
        {
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            Proxy proxy = new Proxy(
                Type.HTTP,
                new InetSocketAddress(proxyHost(), Integer.valueOf(proxyPort())));
            requestFactory.setProxy(proxy);
            logger.info(
                "Setting proxy for request factory with proxyHost:" + proxyHost()
                    + " and proxyPort:" + proxyPort());
            return new RestTemplate(requestFactory);
        }
        return new RestTemplate();
    }

}
