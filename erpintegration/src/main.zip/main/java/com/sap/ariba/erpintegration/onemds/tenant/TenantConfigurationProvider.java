package com.sap.ariba.erpintegration.onemds.tenant;

import com.sap.ariba.erpintegration.onemds.exception.TenantConfigurationException;

import java.util.Map;
import java.util.Set;

public interface TenantConfigurationProvider
{

    public String getClientID (String tenantID) throws TenantConfigurationException;

    public String getClientSecret (String tenantID) throws TenantConfigurationException;

    public String getAuthURL (String tenantID) throws TenantConfigurationException;

    public String getAppURL (String tenantID) throws TenantConfigurationException;

    public String getConfiguration (String tenantID,
                                    TenantConfiguration tenantConfiguration) throws
        TenantConfigurationException;

    public Set<String> getAllTenants() throws TenantConfigurationException;

    public boolean doesConfigurationExist(String tenantID) throws TenantConfigurationException;
    
    public Map<String, Map<String, String>> getTenantConfigurationDetails ();
    
    public void removeTenantConfigurationDetail (String tenantId);

    public void removeTenantConfigurationDetail ();
}
