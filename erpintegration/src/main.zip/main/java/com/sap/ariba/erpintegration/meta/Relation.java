package com.sap.ariba.erpintegration.meta;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * Created by i318483 on 07/06/17.
 */
public class Relation
{
    private String name;

    @XmlElement
    public Field getField ()
    {
        return field;
    }

    public void setField (Field field)
    {
        this.field = field;
    }

    private Field field;

    @XmlAttribute
    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }
}
