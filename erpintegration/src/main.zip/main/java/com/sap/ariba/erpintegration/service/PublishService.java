package com.sap.ariba.erpintegration.service;

import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import org.json.simple.JSONArray;

import java.util.Map;

/**
 * <code>PublishService</code> is responsible for publishing master data from MDNI to publish services.
 */
public interface PublishService
{
    /**
     * This is responsible for publishing data from MDNI to Repository
     *
     * @param dataArray
     * @param anId
     * @param operation
     * @param objectName
     * @param senderBusinessSystemId
     * @return
     * @throws IntegrationServiceException
     */
    public Map<String, Object> publish (JSONArray dataArray,
                                        String anId,
                                        int operation,
                                        String objectName,
                                        String senderBusinessSystemId,
                                        StageXMLData stageXMLData) throws
        IntegrationServiceException;

    /**
     * This is responsible for checking if a particular entity is enabled for direct publish to MDS
     *
     * @param anId
     * @param objectName
     * @return
     */
    public boolean isMDSPublishEnabled (String anId, String objectName, StageXMLData stageXMLData);

    /**
     * THis is responsible to check if a particular entity is excluded for publishing to core apps
     *
     * @param objectName
     * @return
     */
    public boolean isAppPublishExcuded(String anId, String objectName);
}
