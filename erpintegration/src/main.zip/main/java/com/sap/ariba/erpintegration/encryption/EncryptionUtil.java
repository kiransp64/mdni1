package com.sap.ariba.erpintegration.encryption;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Base64;
import java.util.Set;

/**
 * Default algorithm will be AES/CBC/PKCS5Padding
 * 
 * @author I079003
 */
public class EncryptionUtil
{
    public static final String AlgorithmAESGCM = "AES/GCM/NoPadding";
    public static final String DefaultAlgorithm = AlgorithmAESGCM;

    /**
     * Encrypts a specified String with the AES/CBC/PKCS5Padding algorithm using the
     * default encoding of UTF-8 using the current key version. The encrypted bytes 
     * are further Base64 encoded.
     * 
     * @param plainText
     * @return the Base64 encoded encrypted String.
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final String encrypt (String plainText)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        return encrypt(plainText, StandardCharsets.UTF_8.name(), getCurrentEncryptVersion());
    }
    
    /**
     * Encrypts a specified String with the AES/CBC/PKCS5Padding algorithm using the
     * default encoding of UTF-8. The encrypted bytes are further Base64
     * encoded.
     * 
     * @param plainText
     * @param version key version to use for encryption
     * @return the Base64 encoded encrypted String.
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final String encrypt (String plainText, String version)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        return encrypt(plainText, StandardCharsets.UTF_8.name(), version);
    }

    /**
     * Encrypts a specified String with the AES/CBC/PKCS5Padding algorithm using the
     * specified encoding. The encrypted bytes are further Base64
     * encoded.
     * 
     * @param plainText
     * @param encoding
     * @param version key version to use for encryption
     * @return the Base64 encoded encrypted String.
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    private static final String encrypt (String plainText,
                                         String encoding,
                                         String version)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        byte[] encrBytes = encrypt(plainText.getBytes(encoding), version);
        return new String(encrBytes, encoding);
    }

    /**
     * Encrypts the specified byte array with the AES/CBC/PKCS5Padding algorithm.
     * The encrypted bytes are further Base64 encoded.
     * 
     * @param plainBytes
     * @param version key version to use for encryption
     * @return the Base64 encoded encrypted bytes.
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final byte[] encrypt (byte[] plainBytes, String version)
        throws GeneralSecurityException, SecurityInitializationException, IOException
    {
        EncryptionHelper helper = getEncryptionHelper(version);
        byte[] encrBytes = helper.encrypt(plainBytes);
        return Base64.getEncoder().encode(encrBytes);
    }

    /**
     * Encrypts the specified inputstream into the specified outputstream using
     * AES algorithm and current encrypt version. Both the streams are closed
     * after encryption
     * 
     * @param is
     * @param os
     * @return number of bytes encrypted
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final long encrypt (InputStream is, OutputStream os)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        return encrypt(is, os, getCurrentEncryptVersion());
    }
    
    /**
     * Encrypts the specified inputstream into the specified outputstream using
     * AES algorithm and specified encrypt version. Both the streams are closed
     * after encryption
     * 
     * @param is
     * @param os
     * @param version
     * @return number of bytes encrypted
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final long encrypt (InputStream is, OutputStream os, String version)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        EncryptionHelper helper = getEncryptionHelper(version);
        return helper.encrypt(is, os);
    }

    /**
     * Decrypts the specified encrypted text using current encrypt version
     * @param encryptedText
     * @return the decrypted string
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final String decrypt (String encryptedText)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        return decrypt(
            encryptedText,
            StandardCharsets.UTF_8.name(),
            getCurrentEncryptVersion());
    }

    /**
     * Decrypts the specified encrypted text using using the specified encoding
     * using current encrypt version
     * @param encryptedText
     * @param encoding
     * @return
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final String decrypt (String encryptedText, String encoding)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        return decrypt(encryptedText, encoding, getCurrentEncryptVersion());
    }

    /**
     * Decrypts the specified encrypted text using using the specified encoding and
     * encryption version
     * @param encryptedText
     * @param encoding
     * @param version
     * @return
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final String decrypt (String encryptedText, String encoding, String version)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        EncryptionHelper helper = getEncryptionHelper(version);
        byte[] encrBytes = Base64.getDecoder().decode(encryptedText.getBytes(encoding));
        byte[] decryptedBytes = helper.decrypt(encrBytes);
        return new String(decryptedBytes, encoding);
    }

    /**
     * Decrypts the specified input stream into the specified output stream using
     * current encryption version. Both the streams will be closed before returning.
     * @param is
     * @param os
     * @return
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final long decrypt (InputStream is, OutputStream os)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        return decrypt(is, os, getCurrentEncryptVersion());
    }

    /**
     * Decrypts the specified input stream into the specified output stream using the
     * specified encryption version
     * @param is
     * @param os
     * @param version
     * @return
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final long decrypt (InputStream is, OutputStream os, String version)
        throws GeneralSecurityException, IOException, SecurityInitializationException
    {
        EncryptionHelper helper = getEncryptionHelper(version);
        return helper.decrypt(is, os);
    }
    
    /**
     * Decrypts the specified input stream into to return an
     * input stream using the specified encryption version
     * @param is
     * @param version
     * @return
     * @throws GeneralSecurityException
     * @throws IOException
     * @throws SecurityInitializationException
     */
    public static final InputStream decryptStream (InputStream is, String version)
            throws GeneralSecurityException, IOException, SecurityInitializationException
        {
            EncryptionHelper helper = getEncryptionHelper(version);
            return helper.decryptStream(is);
        }
    
    private static EncryptionHelper getEncryptionHelper (String version)
        throws SecurityInitializationException, IOException
    {
        EncryptionHelper helper = EncryptionHelperFactory.getEncryptionHelper(version);
        if (helper == null) {
            String errMsg = 
                "Failed to get AES encryption helper for version %s".formatted(
                    version);
            Log.encryption.error(errMsg);
            throw new SecurityInitializationException(errMsg);
        }
        return helper;
    }

    public static String getCurrentEncryptVersion ()
        throws SecurityInitializationException, IOException
    {
        return EncryptionHelperFactory.getCurrentEncryptVersion();
    }

    public static Set<String> getAllEncryptVersions ()
        throws SecurityInitializationException, IOException
    {
        return EncryptionHelperFactory.getAllEncryptVersions();
    }
}
