package com.sap.ariba.erpintegration.handlers;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.audit.AuditManagerImpl;
import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.cache.LookUpValueCache;
import com.sap.ariba.erpintegration.cache.LookUpValueCacheFactory;
import com.sap.ariba.erpintegration.common.metrics.MDNIMetrics;
import com.sap.ariba.erpintegration.common.metrics.MDNIServiceRegistry;
import com.sap.ariba.erpintegration.encryption.EncryptionUtil;
import com.sap.ariba.erpintegration.encryption.MDNIEncryptionService;
import com.sap.ariba.erpintegration.encryption.SecurityInitializationException;
import com.sap.ariba.erpintegration.monitor.exception.IntegrationMonitoringException;
import com.sap.ariba.erpintegration.monitor.exception.PassportException;
import com.sap.ariba.erpintegration.monitor.im.handler.MonitoringEventHandler;
import com.sap.ariba.erpintegration.monitor.im.helper.IMHelper;
import com.sap.ariba.erpintegration.monitor.im.model.IntegrationContext;
import com.sap.ariba.erpintegration.monitor.im.util.IMEvents;
import com.sap.ariba.erpintegration.monitor.im.util.IntegrationContextBuilder;
import com.sap.ariba.erpintegration.monitor.passport.PassportHandler;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.PersistenceOperationType;
import com.sap.ariba.erpintegration.persistence.dao.EntityVersionRepository;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.dao.IntegrationJobLogRepository;
import com.sap.ariba.erpintegration.persistence.model.EntityVersion;
import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import com.sap.ariba.erpintegration.persistence.model.IntegrationJobLog;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;
import com.sap.ariba.erpintegration.persistence.util.EncryptKey;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.service.exception.AuditFailedException;
import com.sap.ariba.erpintegration.service.exception.IntegrationPayloadProcessorException;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.storage.CloudStorageFactory;
import com.sap.ariba.erpintegration.storage.CloudStorageResponse;
import com.sap.ariba.erpintegration.storage.exception.CloudStorageException;
import com.sap.ariba.erpintegration.util.*;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.json.JSONObject;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javax.sql.rowset.serial.SerialBlob;
import jakarta.ws.rs.core.Response;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.*;
import java.security.GeneralSecurityException;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.zip.ZipInputStream;

import static com.fasterxml.jackson.databind.DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.*;
import static com.sap.ariba.erpintegration.monitor.im.util.IMEvents.PROCESS_XML_DATA;


/**
 * Created by i318483 on 05/06/17.
 */
public class IntegrationDataPayloadProcessor extends RequestHandler
{
    public static final String KeyRecordId = "RecordId";
    public static final String KeyTenantId = "TenantId";

    public static final String KeyRowNumber = "RowNumber";
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.IntegrationDataPayloadProcessor";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    private boolean auditEnabled = Boolean.TRUE;
    private boolean hanaPublishEnabled = Boolean.FALSE;

    private JSONArray dataArray = null;
    public static final int MAXRETRYCOUNT = 5;

    private static final String WarningMessageText = "Referenced data of type";
    private static final String countryCodeTag1 = "CountryCode";
    private static final String countryCodeTag2 = "Country";
    private static final String paymentTermsUniqueKey = "Key.UniqueName";
    private static final String paymentTermTiersInfoKey = "Item";
    private static final String paymentTermsDayLimitKey = "Key.DayLimit";
    private static final String MAX_RETRY_MESSAGE = "Maximum retries executed";
    private String creationDatePaymentTerms;
    private Map<PersistenceOperationType,Set<EntityVersion>> mapOfEntityVersions = new EnumMap<>(PersistenceOperationType.class);
    private static final String senderBusinessSystemIdKey = "SenderBusinessSystemId";
    private final String ActionCodeTag = "ActionCode";
    private static final ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.enable(USE_BIG_DECIMAL_FOR_FLOATS);
    }

    private MDNIServiceRegistry mdniServiceRegistry = null;



    /**
     * Get the recordId,tenantId to process from the request, Get the filePath
     * from corresponding STAGEXMLDATTAB table and call processXMLPayload to
     * persist XML Data to coresponding Object Table.
     *
     * @param request
     * @return
     * @throws IntegrationServiceException
     */
    @Override
    public Response execute (HttpServletRequest request)
        throws IntegrationServiceException
    {
        long tenantId = -1;
        int recordProcessedCount = -1;

        String anId = null;
        String recordId = null;
        String tenantIdStr = null;
        String xmlFilePath = null;
        String objectName = null;
        DAOFactory factory = null;
        GenericDAOStageData dao = null;
        StageXMLData stagedXMLData = null;
        IntegrationJobResponseProcessor jobResponseProcessor = null;
        String errorMessage = null;
        boolean isFMDObject = false;

        logger.info("Started processing XML payload");

        if (!super.isRequestAuthorized(request)) {
            return Response.status(HttpServletResponse.SC_UNAUTHORIZED).build();
        }

        long startTime = System.currentTimeMillis();
        try {
            recordId = HandlerUtil.decodeParams(request.getParameter(KeyRecordId));
            tenantIdStr = HandlerUtil.decodeParams(request.getParameter(KeyTenantId));
            tenantId = Long.parseLong(tenantIdStr);
            anId = Utility.getANId(tenantId);
            logger.info("recordId: {}", recordId);
            logger.info("tenantIdStr: {}", tenantIdStr);
            logger.info("anId: {}", anId);

            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(
                    anId,
                    Operation.PROCESS_XML_DATA,
                    "xml data processing started for tenantId:" + tenantId + ",recordId:"
                        + recordId);
            }

            factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
            stagedXMLData = (StageXMLData)dao.findOne(recordId);
            xmlFilePath = stagedXMLData.getDataPath();
            if(HandlerUtil.isObjectFMDType(stagedXMLData.getObjectName())){
                objectName = stagedXMLData.getObjectName();
                isFMDObject = true;
            }
            else {
                objectName = EventNameToObjectMap.getObjectName(
                    ((StageXMLData)stagedXMLData).getObjectName());
            }
            recordProcessedCount = stagedXMLData.getProcessedCount();
            jobResponseProcessor = new IntegrationJobResponseProcessor();

            processXMLPayload(
                xmlFilePath,
                objectName,
                tenantId,
                stagedXMLData,
                jobResponseProcessor,
                isFMDObject);

            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(
                    anId,
                    Operation.PROCESS_XML_DATA,
                    "xml data processing ended for tenantId:" + tenantId + ",recordId:"
                        + recordId);
            }
        }
        catch (Exception ex)
        {
            logger.error("[MDNI_CRITICAL][ARIBA][XML_Processing] Tenant ID - {}, Object Name - {}, record ID - {}  Exception {} while processing Integration Payload",
                         anId,
                         objectName,
                         recordId,
                         ErrorUtil.getCompleteCausedByErrors(ex));
            if(mdniServiceRegistry == null) {
                mdniServiceRegistry = BeanUtil.getMdniServiceRegistry();
            }
            if(mdniServiceRegistry != null) {
                mdniServiceRegistry.sendMetricsForCounter(MDNIMetrics.STAGEXML_FAILING_JOBS);
            }
            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(
                    anId,
                    Operation.PROCESS_XML_DATA,
                    "upload xml ended for tenantId : " + tenantId + ",recordId:"
                        + recordId + " with Exception : " + ex.getMessage());
            }
            errorMessage = ex.getMessage();
                return  Response.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR)
                        .header(ErrorUtil.X_PROCESSING_FAILURE, "true")
                        .build();
        }
        finally {
            recordProcessedCount++;
            updateStagedXMLDataStatus(
                stagedXMLData,
                jobResponseProcessor,
                recordProcessedCount);
            if(dao!=null) {
                dao.save(stagedXMLData);
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if(stagedXMLData!=null) {
                logger.info("*******Processing time for object "+stagedXMLData.getObjectName() +" ANID " + anId + " is "+elapsedTime/1000+" seconds");
            }

            //if IM integration feature toggle is enable then we need to log inbound Event for particular Job ID
            //check if the sap passport is available in thread then process
            if (IMHelper.isIMEnable()
                            && IMHelper.isPassportAvailableAsPartOfCurrentRequestThread()) {
                IMHelper imHelper = ApplicationContextProvider.getApplicationContext()
                                .getBean(IMHelper.class);
                if (!ObjectUtils.isEmpty(imHelper)) {
                    imHelper.processIMMonitoring(anId,
                                                 recordId,
                                                 stagedXMLData,
                                                 errorMessage);
                }
            }

            AuditClientDataService auditClientDataService;
            auditClientDataService = ApplicationContextProvider.getApplicationContext().getBean(AuditClientDataService.class);
            try {
                auditClientDataService.auditProcessXmlData(
                        objectName,
                        tenantId,
                        stagedXMLData, errorMessage, true);
            } catch (AuditFailedException e) {
                return Response.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR)
                        .header(ErrorUtil.X_PROCESSING_FAILURE, "true")
                        .build();
            }
            try {
                markDependentRecordsForProcessing(objectName, jobResponseProcessor, tenantId);
            } catch (SQLException se) {
                logger.warn("Exception while marking dependent objects for processing {} ", se);
            }
        }
        return Response.status(HttpServletResponse.SC_OK).build();
    }


    private void markDependentRecordsForProcessing (String objectName,
                                                    IntegrationJobResponseProcessor jobResponseProcessor,
                                                    long tenantId) throws SQLException
    {
        int totalRecordsProcessed = 0;
        totalRecordsProcessed = jobResponseProcessor.getTotalRecordsProcessed();

        if (totalRecordsProcessed > 0) {
            final List<String> dependentObjects = MasterDataDependencyProvider.getDependencies(
                objectName);
            if (dependentObjects != null && !dependentObjects.isEmpty()) {
                logger.info("{} Objects are processed for tenant {}", objectName, tenantId);
                logger.info(
                    "Moving dependent objects with Needs Reprocessing status to pending state");

                for (String dependentObject : dependentObjects) {
                    updateRecordsForObjectWithNeedsReprocessingState(
                        objectName,
                        dependentObject,
                        tenantId);
                }
            }
        }
    }

    private void updateRecordsForObjectWithNeedsReprocessingState (String objectName,
                                                                   String dependentObject,
                                                                   long tenantId) throws
        SQLException
    {
        DAOFactory factory = null;
        GenericDAOStageData dao = null;
        List<StageXMLData> stagedXMLDataList = null;

        IntegrationJobLogRepository integrationJobLogRepository = null;
        IntegrationJobLog integrationJobLog = null;

        factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
        stagedXMLDataList = (List<StageXMLData>) dao.findRecordsInNeedsReprocessingStatus(dependentObject,
            StagingTableStatus.NEEDSREPROCESSING.getValue(),
            tenantId);

        if (stagedXMLDataList == null || stagedXMLDataList.isEmpty()) {
            logger.info(
                "No dependent object records found which are in Needs Reprocessing status for object: {}, tenantId: {}",
                objectName,
                tenantId);
            return;
        }

        integrationJobLogRepository = (IntegrationJobLogRepository)factory.getMiscDAO(ObjectTypes.IntegrationJobLog.getValue());

        for (StageXMLData stageXMLData : stagedXMLDataList) {

            integrationJobLog = integrationJobLogRepository.findLatestDateUpdatedRecord(stageXMLData.getId());
            byte[] bytes = XMLUtil.convertBolbToByteArray(integrationJobLog.getWarningMessages());
            String warningMessages = new String(bytes);
            if (warningMessages != null && warningMessages.indexOf(WarningMessageText) != -1
                && warningMessages.indexOf(objectName) != -1) {
                int status = StagingTableStatus.PENDING.getValue();
                int opreationType  = stageXMLData.getOperation();
                String senderBusinessSystemId =
                        stageXMLData.getSenderBusinesssytemId();
                if(opreationType == IntegrationOperationType.FULLLOAD.getValue()){
                    Timestamp sourceCreationDate =  new Timestamp(stageXMLData.getSourceCreatedDate().getTime());
                    logger.debug("sourceCreationDate: {}  for record ID {} , objectName {} , tenant {}",sourceCreationDate,objectName,tenantId);
                    if(HandlerUtil.isCurrentPayloadSourceCreationDateOlder(objectName, tenantId, senderBusinessSystemId, sourceCreationDate)){
                        logger.debug(
                            "stagexmldatatab record ID {} , for objectName {} , tenant {}, senderBusinessSystemId {} is older than existing record, hence marking the record as duplicate",
                            stageXMLData.getId(),
                            objectName,
                            tenantId,
                            senderBusinessSystemId);
                        status = StagingTableStatus.DUPLICATE.getValue();
                        String additionalWarnings = """
                            Payload is older than an existing record for this object, \
                            hence marking it job as duplicate and skipping records from processing\
                            """;
                        List<String> warningsList = new ArrayList<>();
                        warningMessages += additionalWarnings;
                        warningsList.add(warningMessages);
                        IntegrationJobLogUtil.logIntegrationJobProcessingDetails(
                            Utility.getANId(stageXMLData.getTenantId()),
                            new IntegrationJobResponseProcessor(),
                            warningsList,
                            tenantId,
                            stageXMLData.getId(),
                            stageXMLData.getSenderBusinesssytemId(),
                            integrationJobLog.getId(),
                            status);
                    }
                }

                stageXMLData.setStatus(status);
                dao.save(stageXMLData);

                logger.info(
                    "Marked STAGE XML with recordId {} for tenant {} to status {} ",
                    stageXMLData.getId(),
                    tenantId,
                    status);
            }
        }
    }

    private void updateStagedXMLDataStatus (StageXMLData stagedXMLData,
                                            IntegrationJobResponseProcessor jobResponseProcessor,
                                            int recordProcessedCount)
    {
        boolean xmlNeedsReprocessing = false;
        boolean hasFatalErrors = false;
        boolean hasNonFatalException=false;
        if(jobResponseProcessor!=null && jobResponseProcessor.getNonFatalExceptions() != null
                        && !jobResponseProcessor.getNonFatalExceptions().isEmpty()){
            hasNonFatalException=true;
        }

        if (jobResponseProcessor != null && jobResponseProcessor.isStatusError())
        {
            stagedXMLData.setStatus(StagingTableStatus.ERROR.getValue());
        }
        else if(jobResponseProcessor != null && jobResponseProcessor.isTransientFailure())
        {
            stagedXMLData.setProcessedCount(recordProcessedCount);
            if (recordProcessedCount < MAXRETRYCOUNT) {
                stagedXMLData.setStatus(StagingTableStatus.PENDING.getValue());
            }
            else {
                if (HandlerUtil.isMDCS() && stagedXMLData.isMDNIPayload()) {
                    stagedXMLData.setStatus(StagingTableStatus.ERROR.getValue());
                }
                else {
                    markStagedXMLAsProcessedWithWarnings(stagedXMLData);
                }
            }
        }
        else {
            if (jobResponseProcessor != null) {

                hasFatalErrors = isMarkXMLRecordFatal(jobResponseProcessor);
                if (hasFatalErrors) {
                    stagedXMLData.setStatus(StagingTableStatus.ERROR.getValue());
                }
                else {
                    xmlNeedsReprocessing = isXmlNeedsReprocessing(jobResponseProcessor);
                }
            }
            else {
                xmlNeedsReprocessing = true;
            }

            if (recordProcessedCount <= MAXRETRYCOUNT) {
                stagedXMLData.setProcessedCount(recordProcessedCount);
            }

            if (xmlNeedsReprocessing && (recordProcessedCount < MAXRETRYCOUNT)) {
                stagedXMLData.setStatus(StagingTableStatus.NEEDSREPROCESSING.getValue());
            }
            else if (!hasFatalErrors && recordProcessedCount >= MAXRETRYCOUNT) {
                stagedXMLData.setStatus(StagingTableStatus.PROCESSEDWITHWARNINGS.getValue());
            }
            else {
                if (!hasFatalErrors && hasNonFatalException) {
                    stagedXMLData.setStatus(StagingTableStatus.PROCESSEDWITHWARNINGS.getValue());
                }
                else if (!hasFatalErrors) {
                    stagedXMLData.setStatus(StagingTableStatus.PROCESSED.getValue());
                }
            }
        }
        stagedXMLData.setDateUpdated(new Date());
    }

    private void markStagedXMLAsProcessedWithWarnings (StageXMLData stagedXMLData)
    {
        stagedXMLData.setStatus(StagingTableStatus.PROCESSEDWITHWARNINGS.getValue());
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        IntegrationJobLogRepository integrationJobLogRepository = (IntegrationJobLogRepository) factory.getMiscDAO(
            ObjectTypes.IntegrationJobLog.getValue());
        IntegrationJobLog integrationJobLog = integrationJobLogRepository.findLatestDateUpdatedRecord(
            stagedXMLData.getId());
        byte[] buff = MAX_RETRY_MESSAGE.getBytes();
        Blob blob = null;
        try {
            blob = new SerialBlob(buff);
        } catch (SQLException ex) {
            logger.error(
                """
                SQLException occured for recordId {} , \
                exception details - {} \
                """,
                stagedXMLData.getId(),
                ex.getMessage(),
                ex);
        }
        integrationJobLog.setWarningMessages(blob);
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        IntegrationJobLogRepository dao = (IntegrationJobLogRepository) daoFactory.getMiscDAO(
            ObjectTypes.IntegrationJobLog.name());
        dao.save(integrationJobLog);
    }

    /**
     * Read data from file use the xml parser to convert part by part XML
     *
     * @param xmlFilePath
     * @param objectName
     * @param tenantId
     * @throws ParseException
     * @throws IOException
     * @throws IntegrationPayloadProcessorException
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    private IntegrationJobResponseProcessor processXMLPayload (String xmlFilePath,
                                                               String objectName,
                                                               long tenantId,
                                                               StageXMLData stageXMLData,
                                                               IntegrationJobResponseProcessor jobResponseProcessor,
                                                               boolean isFMDObject)
        throws ParseException,
        IOException,
        IntegrationPayloadProcessorException,
        ParserConfigurationException,
        SAXException
    {
        Map<Integer, String> rowNumKeyMap = new HashMap<>();
        Map<Integer, String> lineNumLookupKeyMap = new HashMap<>();
        List<String> skippedRecordWarnings = new ArrayList<String>();

        final String anId = Utility.getANId(stageXMLData.getTenantId());

        final String jsonObjectName;
        if(isFMDObject){
            jsonObjectName = objectName;
        }
        else{
            jsonObjectName = EventNameToObjectMap.getJSONObjectName(objectName);
        }

        final List<Integer> reprocessLines = IntegrationJobLogUtil.getReprocessLinesList(
            stageXMLData.getId());
        int operation = stageXMLData.getOperation();
        if (reprocessLines != null && reprocessLines.size() > 0) {
            operation = IntegrationOperationType.INCREMENTALLOAD.getValue();
            logger.info("Reprocessing the XML data for record {} ", stageXMLData.getId());
        }

        String creationDate = DateFormatUtils.format(stageXMLData.getSourceCreatedDate(), HandlerUtil.dateFormats[1]);

        if(objectName.equalsIgnoreCase(ObjectTypes.PaymentTerms.getValue())){
            creationDatePaymentTerms = creationDate;
        }

        final int operationId = operation;

        int processFromRecordNumber = stageXMLData.getProcessFrom();

        // Read data from file
        // use the xml parser to convert part by part XML

        SAXParserFactory factory = SAXParserFactory.newInstance();
        String SECURE_PROCESSING_PARSER = "http://javax.xml.XMLConstants/feature/secure-processing";
        factory.setFeature(SECURE_PROCESSING_PARSER, true);
        SAXParser saxParser = factory.newSAXParser();

        DefaultHandler handler = new DefaultHandler() {

            boolean startFlag = false;
            String parentQName = jsonObjectName;
            StringBuilder sb = null;
            Stack<String> elements = new Stack<>();
            int lineNum = 1;
            LookUpValueCache lookUpValueCache = LookUpValueCacheFactory.getLookUpValueCache();
            DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
            EntityVersionRepository entityVersionRepository = (EntityVersionRepository)daoFactory.getMiscDAO(
                ObjectTypes.EntityVersion.getValue());

            public void startElement (String uri,
                                      String localName,
                                      String qName,
                                      Attributes attributes)
                throws SAXException
            {

                if (startFlag) {
                    sb.append("<" + qName + " ");
                    for (int i = 0; i < attributes.getLength(); i++) {
                        String attrQName = attributes.getQName(i);
                        String attrValue = attributes.getValue(i);
                        attrValue = LocaleUtil.getAribaLocaleFromXMLAttribute(attrQName,
                                                                              attrValue);
                        sb.append(
                            attrQName + "=\"" + attrValue
                                + "\"");
                        sb.append(" ");
                    }
                    sb = new StringBuilder(sb.subSequence(0, sb.length() - 1));
                    sb.append(">");
                }
                if (qName.equalsIgnoreCase(parentQName)) {
                    if (logger.isDebugEnabled())
                        logger.debug("{} tag processing started", parentQName);
                    if (elements.isEmpty()) {
                        startFlag = true;
                        sb = new StringBuilder();
                    }
                    elements.push(qName);
                }
            }

            public void endElement (String uri, String localName, String qName)
                throws SAXException
            {
                try {
                    if (startFlag) {
                        if (qName.equalsIgnoreCase(parentQName)) {
                            if (logger.isDebugEnabled())
                                logger.debug("{} tag processing ended", parentQName);

                            elements.pop();

                            if (elements.isEmpty()) {
                                if (logger.isDebugEnabled())
                                    logger.debug(
                                        "XML to be processed and JSON object creation started : {}",
                                        sb.toString());
                                startFlag = false;
                                JSONObject json = null;
                                org.json.simple.JSONObject jsondata = null;
                                json = XML.toJSONObject(sb.toString(), true);
                                JSONParser parser = new JSONParser();
                                Object parsedObject = null;
                                parsedObject = parser.parse(json.toString());

                                if (parsedObject instanceof org.json.simple.JSONObject object) {
                                    jsondata = object;
                                }

                                Map<String, String> additionalFields = getAdditionalFileds();
                                for (Entry<String, String> entry : additionalFields.entrySet()) {
                                    if (entry.getKey().equalsIgnoreCase("TimeCreated")
                                        || entry.getKey().equalsIgnoreCase(
                                            "TimeUpdated"))
                                    {
                                        if (logger.isDebugEnabled()) {
                                            logger.debug(
                                                "Putting the creationDate : {}",
                                                creationDate);
                                        }
                                        if(jsondata!=null) {
                                            jsondata.put(entry.getKey(), creationDate);
                                        }
                                    }
                                    else {
                                        if(jsondata!=null) {
                                            jsondata.put(
                                                entry.getKey(),
                                                getDefaultValueForType(
                                                    entry.getValue()).toString());
                                        }
                                    }
                                }

                                if (!StringUtils.isEmpty(stageXMLData.getSenderBusinesssytemId())
                                                && jsondata != null) {
                                    jsondata.put(senderBusinessSystemIdKey,
                                                 stageXMLData.getSenderBusinesssytemId());
                                }

                                // This is required to identify the row which
                                // has to be reprocessed in case of Failures.
                                if(objectName.equalsIgnoreCase(ObjectTypes.User.getValue())){
                                    lineNum--;
                                }
                                if(jsondata!=null) {
                                    jsondata.put(KeyRowNumber, lineNum);
                                }

                                if (logger.isDebugEnabled())
                                    logger.debug(
                                        "XML to be processed and JSON object creation ended");
                                if (logger.isDebugEnabled())
                                    logger.debug(
                                        "Request started for database persistance");

                                boolean isRecordNewerThanLastSent = true;
                                if (stageXMLData.getOperation() == IntegrationOperationType.INCREMENTALLOAD.getValue()){
                                    // Check for update
                                    if(!checkForUpdate(
                                        tenantId,
                                        objectName,
                                        stageXMLData.getSenderBusinesssytemId(),
                                        jsondata,
                                        rowNumKeyMap,
                                        skippedRecordWarnings,
                                        lineNum,
                                        creationDate,isFMDObject))
                                    {
                                        isRecordNewerThanLastSent = false;
                                    }
                                }

                                if(isRecordNewerThanLastSent){
                                    if (reprocessLines != null) {
                                        if (reprocessLines.contains(lineNum)
                                            || lineNum > processFromRecordNumber)
                                        {
                                            addDataForPost(jsondata,objectName,isFMDObject);
                                        }
                                    }
                                    else if (lineNum > processFromRecordNumber) {
                                        addDataForPost(jsondata,objectName,isFMDObject);
                                    }
                                }
                                if(objectName.equalsIgnoreCase(ObjectTypes.User.getValue())) {
                                    Map<String, String> lookUpMap = entityVersionRepository.getLookupValueForObject(objectName,
                                        jsondata,
                                        isFMDObject);

                                    String key = "";
                                    for (String k : lookUpMap.keySet()) {
                                        key += lookUpMap.get(k) + "-";
                                    }
                                    key = key.substring(0, key.length() - 1);
                                    lineNumLookupKeyMap.put(lineNum, key);
                                }
                            }
                            lineNum++;
                        }
                        if (startFlag)
                            sb.append("</" + qName + ">");
                    }
                }
                catch (ParseException ex) {
                    logger.error("[MDNI_CRITICAL][ARIBA][XML_Processing] Tenant ID - {}, Object Name - {}, record ID - {} Exception {} while parsing ",
                                 anId,
                                 objectName,
                                 stageXMLData.getId(),
                                 ErrorUtil.getCompleteCausedByErrors(ex));
                }
                catch (IntegrationPayloadProcessorException | IntegrationServiceException ex) {
                    logger.error("[MDNI_CRITICAL][ARIBA][XML_Processing] Tenant ID - {}, Object Name - {}, record ID - {} Exception {} while parsing and transforming the payload ",
                                 anId,
                                 objectName,
                                 stageXMLData.getId(),
                                 ErrorUtil.getCompleteCausedByErrors(ex));
                }
            }

            public void characters (char ch[], int start, int length) throws SAXException
            {
                if (startFlag) {
                    sb.append(XMLUtil.replaceSpecialChar(ch, start, length));
                }
            }
        };
        boolean isMDNIPayload = stageXMLData.isMDNIPayload();
        PipedInputStream pipedDecrInput = null;

        if (!StringUtils.isEmpty(stageXMLData.getEncryptionVersion())) {
            // We need to decrypt the file before parsing
            // decrypt using old library
            //remove once all old flow encrypted objects are processed
            logger.info("Decrypt records using buyer");
            long startTime = Instant.now().toEpochMilli();
            pipedDecrInput = decryptUsingBuyer(
                xmlFilePath,
                stageXMLData,
                saxParser,
                handler);
            try {
                if (isMDNIPayload) {
                    populateDataArray(new InputStreamReader(pipedDecrInput));
                }
                else {
                    saxParser.parse(pipedDecrInput, handler);
                }

            }
            finally {
                pipedDecrInput.close();
            }
            long endTime = Instant.now().toEpochMilli();
            logger.info("Time taken to decrypt Buyer process XML: {} seconds", (endTime-startTime)/1000);
        }
        else if (stageXMLData.getDataCompressed() == 1 && (EncryptKey.KMS
            == EncryptKey.getEncryptKey(stageXMLData.getEncryptKey())))
        {                                                  // compressed files
                                                           // are encrypted here
                                                           // using kms
            String kmsEnabledProperty = ApplicationContextProvider.getApplicationContext()
                                                                  .getEnvironment()
                                                                  .getProperty(
                                                                      "kmsEnabled");
            boolean kmsEnabled = Boolean.parseBoolean(kmsEnabledProperty);

            if (!kmsEnabled) {
                logger.error(
                    "File {} has been encrypted with KMS but KMS is disabled during decrypt for Tenant - {}, Object - {} and job - {} ",
                    xmlFilePath, tenantId, objectName, stageXMLData.getId());
                throw new IntegrationPayloadProcessorException("File " + xmlFilePath
                                                                   + " has been encrypted with KMS but KMS is disabled during decrypt for Tenant - "
                                                                   + tenantId
                                                                   + ", Object - "
                                                                   + objectName
                                                                   + " and job - "
                                                                   + stageXMLData.getId());
            }
             logger.info("Decrypt records using KMS");
             long startTime = Instant.now().toEpochMilli();
             String zippedFilePath = xmlFilePath;
             InputStream unzippedInputStream = null;
             try {
                 unzippedInputStream = decryptFileAndUnzip(zippedFilePath);
                 if (isMDNIPayload) {
                     populateDataArray(new InputStreamReader(unzippedInputStream));
                 }else {
                     saxParser.parse(unzippedInputStream, handler);
                 }
             }
             catch (GeneralSecurityException | IOException e) {
                 // TODO Auto-generated catch block
                 logger.error("[MDNI_CRITICAL][ARIBA][XML_Processing] Tenant Id - {}, Object name - {}, record ID - {} Exception {} while decrypting and unzipping ",
                              anId,
                              objectName,
                              stageXMLData.getId(),
                              ErrorUtil.getCompleteCausedByErrors(e));
             }
             finally {
                 if(unzippedInputStream != null) {
                     unzippedInputStream.close();
                 }
             }
             long endTime = Instant.now().toEpochMilli();
             logger.info("Time taken to decrypt KMS process XML: {} seconds", (endTime-startTime)/1000);

         }
         else { //neither compressed nor encrypted
            if(HandlerUtil.isAdvancedStorageOptionEnabled()){
                CloudStorageFactory cloudStorageFactory = ApplicationContextProvider.getApplicationContext().getBean(
                        CloudStorageFactory.class);
                CloudStorageResponse cloudStorageResponse = null;
                try {
                    cloudStorageResponse = cloudStorageFactory.getCloudStorage().getStream(
                            xmlFilePath);
                    if (isMDNIPayload) {
                        try (InputStream inputStream = cloudStorageResponse.getInputStream()) {
                            populateDataArray(new InputStreamReader(inputStream));
                        }
                    } else {
                        saxParser.parse(cloudStorageResponse.getInputStream(), handler);
                    }
                } catch (CloudStorageException e) {
                    logger.error("Error while getting the object from cloud store", e);
                    throw new IntegrationPayloadProcessorException(e);
                }
                finally {
                    cloudStorageFactory.getCloudStorage().closeCloudObject(cloudStorageResponse);
                }

            }else {
                if (isMDNIPayload) {
                    populateDataArray(new InputStreamReader(new FileInputStream(xmlFilePath)));
                }else {
                    saxParser.parse(xmlFilePath, handler);
                }
            }
         }
         logger.info("finished parsing");

        IntegrationJobResponseProcessor integrationJobResponseProcessor = processData(
            anId,
            operation,
            objectName,
            stageXMLData,
            lineNumLookupKeyMap,
            jobResponseProcessor,
            skippedRecordWarnings);

        if(stageXMLData.getOperation() == IntegrationOperationType.INCREMENTALLOAD.getValue()) {
            updateEntityVersion(
                tenantId,
                stageXMLData.getSenderBusinesssytemId(),
                objectName,
                creationDate,
                rowNumKeyMap,
                jobResponseProcessor);
        }

        return integrationJobResponseProcessor;
    }

    private void populateDataArray (InputStreamReader inputStreamReader) throws IOException,
        JsonParseException, JsonMappingException, FileNotFoundException
    {
        if(dataArray == null)
            dataArray = new JSONArray();
        TypeReference<List<Map<String, Object>>> typeRef = new TypeReference<List<Map<String, Object>>>()
        {
        };
        List<Map<String, Object>> listOfMappings = mapper.readValue(inputStreamReader,
            typeRef);
        for(Map<String, Object> eachObject : listOfMappings) {
            org.json.simple.JSONObject json = new org.json.simple.JSONObject();
            Iterator<String> itr = eachObject.keySet().iterator();
            while(itr.hasNext()) {
                String key = itr.next();
                json.put(key, eachObject.get(key));
            }
            dataArray.add(json);
        }
    }

    private PipedInputStream decryptUsingBuyer (String xmlFilePath,
                                                StageXMLData stageXMLData,
                                                SAXParser saxParser,
                                                DefaultHandler handler)
        throws FileNotFoundException,
        IOException,
        SAXException
    {

        final InputStream encryptedInputStream = new FileInputStream(new File(xmlFilePath));
                        final PipedInputStream pipedDecrInput = new PipedInputStream();
        final PipedOutputStream pipedDecrOutput = new PipedOutputStream(pipedDecrInput);
        new Thread(new Runnable() {
                public void run ()
                {
                    try {
                    EncryptionUtil.decrypt(
                        encryptedInputStream,
                                               pipedDecrOutput,
                                               stageXMLData.getEncryptionVersion());
                    }
                catch (SecurityInitializationException
                    | GeneralSecurityException | IOException e)
                {
                    logger.error("[MDNI_CRITICAL][ARIBA][Decrypt] Object Name - {}, record ID - {} Exception {} while decrypting file using buyer key {} : ",
                                 stageXMLData.getObjectName(),
                                 stageXMLData.getId(),
                                 ErrorUtil.getCompleteCausedByErrors(e),
                                 xmlFilePath);
                    }
                }
            }).start();


            return pipedDecrInput;
        }

    /**
     * This method is responsible for updating the version of a object
     *
     * @param tenantId
     * @param senderBusinessSystemId
     * @param objectName
     * @param creationDate
     * @param rowNumKeyMap
     * @param jobResponseProcessor
     */
    private void updateEntityVersion (long tenantId,
                                      String senderBusinessSystemId,
                                      String objectName,
                                      String creationDate,
                                      Map<Integer, String> rowNumKeyMap,
                                      IntegrationJobResponseProcessor jobResponseProcessor)
    {
        List<Integer> reprocessLinesList = null;
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        EntityVersionRepository entityVersionRepository = (EntityVersionRepository)daoFactory.getMiscDAO(
            ObjectTypes.EntityVersion.getValue());

        if (jobResponseProcessor.getReprocessLineNumbers() != null
            && !jobResponseProcessor.getReprocessLineNumbers().isEmpty())
        {
            reprocessLinesList = Arrays.asList(
                jobResponseProcessor.getReprocessLineNumbers().split(",")).stream().map(
                    String::trim).map(Integer::parseInt).collect(Collectors.toList());
        }

        Set<Entry<Integer, String>> rowNumKeyMapSet = rowNumKeyMap.entrySet();

        for (Entry<Integer, String> entry : rowNumKeyMapSet) {
            if (reprocessLinesList != null
                && reprocessLinesList.contains(entry.getKey()))
            {
                logger.warn(
                    "Records having problem. Records did not proecess for tenantId [{}], senderBusinessSystemId{}, objectName [{}], rowId [{}], key [{}] ",
                    tenantId,
                    senderBusinessSystemId,
                    objectName,
                    entry.getKey(),
                    entry.getValue());
            }
            else {
                try {
                    processEntity(
                        tenantId,
                        senderBusinessSystemId,
                        objectName,
                        entry.getValue(),
                        creationDate,
                        entityVersionRepository);
                }
                catch (InvalidTypeCodeException | SQLException | IntegrationServiceException e) {
                    logger.error(
                        "Exception while saving version information in data base for tenantId [{}], senderBusinessSystemId [{}], objectName [{}], key [{}]",
                        tenantId,
                        senderBusinessSystemId,
                        objectName,
                        entry.getValue(),
                        e);
                }
            }
        }

        entityVersionRepository.processRecords(mapOfEntityVersions);
    }

    private void processEntity (long tenantId,
                                String senderBusinessSystemId,
                                String objectName,
                                String key,
                                String creationDate,
                                EntityVersionRepository entityVersionRepository) throws
        InvalidTypeCodeException,
        SQLException,
        IntegrationServiceException
    {
        EntityVersion entityVersion = null;
        PersistenceOperationType ops = PersistenceOperationType.UPDATE;
        String hashCode =  HandlerUtil.getHashCode(tenantId,senderBusinessSystemId,objectName,key);
        entityVersion = entityVersionRepository.findOne(hashCode);

        if (entityVersion == null) {
            entityVersion = new EntityVersion();
            ops = PersistenceOperationType.INSERT;
        }

        Date receivedCreationDate = HandlerUtil.parseDate(creationDate);

        setRequiredFieldsForEntity(entityVersion,
            receivedCreationDate, hashCode);

        mapOfEntityVersions.computeIfAbsent(ops, k -> new HashSet<>());
        Set<EntityVersion> entityVersionSet = mapOfEntityVersions.get(ops);
        entityVersionSet.add(entityVersion);
        mapOfEntityVersions.put(ops,entityVersionSet);
    }

    private void setRequiredFieldsForEntity (EntityVersion entityVersion,
                                             Date sentDate,
                                             String hashValue)
        throws InvalidTypeCodeException, SQLException
    {
        if (entityVersion.getDateLastSent() == null) {
            entityVersion.setId(hashValue);
        }
        entityVersion.setDateLastSent(sentDate);
    }

    /**
     * This method is responsible for deciding if one object need to be
     * considered depending on the version
     *
     * @param tenantId
     * @param objectName
     * @param senderBusinessSystemId
     * @param jsondata
     * @param rowNumKeyMap
     * @param skippedRecordWarnings
     * @param lineNum
     * @param creationDate
     * @return
     * @throws IntegrationPayloadProcessorException
     */
    protected boolean checkForUpdate (long tenantId,
                                      String objectName,
                                      String senderBusinessSystemId,
                                      org.json.simple.JSONObject jsondata,
                                      Map<Integer, String> rowNumKeyMap,
                                      List<String> skippedRecordWarnings,
                                      int lineNum,
                                      String creationDate,
                                      boolean isFMDObject)
        throws IntegrationPayloadProcessorException,IntegrationServiceException
    {
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        EntityVersionRepository entityVersionRepository = (EntityVersionRepository)daoFactory.getMiscDAO(
            ObjectTypes.EntityVersion.getValue());

        Map<String, String> lookUpMap = entityVersionRepository.getLookupValueForObject(
            objectName,
            jsondata,
            isFMDObject);

        String key = "";
        for (String k : lookUpMap.keySet()) {
            key += lookUpMap.get(k) + "-";
        }
        key = key.substring(0, key.length() - 1);

        if (logger.isDebugEnabled()) {
            logger.debug("key for object [{}] is [{}]", objectName, key);
        }

        EntityVersion entityVersion = null;
        String hashCode =  HandlerUtil.getHashCode(tenantId,senderBusinessSystemId,objectName,key);
        entityVersion = entityVersionRepository.findOne(hashCode);

        if (entityVersion != null) {
            // convert the creationDate string to date object
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

            Date receivedCreationDate = HandlerUtil.parseDate(creationDate);

            Timestamp receivedCreationTimeStamp = new Timestamp(
                receivedCreationDate.getTime());

            Date lastSentDate = entityVersion.getDateLastSent();

            Timestamp lastSentTimeStamp = new Timestamp(lastSentDate.getTime());

            if (receivedCreationTimeStamp != null && lastSentTimeStamp != null
                && (receivedCreationTimeStamp.compareTo(lastSentTimeStamp) > 0
                    || receivedCreationTimeStamp.compareTo(lastSentTimeStamp) == 0))
            {
                logger.info(
                    "Object is older. So need to update the record and send. lineNum [{}], object [{}], tenantId [{}], senderBusinessSystemId [{}]",
                    lineNum,
                    objectName,
                    tenantId,
                    senderBusinessSystemId);
                // Need to update and send
                rowNumKeyMap.put(lineNum, key);
                return true;
            }
            else {
                String skipMessage = "Record with lookupKey: " + key
                    + " is skipped because Record is older than last sent. So need to reject this update at LineNum: "
                    + lineNum + " , object: " + objectName + " , tenantId: " + tenantId
                    + " , senderBusinessSystemId: " + senderBusinessSystemId + ". ";

                logger.info(
                    "Object is already newer. So need to reject this update at lineNum [{}], object [{}], tenantId [{}], senderBusinessSystemId [{}]",
                    lineNum,
                    objectName,
                    tenantId,
                    senderBusinessSystemId);
                skippedRecordWarnings.add(skipMessage);
                return false;
            }

        }
        else {
            logger.info(
                "First time received. So need to insert in version table. lineNum [{}], object [{}], tenantId [{}], senderBusinessSystemId [{}]",
                lineNum,
                objectName,
                tenantId,
                senderBusinessSystemId);
            rowNumKeyMap.put(lineNum, key);
            return true;
        }
    }

    /**
     * Returns default list of fields to be sent as JSON Data
     *
     * @return
     */
    private Map<String, String> getAdditionalFileds ()
    {
        Map<String, String> fields = new HashMap<>();
        fields.put("TimeCreated", FieldType.DATE);
        fields.put("TimeUpdated", FieldType.DATE);
        fields.put("IsActive", FieldType.BOOLEANTRUE);
        return fields;
    }

    /**
     * Return the default value for each type
     *
     * @param type
     * @return
     */
    private Object getDefaultValueForType (String type)
    {
        switch (type) {
        case FieldType.DATE:
            return new Date();
        case FieldType.BOOLEANTRUE:
            return 1;
        default:
            return null;
        }
    }

    private void addDataForPost (org.json.simple.JSONObject jsonObject,String objectName,boolean isFMDObject)
    {
        if (dataArray == null) {
            dataArray = new JSONArray();
        }
        if(!isFMDObject) {
            //Alpha3 to Alpha2 CountryCode Conversion.
            GenericEntity entity = EntityFactory.getEntity(objectName);
            if (entity != null) {
                entity.processCountryCode(jsonObject);
            }
        }
        dataArray.add(jsonObject);
    }

    /**
     *
     * @param anId
     * @param operation
     * @param objectName
     * @param stageXMLData
     * @param lineNumLookupKeyMap
     * @param jobResponseProcessor
     * @param skippedRecordWarnings
     * @return
     * @throws IntegrationPayloadProcessorException
     */
    private IntegrationJobResponseProcessor processData (String anId,
                                                         int operation,
                                                         String objectName,
                                                         StageXMLData stageXMLData,
                                                         Map<Integer, String> lineNumLookupKeyMap,
                                                         IntegrationJobResponseProcessor jobResponseProcessor,
                                                         List<String> skippedRecordWarnings) throws
        IntegrationPayloadProcessorException
    {
        long tenantId = stageXMLData.getTenantId();
        String recordId = stageXMLData.getId();
        String senderBusinessSystemId = stageXMLData.getSenderBusinesssytemId();

        if (dataArray == null || dataArray.size() == 0) {
            logger.info(
                "No data to process during Integration Payload" + " Processing for job "
                    + stageXMLData.getId());
            IntegrationJobLogUtil.createIntegrationJobLogEntry(
                anId,
                tenantId,
                recordId,
                senderBusinessSystemId,
                objectName,
                stageXMLData.getStatus(),
                skippedRecordWarnings);
            return null;
        }

        if (!HandlerUtil.isMDCS() && objectName.equalsIgnoreCase(ObjectTypes.PaymentTerms.getValue())) {
            processPaymentTermsObject(stageXMLData);
        }

        int startIndex = 0;
        int endIndex = HandlerUtil.KeyBatchSize;
        int numberOfRecordsProcessed = 0;

        Map responseMap = null;
        String integrationJobLogId = IntegrationJobLogUtil.createIntegrationJobLogEntry(
            anId,
            tenantId,
            recordId,
            senderBusinessSystemId,
            objectName,
            stageXMLData.getStatus(),
            skippedRecordWarnings);
        boolean shouldContinueProcessing;

        if (dataArray.size() < endIndex
            || operation == IntegrationOperationType.FULLLOAD.getValue()) {
            try {
                responseMap = HandlerUtil.postDataToApp(
                    dataArray,
                    anId,
                    operation,
                    objectName,
                    senderBusinessSystemId,
                        stageXMLData);
                logger.debug("Processed records for record {}", recordId);
                numberOfRecordsProcessed = dataArray.size();
            } catch (IntegrationServiceException e) {
                logger.error("[MDNI_CRITICAL][ARIBA][Job_Processing] Tenant ID - {}, Object Name - {}, record ID - {}, senderBusinessSystemId - {} Exception {} while posting data to application",
                             anId,
                             objectName,
                             recordId,
                             senderBusinessSystemId,
                             ErrorUtil.getCompleteCausedByErrors(e));
                if (e.isTransient()) {
                    jobResponseProcessor.markTransientFailure();
                }
                throw new IntegrationPayloadProcessorException(e.getMessage());
            } finally {
                logger.debug("Response Map {}", responseMap);
                shouldContinueProcessing = jobResponseProcessor.processJobResponse(responseMap, 0,lineNumLookupKeyMap);
                if(!shouldContinueProcessing){
                    logger.debug("Ending the process as warning Threshold exceeded , startIndex {} , endIndex {} for record {}",
                        startIndex,
                        endIndex,
                        recordId);
                    jobResponseProcessor.setStatusError(true);
                }
                IntegrationJobLogUtil.logIntegrationJobProcessingDetails(
                    anId,
                    jobResponseProcessor,
                    skippedRecordWarnings,
                    tenantId,
                    recordId,
                    senderBusinessSystemId,
                    integrationJobLogId,
                    stageXMLData.getStatus());
                dataArray.clear();
            }

        }
        else {
            int batchNumber = 0;
            try {
                logger.info("Trying to process {} record size", dataArray.size());
                while ((endIndex <= dataArray.size() && startIndex != endIndex)) {
                    List<org.json.simple.JSONObject> subList = null;
                    JSONArray subArray = null;
                    subArray = new JSONArray();
                    subList = dataArray.subList(startIndex, endIndex);
                    subArray.addAll(subList);

                    responseMap = HandlerUtil.postDataToApp(
                        subArray,
                        anId,
                        operation,
                        objectName,
                        senderBusinessSystemId,
                            stageXMLData);
                    logger.debug("Response Map {}", responseMap);
                    shouldContinueProcessing = jobResponseProcessor.processJobResponse(responseMap, batchNumber,lineNumLookupKeyMap);
                    if(!shouldContinueProcessing){
                        logger.info("Ending the process as warning Threshold exceeded , startIndex {} , endIndex {} for record {}",
                            startIndex,
                            endIndex,
                            recordId);
                        jobResponseProcessor.setStatusError(true);
                        break;
                    }
                    logger.info(
                        "Processed records from startIndex {} to endIndex {} for record {} ",
                        startIndex,
                        endIndex,
                        recordId);
                    stageXMLData.setProcessFrom(endIndex);

                    startIndex = endIndex;
                    endIndex = (endIndex + HandlerUtil.KeyBatchSize) < dataArray.size() ?
                        endIndex + HandlerUtil.KeyBatchSize :
                        dataArray.size();
                    batchNumber++;
                    numberOfRecordsProcessed = endIndex;
                }
                IntegrationJobLogUtil.logIntegrationJobProcessingDetails(
                    anId,
                    jobResponseProcessor,
                    skippedRecordWarnings,
                    tenantId,
                    recordId,
                    senderBusinessSystemId,
                    integrationJobLogId,
                    stageXMLData.getStatus());
            } catch (IntegrationServiceException e) {
                logger.error("[MDNI_CRITICAL][ARIBA][Job_Processing] Tenant ID - {}, Object Name - {}, record ID - {} Exception {} while processing records from startIndex {} to endIndex {} ",
                             anId,
                             objectName,
                             recordId,
                             ErrorUtil.getCompleteCausedByErrors(e),
                             startIndex,
                             endIndex);
                if (e.isTransient()) {
                    jobResponseProcessor.markTransientFailure();
                }
                if (!MapUtils.isEmpty(responseMap)) {
                    logger.info(
                        "Updating Integration Job Log even though there seems to be is Exceptions, since the records are processed in batches");
                    IntegrationJobLogUtil.logIntegrationJobProcessingDetails(
                        anId,
                        jobResponseProcessor,
                        skippedRecordWarnings,
                        tenantId,
                        recordId,
                        senderBusinessSystemId,
                        integrationJobLogId,
                        stageXMLData.getStatus());

                    logger.info("Setting processfrom to previous batch for safety");
                    stageXMLData.setProcessFrom(endIndex - HandlerUtil.KeyBatchSize);
                }
                throw new IntegrationPayloadProcessorException(e.getMessage());
            } finally {
                dataArray.clear();
            }
        }

        logger.info("Complete XML is processed for recordId {} ", recordId);
        logger.info("Setting processfrom to actual number of records for {} ", recordId);
        stageXMLData.setProcessFrom(numberOfRecordsProcessed);
        return jobResponseProcessor;
    }

    /**
     ** Groups all paymentTerms json(mapOfuniqueNameJSONObjectList) for the same uniqueName with varying DayLimit.
     * Next iterate for each uniqueName and merge the PaymentTierInfo Objects under the common uniqueName
     */
    private void processPaymentTermsObject (StageXMLData stageXMLData)
    {
        JSONArray paymentTermsDataArray = new JSONArray();
        String senderBusinessSystemId = stageXMLData.getSenderBusinesssytemId();
        int lineNum = 1;
        Map mapOfuniqueNameJSONObjectList = getMapOfuniqueNameJSONObjectList();
        for (Object uniqueName : mapOfuniqueNameJSONObjectList.keySet()) {
            logger.debug("Processing for UniqueName {}",uniqueName);
            List<org.json.simple.JSONObject> jsonObjectList = (List<org.json.simple.JSONObject>) mapOfuniqueNameJSONObjectList.get(
                uniqueName);

            org.json.simple.JSONObject paymentTermsJSONObject = new org.json.simple.JSONObject();
            paymentTermsJSONObject.put("UniqueName", uniqueName);

            String defaultDesc = "";
            Map<String, org.json.simple.JSONObject> langDescMap = getConsolidatedDescription(jsonObjectList);
            JSONArray descriptionArray = new JSONArray();
            for (org.json.simple.JSONObject eachLangConsolidatedDesc : langDescMap.values()) {
                String desc = (String)eachLangConsolidatedDesc.get("Description");
                eachLangConsolidatedDesc.remove("Description");
                eachLangConsolidatedDesc.put("content", desc);
                descriptionArray.add(eachLangConsolidatedDesc);
                if(eachLangConsolidatedDesc.get("languageCode").equals("EN")) {
                    defaultDesc = (String)eachLangConsolidatedDesc.get("content");
                }
            }
            paymentTermsJSONObject.put("Description", descriptionArray);
            paymentTermsJSONObject.put("Name", defaultDesc);
            if(!StringUtils.isEmpty(senderBusinessSystemId)) {
                paymentTermsJSONObject.put(senderBusinessSystemIdKey, senderBusinessSystemId);
            }

            Map mapOfDayLimitPaymentTierInfo = getMapOfDayLimitPaymentTierInfo(jsonObjectList);

            for (Object dayLimit : mapOfDayLimitPaymentTierInfo.keySet()) {
                logger.debug("Processing for dayLimit {} , UniqueName {}",dayLimit,uniqueName);
                JSONArray paymentTermTiersInfoArray = new JSONArray();
                paymentTermTiersInfoArray.addAll((Collection) mapOfDayLimitPaymentTierInfo.get(dayLimit));
                org.json.simple.JSONObject paymentTermTierInfo = new org.json.simple.JSONObject();
                paymentTermTierInfo.put("PaymentTermTiersInfo", paymentTermTiersInfoArray);

                if(!StringUtils.isEmpty(senderBusinessSystemId)) {
                    paymentTermTierInfo.put(senderBusinessSystemIdKey, senderBusinessSystemId);
                }

                Object existingPaymentTermsStep = paymentTermsJSONObject.get("PaymentTermsSteps");

                if (existingPaymentTermsStep instanceof JSONArray array
                    && array.size() > 0) {
                    array.add(paymentTermTierInfo);
                    logger.debug("Adding PaymentTermTierInfo into PaymentTermsSteps for dayLimit {} , UniqueName {} with JSON value {} ",dayLimit,uniqueName,paymentTermTierInfo.toJSONString());
                    paymentTermsJSONObject.put("PaymentTermsSteps", existingPaymentTermsStep);
                }
                else {
                    JSONArray paymentSteps = new JSONArray();
                    paymentSteps.add(paymentTermTierInfo);
                    logger.debug("Adding PaymentTermTierInfo into PaymentTermsSteps for dayLimit {} , UniqueName {} with JSON value {} ",dayLimit,uniqueName,paymentTermTierInfo.toJSONString());
                    paymentTermsJSONObject.put("PaymentTermsSteps", paymentSteps);
                }
            }
            paymentTermsJSONObject.put(KeyRowNumber,lineNum++);
            populateActionCodeInfo(jsonObjectList, paymentTermsJSONObject);
            populateDefaultFields(paymentTermsJSONObject);
            logger.debug("Final JSON Object formed for uniqueName {} , {} ",uniqueName,paymentTermsJSONObject.toJSONString());
            paymentTermsDataArray.add(paymentTermsJSONObject);
        }

        if(paymentTermsDataArray.size() > 0){
            dataArray.clear();
            dataArray = paymentTermsDataArray;
        }
    }

    /**
     * Create map of uniqueName and JSONObjectList across all the PaymentTerm JSON Objects in the current payload.
     * @return
     */
    private  Map<String,List<org.json.simple.JSONObject>> getMapOfuniqueNameJSONObjectList()
    {
        Map<String,List<org.json.simple.JSONObject>> mapOfuniqueNameJSONObjectList = new HashMap();
        List<org.json.simple.JSONObject> jsonObjectList;
        for (Object obj : dataArray) {
            if (obj instanceof org.json.simple.JSONObject jsonObject) {

                Object key = getNestedData(jsonObject, paymentTermsUniqueKey);

                if (key != null && key instanceof String uniqueKey) {
                    if (mapOfuniqueNameJSONObjectList.get(key) == null) {
                        jsonObjectList = new ArrayList<>();
                        jsonObjectList.add(jsonObject);
                        logger.debug("Adding into mapOfuniqueNameJSONObjectList , key {} , value {}",uniqueKey,jsonObjectList.toString());
                        mapOfuniqueNameJSONObjectList.put(uniqueKey, jsonObjectList);
                    }
                    else{
                        jsonObjectList = mapOfuniqueNameJSONObjectList.get(uniqueKey);
                        jsonObjectList.add(jsonObject);
                        logger.debug("Adding into mapOfuniqueNameJSONObjectList , key {} , value {}",uniqueKey,jsonObjectList.toString());
                        mapOfuniqueNameJSONObjectList.put(uniqueKey,jsonObjectList);
                    }
                }
            }
        }
        return mapOfuniqueNameJSONObjectList;
    }

    private Object getNestedData (org.json.simple.JSONObject jsonObject, String key)
    {
        int index = key.indexOf(".");
        if (index != -1) {
            String currentKey = key.substring(0, index);
            if (jsonObject.get(currentKey) instanceof Map) {
                return getNestedData((org.json.simple.JSONObject) jsonObject.get(currentKey),
                    key.substring(index + 1, key.length()));
            }
        }
        else {
            return jsonObject.get(key);
        }
        return null;
    }

    private void  populateActionCodeInfo(List<org.json.simple.JSONObject> jsonObjectList,
    										org.json.simple.JSONObject paymentTermsJSONObject) {
    		org.json.simple.JSONObject jsonObject = jsonObjectList.get(0);
    		Object actionCode = getNestedData(jsonObject, ActionCodeTag);
    		if(actionCode!= null && actionCode instanceof String code) {
    			paymentTermsJSONObject.put(ActionCodeTag, code);
    		}

    }

    private Map getMapOfDayLimitPaymentTierInfo(List<org.json.simple.JSONObject> jsonObjectList){
        Map mapOfDayLimitPaymentTierInfo = new HashMap();

        for (int i = 0; i < jsonObjectList.size(); i++) {
            org.json.simple.JSONObject jsonObject = jsonObjectList.get(i);
            Object paymentTermTiersInfoArray = getNestedData(jsonObject, paymentTermTiersInfoKey);
            if (paymentTermTiersInfoArray instanceof JSONArray paymentTermArray) {
                JSONArray filteredPaymentTermTiersInfoArray = getFilteredPaymentTermTierInfoArray(paymentTermArray);
                Object dayLimit = getNestedData(jsonObject, paymentTermsDayLimitKey);
                mapOfDayLimitPaymentTierInfo.put(dayLimit,filteredPaymentTermTiersInfoArray);
            }
        }
        return mapOfDayLimitPaymentTierInfo;
    }

    private JSONArray getFilteredPaymentTermTierInfoArray(JSONArray paymentTermTiersInfoArray){
        JSONArray filteredPaymentTermTiersInfoArray = new JSONArray();
        for(Object object : paymentTermTiersInfoArray){
            if(object instanceof org.json.simple.JSONObject jsonObject){
                jsonObject.remove("ID");
                jsonObject.remove("FixedDay");
                jsonObject.remove("AdditionalMonth");
                filteredPaymentTermTiersInfoArray.add(jsonObject);
            }
        }
        return filteredPaymentTermTiersInfoArray;
    }

    @SuppressWarnings("unchecked")
    private void populateDefaultFields(org.json.simple.JSONObject paymentTermsJSONObject){
        Map<String, String> additionalFields = getAdditionalFileds();
        for (Entry<String, String> entry : additionalFields.entrySet()) {
            if (entry.getKey().equalsIgnoreCase("TimeCreated")
                || entry.getKey().equalsIgnoreCase(
                "TimeUpdated"))
            {
                logger.info(
                    "Putting the creationDate : {}",
                    creationDatePaymentTerms);
                paymentTermsJSONObject.put(entry.getKey(), creationDatePaymentTerms);
            }
            else {
                paymentTermsJSONObject.put(
                    entry.getKey(),
                    getDefaultValueForType(
                        entry.getValue()).toString());
            }
        }
    }

    /**
     * Concatenate all the Default Description i.e "EN" across all the JSONObjects for a uniqueName
     * @param jsonObjectList
     * @return
     */
    public Map<String, org.json.simple.JSONObject> getConsolidatedDescription (List<org.json.simple.JSONObject> jsonObjectList)
    {
        Map<String, org.json.simple.JSONObject> langDescMap = new HashMap();
        for (org.json.simple.JSONObject jsonObject : jsonObjectList) {
            Object descriptionObject = getNestedData(jsonObject, "Description");
            if (descriptionObject instanceof JSONArray descriptionArray) {
                for (Object eachDescription : descriptionArray) {
                    if (eachDescription instanceof org.json.simple.JSONObject) {
                        populateLangDescMap(langDescMap, eachDescription);
                    }
                }
            }
            else if (descriptionObject instanceof org.json.simple.JSONObject) {
                populateLangDescMap(langDescMap, descriptionObject);
            }
        }
        return langDescMap;
    }

    private void populateLangDescMap (Map<String, org.json.simple.JSONObject> langDescMap,
                                      Object descriptionObject)
    {
        org.json.simple.JSONObject eachLangDesc = (org.json.simple.JSONObject)descriptionObject;
        String descToAppend = (String)eachLangDesc.get("Description");
        String appendedDesc = descToAppend;
        if (langDescMap.containsKey(eachLangDesc.get("languageCode"))) {
            String descAlreadyPresent = (String)langDescMap.get(
                eachLangDesc.get("languageCode")).get("Description");
            appendedDesc = descAlreadyPresent + "," + descToAppend;
            eachLangDesc.put("Description", appendedDesc);
        }
        langDescMap.put((String)eachLangDesc.get("languageCode"), eachLangDesc);
    }

    private boolean isXmlNeedsReprocessing (IntegrationJobResponseProcessor jobResponseProcessor)
    {
        return (jobResponseProcessor.isNoRespose()
            || (jobResponseProcessor.getReprocessLineNumbers() != null
                && !jobResponseProcessor.getReprocessLineNumbers().isEmpty()
                && jobResponseProcessor.getFatalErrorMessages() != null
                && jobResponseProcessor.getFatalErrorMessages().isEmpty()));
    }

    private boolean isMarkXMLRecordFatal (IntegrationJobResponseProcessor jobResponseProcessor)
    {
        return jobResponseProcessor.getFatalErrorMessages() != null
            && !jobResponseProcessor.getFatalErrorMessages().isEmpty();
    }

    private InputStream decryptFileAndUnzip (String encryptedZippedFilePath)
        throws GeneralSecurityException, IOException
    {
        MDNIEncryptionService encryptionService = ApplicationContextProvider.getApplicationContext().getBean(
            MDNIEncryptionService.class);
        PipedInputStream pipedDecrInput = new PipedInputStream();
        PipedOutputStream pipedDecrOutput = new PipedOutputStream(pipedDecrInput);
            // first decrypt and then unzip
            // decrypting
        new Thread(new Runnable() {
                public void run ()
                {
                try (
                    InputStream encryptedInputStream = new FileInputStream(
                        new File(encryptedZippedFilePath));
                    InputStream decrInputStream = encryptionService.getEncryptionService().getDecryptingInputStream(
                        encryptedInputStream);)
                {
                        logger.info("get value of tag system based decryption");
                        byte[] buffer = new byte[1024];
                        int len;
                        while ((len = decrInputStream.read(buffer)) != -1) {
                            logger.info("inside decrypt");
                        pipedDecrOutput.write(buffer, 0, len);
                        }
                    pipedDecrOutput.close();

                    }
                    catch (GeneralSecurityException | IOException e) {
                        logger.error("[MDNI_CRITICAL][ARIBA][Decrypt] Exception {} while decrypting {} : ",
                                     ErrorUtil.getCompleteCausedByErrors(e),
                                     encryptedZippedFilePath);
                        try {
                            pipedDecrInput.close();
                        }
                        catch (IOException e1) {
                            logger.error("[MDNI_CRITICAL][ARIBA][Decrypt] Exception {} while closing piped stream {}",
                                         ErrorUtil.getCompleteCausedByErrors(e1),
                                         encryptedZippedFilePath);
                        }
                    }
                }
            }).start();
            // unzipping the decrypted input stream
        ZipInputStream unzippedStream = new ZipInputStream(pipedDecrInput);
                unzippedStream.getNextEntry();
                return unzippedStream;
            }
        }
