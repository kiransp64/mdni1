package com.sap.ariba.erpintegration.service.rs;

import com.sap.ariba.erpintegration.handlers.RequestHandler;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import org.springframework.web.bind.MissingServletRequestParameterException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

public class IntegrationJobLogProviderService
{
    private static final String KeyAction = "GetIntegrationJobs";

    @GET
    public Response getIntegrationJobs (@Context HttpServletRequest request)
            throws IntegrationServiceException,MissingServletRequestParameterException
    {
        RequestHandler requestHandler = RequestHandler.getHandler(KeyAction);
        return requestHandler.execute(request);
    }
}
