package com.sap.ariba.erpintegration.audit;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class has implementation to insert an audit record in audit_tab table
 * asynchronously.
 * 
 * @author i339952
 */
public class AuditManagerImpl implements AuditManager
{

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.audit.AuditManagerImpl";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private volatile static AuditManagerImpl auditManagerImpl;

    private ExecutorService executerService = null;

    private BlockingQueue<AuditTask> auditTasks = null;


    private AuditManagerImpl ()
    {
        if (logger.isDebugEnabled()) {
            logger.debug("Audit Processor starting.");
        }
        executerService = Executors.newSingleThreadExecutor();
        auditTasks = new LinkedBlockingQueue<>();
        AuditProcessor auditProcessor = new AuditProcessor(auditTasks);
        executerService.submit(auditProcessor);
        if (logger.isDebugEnabled()) {
            logger.debug("Audit Processor started.");
        }
    }

    /**
     * This method returns a AuditManagerImpl instance
     * 
     * @return
     */
    public static AuditManagerImpl getInstance ()
    {
        if (auditManagerImpl == null) {
            synchronized(AuditManagerImpl.class) {
                if (auditManagerImpl == null) {
                    auditManagerImpl = new AuditManagerImpl();
                }
            }
        }
        return auditManagerImpl;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void logAudit (String tenantId, Operation operation, String comment)

    {
        if (logger.isDebugEnabled()) {
            logger.debug(
                "Adding to the queue for audit. Data [tenantId: {}, OperationId: {}, OperationName: {}, Comment: {}]",
                tenantId,
                operation.getOperationId(),
                operation.getOperationName(),
                comment);
            logger.debug("Queue Size before put : {}", auditTasks.size());
        }

        AuditTask auditTask = new AuditTask(tenantId, operation, comment);
        try {
            auditTasks.put(auditTask);
        }
        catch (InterruptedException e) {
            logger.error("Task interupted : {}", e.getMessage(), e);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Queue Size after put : {}", auditTasks.size());
            logger.debug("Adding task to queue Ended");
        }
    }

    public ExecutorService getExecuterService ()
    {
        return executerService;
    }

    public void setExecuterService (ExecutorService executerService)
    {
        this.executerService = executerService;
    }

    public BlockingQueue<AuditTask> getAuditTasks ()
    {
        return auditTasks;
    }

    public void setAuditTasks (BlockingQueue<AuditTask> auditTasks)
    {
        this.auditTasks = auditTasks;
    }
}
