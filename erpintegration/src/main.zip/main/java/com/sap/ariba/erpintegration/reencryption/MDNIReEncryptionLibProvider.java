package com.sap.ariba.erpintegration.reencryption;

import com.sap.ariba.encryption.ReEncryption;
import com.sap.ariba.encryption.config.SupportedJobTypes;
import com.sap.ariba.encryption.scheduler.JobSchedulerException;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.PersistenceContext;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

@Component
@ConditionalOnExpression("${environment.mdcs:false} == false && ${isInternal:false} == false && ${kmsEnabled:false} == true && ${reEncryption:false} == true")
public class MDNIReEncryptionLibProvider
{
    private static final Logger logger = LoggerFactory.getLogger(MDNIReEncryptionLibProvider.class);   
    private static final String USERNAME = "org.quartz.dataSource.myDS.user";
    private static final String PASSWORD = "org.quartz.dataSource.myDS.password";
    private static final String URL = "org.quartz.dataSource.myDS.URL";
    private static final String REENCRYPTIONPROPERTIESFILE = "/re-encryption.properties";
    
    
    @PersistenceContext
    EntityManager em;
    
    @Autowired
    ReEncryptionKeyConfiguration keyConfig;
   
    @Value("${spring.datasource.username}")
    private String username;
    
    @Value("${reEncryptionTimeOutInMinutes}")
    private String reEncryptionTimeOutInMinutes;
    
    @Value("${spring.datasource.password}")
    private String password;

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${re-encryption.scheduler.cron-string}")
    private String cronString;

    private ReEncryption reEncryption = null;
    
    @PostConstruct
    public void initReEncryptionLibrary(){
        EntityManagerFactory emf=em.getEntityManagerFactory();
        Properties reEncryptionProperties = getProperties();
        logger.info("inside reEncryption libr {}");
        try {
            reEncryption =
                new ReEncryption(emf, reEncryptionProperties);
            reEncryption.setSingleEncryptionKeyConfig(keyConfig);
            reEncryption.scheduleReEncryptionJob(cronString,
                new Date(),
                Integer.parseInt(reEncryptionTimeOutInMinutes),
                SupportedJobTypes.FileType);
            reEncryption.startJobs();
            
        }
        catch(JobSchedulerException e) {
            logger.info("Re-Encryption lib exception {} {}", e.getMessage());
            e.printStackTrace();
        }
        
    }
    
    public Properties getProperties() {
        Properties quartzProperties = new Properties();
        quartzProperties.setProperty(USERNAME, username);
        quartzProperties.setProperty(PASSWORD, password);
        quartzProperties.setProperty(URL, url);       
        try(InputStream is = this.getClass().getResourceAsStream(REENCRYPTIONPROPERTIESFILE)) {
            quartzProperties.load(is);
        }
        catch (IOException e) {
            logger.info("Could not load re-encryption properties {}", e.getMessage());
        }
        
        logger.info("properties : {}", quartzProperties.toString());
        return quartzProperties;
    }
    
    public ReEncryption getReEncryption ()
    {
        return reEncryption;
    }
    
}
