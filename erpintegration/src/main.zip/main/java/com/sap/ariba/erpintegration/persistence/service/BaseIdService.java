package com.sap.ariba.erpintegration.persistence.service;

/**
 * Created by i318483 on 02/06/17.
 */
public interface BaseIdService
{
    public String allocateBaseId(String className, Long variant) throws InvalidTypeCodeException;
}
