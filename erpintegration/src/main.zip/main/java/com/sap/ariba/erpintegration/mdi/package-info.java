/**
 * Contains classes handling SCIM functionality.
 *
 * Initially SCIM was planned as a different Micro Service and MDNI name came up.
 *
 * Earlier OneMDS/MDI was not present, hence this was named as mdi. All the contents
 * of MDI microservice were moved under mdi package.
 *
 * TODO: Rename this to be relevant to scim.
 */
package com.sap.ariba.erpintegration.mdi;