package com.sap.ariba.erpintegration.cache;

import java.util.HashMap;

public class LookUpValueCacheImpl extends HashMap<String, String>
    implements LookUpValueCache
{

    public LookUpValueCacheImpl ()
    {
        super();
    }

    @Override
    public String get (String key)
    {
        return super.get(key);
    }

    @Override
    public String put (String key, String value)
    {
        return super.put(key, value);
    }

    @Override
    public boolean containsKey (String key)
    {
        return super.containsKey(key);
    }

}
