package com.sap.ariba.erpintegration.persistence.service;

import com.sap.ariba.erpintegration.persistence.dao.SequenceNumberGetter;
import com.sap.ariba.erpintegration.persistence.dao.TypeMapDao;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.model.TypeMap;
import com.sap.ariba.erpintegration.util.BaseIdGenerator;

/**
 * Created by i318483 on 02/06/17.
 */
public class BaseIdServiceImpl implements BaseIdService {

    private static final String KeyTypeMap = "TypeMap";
    private static final String KeySequenceNumberGetter = "SequenceNumberGetter";
    private static final long ServiceCode = 10;

    private final Object LocalBaseIdLock = new Object();

    private volatile static BaseIdServiceImpl baseIdServiceImpl;

    private BaseIdServiceImpl() {
    }

    public static BaseIdServiceImpl getInstance() {
        if (baseIdServiceImpl == null) {
            synchronized (BaseIdServiceImpl.class) {
                if (baseIdServiceImpl == null) {
                    baseIdServiceImpl = new BaseIdServiceImpl();
                }
            }
        }
        return baseIdServiceImpl;
    }

    @Override
    public String allocateBaseId(String className,
                                 Long variant) throws
            InvalidTypeCodeException {
        synchronized (LocalBaseIdLock) {
            TypeMap typeMap = getTypeCode(className);
            if (typeMap == null) {
                throw new InvalidTypeCodeException(className);
            }
            long essentialTypeCode = getEssentialTypeCode();
            return BaseIdGenerator.generateBaseId(
                    variant,
                    typeMap.getTypeMapCode(),
                    essentialTypeCode,
                    ServiceCode);
        }
    }

    private TypeMap getTypeCode(String className) {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TypeMapDao typeMapDao = (TypeMapDao) factory.getMiscDAO(KeyTypeMap);
        return typeMapDao.findOne(className);
    }

    private long getEssentialTypeCode()
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        SequenceNumberGetter sequenceNumberGetter = (SequenceNumberGetter) factory.getMiscDAO(
                KeySequenceNumberGetter);
        return sequenceNumberGetter.getNextSequenceNumber();
    }
}
