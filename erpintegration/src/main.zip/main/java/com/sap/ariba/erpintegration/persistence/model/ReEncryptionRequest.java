package com.sap.ariba.erpintegration.persistence.model;

import java.util.List;

public class ReEncryptionRequest
{
    List<TenantLevel> tenantLevels;

    String applicationId;

    String supportedTenantLevel;

    public List<TenantLevel> getTenantLevels ()
    {
        return tenantLevels;
    }

    public void setTenantLevels (List<TenantLevel> tenantLevels)
    {
        this.tenantLevels = tenantLevels;
    }

    public String getApplicationId ()
    {
        return applicationId;
    }

    public void setApplicationId (String applicationId)
    {
        this.applicationId = applicationId;
    }

    public String getSupportedTenantLevel ()
    {
        return supportedTenantLevel;
    }

    public void setSupportedTenantLevel (String supportedTenantLevel)
    {
        this.supportedTenantLevel = supportedTenantLevel;
    }    
}
