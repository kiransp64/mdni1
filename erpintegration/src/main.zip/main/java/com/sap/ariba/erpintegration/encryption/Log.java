package com.sap.ariba.erpintegration.encryption;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Log
{
    static final Logger encryption = LoggerFactory.getLogger("encryption");
}
