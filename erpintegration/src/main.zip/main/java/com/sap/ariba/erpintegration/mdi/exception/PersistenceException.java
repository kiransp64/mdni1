package com.sap.ariba.erpintegration.mdi.exception;

public class PersistenceException extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public PersistenceException (Exception e)
    {
        super(e);
    }

    public PersistenceException (String message)
    {
        super(message);
    }

    public PersistenceException (String message, Exception e)
    {
        super(message, e);
    }
}
