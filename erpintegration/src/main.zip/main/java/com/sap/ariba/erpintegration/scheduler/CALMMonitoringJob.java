/*
 * Copyright (c) 2023. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.scheduler;

import com.sap.ariba.erpintegration.SchedulerConfig;
import com.sap.ariba.erpintegration.monitor.exception.PassportException;
import com.sap.ariba.erpintegration.monitor.im.helper.IMHelper;
import com.sap.ariba.erpintegration.monitor.im.util.IMConstants;
import com.sap.ariba.erpintegration.monitor.passport.PassportHandlerImpl;
import com.sap.ariba.erpintegration.monitor.passport.context.ContextHandlerImpl;
import com.sap.ariba.erpintegration.monitor.passport.context.EventContext;
import com.sap.ariba.erpintegration.monitor.passport.core.persistance.Passport;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.IM_MDNI_JOB_CRITICAL;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.JOB_ID;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.SAP_PASSPORT;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.TENANT_ID;

/**
 * This Job is introduced to send IM event for particular JOB id which is not being deleted from Passport table.
 * It will pick all the job id and check the status of Job id from StageXMLData , if status is not in (0,1,3) status then it will send event to IM and delete the entry .
 */
@Component
@DisallowConcurrentExecution
@ConditionalOnExpression(IMConstants.INTEGRATION_MONITORING_ENABLE)
public class CALMMonitoringJob implements Job
{

    private static Logger log = LoggerFactory.getLogger(CALMMonitoringJob.class);

    @Value("${integration.monitoring.enabled}")
    private boolean isImEnable;

    @Value("${calm.integration.mdni.pending.passport.job.schedule}")
    private String calmMonitoringJobSchedule;

    @Lazy
    @Autowired
    @Qualifier("passportHandler")
    private PassportHandlerImpl passportHandler;

    @Lazy
    @Autowired
    private IMHelper imHelper;

    @Lazy
    @Autowired
    private ContextHandlerImpl contextHandler;

    @Override
    public void execute (JobExecutionContext jobExecutionContext) throws JobExecutionException
    {
        String jobId = "";
        try {
            if (isImEnable) {
                DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
                StageXMLDataRepository dao = (StageXMLDataRepository)daoFactory.getGenericDAOStageData(ObjectTypes.XmlPayload.name());
                List<Passport> passportList = passportHandler.getAllPassportData();
                if (passportList != null && !passportList.isEmpty()) {
                    for (Passport passport : passportList) {
                        jobId = passport.getJobId();
                        if (StringUtils.isNotEmpty(jobId)) {
                            StageXMLData jobData = dao.findOne(jobId);
                            if (ObjectUtils.isNotEmpty(jobData)) {
                                int jobStatus = jobData.getStatus();
                                //Will send monitoring event to IM/ESS if Job status is not PENDING or PROCESSING or NEED-REPROCESSING(0,1,3) and will delete the entry from Passport table.
                                if (!checkJobStatus(jobStatus)) {
                                    String anId = Utility.getANId(jobData.getTenantId());
                                    //set necessary parameter to current Thread context like passport token,jobid, tenant id..
                                    Map<String, String> headerMap = new HashMap<>();
                                    headerMap.put(SAP_PASSPORT,
                                                  passport.getPassportToken());
                                    headerMap.put(JOB_ID,
                                                  jobId);
                                    headerMap.put(TENANT_ID,
                                                  anId);
                                    EventContext eventContext = contextHandler.constructRequestContext(headerMap);
                                    eventContext.setSourceEventId(passport.getSourceEventId());//setting source event id to current Thread.
                                    contextHandler.setContextInThread(eventContext);
                                    log.debug("[CALM_MDNI_RECOVERABLE_JOB], Job Id - {}, Tenant Id - {}, Calm integration cron job to resend event to IM/ESS and delete successful entry from passport table.",
                                              jobId,
                                              anId);
                                    imHelper.processIMMonitoring(anId,
                                                                 jobId,
                                                                 jobData,
                                                                 "");
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (PassportException e) {
            log.error("{} , Job Id - {} ,Exception - {}, while deleting sap passport token entry based on info from DB.",
                      IM_MDNI_JOB_CRITICAL,
                      jobId,
                      ErrorUtil.getCompleteCausedByErrors(e));
        }
        catch (Exception e) {
            log.error("{}, Job Id - {} ,Exception - {}, occurred while running calm monitoring job scheduler.",
                      IM_MDNI_JOB_CRITICAL,
                      jobId,
                      ErrorUtil.getCompleteCausedByErrors(e));
        }

    }

    /**
     * Check job status if status is 0,1,3
     *
     * @param jobStatus
     * @return true/false
     */
    private boolean checkJobStatus (int jobStatus)
    {
        return jobStatus == 0 || jobStatus == 1 || jobStatus == 3;
    }

    @Bean(name = "calmMonitoringJobDetailBean")
    public JobDetailFactoryBean calmMonitoringJobDetailFactory ()
    {
        log.debug("Creating calmMonitoringJobDetailBean");
        return SchedulerConfig.createJobDetail(this.getClass());
    }

    @Bean(name = "calmMonitoringCronTrigger")
    public CronTriggerFactoryBean calmMonitoringCronTrigger (
                    @Qualifier("calmMonitoringJobDetailBean") JobDetail jobDetail)
    {
        log.debug("Creating calmMonitoringCronTrigger");
        return SchedulerConfig.createCronTrigger(jobDetail,
                                                 calmMonitoringJobSchedule);
    }
}
