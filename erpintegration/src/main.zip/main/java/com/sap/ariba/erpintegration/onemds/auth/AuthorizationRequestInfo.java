package com.sap.ariba.erpintegration.onemds.auth;

public class AuthorizationRequestInfo
{


    private String clientID;
    private String clientSecret;
    private String authURL;
    private String zoneId;

    public AuthorizationRequestInfo (String clientID,
                                     String clientSecret,
                                     String authURL,
                                     String zoneId)
    {
        this.clientID = clientID;
        this.clientSecret = clientSecret;
        this.authURL = authURL;
        this.zoneId = zoneId;
    }
    public String getClientID ()
    {
        return clientID;
    }

    public void setClientID (String clientID)
    {
        this.clientID = clientID;
    }

    public String getClientSecret ()
    {
        return clientSecret;
    }

    public void setClientSecret (String clientSecret)
    {
        this.clientSecret = clientSecret;
    }

    public String getAuthURL ()
    {
        return authURL;
    }

    public void setAuthURL (String authURL)
    {
        this.authURL = authURL;
    }

    public String getZoneId ()
    {
        return zoneId;
    }

    public void setZoneId (String zoneId)
    {
        this.zoneId = zoneId;
    }

}
