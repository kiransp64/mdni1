package com.sap.ariba.erpintegration.security;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import java.util.Properties;

import jakarta.xml.soap.MessageFactory;
import jakarta.xml.soap.SOAPException;
import jakarta.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerException;

import org.apache.wss4j.common.crypto.Crypto;
import org.apache.wss4j.common.crypto.CryptoFactory;
import org.apache.wss4j.common.ext.WSSecurityException;
import org.apache.wss4j.common.util.XMLUtils;
import org.apache.wss4j.dom.message.WSSecHeader;
import org.apache.wss4j.dom.message.WSSecSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

/**
 * Signature service used for signing WS message xml strings <br>
 * Accepts xml message as input and return signed xml message.
 * 
 * @author i501987 Hanumesh
 *
 */
@Component
public class WSMessageSignatureService {

	private static final Logger logger = LoggerFactory.getLogger(WSMessageSignatureService.class);

	@Value("${org.apache.ws.security.crypto.merlin.keystore.alias:#{null}}")
	private String keyAlias;

	@Value("${privatekeypassword:#{null}}")
	private String privateKeyPass;

	/**
	 * Key Identifier used for signing ,currently uses
	 * WSConstants.X509_KEY_IDENTIFIER <br>
	 * If requires can configure to use different key identifier.
	 */
	@Value("${KeyIdentifierType:3}")
	private int signKeyIdenType;

	/**
	 * Digest algorithm used for signing ,currently uses WSConstants.SHA256 <br>
	 * If requires can configure to use different digest algorithm.
	 */
	@Value("${DigestAlgorithm:http://www.w3.org/2001/04/xmlenc#sha256}")
	private String digestAlgorithm;

	@Autowired
	@Qualifier("SignKeyStore")
	private Properties keyStoreProperties;

	public String signMessage(String xmlString) {

		InputStream xmlStream = new ByteArrayInputStream(xmlString.getBytes());
		SOAPMessage soapMessage;
		try {
			soapMessage = MessageFactory.newInstance().createMessage(null, xmlStream);
			Optional<String> signSoapMessage = signSoapMessage(soapMessage);
			return signSoapMessage.orElse(xmlString);
		} catch (IOException | SOAPException e) {
			logger.error("[MDNI_CRITICAL] Error creating soap meaasge from xml string response");
		}

		return xmlString;
	}

	/**
	 * Takes xml message as input and returned signed xml message <br>
	 * Return null(optinal.empty()) on exceptions .
	 * 
	 * @param soapMessage
	 *            Input xml message
	 * @return Signed xml message
	 */
	private Optional<String> signSoapMessage(SOAPMessage soapMessage) throws IOException
	{
		try {
			Document doc = soapMessage.getSOAPBody().getOwnerDocument();
			Crypto crypto = CryptoFactory.getInstance(keyStoreProperties);

			WSSecSignature sign = new WSSecSignature(doc);
			sign.setUserInfo(keyAlias, privateKeyPass);
			sign.setKeyIdentifierType(signKeyIdenType);
			sign.setUseSingleCertificate(true);
			sign.setDigestAlgo(digestAlgorithm);

			WSSecHeader secHeader = sign.getSecurityHeader();
			secHeader.insertSecurityHeader();
			Document signedDoc = sign.build(crypto);

            return Optional.ofNullable(XMLUtils.prettyDocumentToString(signedDoc));

		} catch (SOAPException e) {
			logger.error("Signing soap message failed , error getting soap body : {}", e);
		} catch (WSSecurityException e) {
			logger.error("Signing soap message failed , error creating security header : {}", e);
		} catch (TransformerException e) {
			logger.error(
					"Signing soap message failed , error transforming signed message to string : {}", e);
		}		
		return Optional.empty();
	}

}
