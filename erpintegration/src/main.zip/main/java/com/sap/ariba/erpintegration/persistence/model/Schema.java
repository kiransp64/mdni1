package com.sap.ariba.erpintegration.persistence.model;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.type.NumericBooleanConverter;
import java.io.Serializable;
import java.util.Date;

/**
 * This is the POJO class for SCHEMA_TAB
 * 
 * @author i339952
 */

@Entity
@Table(name = "SCHEMA_TAB")
@DiscriminatorValue("b")
public class Schema implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String objectType = "Schema";
    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "DATE_CREATED")
    private Date dateCreated;

    @Column(name = "DATE_UPDATED")
    private Date dateUpdated;

    @Column(name = "TENANT_ID")
    private long tenantId;

    @Column(name = "SENDER_BUSINESS_SYSTEM_ID")
    private String senderBusinessSystemId;

    @Column(name = "OBJECT_NAME")
    private String objectName;

    @Convert(converter = NumericBooleanConverter.class)
    @Column(name = "IS_FMD")
    private Boolean isFMD;

    @Column(name = "PATH")
    private String path;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public Date getDateCreated ()
    {
        return dateCreated;
    }

    public void setDateCreated (Date dateCreated)
    {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated ()
    {
        return dateUpdated;
    }

    public void setDateUpdated (Date dateUpdated)
    {
        this.dateUpdated = dateUpdated;
    }

    public long getTenantId ()
    {
        return tenantId;
    }

    public void setTenantId (long tenantId)
    {
        this.tenantId = tenantId;
    }

    public String getSenderBusinessSystemId ()
    {
        return senderBusinessSystemId;
    }

    public void setSenderBusinessSystemId (String senderBusinessSystemId)
    {
        this.senderBusinessSystemId = senderBusinessSystemId;
    }

    public String getPath ()
    {
        return path;
    }

    public void setPath (String path)
    {
        this.path = path;
    }

    public String getObjectName ()
    {
        return objectName;
    }

    public void setObjectName (String objectName)
    {
        this.objectName = objectName;
    }

    public Boolean isFMD ()
    {
        return isFMD;
    }

    public void setFMD (Boolean isFMD)
    {
        this.isFMD = isFMD;
    }

    public static String getObjectType ()
    {
        return objectType;
    }
}
