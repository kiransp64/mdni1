package com.sap.ariba.erpintegration.encryption;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;

public interface EncryptionHelper
{
    /**
     * Encrypts the input bytes.
     * 
     * @param plainBytes the input bytes, array should not be null.
     * @return the encrypted byte array, will not be null.
     * @exception GeneralSecurityException when an exception occurs during the
     *                encryption process.
     */
    public byte[] encrypt (byte[] plainBytes) throws GeneralSecurityException;

    /**
     * Decrypts the input bytes.
     * 
     * @param encryptedBytes the input bytes obtained from a previous call to
     *            encrypt.
     * @return the unencrypted byte array, will not be null.
     * @exception GeneralSecurityException when an exception occurs during the
     *                decryption process.
     */
    public byte[] decrypt (byte[] encryptedBytes) throws GeneralSecurityException;
    
    /**
     * Encrypts the input stream into the specified output stream. Note that
     * once this method is called, the output stream is no longer available for
     * further write operation. 
     * 
     * @param is the input stream whose data is to encrypt, must not be null.
     * @param os the output stream where encrypted data is to be written, must
     *            not be null.
     * @return the number of bytes written to the output stream
     * @exception GeneralSecurityException when an exception occurs during the
     *                encryption process.
     * @exception IOException when an I/O error occurs.
     */
    public long encrypt (InputStream is, OutputStream os)
        throws GeneralSecurityException, IOException;

    /**
     * Decrypts the given input stream into the specified output stream.
     * 
     * @param is the input stream with encrypted data, must not be null.
     * @param os the output stream where decrypted data is to be written, must
     *            not be null.
     * @return the number of bytes written to the output stream
     * @exception GeneralSecurityException when an exception occurs during the
     *                decryption process.
     * @exception IOException when an I/O error occurs.
     */
    public long decrypt (InputStream is, OutputStream os)
        throws GeneralSecurityException, IOException;
    
    /**
     * Decrypts the given input stream with encrypted data to an
     * input stream with decrypted data
     * 
     * @param is the input stream with encrypted data, must not be null.
     * @return the input stream with decrypted data
     * @exception GeneralSecurityException when an exception occurs during the
     *                decryption process.
     * @exception IOException when an I/O error occurs.
     */
    public InputStream decryptStream(InputStream is)
    		throws GeneralSecurityException, IOException;
    
    /**
     * Returns the name of the encrytion algorithm implemented by this class.
     * 
     * @return the name of the algorithm, which should be one of the names as
     *         specified by Java's JCE framework.
     */
    public String getAlgorithm ();
}
