package com.sap.ariba.erpintegration.scheduler.exception;

import org.quartz.JobExecutionException;

public class IntegrationJobProcessingException extends JobExecutionException {
    private static final long serialVersionUID = 1L;

    public IntegrationJobProcessingException(String message) {
        super(message);
    }
}