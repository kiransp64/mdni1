package com.sap.ariba.erpintegration.util;

import java.util.Arrays;

/**
 * Created by i318483 on 02/06/17.
 */
public class BaseIdGenerator
{

    /**
     * Format of the BaseId
     * Total Length is 17 Characters
     * First 4 are for Variant
     * 2 Characters for the Service Code
     * 3 Characters for the Object Type Code
     * 8 Characters for the Sequence number
     */

    private static final int OptimizedTypeCodeWidth = 8;
    private static final int OptimizedEssentialTypeCodeWidth = 3;
    private static final int OptimizedVariantNumberWidth = 4;
    private static final int OptimizedServiceCodeWidth = 2;

    private static final int Base64 = 64;

    private static final char base64ConvertTable[] =
        {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
         'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
         'U', 'V', 'W', 'X', 'Y', 'Z',
         'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
         'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
         'u', 'v', 'w', 'x', 'y', 'z',
         '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
         '@', '!'
        };

    private static int toBase64 (long num, char[] chr, int off)
    {
        if (num == 0) {
            chr[off] = 'A';
            off--;
        }
        else {
            for (; num > 0 ; off--) {
                chr[off] = base64ConvertTable[(int)(num % 64)];
                num = num / Base64;
            }
        }
        return off;
    }

    public static String generateBaseId (long variantId, long typeCode, long essentialTypeCode, long serviceCode)
    {
        char[] variantArr = new char[OptimizedVariantNumberWidth];
        Arrays.fill(variantArr,'A');
        toBase64(variantId, variantArr, OptimizedVariantNumberWidth -1);

        char[] serviceCodeArr = new char[OptimizedServiceCodeWidth];
        Arrays.fill(serviceCodeArr,'A');
        toBase64(serviceCode, serviceCodeArr, OptimizedServiceCodeWidth -1);

        char[] typeCodeArr = new char[OptimizedEssentialTypeCodeWidth];
        Arrays.fill(typeCodeArr,'A');
        toBase64(typeCode, typeCodeArr, OptimizedEssentialTypeCodeWidth -1);

        char[] essentialTypeCodeArr = new char[OptimizedTypeCodeWidth];
        Arrays.fill(essentialTypeCodeArr,'A');
        toBase64(essentialTypeCode, essentialTypeCodeArr, OptimizedTypeCodeWidth -1);

        StringBuffer sb = new StringBuffer();
        sb.append(variantArr).append(serviceCodeArr).append(typeCodeArr).append(essentialTypeCodeArr);

        return sb.toString();
    }
}
