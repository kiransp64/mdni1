package com.sap.ariba.erpintegration.mdi.api;

import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import com.sap.scimono.api.Schemas;

public class SchemasExt extends Schemas
{

    @Autowired
    public SchemasExt (Application scimApplication, @Context UriInfo uriInfo)
    {
        super(scimApplication, uriInfo);
    }

}
