package com.sap.ariba.erpintegration.persistence.model;

import org.json.simple.JSONObject;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "STAGEXMLDATATAB")
public class StageXMLData  extends GenericEntityStageData {
	
private static final long serialVersionUID = 1L;

	@Column(name = "OBJECTNAME")
	private String objectName;

	@Column(name = "UUID")
	private String UUID;

	@Column(name = "SENDERBUSINESSSYSTEMID")
	private String senderBusinesssytemId;

	@Column(name = "ISSTATIC")
	private int isStatic = 0;

	@Column(name = "OPERATION")
	private int operation = -1;

	@Column(name = "PROCESSFROM")
	private int processFrom = 0;

	@Column(name = "PROCESSEDCOUNT")
	private int processedCount;

	@Column(name = "SOURCE_CREATED_DATE")
	private Date sourceCreatedDate;
	
	@Column(name = "ENCRYPTIONVERSION")
    private String encryptionVersion;

	@Column(name = "DATA_PURGED")
	private int dataPurged = 0;

	@Column(name = "DATA_COMPRESSED")
	private int dataCompressed = 0;

    @Column(name = "AUTH_TYPE")
    private String authenticationType;

	@Column(name = "IS_MDNI_PAYLOAD")
    private boolean isMDNIPayload;

	@Column(name = "ENCRYPT_KEY")
	private String encryptKey;


	public int getDataCompressed() {
		return dataCompressed;
	}

	public void setDataCompressed(int dataCompressed) {
		this.dataCompressed = dataCompressed;
	}

    public String getAuthenticationType() {
        return authenticationType;
    }

    public void setAuthenticationType(String authenticationType) {
        this.authenticationType = authenticationType;
    }

	public int getProcessedCount()
	{
		return processedCount;
	}

	public void setProcessedCount(int processedCount)
	{
		this.processedCount = processedCount;
	}

	public int getProcessFrom()
	{
		return processFrom;
	}

	public void setProcessFrom(int processFrom)
	{
		this.processFrom = processFrom;
	}
	
	public String getEncryptionVersion ()
    {
        return encryptionVersion;
    }

    public void setEncryptionVersion (String encryptionVersion)
    {
        this.encryptionVersion = encryptionVersion;
    }

	public String getObjectName() { return objectName; }

	public void setObjectName(String objectName) { this.objectName = objectName; }

	public String getUUID() { return UUID; }

	public void setUUID(String UUID) { this.UUID = UUID; }

	public String getSenderBusinesssytemId() { return senderBusinesssytemId; }

	public void setSenderBusinesssytemId(String senderBusinesssytemId) { this.senderBusinesssytemId = senderBusinesssytemId; }

	public int getIsStatic() { return isStatic; }

	public void setIsStatic(int isStatic) { this.isStatic = isStatic; }

	public void setSpecialFields (JSONObject object){};

	public int getOperation() {
		return operation;
	}

	public void setOperation(int operation) {
		this.operation = operation;
	}

	public Date getSourceCreatedDate() {
		return sourceCreatedDate;
	}

	public void setSourceCreatedDate(Date sourceCreatedDate) {
		this.sourceCreatedDate = sourceCreatedDate;
	}
	public int getDataPurged () { return dataPurged;}

	public void setDataPurged (int dataPurged) { this.dataPurged = dataPurged;}

	public boolean isMDNIPayload ()
	{
		return isMDNIPayload;
	}

	public void setMDNIPayload (boolean MDNIPayload)
	{
		isMDNIPayload = MDNIPayload;
	}

	public String getEncryptKey ()
	{
		return encryptKey;
	}

	public void setEncryptKey (String encryptKey)
	{
		this.encryptKey = encryptKey;
	}
}
