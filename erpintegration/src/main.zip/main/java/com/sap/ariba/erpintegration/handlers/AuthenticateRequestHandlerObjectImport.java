package com.sap.ariba.erpintegration.handlers;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.Interceptor;
import org.apache.cxf.interceptor.InterceptorChain;
import org.apache.cxf.phase.Phase;

import org.apache.cxf.wsdl.interceptors.DocLiteralInInterceptor;
import org.apache.cxf.interceptor.ServiceInvokerInterceptor;

import javax.xml.namespace.QName;
import java.util.Set;

public class AuthenticateRequestHandlerObjectImport extends AuthenticateRequestHandlerBase
{
    public static final String NS_URI = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
    public static final String LOCAL_PART = "Security";
    public static final String PREFIX = "wsse";

    /**
     * Added as part of FIX for - PLMDS-4242
     * @return
     */
    @Override
    public Set<QName> getUnderstoodHeaders()
    {
        return Set.of(new QName(NS_URI, LOCAL_PART, PREFIX));
    }
    
    public AuthenticateRequestHandlerObjectImport()
    {
        super(Phase.PRE_PROTOCOL);
        getAfter().add(SAAJInInterceptor.class.getName());
    }

    @Override
    public void handleMessage (SoapMessage message) throws Fault
    {
        InterceptorChain interceptors = message.getInterceptorChain();
        for (Interceptor interceptor : interceptors) {
            if ((interceptor instanceof DocLiteralInInterceptor)
                || (interceptor instanceof ServiceInvokerInterceptor))
            {
                message.getInterceptorChain().remove(interceptor);
            }
        }
        super.handleMessage(message);
    }
}
