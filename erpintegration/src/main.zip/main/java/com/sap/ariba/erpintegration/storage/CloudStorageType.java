package com.sap.ariba.erpintegration.storage;

public enum CloudStorageType {
    AWS_OBJECT_STORAGE("AWS_OBJECT_STORAGE"),
    AZURE_BLOB_STORAGE("AZURE_BLOB_STORAGE"),
    GCP_OBJECT_STORAGE("GCP_OBJECT_STORAGE"),
    MINIO_OBJECT_STORAGE("MINIO_OBJECT_STORAGE");

    private String type;

    CloudStorageType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }
}
