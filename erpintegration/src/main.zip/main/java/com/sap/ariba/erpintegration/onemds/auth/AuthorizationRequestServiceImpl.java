package com.sap.ariba.erpintegration.onemds.auth;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import com.sap.ariba.erpintegration.onemds.destination.DestinationFetcherService;
import com.sap.ariba.erpintegration.onemds.destination.DestinationFetcherServiceImpl;
import com.sap.ariba.erpintegration.onemds.exception.AuthorizationRequestException;
import com.sap.ariba.erpintegration.onemds.exception.TenantServiceException;
import com.sap.ariba.erpintegration.onemds.tenant.MDCSMdiDestinationTenantServiceImpl;
import com.sap.ariba.erpintegration.onemds.tenant.TenantService;
import com.sap.ariba.erpintegration.util.ErrorUtil;

@Component 
@ConditionalOnExpression("${environment.mdcs:false}==true")
public class AuthorizationRequestServiceImpl implements AuthorizationRequestService
{
    private static final Logger logger = LoggerFactory.getLogger(
        AuthorizationRequestServiceImpl.class);

    @Autowired 
    @Qualifier("mdcsMdiTenantService")
    private TenantService mdcsMdiTenantService;

    @Autowired
    protected DestinationFetcherService destinationFetcherServiceImpl;
    
    @Autowired
    @Qualifier("mdcsMdiDestinationTenantService")
    private MDCSMdiDestinationTenantServiceImpl mdcsMdiDestinationTenantServiceImpl;


    @Override
    public AuthorizationRequestInfo getAuthorizationRequestInfo (AuthorizationRequestType type,
                                                                 String tenantId)
        throws AuthorizationRequestException
    {

        String authURL = null;
        String clientID = null;
        String clientSecret = null;
        boolean isFallBackToMDI = true;

        if (type.equals(AuthorizationRequestType.MDCS_DESTINATION)) {
            try {
                /*
                 * Check whether destination is previously configured for this tenant
                 */
                isFallBackToMDI = mdcsMdiDestinationTenantServiceImpl.isFallBackToMDI(
                    tenantId);

            }
            catch (TenantServiceException e) {
                logger.error(
                    "[MDI_CRITICAL] Tenant ID - {}, Error - {} while fetching tenant ",
                    tenantId,
                    ErrorUtil.getCompleteCausedByErrors(e));
                throw new AuthorizationRequestException(
                    "Error while fetching tenant for tenantID " + tenantId,
                    e);
            }
            Map<String, Object> destination = null;
            try {
                destination = destinationFetcherServiceImpl.getDestination(tenantId);
            }
            catch (Exception e) {

                try {
                    mdcsMdiDestinationTenantServiceImpl.handleDestinationFetchFail(
                        tenantId,
                        isFallBackToMDI,
                        e);
                }
                catch (TenantServiceException e1) {
                    logger.error(
                        "Error - {}, while fetching destination for tenant : {}.A Destination of type sap.mdi.mdcs.hub was configured for this Tenant . As a result, do not use MDI secrets to obtain authorization information",
                        tenantId);
                    throw new AuthorizationRequestException(
                        "Error while fetching destination for tenant :  " + tenantId
                            + ".A Destination of type sap.mdi.mdcs.hub was configured for this Tenant . As a result, do not use MDI secrets to obtain authorization information",
                        e);
                }
            }

            if (destination != null) {
                authURL = (String)destination.get(
                    DestinationFetcherServiceImpl.DESTINATION_URL_TOKEN_SERVICE_URL);
                clientID = (String)destination.get(
                    DestinationFetcherServiceImpl.DESTINATION_CLIENT_ID);
                clientSecret = (String)destination.get(
                    DestinationFetcherServiceImpl.DESTINATION_CLIENT_SECRET);
                logger.info(
                    "Generating MDI Access Token using Destination for tenantId - {}",
                    tenantId);
                AuthorizationRequestInfo authorizationRequestInfo = new AuthorizationRequestInfo(
                    clientID,
                    clientSecret,
                    authURL,
                    null);
                return authorizationRequestInfo;
            }
            else if (!isFallBackToMDI) {
                try {
                    mdcsMdiDestinationTenantServiceImpl.handleDestinationNotFound(
                        tenantId);
                }
                catch (TenantServiceException e1) {
                    logger.error(
                        "Destination of type sap.mdi.mdcs.hub was configured for tenant : {} .But now there is no Destination of type sap.mdi.mdcs.hub found. As a result, do not use MDI secrets to obtain authorization information",
                        tenantId);
                    throw new AuthorizationRequestException(
                        "Could not find Destination of type sap.mdi.mdcs.hub for tenant :" + tenantId);
                }

            }

        }
        logger.info("Getting Authorization info from MDI Service instance directly.", tenantId);
        return getMDIAuthorizationRequestInfo(tenantId);

    }

    private AuthorizationRequestInfo getMDIAuthorizationRequestInfo (String tenantId)
        throws AuthorizationRequestException
    {
        String authURL = null;
        String clientID = null;
        String clientSecret = null;
        try {
            authURL = mdcsMdiTenantService.getAuthURL(tenantId);
            clientID = mdcsMdiTenantService.getClientID(tenantId);
            clientSecret = mdcsMdiTenantService.getClientSecret(tenantId);
        }
        catch (TenantServiceException e) {
            logger.error(
                "Error - {}, while fetching AuthURL, ClientID and ClientSecret using OneMDS binding for tenant : {}",
                ErrorUtil.getCompleteCausedByErrors(e),
                tenantId);
            throw new AuthorizationRequestException(
                "Error while fetching  AuthURL, ClientID and ClientSecret using OneMDS binding for tenant "
                    + tenantId,
                e);
        }
        logger.info(
            "Generating MDI Access Token for tenantId - {}",
            tenantId);
        AuthorizationRequestInfo authorizationRequestInfo = new AuthorizationRequestInfo(
            clientID,
            clientSecret,
            authURL,
            tenantId);
        return authorizationRequestInfo;
    }

}
