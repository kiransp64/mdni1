package com.sap.ariba.erpintegration.reencryption;

import com.sap.ariba.erpintegration.onemds.process.api.MDIInternalAuthFilter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.Map;

public class ReEncryptionOAuthFilter extends MDIInternalAuthFilter
{
    public static final String REENCRYPTION_NAME_SPACE = "encryptionmanagement/v1/app";
    public static final String ENCRYTPTION_MANAGERMENT_SCOPE = "erpnativeintgsvc:encryptionmanagement";

    @Override
    public void filter (ContainerRequestContext requestContext)
    {
        if(isReEncryptionCall(requestContext)){
            baseFilter(requestContext);
        }
    }

    protected void baseFilter (ContainerRequestContext requestContext)
    {
        super.filter(requestContext);
    }

    @Override
    protected boolean checkScope (ContainerRequestContext requestContext, String userInfo)
    {
        Map<String, Object> oAuthUserInfo = getUserInfoAsMap(userInfo);
        if(!validateRequiredScope(oAuthUserInfo, ENCRYTPTION_MANAGERMENT_SCOPE)){
            throw new WebApplicationException("Re-Encryption APIs are to be called with proper scope.",
                                              HttpStatus.UNAUTHORIZED.value());
        }
        return true;
    }

    private boolean isReEncryptionCall (ContainerRequestContext requestContext)
    {
        if (requestContext != null) {
            UriInfo uriInfo = requestContext.getUriInfo();
            if (uriInfo != null) {
                URI absolutePath = uriInfo.getAbsolutePath();
                if (absolutePath != null) {
                    String path = absolutePath.getPath();
                    if (!StringUtils.isEmpty(path)) {
                        return path.contains(REENCRYPTION_NAME_SPACE);
                    }
                }
            }
        }
        return false;
    }
}
