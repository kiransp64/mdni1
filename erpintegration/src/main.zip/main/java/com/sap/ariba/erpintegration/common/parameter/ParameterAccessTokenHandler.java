package com.sap.ariba.erpintegration.common.parameter;

import com.sap.ariba.erpintegration.onemds.process.job.AribaMDNIAccessTokenHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This class is used for fetch the access token from cache.
 */
@Component
@Primary
@ConditionalOnExpression("${environment.mdcs:false}==false")
public class ParameterAccessTokenHandler extends AribaMDNIAccessTokenHandler {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(ParameterAccessTokenHandler.class);
    private static Map<String, Map<String, String>> cachedAccessToken = new ConcurrentHashMap<>();
    private Map<String, String> tokenMap;

    @Autowired
    private ParameterOAuthToken parameterOAuthToken;

    public Map<String, String> getAccessToken (String anId, String scope)
    {
        String anIdWithScope = anId + '_' + scope;
        Map<String, String> accessToken = cachedAccessToken.get(anIdWithScope);
        if (accessToken != null) {
            if (isValidTokenMap(accessToken)) {
                LOGGER.info(
                        "Got valid Parameter Api access token from cache for anid {} scope{}",
                        anId,scope);
                return accessToken;
            }
        }
        tokenMap = parameterOAuthToken.getTokens(anId, null,scope);
        cachedAccessToken.put(anIdWithScope, tokenMap);
        return tokenMap;
    }
}
