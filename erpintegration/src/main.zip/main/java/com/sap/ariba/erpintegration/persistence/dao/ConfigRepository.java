package com.sap.ariba.erpintegration.persistence.dao;

import com.sap.ariba.erpintegration.persistence.model.IntegrationConfig;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component("ConfigRepositoryComponent")
public interface ConfigRepository extends GenericDataDao<IntegrationConfig> {
    @Query("select C from IntegrationConfig C where C.tenantId = :tenantId and C.key = :configKey")
    IntegrationConfig findOne(@Param("tenantId") long tenantId, @Param("configKey") String configKey);
    
    IntegrationConfig findTopByKeyOrderByKey (String key);
    
    @Query("select id,dateCreated,dateUpdated from IntegrationConfig s where tenantId = :tenantId order by id desc")
    public Page<IntegrationConfig> findKeyFieldsOfAllRecords(@Param("tenantId") long tenantId, Pageable pageable);

    @Modifying
    @Transactional(readOnly = false)
    @Query("""
           Update IntegrationConfig c \
           set c.isActive = 0 \
           where c.key = :configKey AND c.tenantId IN (:tenantIds)\
           """)
    public int deactivateConfigurations (@Param("tenantIds") List<Long> tenantIds,
                                         @Param("configKey") String configKey);

    @Transactional
    long deleteByTenantId(long tenantId);
}
