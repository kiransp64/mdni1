package com.sap.ariba.erpintegration.service.rs;

import java.io.IOException;

import com.sap.ariba.erpintegration.mdi.api.APIUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.sap.ariba.erpintegration.service.rs.config.InspectorConfig;

@Controller
@ConditionalOnExpression(    
    "${isInternal:false} == true"
)
public class InspectorController
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.service.rs.config.InspectorConfig";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    @Autowired
    private AuditClientDataService auditClientDataService;
    
    @Autowired
    private InspectorConfig uiConfig;
    
    @RequestMapping(method = RequestMethod.GET, value = "/inspector")
    public void getMdniUi(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{
        logger.info("the request for UI reached controller "+ APIUtil.sanitizeInput(String.valueOf(request.getRequestURL())));
        String authHeader = response.getHeader("Authorization");
        if(authHeader == null) {
            String errorMessage = "Failed to load inspector as token is missing";
            logger.error(errorMessage);
            return;
        }
        String redirectUrl = uiConfig.getInspectorRedirectUrl();
        logger.info("the redirect url is "+redirectUrl);
        String url = redirectUrl + "?allowUiAccess=true&token=" + authHeader;      
        response.sendRedirect(url);    
    }

}