package com.sap.ariba.erpintegration.service.rs;

import com.sap.ariba.erpintegration.audit.AuditManagerImpl;
import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.OracleDAOFactory;
import com.sap.ariba.erpintegration.persistence.dao.SchemaRepository;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.processor.WSDLToRNGSchemaGenerator;
import com.sap.ariba.erpintegration.schema.SchemaUtil;
import com.sap.ariba.erpintegration.service.exception.BadRequestException;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.service.exception.InvalidTenantIdException;
import com.sap.ariba.erpintegration.service.rs.fileFortification.validator.FileFortificationValidator;
import com.sap.ariba.erpintegration.util.Constants;
import com.sap.ariba.erpintegration.util.EventNameToObjectMap;
import com.sap.ariba.erpintegration.util.XMLUtil;
import org.apache.commons.io.FilenameUtils;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.XMLUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import jakarta.activation.DataHandler;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import static org.apache.commons.lang3.StringUtils.endsWith;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.split;

/**
 * Created by i318483 on 03/05/17.
 */
public class IntegrationRestService
{

    private static final String nameOfLogger =
        "com.sap.ariba.erpintegration.service.rs.IntegrationRestService";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private static final String SCHEMA_DIR = "schema";
    private static final String WSDL_DIR = "wsdl";

    private static final String complexTypeTagName = "xsd:complexType";
    private static final String nameAttribute = "name";
    private static final String DOUBLE_HASH = "##";
    private static final String UNDER_SCORE = "_";

    @Value("${basePath}")
    private String basePath;
    
    @Value("${senderBusinessSystemIdRegEx}")
    private String senderBusinessSystemIdRegEx;

    @Value("${remote.auditService.enable}")
    private boolean auditClientEnabled;

    private boolean auditEnabled = Boolean.TRUE;

    private boolean sameSchemaCheckEnabled = Boolean.TRUE;

    private Date wsdlUploadDate;

    @Value("${upload.wsdl.fileFortification.enable}")
    private boolean fileFortificationEnable;

    public void setAuditClientDataService(AuditClientDataService auditClientDataService) {
        this.auditClientDataService = auditClientDataService;
    }

    @Autowired
    private AuditClientDataService auditClientDataService;

    @Autowired
    private FileFortificationValidator fileFortificationValidator;


    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Path("/uploadWSDLFile")
    public Response uploadWSDLFile (@Context HttpServletRequest request,
        MultipartBody multipartBody)
            throws IntegrationServiceException, MissingServletRequestParameterException, BadRequestException, InvalidTenantIdException

    {
        int read = 0;
        String tenantId = null;
        String output = null;
        String baseDir = null;
        String fileLocation = null;
        String inputFileName = null;
        InputStream is = null;
        byte[] bytes = new byte[4096];
        FileOutputStream outputStream = null;
        String normalizedFileName = null;
        String objectName = null;
        String senderBusinessSystemId = null;
        long wsdlUploadTimeStamp = 0;
        boolean isFMD = Boolean.TRUE;

        InputStream copyInputStreamData[] = null;

        OracleDAOFactory daoFactory = (OracleDAOFactory)DAOFactory.getDAOFactory(
            DAOFactory.ORACLE);
        SchemaRepository dao = (SchemaRepository)daoFactory.getMiscDAO(
            ObjectTypes.Schema.getValue());


        if (logger.isDebugEnabled())
            logger.debug("Starting the WSDL upload service");

        try {
            if (multipartBody != null) {
                List<Attachment> attachments = multipartBody.getAllAttachments();
                DataHandler handler = attachments.get(0).getDataHandler();
                is = handler.getInputStream();

                if (attachments.get(0).getContentDisposition() == null) {
                    logger.error("[MDNI_CRITICAL][ARIBA][UploadWSDL] WSDL fie  not passed as request parameter");
                    String errorMessage = "Required file parameter and Multipart is not present";
                    throwUploadWsdlExceptions(request,"NULL_CONTENT_DISPOSITION", errorMessage);
                }
                inputFileName = attachments.get(0).getContentDisposition().getParameter(
                    "filename");

                if (isBlank(inputFileName) || ObjectUtils.isEmpty(is)) {
                    logger.error(" [MDNI_CRITICAL][ARIBA][UploadWSDL] File or .WSDL file not passed as part of request ");
                    String errorMessage = "File should not be empty";
                    throwUploadWsdlExceptions(request,
                                              "WSDL_FILE_EXCEPTION",
                                              errorMessage);
                }
                if (!endsWith(inputFileName,
                              "wsdl")) {
                    logger.error("[MDNI_CRITICAL][ARIBA][UploadWSDL] .WSDL file not passed as part of request ");
                    String errorMessage = "Required .wsdl file only";
                    throwUploadWsdlExceptions(request,
                                              "WSDL_FILE_EXCEPTION",
                                              errorMessage);
                }
                String[] splitExtension = split(inputFileName,
                                                ".");
                if (splitExtension.length > 2) {
                    logger.error("[MDNI_CRITICAL][ARIBA][UploadWSDL] Multiple extension passed as part of wsdl file");
                    String errorMessage = "Required only one extension for given file";
                    throwUploadWsdlExceptions(request,
                                              "WSDL_FILE_EXCEPTION",
                                              errorMessage);
                }
                int fileSize = is.available();
                long megabytes = ((fileSize / 1024) / 1024);

                if (megabytes > 5) {
                    logger.error("[MDNI_CRITICAL][ARIBA][UploadWSDL] File exceeded the size more then 5 mb , actual file size :{} ",
                                 megabytes);
                    String errorMessage = "File of maximum 5MB size is allowed.";
                    throwUploadWsdlExceptions(request, "WSDL_FILE_EXCEPTION", errorMessage);
                }
                // inputFileName = getOriginalFileName(multivaluedMap);
                if (is != null && inputFileName != null) {
                    if (logger.isDebugEnabled())
                        logger.debug("File found with the name : {}", inputFileName);

                    if (basePath == null) {
                        basePath = "/tmp/nfs/";
                    }

                    File nfsMountedDirectory = new File(basePath);
                    if (!nfsMountedDirectory.exists()) {
                        logger.warn("/tmp/nfs not Mounted");
                        String errorMessage = "/tmp/nfs not Mounted";
                        throwUploadWsdlExceptions(request,"NFS_NOT_MOUNTED", errorMessage);
                    }

                    tenantId = request.getParameter(Constants.KeyTenantId);

                    if (tenantId == null || StringUtils.isEmpty(tenantId)) {
                        logger.error("tenantId not passed as request parameter");
                        String errorMessage = "Required " + Constants.KeyTenantId + " parameter String is not present";
                        throwUploadWsdlExceptions(request,"TENANT_ID_EMPTY", errorMessage);
                    }

                    if (!Utility.isTenantExists(tenantId)) {
                        logger.error("Invalid tenantId passed as request parameter");
                        throw new InvalidTenantIdException(
                                "Invalid tenantId passed as request parameter");
                    }
                    objectName = request.getParameter(Constants.KeyObjectName);

                    if (objectName == null || StringUtils.isEmpty(objectName)) {
                        logger.error("objectName not passed as request parameter");
                        String errorMessage  = "Required " + Constants.KeyObjectName + " parameter String is not present";
                        throwUploadWsdlExceptions(request,"OBJECT_NAME_EMPTY", errorMessage);
                    }

                    senderBusinessSystemId = request.getParameter(
                        Constants.KeySenderBusinessSystemId);

                    if (senderBusinessSystemId == null
                        || StringUtils.isEmpty(senderBusinessSystemId)) {
                        logger.warn(
                            "senderBusinessSystemId not passed as request parameter. It's a optional field");
                    } else if(!this.validateSenderBusinessSystemId(senderBusinessSystemId)){
                        String errorMsg = "senderBusinessSystemId "+ senderBusinessSystemId + " has unapproved characters";
                        logger.error(errorMsg);
                        throwUploadWsdlExceptions(request,"SENDER_ID_INVALID_CHAR", errorMsg);
                    }

                    //If fileFortificationEnable is true then making File fortification Client call to validate the wsdl file
                    if (fileFortificationEnable) {
                        copyInputStreamData = cloneInputStreamData(is);
                        logger.info(" [IntegrationRestService] File fortification Client invocation for Object name : {} and TenantId : {}",
                                    objectName,
                                    tenantId);
                        fileFortificationValidator.validateFileThroughFileFortification(request,
                                                                                        tenantId,
                                                                                        objectName,
                                                                                        inputFileName,
                                                                                        copyInputStreamData[0]);
                        is = copyInputStreamData[1];
                        if (auditEnabled) {
                            AuditManagerImpl.getInstance().logAudit(tenantId,
                                                                    Operation.WSDL_UPLOAD,
                                                                    new StringBuilder().append("upload wsdl started for tenantId : ")
                                                                                    .append(tenantId)
                                                                                    .append(" Object Name : ")
                                                                                    .append(objectName)
                                                                                    .append(" File Fortification Validation Pass for given WSDL")
                                                                                    .toString());
                        }
                    }



                    if (auditEnabled) {
                        AuditManagerImpl.getInstance().logAudit(
                            tenantId,
                            Operation.WSDL_UPLOAD,
                            "upload wsdl started for tenantId : " + tenantId
                                + " Object Name : " + objectName
                                + " Sender Business System Id : "
                                + senderBusinessSystemId);
                    }

                    baseDir = basePath + tenantId;

                    if (inputFileName != null && !StringUtils.isEmpty(inputFileName)) {
                        fileLocation = baseDir + "/" + WSDL_DIR + "/" + inputFileName;

                        if (logger.isDebugEnabled())
                            logger.debug("WSDL store location : {}", fileLocation);
                    }

                    try {
                        normalizedFileName = FilenameUtils.normalize(fileLocation);
                        File file = new File(normalizedFileName);
                        File parentDir = new File(file.getParent());
                        if (!parentDir.exists()) {
                            if (!parentDir.mkdirs()) {
                                logger.warn("Directory creation failed");
                            }
                        }
                        outputStream = new FileOutputStream(file);

                        while ((read = is.read(bytes)) != -1) {
                            outputStream.write(bytes, 0, read);
                        }



                        outputStream.flush();
                    }
                    finally {
                        try {
                            if (outputStream != null) {
                                outputStream.close();
                            }
                            if (is != null) {
                                is.close();
                            }
                            //closing the copied input stream
                            if (copyInputStreamData != null) {
                               for (InputStream i : copyInputStreamData) {
                                   i.close();
                               }
                            }
                        }
                        catch (IOException io) {
                            logger.error("Exception while closing output stream", io);
                            throw io;
                        }
                    }
                }

                // need to validate if the objectname is correct by
                // searching a complex type in the wsdl file.
                if (!this.objectPresent(normalizedFileName, objectName)) {
                    String errorMsg = "objectName "+ objectName + " and attached WSDL file are not in sync";
                    logger.error(errorMsg);
                    deleteFile(normalizedFileName);
                    throwUploadWsdlExceptions(request, "OBJECT_ATTACHMENT_MISMATCH", errorMsg);
                }

                //Audit when uploadwsdl starts
                auditClientDataService.auditWsdlUpload(request, null, null, true);

                wsdlUploadDate = new Date();

                wsdlUploadTimeStamp = auditClientEnabled ?  wsdlUploadDate.getTime() : 0L;

                generateRNGSchemaFromWSDLFile(
                    baseDir,
                    fileLocation,
                    objectName,
                    senderBusinessSystemId,
                        wsdlUploadTimeStamp);

                if (EventNameToObjectMap.getObjectName(objectName) == null) {
                    isFMD = true;
                }
                else {
                    isFMD = false;
                }

                if (logger.isDebugEnabled())
                    logger.debug("objectName : {}, isFMD : {}", objectName, isFMD);

                // check if the existing schema is same as new schema
                boolean schemaPresent = false;
                if (sameSchemaCheckEnabled) {
                    schemaPresent = this.isExistingXSDSame(
                        tenantId,
                        objectName,
                        senderBusinessSystemId);
                }

                if (!schemaPresent) {
                    if (logger.isInfoEnabled())
                        logger.info(
                            "New Schema Found for tenantId {}, senderBusinessSystemId {} and objectName {}",
                            tenantId,
                            senderBusinessSystemId,
                            objectName);
                    // Replace the old schema files with new ones
                    this.replaceSchemaFile(
                        tenantId,
                        objectName,
                        senderBusinessSystemId);
                    this.cleanTempSchemaFiles(tenantId, objectName,senderBusinessSystemId);
                    // Make a database entry for the main schema information
                    dao.save(
                        tenantId,
                        senderBusinessSystemId,
                        objectName,
                        isFMD,
                        basePath + tenantId + "/" + SCHEMA_DIR + "/" + objectName
                            + (senderBusinessSystemId == null ? ""
                            : "_" + senderBusinessSystemId)
                            + ".xsd");
                }
                else {
                    if (logger.isInfoEnabled())
                        logger.info(
                            "New Schema same as old schema for tenantId {}, senderBusinessSystemId {} and objectName {}. Cleaning up the generated files",
                            tenantId,
                            senderBusinessSystemId,
                            objectName);
                    this.cleanTempSchemaFiles(
                        tenantId,
                        objectName,
                        senderBusinessSystemId);
                }

                String documentId = objectName
                        + (senderBusinessSystemId == null ? ""
                        : UNDER_SCORE + senderBusinessSystemId) + DOUBLE_HASH + wsdlUploadTimeStamp;

                auditClientDataService.auditWsdlUpload(request, null, documentId, false);
                if (auditEnabled) {
                    AuditManagerImpl.getInstance().logAudit(
                        tenantId,
                        Operation.WSDL_UPLOAD,
                        "upload wsdl ended for tenantId : " + tenantId + " Object Name : "
                            + objectName + " Sender Business System Id : "
                            + senderBusinessSystemId);
                }
            }
        }
        catch (IOException | ParserConfigurationException | SAXException
            | TransformerFactoryConfigurationError | TransformerException
                | InvalidTenantIdException e) {
            logger.error("Exception : {}", e.getMessage(), e);

            // Clean all the schema files
            this.cleanTempSchemaFiles(tenantId, objectName, senderBusinessSystemId);

            if (auditEnabled) {
                AuditManagerImpl.getInstance().logAudit(
                        tenantId,
                        Operation.WSDL_UPLOAD,
                        "upload wsdl ended for tenantId : " + tenantId + " Object Name : "
                                + objectName + " Sender Business System Id : "
                                + senderBusinessSystemId + " with exception : "
                                + e.getMessage());
            }

            auditClientDataService.auditWsdlUpload(request,  e.getMessage(), null, false);

            throw new IntegrationServiceException(new Exception(e));
        }
        finally {
            // check if the initial wsdl file is present. If present delete, as
            // it has to be deleted in any case.
            try {
                is.close();
            }
            catch (IOException e) {
                logger.error("Failed to close input stream");
            }
            if (logger.isDebugEnabled()) {
                logger.debug("deleting {}, if it is still present", normalizedFileName);
            }
            File file = null;
        }

        output = "Successfully configured schema for tenant : " + tenantId
            + ", objectName: " + objectName + ", senderBusinessSystemId : "
            + senderBusinessSystemId;

        return Response.status(HttpServletResponse.SC_OK).entity(output).build();
    }

    /**
     * This method will take the input stream and clone it for multi purpose use
     *
     * @param inputStream
     * @return
     * @throws IOException
     */
    private InputStream[] cloneInputStreamData (InputStream inputStream) throws IOException
    {
        logger.info("Cloning input stream for WSDL file");
        ByteArrayOutputStream boas = new ByteArrayOutputStream();
        InputStream[] copyInputStream = new InputStream[2];
        try {
            byte buffer[] = new byte[4096];
            int length;
            while ((length = inputStream.read(buffer)) > -1) {
                boas.write(buffer,
                           0,
                           length);
            }
            boas.flush();
            //storing multiple copy of Input stream to Input stream Array type for further use
            copyInputStream[0] = new ByteArrayInputStream(boas.toByteArray());
            copyInputStream[1] = new ByteArrayInputStream(boas.toByteArray());
        }
        finally {
            try {
                if (boas != null) {
                    boas.close();
                }
            }
            catch (IOException io) {
                logger.error("Exception while closing output stream in cloneInputStreamData() method: {}",
                             io);
                throw io;
            }
        }
        return copyInputStream;
    }

    private void throwUploadWsdlExceptions(HttpServletRequest request, String errorType, String errorMessage) throws MissingServletRequestParameterException, IntegrationServiceException, InvalidTenantIdException, BadRequestException {

        auditClientDataService.auditWsdlUpload(request,  errorMessage, null, false);
        switch (errorType) {
            case "NULL_CONTENT_DISPOSITION":
                throw new MissingServletRequestParameterException(
                        "file",
                        "Multipart");

            case "NFS_NOT_MOUNTED":
                throw new IntegrationServiceException(errorMessage);

            case "TENANT_ID_EMPTY":
                throw new MissingServletRequestParameterException(
                        Constants.KeyTenantId,
                        "String");

            case "WSDL_FILE_EXCEPTION":
                throw new BadRequestException(errorMessage);

            case "FILE_FORTIFICATION_FAILED":
                throw new IntegrationServiceException(errorMessage);

            case "OBJECT_NAME_EMPTY":
                throw new MissingServletRequestParameterException(
                        Constants.KeyObjectName,
                        "String");

            case "OBJECT_ATTACHMENT_MISMATCH":
            case "SENDER_ID_INVALID_CHAR":
                throw new BadRequestException(errorMessage);


        }
    }


    private void removeFilesOrDirectories (String path)
    {
        File files = new File(path);
        if (files.exists()) {
            if (files.isDirectory()) {
                for (File file : files.listFiles()) {  // firstly ,delete all the files in a directory
                    try {
                        Boolean fileDeleted = file.delete();
                        if (!fileDeleted) {
                            throw new Exception("Cannot delete file");
                        }
                        else if (logger.isDebugEnabled()) {
                            logger.debug("Files deleted : {}", file);
                        }
                    }
                    catch (Exception e) {
                        logger.error(e.getMessage());
                    }
                }
                try {
                    Boolean filesDeleted = files.delete(); // then delete
                                                           // directory
                    if (!filesDeleted) {
                        throw new Exception("Could not delete directory");
                    }
                    else if (logger.isDebugEnabled()) {
                        logger.debug("Directory deleted : {}", files);
                    }
                }
                catch (Exception e) {
                    logger.error(e.getMessage());
                }

            }
            else {
                try {
                    Boolean filesDeleted = files.delete();
                    if (!filesDeleted) {
                        throw new Exception("Cannot delete file");
                    }
                    else if (logger.isDebugEnabled()) {
                        logger.debug("File deleted : {}", files);
                    }
                }
                catch (Exception e) {
                    logger.error(e.getMessage());
                }
            }
        }
        else {
            logger.warn("Path doesn't exists : {}", files);
        }
    }
    
    private boolean validateSenderBusinessSystemId(String senderBusinessSystemId) throws BadRequestException
    {
        try {
            if (senderBusinessSystemIdRegEx.isEmpty()) {
                String errorMsg = "SenderBusinessSytemId regex pattern is empty";
                throw new BadRequestException(errorMsg);
            }
        }
        finally {
            logger.error("Sender BusinessSystemId regex pattern is empty");
        }
        return senderBusinessSystemId.matches(senderBusinessSystemIdRegEx);
    } 

    /**
     * This method is responsible for cleaning up temp files after successful
     * completion of the task or if some exception thrown in middle
     *
     * @param tenantId
     * @param objectName
     * @param senderBusinessSystemId
     */
    private void cleanTempSchemaFiles (String tenantId,
        String objectName,
        String senderBusinessSystemId)
    {
        if (logger.isDebugEnabled()) {
            logger.debug("Started cleaning the schema files");
        }
        if (basePath == null) {
            basePath = "/tmp/nfs/";
        }

        String schemaDir = basePath + tenantId + "/" + SCHEMA_DIR + "/" + objectName
            + (senderBusinessSystemId == null ? "" : "_" + senderBusinessSystemId) + "/";


        String tempDir = FilenameUtils.normalize(schemaDir);

        if (logger.isDebugEnabled()) {
            logger.debug(
                "[xsd and rng deleted at directory location : {}]",
                schemaDir);
        }

        this.removeFilesOrDirectories(tempDir);  // remove rng

        if (logger.isDebugEnabled()) {
            logger.debug("Cleaning the schema files ended");
        }

    }

    /**
     * This method is responsible for replacing the existing schema (XSD) ile with the new
     * incoming files
     *
     * @param tenantId
     * @param objectName
     * @param senderBusinessSystemId
     * @throws IOException
     */
    private void replaceSchemaFile (String tenantId,
        String objectName,
        String senderBusinessSystemId)
        throws IOException
    {
        String folderLocation = null;
        if (logger.isDebugEnabled()) {
            logger.debug("Started Replacing the old file with new file");
        }
        if (basePath == null) {
            folderLocation = "/tmp/nfs/";
        }
        else {
            folderLocation = basePath;
        }

        folderLocation += tenantId + "/" + SCHEMA_DIR + "/";

        File newSchemaDir = new File(folderLocation + "/" + objectName
            + (senderBusinessSystemId == null ? "" : "_" + senderBusinessSystemId) + "/");

        if(newSchemaDir.exists()) {
            for (String schema : newSchemaDir.list()) {

                String originalFilePath = FilenameUtils.normalize(
                    folderLocation + FilenameUtils.getName(schema));

                if (logger.isDebugEnabled()) {
                    logger.debug("Original File : {}", originalFilePath);
                }

                String tempFilePath =
                    FilenameUtils.normalize(newSchemaDir + "/" + schema);

                if (logger.isDebugEnabled()) {
                    logger.debug("Temp File : {}", tempFilePath);
                }

                String backupFilePath = FilenameUtils.normalize(
                    folderLocation + "backup_" + FilenameUtils.getName(schema));

                if (logger.isDebugEnabled()) {
                    logger.debug("Backup File : {}", backupFilePath);
                }

                renameFile(originalFilePath, tempFilePath, backupFilePath);
            }
        }
    }

    private void renameFile (String originalFilePath, String tempFilePath,
        String backupFilePath) throws IOException
    {
        // Create the file object
        File originalFile = new File(originalFilePath);
        File tempFile = new File(tempFilePath);
        File backupFile = new File(backupFilePath);

        // Create the back up file for original file
        if (logger.isDebugEnabled()) {
            logger.debug("Starting to rename the original file to back up file");
        }

        if (!originalFile.exists()) {
            if (logger.isDebugEnabled()) {
                logger.debug(
                    "Orignial file does not exist, so mostly it's the first request");
            }
            if (tempFile.renameTo(originalFile)) {
                if (logger.isDebugEnabled()) {
                    logger.debug(
                        "Successfully renamed the temp file to the original file");
                }
            }
            else {
                // on failure rename the temp file. rename the backup file to
                // original file
                logger.warn("Rename from tempfile to original file failed");
                throw new IOException(
                    "Could not rename temp file to original file");
            }
        }
        else {
            if (originalFile.renameTo(backupFile)) {
                // when backup file created successfully. Rename the temp file
                // to
                // original file
                if (logger.isDebugEnabled()) {
                    logger.debug(
                        "Successfully renamed the original file to the back up file");
                    logger.debug("Starting to rename the temp file to original file");
                }
                if (tempFile.renameTo(originalFile)) {
                    if (logger.isDebugEnabled()) {
                        logger.debug(
                            "Successfully renamed the temp file to the original file");
                        logger.debug("Starting to delte the backupfile");
                    }
                    // on successfully rename the temp file. delete the back up
                    // file
                    if (backupFile.exists()) {
                        try {
                            boolean fileDeleted = backupFile.delete();
                            if (!fileDeleted) {
                                throw new Exception("Cannot delete file");
                            }
                            else if (logger.isDebugEnabled()) {
                                logger.debug("Deleted the backup file");
                            }
                        }
                        catch (Exception e) {
                            logger.error("Unable to delete file {}", e.getMessage());
                        }    
                    }
                }
                else {
                    // on failure rename the temp file. rename the backup file
                    // to
                    // original file
                    logger.warn(
                        "Rename from tempfile to original file failed, so renamin the back up file to original file");
                    try {
                        Boolean backupFileRenamed = backupFile.renameTo(originalFile);
                        if (!backupFileRenamed) {
                            throw new Exception(
                                "Cannot Rename Backup file to original file");
                        }
                    }
                    catch (Exception e) {
                        logger.error(e.getMessage());
                    }
                    throw new IOException(
                        "Could not able to rename temp file to original file");
                }
            }
            else {
                logger.warn("Back up of original file did not happen");
                throw new IOException("Back up of original file did not happen");
            }
        }
    }

    /**
     * This method is responsible for getting the content of the file
     *
     * @param file
     * @return
     * @throws IOException
     */
    private String getFileContent (String file) throws IOException
    {
        String content = new String(
            Files.readAllBytes(Paths.get(file)),
            StandardCharsets.UTF_8);

        return content;
    }

    /**
     * This method will be responsible for checking if existing schema is same
     * as incoming schema. If they are same, it will return true.
     *
     * @param tenantId
     * @param objectName
     * @throws SAXException
     * @throws IOException
     * @throws IntegrationServiceException
     */
    private boolean isExistingXSDSame (String tenantId,
        String objectName,
        String senderBusinessSystemId)
        throws SAXException, IOException, IntegrationServiceException
    {
        String folderLocation = null;
        if (basePath == null) {
            folderLocation = "/tmp/nfs/";
        }
        else {
            folderLocation = basePath;
        }

        folderLocation += tenantId + "/" + SCHEMA_DIR + "/";

        String newDirPath = FilenameUtils.normalize(folderLocation + objectName
            + (senderBusinessSystemId == null ? "" : "_"+senderBusinessSystemId) + "/");

        File schemaDir = new File(newDirPath);

        if(schemaDir.exists()) {
            for (File schema : schemaDir.listFiles()) {
                String originalFilePath = FilenameUtils.normalize(
                    folderLocation + schema.getName());

                if (logger.isDebugEnabled()) {
                    logger.debug("Original File : {}", originalFilePath);
                }

                if (logger.isDebugEnabled()) {
                    logger.debug("New File : {}", schema.getName());
                }

                if (!new File(originalFilePath).exists()) {
                    if (logger.isInfoEnabled())
                        logger.info(
                            "no existing schema present for tenant id {} and objectName {}. So not going for the check.",
                            tenantId,
                            objectName);
                    return false;
                }

                String originalXsdContent = getFileContent(originalFilePath);
                String newXsdContent = getFileContent(schema.getAbsolutePath());

                XMLUnit.setIgnoreWhitespace(true);
                XMLUnit.setIgnoreAttributeOrder(true);

                DetailedDiff diff = new DetailedDiff(
                    XMLUnit.compareXML(originalXsdContent, newXsdContent));

                List<?> allDifferences = diff.getAllDifferences();

                if (allDifferences.size() == 0) {
                    if (logger.isInfoEnabled())
                        logger.info("Incoming schema is same as exising schema");
                    continue;
                }
                else {
                    if (logger.isInfoEnabled())
                        logger.info(
                            "New schema received, which is not same as existing schema");
                    return false;
                }
            }
        }
        return true;
    }

    private void generateRNGSchemaFromWSDLFile (String baseDir,
        String fileLocation,
        String objectName,
        String senderBusinessSystemId,
        long wsdlUploadTime)
        throws IOException,
        SAXException,
        ParserConfigurationException,
        TransformerFactoryConfigurationError,
        TransformerException
    {

        WSDLToRNGSchemaGenerator wsdlToRNGSchemaGenerator = new WSDLToRNGSchemaGenerator(
            baseDir,
            fileLocation,
            objectName,
            senderBusinessSystemId
        );
        wsdlToRNGSchemaGenerator.setWsdlUploadTime(wsdlUploadTime);
        wsdlToRNGSchemaGenerator.generateRNGSchemaFromWSDL();
    }

    private boolean objectPresent (String filePath, String objectName)
        throws SAXException, IOException, ParserConfigurationException
    {
        Node objectNode = null;
        try (FileInputStream is = new FileInputStream(new File(filePath));) {
            Document xsdDoc = XMLUtil.getDocBuilder().parse(is);
            objectNode = SchemaUtil.getObjectElement(xsdDoc, objectName);
        }
        catch (IOException | SAXException | ParserConfigurationException e) {
            throw e;
        }

        return objectNode != null;
    }

    @GET
    @Path("/greetings")
    public Response greetings ()
    {
        return Response.status(HttpServletResponse.SC_OK).entity("Greetings!!!").build();
    }

    @GET
    @Path("/health")
    public Response health ()
    {
        return Response.status(HttpServletResponse.SC_OK).entity("I AM FINE!!!").build();
    }

    private void deleteFile(String filePath) {
        try {
            File file = new File(filePath);
            if(file.exists()) {
                Files.delete(file.toPath());
                return;
            }
            logger.info(filePath + " doesnot exist");
        }
        catch (IOException ex){
            logger.info("Error in deleting file "+filePath, ex);
        }
    }

}

enum FileType
{
    XSD("xsd"), WSDL("wsdl"), RNG("rng");

    private String extension;

    FileType (String extension)
    {
        this.extension = extension;
    }

    public String getExtension ()
    {
        return extension;
    }
}
