package com.sap.ariba.erpintegration.storage;

import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.sap.ariba.erpintegration.storage.exception.CloudStorageException;
import jakarta.annotation.PostConstruct;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

@Service
@Qualifier("GCPObjectStorage")
@ConditionalOnExpression(value = "${advanced.storage.option}")
public class GCPObjectStorage implements CloudStorage {

    private Logger logger = LoggerFactory.getLogger(GCPObjectStorage.class);

    @Value("${vcap.services.objectstore.credentials.base64EncodedPrivateKeyData}")
    String base64EncodedPrivateKeyData;

    @Value("${vcap.services.objectstore.credentials.projectId}")
    String projectId;

    @Value("${vcap.services.objectstore.credentials.bucket}")
    String bucketName;

    private Storage storageClient;

    private static final String UTF_8 = "UTF-8";
    private static final String TEXT_JSON = "text/json";

    @PostConstruct
    public void init() throws IOException {
        try {
            String credentials = Base64.decodeBase64(base64EncodedPrivateKeyData).toString();
            InputStream is = new ByteArrayInputStream(credentials.getBytes(Charset.forName(UTF_8)));
            ServiceAccountCredentials sac = ServiceAccountCredentials.fromStream(is);
            storageClient = StorageOptions.newBuilder()
                    .setProjectId(projectId)
                    .setCredentials(sac)
                    .build()
                    .getService();
        }catch (Exception e){
            logger.error("Error while creating the GCP storage client");
        }
    }

    @Override
    public void put(String path, String content) throws CloudStorageException {
        BlobId blobId = BlobId.of(bucketName, path);
        BlobInfo blobInfo = null;
        blobInfo = BlobInfo.newBuilder(blobId)
                .setContentType(TEXT_JSON)
                .build();
        storageClient.create(blobInfo, content.getBytes(Charset.forName(UTF_8)));
        logger.info("Object {} successfully uploaded to GCP bucket {}", path, bucketName);
    }

    @Override
    public String getContent(String path) throws CloudStorageException {
        BlobId blobId = BlobId.of(bucketName, path);
        Blob blob = storageClient.get(blobId);
        logger.info("Object {} successfully downloaded from GCP bucket {}", path, bucketName);
        return new String(blob.getContent(), Charset.forName(UTF_8));
    }

    @Override
    public CloudStorageResponse getStream(String path) throws CloudStorageException {
        BlobId blobId = BlobId.of(bucketName, path);
        Blob blob = storageClient.get(blobId);
        logger.info("Object {} successfully downloaded from GCP bucket {}", path, bucketName);
        return new CloudStorageResponse(null,new ByteArrayInputStream(blob.getContent()));
    }

    @Override
    public void remove(String path) throws CloudStorageException {
        BlobId blobId = BlobId.of(bucketName, path);
        storageClient.delete(blobId);
        logger.info("Object {} successfully removed from GCP bucket {}", path , bucketName);
    }

    protected void setStorageClient(Storage storageClient) {
        this.storageClient = storageClient;
    }

    @Override
    public void closeCloudObject (CloudStorageResponse responseStream)
    {
        /* we have to handle this in future */
    }
}
