package com.sap.ariba.erpintegration.mdi.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.List;

@Component
public class OpenApiConfig {
    public static final String X_FORWARDED_HOST = "x-forwarded-host";
    public static final String OPENAPI = "openapi";

    @Value("${server.servlet.openapi.context-path}")
    private String openApiContextPath;
    @Value("${server.servlet.context-path}")
    private String contextPath;
    @Value("${mdi.common.baseURL}")
    private String baseUrl;
    @Value("${mdi.common.openApiBaseUrl}")
    private String openApiBaseUrl;

    @Autowired
    CommonConfig commonConfig;

    private boolean isOpenApiContext;
    public boolean isOpenApiContext ()
    {
        return isOpenApiContext;
    }

    public void validateOpenApiUrl (MultivaluedMap<String, String> headers)
    {
        List<String> forwards = headers.get(X_FORWARDED_HOST);
        if ((forwards != null) && (forwards.stream().anyMatch(url -> url.toLowerCase().contains(OPENAPI)))) {
            setup();
        }
        else {
            reset();
        }
    }

    public void setup ()
    {
        if (!isOpenApiContext()) {
            isOpenApiContext = true;
            commonConfig.setBaseURL(openApiBaseUrl);
            commonConfig.setContextPath(openApiContextPath);
        }

    }

    public void reset ()
    {
        if (isOpenApiContext()) {
            isOpenApiContext = false;
            commonConfig.setBaseURL(baseUrl);
            commonConfig.setContextPath(contextPath);
        }
    }

}
