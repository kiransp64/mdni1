package com.sap.ariba.erpintegration.common.async;

import brave.Tracer;
import brave.Tracing;
import brave.baggage.BaggagePropagation;
import brave.context.slf4j.MDCScopeDecorator;
import brave.propagation.B3Propagation;
import brave.propagation.ThreadLocalCurrentTraceContext;
import brave.sampler.Sampler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Application Configuration class for creating common Bean to manage by Spring container.
 */
@Configuration
public class CommonAppConfig
{
    @Bean
    public Tracing tracing ()
    {
        return Tracing.newBuilder().currentTraceContext(this.threadLocalCurrentTraceContext())
                        .supportsJoin(false).traceId128Bit(true)
                        .propagationFactory(BaggagePropagation.newFactoryBuilder(B3Propagation.FACTORY)
                                                            .build()).sampler(Sampler.ALWAYS_SAMPLE)
                        .localIp("0.0.0.0")//giving void ip address.
                        .build();
    }

    @Bean
    ThreadLocalCurrentTraceContext threadLocalCurrentTraceContext ()
    {
        return ThreadLocalCurrentTraceContext.newBuilder()
                        .addScopeDecorator(MDCScopeDecorator.get()).build();
    }

    @Bean
    public Tracer tracer ()
    {
        return tracing().tracer();
    }

}
