package com.sap.ariba.erpintegration.common.metrics;

public enum MDNIMetrics {
    CIG_REQUEST_ERROR("mdni.cig.request.error"),
    STAGEXML_PENDING_JOBS("mdni.stagexml.pending.jobs"),
    STAGEXML_FAILING_JOBS("mdni.stagexml.failing.jobs"),
    STAGEXML_JOB_DISTRIBUTION_ERROR("mdni.stagexml.job.distribution.error"),
    CIG_REQUEST_AUTH_ERROR("mdni.cig.request.auth.error");
    
    private final String key;

    MDNIMetrics(String key)
    {
        this.key = key;
    }
    
    public String getKey ()
    {
        return this.key;
    }
}
