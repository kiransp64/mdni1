package com.sap.ariba.erpintegration.filters;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

@Configuration
public class RequestFilterConfig
{
    // TODO : Make these configurable.
    @Bean
    public CommonsRequestLoggingFilter logFilter ()
    {
        CommonsRequestLoggingFilter filter = new CommonsRequestLoggingFilter();
        filter.setIncludeQueryString(true);
        filter.setIncludePayload(true);
        filter.setMaxPayloadLength(10000);
//        filter.setIncludeHeaders(true);// Removing - Spring Version Conflict
        filter.setAfterMessagePrefix("Payload is : ");
        return filter;
    }
}
