package com.sap.ariba.erpintegration.schema;

import java.util.Date;

public class SchemaDetail
{
    private String senderBusinessSystemId;
    private Date lastUpdated;
    private String objectName;
    private boolean isFMD;

    public SchemaDetail (String senderBusinessSystemId,
                         String objectName,
                         boolean isFMD,
                         Date lastUpdated)
    {
        this.senderBusinessSystemId = senderBusinessSystemId;
        this.objectName = objectName;
        this.isFMD = isFMD;
        this.lastUpdated = lastUpdated;
    }

    public String getSenderBusinessSystemId ()
    {
        return senderBusinessSystemId;
    }

    public void setSenderBusinessSystemId (String senderBusinessSystemId)
    {
        this.senderBusinessSystemId = senderBusinessSystemId;
    }

    public Date getLastUpdated ()
    {
        return lastUpdated;
    }

    public void setLastUpdated (Date lastUpdated)
    {
        this.lastUpdated = lastUpdated;
    }

    public String getObjectName ()
    {
        return objectName;
    }

    public void setObjectName (String objectName)
    {
        this.objectName = objectName;
    }

    public boolean isFMD ()
    {
        return isFMD;
    }

    public void setFMD (boolean isFMD)
    {
        this.isFMD = isFMD;
    }

}
