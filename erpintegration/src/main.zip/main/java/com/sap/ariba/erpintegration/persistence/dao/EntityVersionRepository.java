package com.sap.ariba.erpintegration.persistence.dao;


import com.sap.ariba.erpintegration.service.rs.EntityVersionRepositoryCustom;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.sap.ariba.erpintegration.persistence.model.EntityVersion;

/**
 * This is the repository class for ENTITY_VERSION_TAB table.
 *
 * @author i339952
 */
@Component("EntityVersionRepositoryComponent")
public interface EntityVersionRepository extends CrudRepository<EntityVersion, String>,EntityVersionRepositoryCustom
{
    @Query("select ev from EntityVersion ev where ev.id = :hashValue")
    EntityVersion findOne (@Param("hashValue") String hashValue);

}
