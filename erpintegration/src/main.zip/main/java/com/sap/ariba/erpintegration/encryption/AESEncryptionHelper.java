package com.sap.ariba.erpintegration.encryption;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.IOUtils;

public class AESEncryptionHelper implements EncryptionHelper
{
    private byte[] keyBytes;
    private static SecureRandom random = null;
    private static int BlockSizeBytes = 16;
    
    static {
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
        }
        catch (NoSuchAlgorithmException e) {
            String errMsg = "Could not initialize AES encryption";
            Log.encryption.error(errMsg);
            throw new RuntimeException(errMsg, e);
        }
    }

    public AESEncryptionHelper (String secretKey) throws IOException, SecurityInitializationException
    {
        this(secretKey, StandardCharsets.UTF_8.name());
    }

    public AESEncryptionHelper (String secretKey, String encoding) throws IOException, SecurityInitializationException
    {
        this(secretKey.getBytes(encoding));
    }

    public AESEncryptionHelper (byte[] key) throws SecurityInitializationException
    {
        if (key == null) {
            String errMsg = "Input key bytes cannot be null";
            Log.encryption.error(errMsg);
            throw new SecurityInitializationException(errMsg);
        }
        int length = key.length;
        if (length < getMinKeyLength()) {
            length = getMinKeyLength();
            byte[] newKeyBytes = new byte[length];
            System.arraycopy(key, 0, newKeyBytes, 0, key.length);
            this.keyBytes = newKeyBytes;
        }
        else {
            length = getMaxKeyLength();
            byte[] newKeyBytes = new byte[length];
            System.arraycopy(key, 0, newKeyBytes, 0, length);
            this.keyBytes = newKeyBytes;
        }
    }

    protected KeySpec getKeySpec () throws GeneralSecurityException
    {
        return new SecretKeySpec(keyBytes, "AES");
    }

    /*
     Both min and max key lengths are 16 as AES is prone to problems with
     bigger keys. This is consistent with the implementation in Buyer.
     */
    protected int getMaxKeyLength ()
    {
        return 16;
    }
    
    protected int getMinKeyLength ()
    {
        return 16;
    }

    public String getAlgorithm ()
    {
        return EncryptionUtil.AlgorithmAESGCM;
    }

    public byte[] encrypt (byte[] plainBytes) throws GeneralSecurityException
    {
        byte[] iv = getIv();

        Cipher c = initCipher(Cipher.ENCRYPT_MODE, iv);
        int len = c.getOutputSize(plainBytes.length);
        byte[] output = new byte[iv.length + len];
        System.arraycopy(iv, 0, output, 0, iv.length);
        c.doFinal(plainBytes, 0, plainBytes.length, output, iv.length);

        return output;
    }

    public byte[] decrypt (byte[] encryptedBytes) throws GeneralSecurityException
    {
        byte[] iv = new byte[getMaxKeyLength()];

        System.arraycopy(encryptedBytes, 0, iv, 0, iv.length);
        Cipher c = initCipher(Cipher.DECRYPT_MODE, iv);

        return c.doFinal(encryptedBytes, iv.length, encryptedBytes.length - iv.length);

    }

    protected Cipher initCipher (int mode, byte[] iv) throws GeneralSecurityException
    {
        KeySpec spec = getKeySpec();
        SecretKey secretKey = (SecretKey)spec;
        Cipher cipher = Cipher.getInstance(getAlgorithm());
        cipher.init(mode, secretKey, new GCMParameterSpec(128, iv));
        return cipher;
    }

    private byte[] getIv ()
    {
        byte[] iv = new byte[BlockSizeBytes];
        random.nextBytes(iv);

        return iv;
    }

    public OutputStream getEncryptingOutputStream (OutputStream encrypted)
        throws GeneralSecurityException, IOException
    {
        byte[] iv = getIv();
        encrypted.write(iv);
        Cipher cipher = initCipher(Cipher.ENCRYPT_MODE, iv);
        Log.encryption.debug(
            "initialized cipher for %s to encrypt output stream",
            getAlgorithm());
        return new CipherOutputStream(encrypted, cipher);
    }

    public InputStream getDecryptingInputStream (InputStream encrypted)
        throws GeneralSecurityException, IOException
    {

        byte[] iv = new byte[BlockSizeBytes];
        if (encrypted.read(iv) != BlockSizeBytes) {
            throw new GeneralSecurityException(
                "Could not retrieve IV from AES encrypted stream");
        }
        Cipher cipher = initCipher(Cipher.DECRYPT_MODE, iv);
        Log.encryption.debug(
            "initialized cipher for %s to decrypt output stream",
            getAlgorithm());
        return new CipherInputStream(encrypted, cipher);

    }

    @Override
    public long encrypt (InputStream is, OutputStream os)
        throws GeneralSecurityException, IOException
    {
        long bytesWritten = 0;
        try (OutputStream cos = getEncryptingOutputStream(os)) {
            bytesWritten = IOUtils.copy(is, cos);
            is.close();
        }
        catch (IOException e) {
            throw e;
        }
        return bytesWritten;
    }

   @Override
    public long decrypt (InputStream is, OutputStream os)
        throws GeneralSecurityException, IOException
    {
        InputStream cis = getDecryptingInputStream(is);
        long bytesWritten = IOUtils.copy(cis, os);
        cis.close();
        os.close();
        return bytesWritten;
    }
    
    public InputStream decryptStream(InputStream is) 
    		throws GeneralSecurityException, IOException {
    		InputStream dis = getDecryptingInputStream(is);
    		return dis;
    }
}
