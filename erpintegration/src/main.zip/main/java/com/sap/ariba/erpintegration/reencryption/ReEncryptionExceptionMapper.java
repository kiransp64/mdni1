package com.sap.ariba.erpintegration.reencryption;

import com.sap.ariba.erpintegration.mdi.common.util.TracingHelper;
import com.sap.ariba.security.tool.keyrotation.v1.model.ErrorCode;
import org.apache.cxf.jaxrs.impl.WebApplicationExceptionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Component
public class ReEncryptionExceptionMapper extends WebApplicationExceptionMapper
{
    @Autowired
    private TracingHelper tracingHelper;

    @Override
    public Response toResponse (WebApplicationException ex)
    {
        String traceId = tracingHelper != null ?
            tracingHelper.getTraceId() :
            TracingHelper.NOT_AVAILABLE_TRACKING_ID;
        return Response.status(ex.getResponse().getStatus()).entity(
                           new ErrorCode("Re-Encryption", ex.getResponse().getStatus(), ex.getMessage(),
                                         traceId)).header(ReEncryptionAPI.TRACKING_ID, traceId)
                       .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                       .build();
    }
}
