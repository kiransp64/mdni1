package com.sap.ariba.erpintegration;

import com.sap.ariba.encryption.annotation.EncryptedColumnModelImpl;
import com.sap.ariba.encryption.scheduler.service.DatabaseJob;
import com.sap.ariba.encryption.scheduler.service.DatabaseTask;
import com.sap.ariba.encryption.scheduler.service.FileJob;
import com.sap.ariba.encryption.scheduler.service.FileTask;
import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Created by i318483
 */

@SpringBootApplication(scanBasePackages = {"com.ariba","com.sap.ariba.erpintegration"}, exclude = { SecurityAutoConfiguration.class})
@ImportResource({ "classpath:cxf-servlet.xml", "classpath:cxf-servlet-scim.xml"  })
@EntityScan(basePackageClasses = { DatabaseJob.class, DatabaseTask.class, FileJob.class,
                FileTask.class, EncryptedColumnModelImpl.class },
            basePackages = { "com.sap.ariba.erpintegration" })
@EnableRetry
@EnableAsync
@ServletComponentScan
public class Application extends SpringBootServletInitializer
{
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    
    @Bean
    public ServletRegistrationBean dispatcherServletCxf ()
    {
    	ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(new CXFServlet(), "/api/*");
    	servletRegistrationBean.setName("cxfServlet");
        return servletRegistrationBean;
    }
    
    @Bean(name = Bus.DEFAULT_BUS_ID)
    public SpringBus springBus ()
    {
        return new SpringBus();
    }
}
