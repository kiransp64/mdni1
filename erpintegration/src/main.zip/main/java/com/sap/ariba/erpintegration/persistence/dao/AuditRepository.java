package com.sap.ariba.erpintegration.persistence.dao;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.persistence.model.Audit;
import com.sap.ariba.erpintegration.persistence.service.BaseIdServiceImpl;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;
import com.sap.ariba.erpintegration.persistence.util.Utility;

/**
 * This is the repository class for AUDIT_TAB table.
 * 
 * @author i339952
 */
@Component("AuditRepositoryComponent")
public interface AuditRepository extends GenericDataDao<Audit>
{
    public static String nameOfLogger = "com.sap.ariba.erpintegration.persistence.dao.AuditRepository";
    public static Logger logger = LoggerFactory.getLogger(nameOfLogger);

    // public Audit findOne (String id);

    public List<Audit> findByTenantIdAndOperationIdOrderByDateCreatedDesc (String tenantId,
                                                                           long opertionId);

    public List<Audit> findByTenantIdOrderByDateCreatedDesc (String tenantId);

    @Query("select id,dateCreated,dateUpdated from Audit s where tenantId = :tenantId order by id desc")
    public Page<Audit> findKeyFieldsOfAllRecords(@Param("tenantId") long tenantId, Pageable pageable);
    
    default void save (String tenantId, Operation operation, String comment)
        throws InvalidTypeCodeException, SQLException, UnsupportedEncodingException
    {
        if (logger.isDebugEnabled()) {
            logger.debug(
                "Save Started. Data [tenantId: {}, OperationId: {}, OperationName: {}, Comment: {}]",
                tenantId,
                operation.getOperationId(),
                operation.getOperationName(),
                comment);
        }
        Audit audit = new Audit();

        long internalTenantId = -1;
        if (Utility.isTenantExists(tenantId)) {
            internalTenantId = Utility.getTenantId(tenantId);
        }

        if (logger.isDebugEnabled()) {
            logger.debug(
                "systemTenantId for tenant id {} is {}",
                tenantId,
                internalTenantId);
        }

        if (Long.valueOf(internalTenantId).equals(-1)) {
            if (logger.isDebugEnabled()) {
                logger.debug("systemTenantId is -1. It could be a new tenant");
            }
        }
        String baseId = this.getBaseId(internalTenantId, audit.getObjectType());
        Date date = new Date();
        audit.setDateCreated(date);
        audit.setDateUpdated(date);
        audit.setId(baseId);
        audit.setTenantId(internalTenantId);
        audit.setOperationId(operation.getOperationId());
        audit.setOperationName(operation.getOperationName());
        audit.setComment(comment);

        save(audit);

        if (logger.isDebugEnabled()) {
            logger.debug("Save Ended");
        }
    }

    default String getBaseId (long variantId, String objectName)
        throws InvalidTypeCodeException
    {
        BaseIdServiceImpl service = BaseIdServiceImpl.getInstance();
        return service.allocateBaseId(objectName, variantId);
    }

}
