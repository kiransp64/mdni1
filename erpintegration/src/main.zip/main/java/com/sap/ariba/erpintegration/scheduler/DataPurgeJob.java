package com.sap.ariba.erpintegration.scheduler;

import com.sap.ariba.erpintegration.SchedulerConfig;
import com.sap.ariba.erpintegration.audit.AuditManagerImpl;
import com.sap.ariba.erpintegration.audit.Operation;
import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.storage.CloudStorageFactory;
import com.sap.ariba.erpintegration.storage.exception.CloudStorageException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import org.joda.time.DateTime;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.List;

/**
 * Created by c5259108 on 20/12/17.
 */
@Component
@DisallowConcurrentExecution
@ConditionalOnExpression(    
    "${isInternal:false} == false"
)
public class DataPurgeJob implements Job
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.scheduler.DataPurgeJob";
    private static final Logger logger = LoggerFactory.getLogger(
        nameOfLogger);

    private static final String xmlExtension = ".xml";

    private static final String zipExtension = ".zip";


    @Value("${dataPurgeJob.cronExpression}")
    private String cronExpression;

    @Value("${dataPurgeJob.retainNoOfDays}")
    private int retainNoOfDays;
    
    @Value("${dataPurgeJob.retainErrorJobsNoOfDays}")
    private int retainErrorJobsNoOfDays;

    @Value("${remote.auditService.enable}")
    private boolean isAuditServiceEnabled;

    @Value(("${dataPurgeJob.audit.retainNoOfDays}"))
    private int retaionNoOfDaysForAudit;

    @Value(("${dataPurgeJob.query.pagesize}"))
    private int dataPurgeJobQueryPageSize;
    

    private boolean auditEnabled = Boolean.TRUE;

    @Autowired(required = false)
    private CloudStorageFactory cloudStorageFactory;

    @Bean(name = "dataPurgeJobBean")
    public JobDetailFactoryBean dataPurgeJob ()
    {
        if (logger.isDebugEnabled())
            logger.debug("Creating dataPurgeJobBean");
        return SchedulerConfig.createJobDetail(this.getClass());
    }

    @Bean(name = "dataPurgeJobBeanTrigger")
    public CronTriggerFactoryBean dataPurgeJobBeanTrigger (@Qualifier("dataPurgeJobBean") JobDetail jobDetail)
    {
        logger.info("Creating dataPurgeJobBeanTrigger");
        return SchedulerConfig.createCronTrigger(jobDetail, cronExpression);
    }


    @Override public void execute (JobExecutionContext jobExecutionContext) throws
        JobExecutionException
    {
        logger.info("DataPurgeJob started");
        DAOFactory daoFactory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        StageXMLDataRepository dao = (StageXMLDataRepository) daoFactory.getGenericDAOStageData(ObjectTypes.XmlPayload.name());

        int retentionDays = isAuditServiceEnabled ? retaionNoOfDaysForAudit : retainNoOfDays;
        int errorRetentionDays = isAuditServiceEnabled ? retaionNoOfDaysForAudit : retainErrorJobsNoOfDays;
        Pageable pageReq = PageRequest.of(0, dataPurgeJobQueryPageSize);
        List<StageXMLData> stageXMLDataList = dao.findListOfDataPathForProcessing(getDateConsideringRetentionDays(retentionDays), pageReq);
        logger.info("No. of records found to purge: {}", stageXMLDataList.size());
        processRecords(stageXMLDataList);
        
        List<StageXMLData> stageXMLDataErrorJobsList = dao.findListOfDataPathForErrorJobsProcessing(getDateConsideringRetentionDays(errorRetentionDays));
        logger.info("No. of records with error status found to purge: {}", stageXMLDataErrorJobsList.size());
        processRecords(stageXMLDataErrorJobsList);
    }

    private Date getDateConsideringRetentionDays(int days){
        return new DateTime(new Date()).minusDays(days).toDate();
    }

    private void processRecords(List<StageXMLData> stageXMLDataList){
        deleteFiles(stageXMLDataList);
        updateDataPathFilePurgedStatus(stageXMLDataList);
    }

    private void deleteFiles(List<StageXMLData> stageXMLDataList){
        String xmlFilePath = null;
        String zipFilePath = null;
        for(StageXMLData stageXMLData:stageXMLDataList){
            xmlFilePath = stageXMLData.getDataPath();
            //Delete the xml file if available
            if(HandlerUtil.isAdvancedStorageOptionEnabled()){
                deleteFileFromCloudStorage(xmlFilePath, stageXMLData);
            }else {
                deleteFile(xmlFilePath, stageXMLData);
            }

            if(xmlFilePath.contains(xmlExtension)) {
                zipFilePath = xmlFilePath.replace(xmlExtension, zipExtension);
                //Deletes the zipfile if available
                if(HandlerUtil.isAdvancedStorageOptionEnabled()){
                    deleteFileFromCloudStorage(zipFilePath, stageXMLData);
                }else {
                    deleteFile(zipFilePath, stageXMLData);
                }
            }
        }
    }

    private void deleteFile(String filePath, StageXMLData stageXMLData) {
        try {
            File file = new File(filePath);
            if(!file.exists()){
                logger.warn("File {} doesnot exist",filePath);
                return;
            }
            Files.delete(file.toPath());
            logger.debug("File {} deleted succesfully",filePath);
            if (auditEnabled) {
                String anId = Utility.getANId(stageXMLData.getTenantId());
                AuditManagerImpl.getInstance().logAudit(
                        anId,
                        Operation.PURGE_XML_DATA,
                        "deleted file : " + filePath);
            }
        }
        catch (IOException ex){
            logger.error("Exception while deleting file {}, exception details ", filePath,ex);
        }
    }

    private void deleteFileFromCloudStorage(String filePath, StageXMLData stageXMLData) {
        long tenantId = stageXMLData.getTenantId();
        try {
            if(filePath != null) {
                cloudStorageFactory.getCloudStorage().remove(filePath);
            }
        } catch (CloudStorageException e) {
            logger.error("Error while deleting object. File Object :{}",
                    filePath, e);
        }
    }


    private void updateDataPathFilePurgedStatus(List<StageXMLData> stageXMLDataList) {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        GenericDAOStageData dao = factory.getGenericDAOStageData(ObjectTypes.XmlPayload.getValue());
        for (StageXMLData stageXMLData : stageXMLDataList) {
            logger.debug("Setting datapath_file_purged column as purged for record {}",stageXMLData.getId());
            stageXMLData.setDataPurged(1);
            stageXMLData.setDateUpdated(new Date());
            dao.save(stageXMLData);
        }
    }
}

