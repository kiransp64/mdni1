package com.sap.ariba.erpintegration.onemds.tenant;

import com.sap.ariba.erpintegration.onemds.exception.TenantConfigurationException;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component("tenantConfigurationProvider")
@ConditionalOnExpression("${onemds.tenant.property.ariba.customer.based.configuration}==true")
public class AribaCustomerTenantConfigurationProvider
    extends AbstractTenantConfigurationProvider
{
    public static final String CLIENT_SECRET = "ClientSecret";
    public static final String CLIENT_ID = "ClientId";
    public static final String XSUAA_URL = "XsuaaUrl";
    public static final String END_POINT_URL = "EndPointURL";
    public static final String TIME_UPDATED = "TimeUpdated";
    private static final String MISSING = " is missing. ";
    public static final Logger logger = LoggerFactory.getLogger(
        AribaCustomerTenantConfigurationProvider.class);

    @Override
    protected void loadConfiguration (String tenantID) throws TenantConfigurationException
    {
        try {
            Map responseAsMap = HandlerUtil.getXSUAAConfiguredCredentials(tenantID);
            if (responseAsMap != null && MapUtils.isNotEmpty(responseAsMap)) {
                Map<String, String> xsuaaconfigDetails = new HashMap<>();
                StringBuffer error = new StringBuffer();
                if (responseAsMap.get(END_POINT_URL) != null) {
                    xsuaaconfigDetails.put(TenantConfiguration.APP_URL.getValue(),
                        (String)responseAsMap.get(END_POINT_URL));
                }
                else {
                    error.append(END_POINT_URL + MISSING);
                }
                
                if (responseAsMap.get(XSUAA_URL) != null) {
                    xsuaaconfigDetails.put(TenantConfiguration.AUTH_URL.getValue(),
                        (String)responseAsMap.get(XSUAA_URL));
                }
                else {
                    error.append(XSUAA_URL + MISSING);
                }
                
                if (responseAsMap.get(CLIENT_ID) != null) {
                    xsuaaconfigDetails.put(TenantConfiguration.CLIENT_ID.getValue(),
                        (String)responseAsMap.get(CLIENT_ID));
                }
                else {
                    error.append(CLIENT_ID + MISSING);
                }
                
                if (responseAsMap.get(CLIENT_SECRET) != null) {
                    xsuaaconfigDetails.put(TenantConfiguration.CLIENT_SECRET.getValue(),
                        (String)responseAsMap.get(CLIENT_SECRET));
                }
                else {
                    error.append(CLIENT_SECRET + MISSING);
                }
                
                if (responseAsMap.get(TIME_UPDATED) != null) {
                    xsuaaconfigDetails.put(TenantConfiguration.TIME_UPDATED.getValue(),
                        (String)responseAsMap.get(TIME_UPDATED));
                }
                else {
                    error.append(TIME_UPDATED + MISSING);
                }
                
                if (StringUtils.isNotEmpty(error.toString())) {
                    throw new IntegrationServiceException(error.toString());
                }
                else {
                    this.tenantConfigurationDetails.put(tenantID,
                        xsuaaconfigDetails);
                }
            }
            else {
                logger.warn("No XSUAA Auth credentials found for tenant {}", tenantID);
            }

        }
        catch (IntegrationServiceException e) {
            logger.error("Error while getting XSUAA Auth Credentials for tenant "+tenantID, e);
        }

    }

}
