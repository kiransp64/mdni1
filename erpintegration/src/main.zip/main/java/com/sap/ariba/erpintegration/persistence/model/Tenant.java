package com.sap.ariba.erpintegration.persistence.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

/**
 * Created by i318483 on 19/06/17.
 */
@Entity
@Table(name = "TENANT_TAB")

public class Tenant implements Serializable
{

    private static final long serialVersionUID = 1L;
    private static final String objectType = "Tenant";

    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "TENANT_ID")
    @GeneratedValue(generator = "tenant_id_sequence", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "tenant_id_sequence", sequenceName = "tenant_id_sequence", allocationSize = 1)
    private long tenantId;

    @Column(name = "IS_ACTIVE")
    private int isActive;

    @Column(name = "DATE_CREATED")
    private Date dateCreated;

    @Column(name = "DATE_UPDATED")
    private Date dateUpdated;

    @Column(name = "STATUS")
    private int status = 1;

    @Column(name = "AN_ID")
    private String anId;

    @Column(name = "PARENT_AN_ID")
    private String parentAnId;

    @Column(name = "REALM_NAME")
    private String realmName;

    @Column(name = "WEIGHT")
    private Double weight;
    
    @Column(name = "MDI_ENABLED")
    private String mdiEnabled;

    @Column(name = "MDI_PROCESS_TIME")
    private Date mdiProcessTime;
    
    @Column(name = "MDI_CONFIG_TIME_UPDATED")
    private Date mdiConfigTimeUpdated;

    @Column(name = "PURGE_STATUS")
    private String purgeStatus;
    
    @Column(name = "DESTINATION_ENABLED")
    private boolean destinationEnabled;


    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public long getTenantId ()
    {
        return tenantId;
    }

    public void setTenantId (long tenantId)
    {
        this.tenantId = tenantId;
    }

    public int getIsActive ()
    {
        return isActive;
    }

    public void setIsActive (int isActive)
    {
        this.isActive = isActive;
    }

    public Date getDateCreated ()
    {
        return dateCreated;
    }

    public void setDateCreated (Date dateCreated)
    {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated ()
    {
        return dateUpdated;
    }

    public void setDateUpdated (Date dateUpdated)
    {
        this.dateUpdated = dateUpdated;
    }

    public int getStatus ()
    {
        return status;
    }

    public void setStatus (int status)
    {
        this.status = status;
    }

    public String getAnId ()
    {
        return anId;
    }

    public void setAnId (String anId)
    {
        this.anId = anId;
    }

    public String getObjectType ()
    {
        return objectType;
    }

    public String getParentAnId ()
    {
        return parentAnId;
    }

    public void setParentAnId (String parentAnId)
    {
        this.parentAnId = parentAnId;
    }

    public String getRealmName ()
    {
        return realmName;
    }

    public void setRealmName (String realmName)
    {
        this.realmName = realmName;
    }

    public Double getWeight ()
    {
        return weight;
    }

    public void setWeight (Double weight)
    {
        this.weight = weight;
    }

    public String getMdiEnabled ()
    {
        return mdiEnabled;
    }

    public void setMdiEnabled (String mdiEnabled)
    {
        this.mdiEnabled = mdiEnabled;
    }

    public Date getMDIProcessTime ()
    {
        return mdiProcessTime;
    }

    public void setMDIProcessTime (Date mdiProcessTime)
    {
        this.mdiProcessTime = mdiProcessTime;
    }

    public Date getMdiConfigTimeUpdated ()
    {
        return mdiConfigTimeUpdated;
    }

    public void setMdiConfigTimeUpdated (Date mdiConfigTimeUpdated)
    {
        this.mdiConfigTimeUpdated = mdiConfigTimeUpdated;
    }

    public String getPurgeStatus ()
    {
        return purgeStatus;
    }

    public void setPurgeStatus (String purgeStatus)
    {
        this.purgeStatus = purgeStatus;
    }
    
    public boolean isDestinationEnabled ()
    {
        return destinationEnabled;
    }

    public void setDestinationEnabled (boolean destinationEnabled)
    {
        this.destinationEnabled = destinationEnabled;
    }

    @Override
    public String toString ()
    {
        return "Tenant{" + "id='" + id + '\'' + ", tenantId=" + tenantId + ", isActive="
            + isActive + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
            + ", status=" + status + ", anId='" + anId + '\'' + ", parentAnId='"
            + parentAnId + '\'' + ", realmName='" + realmName + '\'' + ", weight="
            + weight + ", mdiEnabled='" + mdiEnabled + '\'' + ", mdiProcessTime="
            + mdiProcessTime + ", mdiConfigTimeUpdated=" + mdiConfigTimeUpdated
            + ", purgeStatus='" + purgeStatus + '\''+ ", destinationEnabled=" + destinationEnabled  + '}';
    }
}
