package com.sap.ariba.erpintegration.util;

/**
 * Created by c5259108 on 06/09/17.
 */
public class FieldType {
    public static final String DATE = "DATE";
    public static final String BOOLEANTRUE = "BOOLEANTRUE";
}
