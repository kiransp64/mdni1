/*
 * Copyright (c) 2022. SAP Ariba, Inc.
 * All rights reserved. Patents pending.
 *
 * Responsible : Sagar Shukla (i555787)
 *
 */

package com.sap.ariba.erpintegration.service.rs;

import com.sap.ariba.erpintegration.handlers.IntegrationJobLogProvider;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import static com.sap.ariba.erpintegration.util.Constants.KeyJobId;
import static com.sap.ariba.erpintegration.util.Constants.KeyObjectName;
import static com.sap.ariba.erpintegration.util.Constants.KeyTenantId;

/**
 * Integration Job status Controller to get the status of Job ID i.e created from Upload Xml api.
 */
@Controller
@RequestMapping(value = "/v2/integrationjob")
public class IntegrationJobStatusController
{

    /**
     * This class will get the job status based on necessary parameter.
     */
    @Autowired
    private IntegrationJobLogProvider integrationJobLogProvider;

    /**
     * This method will fetch the latest integration job id status from DB.
     *
     * @param tenantId i.e associated tenant id with the Job id
     * @param jobId i.e created from Upload xml api for every request
     * @param objectName i.e Object name i.e Incoterms, User, Cost center etc.
     * @return status Response having all the details for Job id .
     * @throws IntegrationServiceException
     * @throws MissingServletRequestParameterException
     */
    @GET
    @Path("/status")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getIntegrationJobs (@QueryParam(value = KeyTenantId) @Valid String tenantId,
                                        @QueryParam(KeyJobId) @Valid String jobId,
                                        @QueryParam(KeyObjectName) @Valid String objectName)
                    throws IntegrationServiceException, MissingServletRequestParameterException
    {
        return integrationJobLogProvider.getIntegrationJobStatus(tenantId,
                                                                 jobId,
                                                                 objectName);
    }
}
