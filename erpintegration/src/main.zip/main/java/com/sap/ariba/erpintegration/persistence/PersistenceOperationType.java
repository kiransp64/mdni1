package com.sap.ariba.erpintegration.persistence;

public enum PersistenceOperationType
{
    UPDATE,
    INSERT;
}
