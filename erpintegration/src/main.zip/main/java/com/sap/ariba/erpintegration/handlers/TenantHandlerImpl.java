package com.sap.ariba.erpintegration.handlers;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.ariba.erpintegration.persistence.dao.HanaTenantRepository;
import com.sap.ariba.erpintegration.persistence.model.HanaTenant;
import com.sap.ariba.erpintegration.service.exception.ResourceNotFoundException;

/**
 * <pre>
 * 1. Create a table tenant_tab with {anid, url, tenantid}
 * 2. All the get requests should come to cache and get returned with the config. In case of cache miss, go the table.
 * 3. If anid not present in the table create one record and request hana to create tenant 
 * 4. update the tenantid in the table on return.
 * 5. if simultaneous request comes, it will fail to insert because of unique constraint. In case this notify tenant creation in progress.
 * 6. In case if for some record tenant id is not present, call hana to create tenant. 
 * 7. Hana should always, look up for the an id and then create the tenant. It should return tenantid.
 * 8. Which hana box to hit is decided upon the number of records present for each url.
 * 9. Consider the AN id with '-T' for test realm and merp case.
 * </pre>
 * 
 * @author i339952
 */
@Service
public class TenantHandlerImpl implements TenantHandler
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.handlers.TenantHandlerImpl";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);
    private static final String ACCEPT = "accept";
    private static final String APP_JSON = "application/json";
    private static final String UTF_8 = "UTF-8";

    private static final long ExpirationTimeInMillis = 6 * 60 * 60 * 1000;// 6
    // Hours
    private static long timeSinceCacheRefreshed = 0L;

    @Autowired
    private HanaTenantRepository hanaTenantRepository;

    private Map<String, Map> tenantCache = null;

    @Override
    public Map<String, Object> getTenant (String tenantIdentifier)
        throws ResourceNotFoundException
    {
        if (tenantCache == null || (System.currentTimeMillis()
            - timeSinceCacheRefreshed) > ExpirationTimeInMillis)
        {
            tenantCache = new ConcurrentHashMap<>();
            timeSinceCacheRefreshed = System.currentTimeMillis();
        }

        // Search in cache
        if (!tenantCache.containsKey(tenantIdentifier)) {
            HanaTenant t = hanaTenantRepository.findOne(tenantIdentifier, 2);

            Map<String, Object> tenantMap = new HashMap<String, Object>();
            if (t != null) {
                tenantMap.put("anId", t.getAnId());
                tenantMap.put("realm", t.getRealm());
                tenantMap.put("tenantId", t.getHanaTenantId());
                tenantMap.put("hanaPod", t.getHanaPod());
                tenantCache.put(t.getAnId(), tenantMap);
                tenantCache.put(t.getRealm(), tenantMap);
            }
            else if (t == null) {
                throw new ResourceNotFoundException("Tenant Not Found.");
            }
        }
        else {
            logger.info(
                "tenant Identifier {} found in cache. no need to search in haha.",
                tenantIdentifier);
        }
        return tenantCache.get(tenantIdentifier);
    }
}
