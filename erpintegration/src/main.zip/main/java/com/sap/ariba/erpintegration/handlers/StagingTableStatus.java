package com.sap.ariba.erpintegration.handlers;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by c5259108 on 29/05/17.
 */
public enum StagingTableStatus {
    PENDING(0, "Pending Processing"),
    PROCESSING(1, "Processing"),
    PROCESSED(2, "Processed"),
    NEEDSREPROCESSING(3, "Needs Re-Processing"),
    PROCESSEDWITHWARNINGS(4, "Processed with warnings"),
    ERROR(5, "Error"),
    DUPLICATE(6, "Duplicate"),
    DISCARDED(7, "Discarded");

    private final int value;
    private final String description;

    private StagingTableStatus (int value, String desc)
    {
        this.value = value;
        this.description = desc;
    }

    public int getValue ()
    {
        return this.value;
    }

    public String getDescription ()
    {
        return this.description;
    }
    
    public static String getJobStatusDescription (int stageTableStatus)
    {
        String jobStatus = "";
        for (StagingTableStatus stat : StagingTableStatus.values()) {
            if (stat.getValue() == stageTableStatus) {
                jobStatus = stat.getDescription();
                break;
            }
        }
        return jobStatus;
    }
    
    public static StagingTableStatus getStagingTableStatus (String stageTableDesc)
    {
        StagingTableStatus jobStatusEnum = null;
        for (StagingTableStatus stat : StagingTableStatus.values()) {
            if (stat.getDescription().equals(stageTableDesc)) {
                jobStatusEnum = stat;
                break;
            }
        }
        return jobStatusEnum;
    }

    public static List<Integer> getProcessedStatuses ()
    {
        List<Integer> statuses = new ArrayList<>();
        statuses.add(StagingTableStatus.PROCESSED.getValue());
        statuses.add(StagingTableStatus.PROCESSEDWITHWARNINGS.getValue());
        statuses.add(StagingTableStatus.DISCARDED.getValue());
        statuses.add(StagingTableStatus.DUPLICATE.getValue());
        return statuses;
    }
}
