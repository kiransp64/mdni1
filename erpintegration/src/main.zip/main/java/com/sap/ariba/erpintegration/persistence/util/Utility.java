package com.sap.ariba.erpintegration.persistence.util;

import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.TenantIdGetter;
import com.sap.ariba.erpintegration.persistence.dao.TenantRepository;
import com.sap.ariba.erpintegration.persistence.model.Tenant;
import org.json.simple.JSONObject;

import java.util.Map;

/**
 * Created by c5259108 on 17/07/17.
 */
public class Utility {

    private static final long SYSTEMTENANTID = 0;
    private static final String SYSTEMANID = "SYSANXX0001";

    public static long getTenantId (String anId)
    {
        long tenantId = -1;
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository) factory.getMiscDAO(ObjectTypes.Tenant.getValue());
        Tenant tenant = (Tenant) dao.findOne(anId);
        if (tenant != null) {
            tenantId = tenant.getTenantId();
        }
        else {
            TenantIdGetter idGetter = (TenantIdGetter) factory.getMiscDAO(ObjectTypes.TenantIdGetter.getValue());
            tenantId = idGetter.getTenantId();
        }

        return tenantId;
    }
    
    /**
     * Returns the realm name of the tenant identified by the specified
     * <code>anId</code>
     * 
     * @return realm name of the tenant if the tenant exists or else empty
     *         string
     */
    public static String getRealmName (String anId)
    {
        String realmName = "";
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository)factory.getMiscDAO(
            ObjectTypes.Tenant.getValue());
        Tenant tenant = (Tenant)dao.findOne(anId);
        if (tenant != null) {
            realmName = tenant.getRealmName();
        }
        return realmName;
    }

    public static String getANId (long tenantId)
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository) factory.getMiscDAO(ObjectTypes.Tenant.getValue());
        Tenant tenant = (Tenant) dao.findOne(tenantId);
        if (tenant != null) {
            return tenant.getAnId();
        }

        return null;
    }

    public static boolean isTenantExists (String anId)
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository) factory.getMiscDAO(ObjectTypes.Tenant.getValue());
        Tenant tenant = (Tenant) dao.findOne(anId);
        return tenant != null && tenant.getIsActive() == 1;
    }

    public static long getSystemTenantId ()
    {
        return SYSTEMTENANTID;
    }

    public static String getSystemAnId() {
        return SYSTEMANID;
    }

    public static Object getNestedData(JSONObject jsonObject, String key)
    {
        int index = key.indexOf(".");
        if (index != -1) {
            String currentKey = key.substring(0, index);
            if (jsonObject.get(currentKey) instanceof Map) {
                return getNestedData(
                    (JSONObject)jsonObject.get(currentKey),
                    key.substring(index + 1, key.length()));
            }
        }
        else {
            return jsonObject.get(key);
        }
        return null;
    }

    public static Object setNestedData(JSONObject jsonObject, String key,String value)
    {
        int index = key.indexOf(".");
        if (index != -1) {
            String currentKey = key.substring(0, index);
            if (jsonObject.get(currentKey) instanceof Map) {
                return setNestedData(
                    (JSONObject)jsonObject.get(currentKey),
                    key.substring(index + 1, key.length()),value);
            }
        }
        else {
            return jsonObject.put(key,value);
        }
        return null;
    }

    public static boolean isTenantActive (String anId)
    {
        DAOFactory factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        TenantRepository dao = (TenantRepository)factory.getMiscDAO(ObjectTypes.Tenant.getValue());
        Tenant tenant = (Tenant)dao.findOne(anId);
        return tenant != null && tenant.getIsActive() == 1;
    }
}
