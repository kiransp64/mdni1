package com.sap.ariba.erpintegration.service.mds;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsonorg.JsonOrgModule;
import com.sap.ariba.erpintegration.audit.client.AuditClientDataService;
import com.sap.ariba.erpintegration.common.parameter.ParameterFetcher;
import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.mdi.common.resource.Resource;
import com.sap.ariba.erpintegration.mdi.common.resource.ResourceOperation;
import com.sap.ariba.erpintegration.mdi.common.resource.ResourceType;
import com.sap.ariba.erpintegration.mdi.common.resource.request.RequestContext;
import com.sap.ariba.erpintegration.mdi.common.transform.TransformContext;
import com.sap.ariba.erpintegration.mdi.common.transform.exception.TransformException;
import com.sap.ariba.erpintegration.mdi.common.transform.service.JSONtransformService;
import com.sap.ariba.erpintegration.mdi.exception.PersistenceException;
import com.sap.ariba.erpintegration.mdi.meta.customer.CustomerIdentifierType;
import com.sap.ariba.erpintegration.mdi.meta.customer.CustomerMeta;
import com.sap.ariba.erpintegration.mdi.meta.customer.Destination;
import com.sap.ariba.erpintegration.persistence.model.StageXMLData;
import com.sap.ariba.erpintegration.service.PublishService;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.service.exception.ParameterFetcherException;
import com.sap.ariba.erpintegration.service.exception.TransientWebClientResponseException;
import com.sap.ariba.erpintegration.util.HandlerUtil;
import com.sap.ariba.erpintegration.util.IntegrationJobResponseProcessor;
import jakarta.annotation.PostConstruct;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.sap.ariba.erpintegration.handlers.IntegrationOperationType.FULLLOAD;
import static com.sap.ariba.erpintegration.service.mds.MDSEntityBatchResourceManager.COUNT_KEY;
import static com.sap.ariba.erpintegration.service.mds.MDSEntityBatchResourceManager.DELETED_KEY;
import static com.sap.ariba.erpintegration.service.mds.MDSEntityBatchResourceManager.INSERTED_KEY;
import static com.sap.ariba.erpintegration.service.mds.MDSEntityBatchResourceManager.UPDATED_KEY;
import static com.sap.ariba.erpintegration.service.mds.MDSPublishStatus.FAILURE;
import static com.sap.ariba.erpintegration.service.mds.MDSPublishStatus.SUCCESS;

@Service
@ConditionalOnExpression("${environment.mdcs:false}==false")
public class MDNIToMDSPublishService implements PublishService
{
    private static final Logger log = LoggerFactory.getLogger(MDNIToMDSPublishService.class);

    @Autowired
    @Qualifier("scimToMDSJSONTransfomService")
    private JSONtransformService scimToMDSJSONTransformService;

    @Autowired
    @Qualifier("mdsEntityBatchResourceManager")
    private MDSEntityBatchResourceManager mdsEntityBatchResourceManager;

    @Autowired(required=false)
    private MDSEntityDeactivationService deactivationService;

    @Autowired(required=false)
    MDSPublishFeatureCheckService mdsPublishFeatureCheckService;

    @Autowired
    private MDSPublishConfiguration mdsPublishConfiguration;

    private ObjectMapper objectMapper;

    private StageXMLData stageXMLData;

    @Autowired
    @Qualifier("AribaCustomerMeta")
    private CustomerMeta customerMeta;

    @Autowired
    private AuditClientDataService auditClientDataService;

    @Autowired
    private ParameterFetcher parameterFetcher;

    /*
    This property holds the Entities those get published to MDS hana directly, but they are not MM objects.
     */
    private final static List<String> MDS_DIRECT_PUBLISH_EXCLUDE_ENTITIES = new ArrayList<>(Arrays. asList("CostCenter","GeneralLedger"));
    private static final String DIRECT_PUBLISH_TO_MDS_PARAM_KEY = "Application.MasterData.Integration.DirectPublishToMDS";

    @PostConstruct
    private void initialize ()
    {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JsonOrgModule());
    }


    @Override
    public Map<String, Object> publish(JSONArray dataArray,
                                       String anId,
                                       int operation,
                                       String objectName,
                                       String senderBusinessSystemId, StageXMLData stageXMLData) throws
        IntegrationServiceException
    {
        if (StringUtils.isBlank(senderBusinessSystemId)) {
            final String errorMsg = 
                "Failed to publish '%s' data for ANID:'%s' to MDS as SenderBusinessSystemId is null".formatted(
                    objectName,
                    anId);
            log.error(errorMsg);
            // Populate error message in response map to fail the job
            return getErrorResponseFor(errorMsg);
        }
        try {
            if (FULLLOAD.getValue() == operation) {
                log.info("""
                        Attempting to deactivate existing '{}' entities for ANID '{}' \
                        with SenderBusinessSystemId '{}' in MDS\
                        """,
                    objectName,
                    anId,
                    senderBusinessSystemId);
                // Deactivate existing entities
                deactivationService.deactivateExistingRecords(objectName,
                    anId,
                    senderBusinessSystemId);
                log.info("""
                        Successfully deactivated '{}' entities for ANID '{}' \
                        with SenderBusinessSystemId '{}' in MDS\
                        """,
                    objectName,
                    anId,
                    senderBusinessSystemId);
            }
            // Publish 'dataArray' to MDS
            return transformAndPublish(dataArray, anId, objectName, senderBusinessSystemId, stageXMLData);
        } catch (TransientWebClientResponseException ex) {
            log.error("""
                    TransientWebClientResponseException encountered while publishing '{}' \
                    entity for ANID '{}' with SenderBusinessSystemId '{}' to MDS.\
                    """,
                objectName,
                anId,
                senderBusinessSystemId,
                ex);
            // Transient exceptions can be retried later
            // Throw IntegrationServiceException to stop the current
            // execution
            auditClientDataService.auditMdniToMdsData(null, anId, objectName, senderBusinessSystemId, stageXMLData, ex.getMessage());
            throw new IntegrationServiceException(ex, true);
        } catch (Exception ex) {
            log.error("""
                    Exception encountered while publishing '{}' entity for ANID '{}' \
                    with SenderBusinessSystemId '{}' to MDS.\
                    """,
                objectName,
                anId,
                senderBusinessSystemId,
                ex);
            // Any other exception caught at this point is a fatal error
            // Populate error message in response map
            auditClientDataService.auditMdniToMdsData(null, anId, objectName, senderBusinessSystemId, stageXMLData, ExceptionUtils.getRootCauseMessage(ex));
            return getErrorResponseFor(ExceptionUtils.getRootCauseMessage(ex));
        }
    }



    protected Map<String, Object> transformAndPublish (JSONArray dataArray,
                                                       String anId,
                                                       String objectName,
                                                       String senderBusinessSystemId,
                                                       StageXMLData stageXMLData) throws
        TransformException,
        PersistenceException
    {
        if (dataArray.size() <= HandlerUtil.KeyBatchSize) {
            // Publish the entire payload in one go
            log.info("""
                    Attempting to publish {} '{}' entities for ANID '{}' \
                    with SenderBusinessSystemId '{}' to MDS\
                    """,
                dataArray.size(),
                objectName,
                anId,
                senderBusinessSystemId);
            Map<String, Object> mdsResponse = publishData(dataArray,
                anId,
                objectName,
                senderBusinessSystemId);
            log.info("""
                    Successfully published {} '{}' entities for ANID '{}' \
                    with SenderBusinessSystemId '{}' to MDS\
                    """,
                dataArray.size(),
                objectName,
                anId,
                senderBusinessSystemId);
            int recordsInserted = 0, recordsUpdated = 0, recordsDeleted = 0;
            recordsInserted = getCountFor(mdsResponse, INSERTED_KEY);
            recordsUpdated = getCountFor(mdsResponse, UPDATED_KEY);
            recordsDeleted = getCountFor(mdsResponse, DELETED_KEY);

            String responseInfo = "Successfully inserted %d records, updated %d records and deleted %d records".formatted(
                recordsInserted, recordsUpdated, recordsDeleted);

            auditClientDataService.auditMdniToMdsData(responseInfo, anId, objectName, senderBusinessSystemId, stageXMLData, null);
            // Generate and return success response
            return generateSuccessResponse(getCountFor(mdsResponse, INSERTED_KEY),
                getCountFor(mdsResponse, UPDATED_KEY),
                getCountFor(mdsResponse, DELETED_KEY));
        }
        else {
            int recordsInserted = 0, recordsUpdated = 0, recordsDeleted = 0;
            int batchNumber = 0, totalRecordsPublished = 0;
            // Divide the payload into batches
            List<List<? extends JSONObject>> payloadBatches = ListUtils.partition(dataArray,
                HandlerUtil.KeyBatchSize);
            log.info("""
                    Number of records for '{}' entity for ANID '{}' with \
                    SenderBusinessSystemId '{}' is {} which exceeds batch size of {}. \
                    This payload will be published to MDS in {} batches.\
                    """,
                objectName,
                anId,
                senderBusinessSystemId,
                dataArray.size(),
                HandlerUtil.KeyBatchSize,
                payloadBatches.size());
            for (final List<? extends JSONObject> payloadBatch : payloadBatches) {
                log.info("""
                        Attempting to publish batch {} (of size {}) '{}' entities \
                        for ANID '{}' with SenderBusinessSystemId '{}' to MDS\
                        """,
                    ++batchNumber,
                    payloadBatch.size(),
                    objectName,
                    anId,
                    senderBusinessSystemId);
                Map<String, Object> mdsResponse = publishData(payloadBatch,
                    anId,
                    objectName,
                    senderBusinessSystemId);
                recordsInserted += getCountFor(mdsResponse, INSERTED_KEY);
                recordsUpdated += getCountFor(mdsResponse, UPDATED_KEY);
                recordsDeleted += getCountFor(mdsResponse, DELETED_KEY);
                totalRecordsPublished += payloadBatch.size();
                log.info("""
                        Successfully published {} (of total {}) '{}' entities for ANID '{}' \
                        with SenderBusinessSystemId '{}' to MDS\
                        """,
                    totalRecordsPublished,
                    dataArray.size(),
                    objectName,
                    anId,
                    senderBusinessSystemId);
            }
            String responseInfo = "Successfully inserted %d records, updated %d records and deleted %d records".formatted(
                recordsInserted, recordsUpdated, recordsDeleted);
            auditClientDataService.auditMdniToMdsData(responseInfo, anId, objectName, senderBusinessSystemId, stageXMLData, null);
            // Generate and return success response
            return generateSuccessResponse(recordsInserted, recordsUpdated, recordsDeleted);
        }
    }

    protected Map<String, Object> publishData (List<? extends JSONObject> dataArray,
                                               String anId,
                                               String objectName,
                                               String senderBusinessSystemId) throws
        TransformException,
        PersistenceException
    {
        JsonNode body = getJsonNode(dataArray);
        log.debug("""
                SOAP converted JSON payload for '{}' entity for ANID '{}' \
                with SenderBusinessSystemId '{}' to be published to MDS:\s
                 {}\
                """,
            objectName,
            anId,
            senderBusinessSystemId,
            body);
        final Entity entity = Entity.getEntity(objectName);
        TransformContext transformContext = new TransformContext(anId,
            body,
            Resource.ENTITY,
            ResourceType.MDNI,
            ResourceOperation.LOAD,
            entity,
            ResourceType.MDS);
        transformContext.setSenderBusinessSystemId(senderBusinessSystemId);
        JsonNode mdsNode = scimToMDSJSONTransformService.transform(transformContext);
        log.debug("""
                Payload for '{}' entity for ANID '{}' \
                with SenderBusinessSystemId '{}' to be published to MDS:\s
                 {}\
                """,
            objectName,
            anId,
            senderBusinessSystemId,
            mdsNode);
        RequestContext reqContext = new RequestContext(anId,
            getMDSPayload(mdsNode),
            Resource.ENTITY,
            ResourceType.MDS,
            ResourceOperation.LOAD,
            entity);
        return mdsEntityBatchResourceManager.load(reqContext);
    }

    private Map<String, Object> generateSuccessResponse (final int recordsInserted,
                                                         final int recordsUpdated,
                                                         final int recordsDeleted)
    {
        Map<String, Object> response = new HashMap<>();
        response.put(IntegrationJobResponseProcessor.MDSPublishStatus, SUCCESS);
        response.put(IntegrationJobResponseProcessor.RecordsCreated, recordsInserted);
        response.put(IntegrationJobResponseProcessor.RecordsUpdated, recordsUpdated);
        response.put(IntegrationJobResponseProcessor.RecordsDeleted, recordsDeleted);
        return response;
    }

    private int getCountFor (Map<String, Object> mdsResponse, String key)
    {
        if (MapUtils.isNotEmpty(mdsResponse)) {
            if (mdsResponse.containsKey(key)) {
                if (mdsResponse.get(key) instanceof Map) {
                    Map<String, Object> innerMap = (Map) mdsResponse.get(key);
                    if (innerMap.containsKey(COUNT_KEY)) {
                        return (int) innerMap.get(COUNT_KEY);
                    }
                }
            }
        }
        return 0;
    }

    private List<Map<String, Object>> getMDSPayload (JsonNode body)
    {
        if (body.isArray()) {
            return objectMapper.convertValue(body,
                new TypeReference<LinkedList<Map<String, Object>>>()
                {
                });
        }
        return Collections.emptyList();
    }

    private JsonNode getJsonNode (List<? extends JSONObject> dataArray)
    {
        return objectMapper.valueToTree(dataArray);
    }

    /**
     * Returns the error response map for the specified
     * <code>errorMessage</code>
     */
    private Map<String, Object> getErrorResponseFor (String errorMessage)
    {
        Map<String, Object> response = new HashMap<>();
        // Populate error message in response map
        List<Map<String, String>> errorMessages = new ArrayList<>();
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put(IntegrationJobResponseProcessor.ErrorMessage, errorMessage);
        errorMessages.add(errorMap);
        response.put(IntegrationJobResponseProcessor.MDSPublishStatus, FAILURE);
        response.put(IntegrationJobResponseProcessor.FatalErrors, errorMessages);
        return response;
    }

    /**
     * Checks if the specified <code>objectName</code> for the tenant identified
     * by the specified <code>anId</code> can be published to MDS directly from
     * MDNI
     *
     * @param anId
     * @param objectName
     */
    @Override
    public boolean isMDSPublishEnabled (String anId, String objectName, StageXMLData stageXMLData) {
        /*
             If entityName either CostCenter or GeneralLedger(SV Flow)
                then
                    if it's only sourcing realm
                        then
                            return true(Direct publish to MDS Hana)
                        else
                            return false (first publish to buyer and record will flow from there)
             else
                if entity is material master entity
                    then
                        return true
                    else
                        return false
         */
        try {
            if (MDS_DIRECT_PUBLISH_EXCLUDE_ENTITIES.contains(objectName)) {
                if (isMdsPublishFeatureEnabled(anId, stageXMLData)) {
                    List<Destination> destinations = customerMeta.getSubscribingApps(CustomerIdentifierType.AN_ID,
                            anId);
                    if (destinations.size() == 1 && destinations.get(0) == Destination.SOURCING) {
                        return true;
                    } else {
                        return false;
                    }
                }
            } else {
                if (isMdsPublishFeatureEnabled(anId, stageXMLData)) {
                    Set<String> mdsPublishEnbledEntities = mdsPublishConfiguration.getEnabledEntities();
                    if (!CollectionUtils.isEmpty(mdsPublishEnbledEntities)) {
                        return mdsPublishEnbledEntities.contains(objectName);
                    }
                }
            }
        } catch (ParameterFetcherException ex) {
            log.error("Error occurred while getting data from parameter fetch api with ANID:'{}' and parameterkey{} ",
                    anId,
                    DIRECT_PUBLISH_TO_MDS_PARAM_KEY,
                    ex);
        }
        catch (Exception ex) {
            log.error("Error occurred while checking if MDS publish is enabled for ANID:'{}' : {}",
                    anId,
                    ex);
        }
        return false;
    }

    /**
     * Returns true if the specified <code>objectName</code> is excluded from publishing to
     * Buyer or Sourcing (S4)
     *
     * @param objectName the entity name
     */
    public boolean isBuyerPublishExcluded (String objectName)
    {
        Set<String> excludedEntities = mdsPublishConfiguration.getBuyerPublishExcludedEntities();
        if (!CollectionUtils.isEmpty(excludedEntities)) {
            return excludedEntities.contains(objectName);
        }
        return false;
    }

    /**
     * If the <code>anId</code> present only in sourcing and if the <code>objectName</code> is not
     * supported in sourcing then return true. If the anId has both buyer and sourcing, it's assumed
     * mdni would be configured to buyer realm.
     *
     * @param anId
     * @param objectName
     * @return
     */
    public boolean isS4PublishExcluded (String anId, String objectName)
    {
        List<Destination> destinations = customerMeta.getSubscribingApps(CustomerIdentifierType.AN_ID,
            anId);
        if (destinations.size() == 1 && destinations.get(0) == Destination.SOURCING) {
            Set<String> excludedEntities = mdsPublishConfiguration.getS4PublishExcludedEntities();
            if (!CollectionUtils.isEmpty(excludedEntities)) {
                return excludedEntities.contains(objectName);
            }
        }
        return false;
    }

    /**
     * This method check if buyer or s4 publish excluded for a given realm and master data type.
     * This is because some master data types are not present in buyer/s4, but present in MDS.
     *
     * @param anId
     * @param objectName
     * @return
     */
    @Override
    public boolean isAppPublishExcuded (String anId, String objectName)
    {
       return isBuyerPublishExcluded(objectName) || isS4PublishExcluded(anId, objectName);
    }

    private boolean isMdsPublishFeatureEnabled (String anId, StageXMLData stageXMLData)
            throws Exception
    {
        if (!mdsPublishFeatureCheckService.isMDSPublishFeatureEnabled(anId)) {
            if (stageXMLData.isMDNIPayload()) {
                return parameterFetcher.getBoolean(anId, DIRECT_PUBLISH_TO_MDS_PARAM_KEY);
            }
            return false;
        }
        return true;
    }
}
