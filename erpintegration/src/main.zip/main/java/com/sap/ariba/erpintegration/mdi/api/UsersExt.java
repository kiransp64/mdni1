package com.sap.ariba.erpintegration.mdi.api;

import com.sap.ariba.erpintegration.mdi.api.exception.map.ErrorResponse;
import com.sap.ariba.erpintegration.mdi.api.exception.map.ErrorResponseBuilderFactory;
import com.sap.ariba.erpintegration.mdi.common.entity.Entity;
import com.sap.ariba.erpintegration.mdi.common.resource.Resource;
import com.sap.ariba.erpintegration.mdi.common.resource.ResourceOperation;
import com.sap.ariba.erpintegration.mdi.common.resource.ResourceType;
import com.sap.ariba.erpintegration.mdi.common.resource.request.RequestContext;
import com.sap.ariba.erpintegration.mdi.common.resource.request.RequestUtil;
import com.sap.ariba.erpintegration.mdi.common.util.TracingHelper;
import com.sap.ariba.erpintegration.mdi.exception.EntityAttributeFetcherException;
import com.sap.ariba.erpintegration.mdi.exception.NotFoundException;
import com.sap.ariba.erpintegration.mdi.exception.NotValidException;
import com.sap.ariba.erpintegration.mdi.exception.PersistenceException;
import com.sap.ariba.erpintegration.mdi.exception.ResourceParseException;
import com.sap.ariba.erpintegration.mdi.exception.SearchException;
import com.sap.ariba.erpintegration.mdi.exception.ValidationException;
import com.sap.ariba.erpintegration.mdi.integrate.integrator.Operation;
import com.sap.ariba.erpintegration.mdi.mds.search.constants.MDSsearchConstants;
import com.sap.ariba.erpintegration.mdi.mds.search.entity.UserListScimResponse;
import com.sap.ariba.erpintegration.mdi.mds.search.hanasql.EntityAttributeFetcher;
import com.sap.ariba.erpintegration.mdi.mds.search.request.HanaRequestMeta;
import com.sap.ariba.erpintegration.mdi.mds.search.request.RequestMeta;
import com.sap.ariba.erpintegration.mdi.parser.AttributeParser;
import com.sap.ariba.erpintegration.mdi.parser.model.Attributes;
import com.sap.ariba.erpintegration.mdi.scim.resource.ResponseAttribute;
import com.sap.ariba.erpintegration.mdi.scim.resource.manager.SCIMUserEntityManager;
import com.sap.ariba.erpintegration.mdi.scim.resource.patch.PatchUpdateManager;
import com.sap.ariba.erpintegration.mdi.scim.resource.validate.PatchValidator;
import com.sap.ariba.erpintegration.mdi.scim.resource.validate.UserValidator;
import com.sap.ariba.erpintegration.monitor.im.helper.IMHelper;
import com.sap.ariba.erpintegration.util.ErrorUtil;
import com.sap.scimono.api.API;
import com.sap.scimono.api.Users;
import com.sap.scimono.api.patch.PATCH;
import com.sap.scimono.entity.User;
import com.sap.scimono.entity.paging.PagedByIndexSearchResult;
import com.sap.scimono.entity.patch.PatchBody;

import com.sap.scimono.entity.schema.validation.ValidStartId;
import io.micrometer.core.annotation.Timed;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static com.sap.ariba.erpintegration.mdi.api.APIUtil.validate;
import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.INBOUND_FAILURE;
import static com.sap.ariba.erpintegration.monitor.im.util.IMEvents.SCIM;
import static com.sap.scimono.api.API.APPLICATION_JSON_SCIM;
import static com.sap.scimono.api.API.COUNT_PARAM;
import static com.sap.scimono.api.API.FILTER_PARAM;
import static com.sap.scimono.api.API.START_ID_PARAM;
import static com.sap.scimono.api.API.START_INDEX_PARAM;
import static com.sap.scimono.api.API.USERS;
import static com.sap.scimono.entity.paging.PagedByIndexSearchResult.DEFAULT_START_INDEX;

@Path(USERS)
@Produces(APPLICATION_JSON_SCIM)
@Consumes(APPLICATION_JSON_SCIM)
public class UsersExt extends Users
{

    private static final Logger logger = LoggerFactory.getLogger(UsersExt.class);
    public static final String DEFAULT_COUNT = "10";
    public static final String DOUBLE_QOUTE="\"";

    @Value("${mdi.mdssearch.window.pagination}")
    private boolean windowsPagination;
    
    @Value("${mdi.mdssearch.window.pagination.default.limit}")
    private int windowsPaginationDefaultLimit;

    @Value("${mdi.mdssearch.attribute.pagination.default.limit}")
    private int attributePaginationDefaultLimit;

    @Autowired
    SCIMUserEntityManager scimUserEntityResourceManager;

    @Autowired
    PatchUpdateManager<User> patchUpdateManager;

    @Autowired
    PatchValidator patchValidator;
    @Autowired
    private TracingHelper tracingHelper;

    @Autowired
    private UserValidator userValidator;

    @HeaderParam(value = RequestUtil.TENANT_ID_PARAM) @Getter @Setter String tenantId;

    private ThreadLocal<String> passwordAdapterThreadLocal = new ThreadLocal<>();


    @Autowired
    private EntityAttributeFetcher entityAttributeFetcher;

    @Autowired
    private AttributeParser attributeParser;

    @Lazy
    @Autowired
    private IMHelper imHelper;

    @Lazy
    @Autowired
    private ErrorResponseBuilderFactory errorResponseBuilderFactory;


    @Autowired
    public UsersExt (Application scimApplication, @Context UriInfo uriInfo)
    {
        super(scimApplication, uriInfo);
    }
    
    @POST
    @Timed("mds.scim.create.user")
    public Response createUser (User newUser)
    {
        try {
            logger.debug("Received Request to create user for tenant ID {}", APIUtil.sanitizeInput(tenantId));
            validate(newUser, tenantId);
            RequestContext<User> reqContext = new RequestContext<User>(
                tenantId,
                newUser,
                Resource.ENTITY,
                ResourceType.SCIM,
                ResourceOperation.CREATE,
                Entity.USER);

            Map<String, Object> responseMap = scimUserEntityResourceManager.create(
                reqContext);
            URI location = (URI)responseMap.get(ResponseAttribute.LOCATION.getName());
            User user = (User)responseMap.get(ResponseAttribute.ENTITY.getName());
            return Response.created(location).entity(user).type(API.APPLICATION_JSON_SCIM).header(
                TracingHelper.TRACKING_ID,
                getTrackingID()).build();
        }
        catch (Exception e) {
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {}, User creation failed.",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(e));
            logIMEvent(tenantId,
                       StringUtils.isNotEmpty(newUser.getUserName()) ? newUser.getUserName() : "",
                       Entity.USER.getValue(),
                       ResourceOperation.CREATE,
                       e);
            throw new WebApplicationException(e);
        }
    }

    @PUT
    @Path("{id}")
    @Timed("mds.scim.update.user")
    public Response updateUser (User user,
                                @PathParam("id") String userName)
    {
        try {
            validate(user, tenantId, userName);
            RequestContext<User> reqContext = new RequestContext<User>(
                tenantId,
                user,
                Resource.ENTITY,
                ResourceType.SCIM,
                ResourceOperation.UPDATE,
                Entity.USER);

            Map<String, Object> responseMap = scimUserEntityResourceManager.update(
                reqContext);
            URI location = (URI)responseMap.get(ResponseAttribute.LOCATION.getName());
            user = (User)responseMap.get(ResponseAttribute.ENTITY.getName());
            return Response.ok(user).type(API.APPLICATION_JSON_SCIM).header(
                TracingHelper.TRACKING_ID,
                getTrackingID()).header(HttpHeaders.LOCATION,location).build();
        }
        catch (Exception e) {
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {}, User updation failed.",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(e));
            logIMEvent(tenantId,
                       userName,
                       Entity.USER.getValue(),
                       ResourceOperation.UPDATE,
                       e);
            throw new WebApplicationException(e);
        }
    }
    @DELETE
    @Path("{id}")
    @Timed("mds.scim.delete.user")
    public void deleteUser (@PathParam("id")  final String userId)
    {
        try {
            validate(tenantId);
            RequestContext<String> reqContext = new RequestContext<String>(
                    tenantId,
                    userId,
                    Resource.ENTITY,
                    ResourceType.SCIM,
                    ResourceOperation.DELETE,
                    Entity.USER);
            String passwordAdapter = passwordAdapterThreadLocal.get();
            if (StringUtils.isNotEmpty(passwordAdapter)) {
                reqContext.setPasswordAdapter(passwordAdapter);
            }
            scimUserEntityResourceManager.delete(reqContext);
            Response.noContent().type(API.APPLICATION_JSON_SCIM).header(
                    TracingHelper.TRACKING_ID,
                    getTrackingID()).build();
        }
        catch (PersistenceException e) {
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {} while deleting user",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(e));
            logIMEvent(tenantId,
                       userId,
                       Entity.USER.getValue(),
                       ResourceOperation.DELETE,
                       e);
            throw new WebApplicationException(e);
        }
        finally {
            passwordAdapterThreadLocal.remove();
        }
    }


    private String getTrackingID ()
    {
        String trackingID = TracingHelper.NOT_AVAILABLE_TRACKING_ID;
        if (tracingHelper != null) {
            trackingID = tracingHelper.getTraceId();
        }
        return trackingID;
    }

    @GET
    @Timed("mds.scim.getentities.user")
    public Response getUsers (@DefaultValue(DEFAULT_START_INDEX) @QueryParam(START_INDEX_PARAM) int startIndex,
                              @DefaultValue(DEFAULT_COUNT) @QueryParam(COUNT_PARAM) int count,
                              @QueryParam(START_ID_PARAM) @ValidStartId String startId,
                              @QueryParam(FILTER_PARAM) final String filter, @QueryParam("passwordAdapter") String passwordAdapter)
    {
        try {
            logger.debug(
                "Reading users with paging parameters startIndex {} startId {} count {}",
                APIUtil.sanitizeInput(String.valueOf(startIndex)),
                APIUtil.sanitizeInput(startId),
                APIUtil.sanitizeInput(String.valueOf(count)));
            if (startIndex < 1) {
                startIndex = 1;
            }
            startIndex = startIndex - 1;
            if (count < 0) {
                count = 0;
            }
            RequestMeta reqMeta = new RequestMeta(
                Entity.USER,
                startIndex,
                count,
                filter,
                false,
                tenantId);
            reqMeta.setWindowPagination(windowsPagination);
            reqMeta.setWindowPaginationDefaultLimit(windowsPaginationDefaultLimit);
            reqMeta.setAttributePaginationDefaultLimit(attributePaginationDefaultLimit);
            
            HanaRequestMeta hanaReqMeta = new HanaRequestMeta();
            hanaReqMeta.setReqMeta(reqMeta);
            RequestContext<HanaRequestMeta> reqContext = new RequestContext<HanaRequestMeta>(
                tenantId,
                hanaReqMeta,
                Resource.ENTITY,
                ResourceType.SCIM,
                ResourceOperation.GET_ENTITIES,
                Entity.USER);
            reqContext.setPasswordAdapter(passwordAdapter);
            Map<String, Object> responseMap = scimUserEntityResourceManager.getEntities(
                reqContext);
            if (responseMap != null) {
                List<UserListScimResponse> users = (List<UserListScimResponse>)responseMap.get(
                    ResponseAttribute.ENTITY.getName());
                Long totalResults=(Long)responseMap.get(ResponseAttribute.COUNT.getName());
                return Response.ok(
                    new PagedByIndexSearchResult<UserListScimResponse>(
                        users,
                        totalResults.intValue(),
                        users.size(),
                        Integer.valueOf(startIndex + 1))).header(
                            TracingHelper.TRACKING_ID,
                            getTrackingID()).build();
            }
            return Response.ok(new PagedByIndexSearchResult<User>(new LinkedList<>(),
                    0, count, Integer.valueOf(startIndex + 1))).header(TracingHelper.TRACKING_ID,
                    getTrackingID()).build();

        }
        catch (SearchException e) {
            logger.info("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {} while Searching data for user",
                        APIUtil.sanitizeInput(tenantId),
                        ErrorUtil.getCompleteCausedByErrors(e));
            throw new WebApplicationException(e);

        }
    }

    @GET
    @Path("{id}")
    @Timed("mds.scim.getentity.user")
    public Response getUser (@PathParam("id")  final String userId,
                             @QueryParam("attributes") String attributes,
                             @QueryParam("passwordAdapter") String passwordAdapter)
    {
        try {
            logger.debug("Reading user {}", APIUtil.sanitizeInput(userId));
            StringBuilder filter = new StringBuilder();
            filter.append("userName eq ").append(DOUBLE_QOUTE).append(userId).append(DOUBLE_QOUTE);
            RequestMeta reqMeta = new RequestMeta(Entity.USER, filter.toString(), tenantId);
            if (attributes != null) {
                Attributes userAttributes = attributeParser.parseAttribute(attributes);
                if (userAttributes.getPaginatedAttributesOptions() != null && userAttributes.getMembers().contains("groups")) {
                    reqMeta.setPaginatedAttributesOptions(userAttributes.getPaginatedAttributesOptions());
                    reqMeta.setAttributesPaginated(true);
                }
            }
            reqMeta.setWindowPagination(windowsPagination);
            reqMeta.setWindowPaginationDefaultLimit(windowsPaginationDefaultLimit);
            reqMeta.setAttributePaginationDefaultLimit(attributePaginationDefaultLimit);

            HanaRequestMeta hanaReqMeta = new HanaRequestMeta();
            hanaReqMeta.setReqMeta(reqMeta);

            RequestContext<HanaRequestMeta> reqContext = new RequestContext<HanaRequestMeta>(
                tenantId,
                hanaReqMeta,
                Resource.ENTITY,
                ResourceType.SCIM,
                ResourceOperation.GET_ENTITY,
                Entity.USER);

            reqContext.setPasswordAdapter(passwordAdapter);

            Map<String, Object> responseMap = scimUserEntityResourceManager.getEntity(
                reqContext);
            if (responseMap != null) {
                URI location = (URI)responseMap.get(ResponseAttribute.LOCATION.getName());
                User user = (User)responseMap.get(ResponseAttribute.ENTITY.getName());
                return Response.ok(user).tag(user.getMeta().getVersion()).location(
                    location).header(TracingHelper.TRACKING_ID, getTrackingID()).build();
            }
            else {
                throw new WebApplicationException(new NotFoundException(
                        "Resource with given user doesn't exist"));
            }
        }
        catch (SearchException e) {
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {} while searching data for user",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(e));
            throw new WebApplicationException(e);
        }
        catch (ResourceParseException re){
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {} while parsing user attributes ",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(re));
            re.printStackTrace();
            throw new WebApplicationException(re);
        }
    }

    @PATCH
    @Path("{id}")
    public Response patchUser (@PathParam("id")  final String userId,
                               final PatchBody patchBody)
    {
        try {
            logger.debug("Reading user {}", APIUtil.sanitizeInput(userId));
            StringBuilder filter = new StringBuilder();
            //changing approach
            //1. validate the passwordAdapter, if not valid throw exception
            //2. if valid, find all the records for given username and check if record with given passwordAdapter exist or not
            //if not throw exception saying records does not exist with given username and passwordAdapter
            //if exist then remove the patchOperation of passwordAdapter from PatchBody

            String passwordAdapterForPatch = scimUserEntityResourceManager.validatePasswordAdapterForPatch(patchBody,
                                                                                     tenantId,
                                                                                     userId);
            userValidator.validateCustomAttributeForPatch(patchBody, tenantId);

            filter.append("userName eq ").append(DOUBLE_QOUTE).append(userId).append(DOUBLE_QOUTE);
            RequestMeta reqMeta = new RequestMeta(Entity.USER, filter.toString(), tenantId);
            HanaRequestMeta hanaReqMeta = new HanaRequestMeta();
            hanaReqMeta.setReqMeta(reqMeta);
            RequestContext<HanaRequestMeta> hanaRequestMetaRequestContext = new RequestContext<>(tenantId,
                                                                                                 hanaReqMeta,
                                                                                                 Resource.ENTITY,
                                                                                                 ResourceType.SCIM,
                                                                                                 ResourceOperation.GET_ENTITY,
                                                                                                 Entity.USER);
            hanaRequestMetaRequestContext.setPasswordAdapter(passwordAdapterForPatch);
            Map<String, Object> responseMap = scimUserEntityResourceManager.getEntity(hanaRequestMetaRequestContext);
            if (responseMap != null) {
                //Found User
                User existingUser = (User)responseMap.get(ResponseAttribute.ENTITY.getName());

                User updatedUser =
                        patchUpdateManager.updateExistingResourceUsingPatch(existingUser, patchBody);
                RequestContext<User> requestContext = new RequestContext<>(
                        tenantId,
                        updatedUser,
                        Resource.ENTITY,
                        ResourceType.SCIM,
                        ResourceOperation.PATCH,
                        Entity.USER);
                //Pre-check UUID uniqueness here during PATCH operation,
                // from Patch body and not the existing User data
                patchValidator.validateUniqueUserUUID(requestContext, patchBody);
                if (updatedUser != null) {
                    Map<String, Object> updateResponseMap = scimUserEntityResourceManager.update(
                            requestContext, Operation.PATCH);
                    URI location = (URI)updateResponseMap.get(ResponseAttribute.LOCATION.getName());
                    updatedUser = (User)updateResponseMap.get(ResponseAttribute.ENTITY.getName());
                    return Response.ok(updatedUser).type(API.APPLICATION_JSON_SCIM).header(
                            TracingHelper.TRACKING_ID,
                            getTrackingID()).header(HttpHeaders.LOCATION, location).build();
                }else{
                    URI location = (URI)responseMap.get(ResponseAttribute.LOCATION.getName());
                    return Response.ok(existingUser).type(API.APPLICATION_JSON_SCIM).header(
                            TracingHelper.TRACKING_ID,
                            getTrackingID()).header(HttpHeaders.LOCATION, location).build();

                }

            }
            else {
                throw new NotFoundException(
                        "Resource with given user doesn't exist");
            }
        }
        catch (ValidationException | EntityAttributeFetcherException vee) {
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {} while patching user",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(vee));
            throw new WebApplicationException(vee);
        }
        catch (NotValidException ne) {
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {} while patching User. Sending 204 No content",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(ne));
            if (IMHelper.isIMEnable())
            //sending error inbound/outbound event to im.
            {
                imHelper.processIMMonitoring(tenantId,
                                             StringUtils.isNotEmpty(userId) ? userId : "",
                                             Entity.USER.getValue(),
                                             ResourceOperation.PATCH,
                                             ne.getMessage(),
                                             true,
                                             INBOUND_FAILURE,
                                             SCIM);
            }
            return Response.noContent().type(API.APPLICATION_JSON_SCIM).header(
                    TracingHelper.TRACKING_ID,
                    getTrackingID()).build();
        }
        catch (Exception e) {
            logger.error("[MDNI_CRITICAL][ARIBA][SCIM] Tenant ID - {}, Exception {} while patching User with patch - {}",
                         APIUtil.sanitizeInput(tenantId),
                         ErrorUtil.getCompleteCausedByErrors(e),
                         APIUtil.patchBodyToString(patchBody));
            logIMEvent(tenantId,
                       userId,
                       Entity.USER.getValue(),
                       ResourceOperation.PATCH,
                       e);
            throw new WebApplicationException(e);
        }

    }

    @QueryParam(value = "passwordAdapter")
    @DefaultValue(MDSsearchConstants.PASSWORD_ADAPTER1)
    public void setPasswordAdapter (String passwordAdapter)
    {
        passwordAdapterThreadLocal.set(passwordAdapter);
    }
    
    /**
     * logging scim failure event to IM .
     *
     * @param tenantId
     * @param uniqueName
     * @param objectName
     * @param operation
     * @param error
     */
    private void logIMEvent (String tenantId,
                             String uniqueName,
                             String objectName,
                             ResourceOperation operation,
                             Exception error)
    {
        try {
            if (IMHelper.isIMEnable()) {
                ErrorResponse errorResponse = errorResponseBuilderFactory.getErrorResponseKnownExceptions(error);
                String errorMsg = ObjectUtils.isNotEmpty(errorResponse) ?
                                errorResponse.getMessage() :
                                "";
                imHelper.processIMMonitoring(tenantId,
                                             uniqueName,
                                             objectName,
                                             operation,
                                             errorMsg,
                                             true,
                                             INBOUND_FAILURE,
                                             SCIM);
            }
        }
        catch (Exception e) {
            logger.error("Error -{}, while sending Inbound Failure event to IM for TenantId - {} , UniqueName - {} , Object name - {} , ResourceOperation - {}",
                         e,
                         APIUtil.sanitizeInput(tenantId),
                         APIUtil.sanitizeInput(uniqueName),
                         APIUtil.sanitizeInput(objectName),
                         operation);
        }
    }
}
