package com.sap.ariba.erpintegration.service.rs;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sap.ariba.erpintegration.handlers.RequestHandler;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;


/**
 * Created by i318483 on 31/05/17.
 */
// @RestController
public class IntegrationConfigService {

    private final static String KeyAction = "PersistIntegrationConfig";

    @POST
    @RequestMapping("/processConfigData")
    public Response processConfigData(@Context HttpServletRequest request) throws IntegrationServiceException,
        MissingServletRequestParameterException
    {
        RequestHandler requestHandler = RequestHandler.getHandler(KeyAction);
        return requestHandler.execute(request);
    }
}
