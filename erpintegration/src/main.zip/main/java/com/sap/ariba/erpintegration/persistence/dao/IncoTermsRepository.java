package com.sap.ariba.erpintegration.persistence.dao;

import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;

import org.hibernate.annotations.BatchSize;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import com.sap.ariba.erpintegration.persistence.model.IncoTerms;


@Component("IncoTermsRepositoryComponent")
public interface IncoTermsRepository<T,D> extends GenericDAO<IncoTerms, Long> {
    
    @Query("select s from IncoTerms s where s.tenantId = :tenantId and s.code = :code")
    GenericEntity findOne(@Param("tenantId") long tenantId, @Param("code") String code);

    @Query("select s from IncoTerms s where s.tenantId = :tenantId and s.code = :taxCode and  s.code = :countryCode")
    GenericEntity findOne(@Param("tenantId") long tenantId, @Param("taxCode") String taxCode, @Param("countryCode") String countryCode);


    @Query("select s from IncoTerms s where s.code = :code")
    List<GenericEntity> findAllReferences(@Param("code") String code);

    @Query("select s from IncoTerms s where dateUpdated > :timeUpdated and tenantId = :tenantId order by id")
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "INCOTERMS_TAB", cascade = CascadeType.PERSIST)
    @BatchSize(size = 1000)
    public List<GenericEntity> findAll(@Param("timeUpdated") Date timeUpdated,
                                       @Param("tenantId") long tenantId);

    @Query("select s from IncoTerms s where tenantId = :tenantId order by id")
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "INCOTERMS_TAB", cascade = CascadeType.PERSIST)
    @BatchSize(size = 1000)
    public List<GenericEntity> findAll(@Param("tenantId") long tenantId);

    @Query("select data from IncoTerms where dateUpdated > :timeUpdated and id > :lastRecordId and tenantId = :tenantId order by id")
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "INCOTERMS_TAB", cascade = CascadeType.PERSIST)
    @BatchSize(size = 1000)
    public List<GenericEntity> findAll(@Param("timeUpdated") Date timeUpdated, @Param("lastRecordId") String lastRecordId, @Param("tenantId") long tenantId);

    @Query("select s from IncoTerms s where s.dateUpdated >= :minTimeUpdated and s.dateUpdated <= :maxTimeUpdated and s.tenantId = :tenantId order by s.id asc")
    public Page<GenericEntity> findAll(@Param("tenantId") long tenantId,
                                       @Param("minTimeUpdated") Date minTimeUpdated,
                                       @Param("maxTimeUpdated") Date maxTimeUpdated,
                                       Pageable pageable);

    @Query("select s from IncoTerms s where s.dateUpdated >= :minTimeUpdated and s.dateUpdated <= :maxTimeUpdated and s.id > :lastRecordId and s.tenantId = :tenantId order by s.id asc")
    public Page<GenericEntity> findAll(@Param("tenantId") long tenantId,
                                       @Param("minTimeUpdated") Date minTimeUpdated,
                                       @Param("maxTimeUpdated") Date maxTimeUpdated,
                                       @Param("lastRecordId") String lastRecordId,
                                       Pageable pageable);

}
