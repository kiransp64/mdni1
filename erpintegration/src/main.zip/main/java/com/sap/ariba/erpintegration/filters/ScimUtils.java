package com.sap.ariba.erpintegration.filters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.ariba.erpintegration.mdi.api.exception.map.ErrorResponse;
import com.sap.ariba.erpintegration.mdi.common.resource.ResourceOperation;
import com.sap.ariba.erpintegration.mdi.integrate.integrator.Operation;
import com.sap.scimono.api.API;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.sap.ariba.erpintegration.monitor.im.util.IMConstants.*;

public class ScimUtils {

    private static final Logger logger =
            LoggerFactory.getLogger(ScimUtils.class);

    public static String ACCEPT_TYPE = "Accept";
    /**
     * Will get the Object name from incoming request URI.
     *
     * @param requestUri
     * @return Object name i.e. User/Group
     */
    public static String getObjectName (String requestUri)
    {
        String objectName = "";
        if (StringUtils.isNotEmpty(requestUri)) {
            if (requestUri.toUpperCase().contains(USER)) {
                objectName = USER_ENTITY;
            }
            else if (requestUri.toUpperCase().contains(GROUP)) {
                objectName = GROUP_ENTITY;
            }
        }
        return objectName;
    }

    /**
     * Get ResourceOperation of scim api call based on request method
     *
     * @param requestMethod
     * @return ResourceOperation i.e. CREATE/UPDATE etc.
     */
    public static ResourceOperation getRequestOperation (String requestMethod)
    {
        ResourceOperation resourceOperation = null;
        if (StringUtils.isNotEmpty(requestMethod)) {
            resourceOperation = Operation.valueOf(requestMethod).getResourceOperation();
        }
        return resourceOperation;
    }


    /**
     * Check if incoming request is related to scim api call.
     * based on URI contains scim path.
     *
     * @param request
     * @return true or false
     */
    public static boolean isScimCall (HttpServletRequest request)
    {
        if (ObjectUtils.isNotEmpty(request)) {
            String requestUri = request.getRequestURI();
            return StringUtils.isNotEmpty(requestUri) && requestUri.toUpperCase()
                            .contains(SCIM);
        }
        return false;
    }

    public static void writeScimErrorResponse(String errResponse,
                                              int status,
                                              HttpServletResponse response) {

        try {
            response.setContentType(API.APPLICATION_JSON_SCIM);
            response.setStatus(status);

            ErrorResponse errorResponse = new ErrorResponse(status, errResponse);
            response.getWriter().write((new ObjectMapper()).writeValueAsString(errorResponse));
        } catch (IOException e) {
            logger.error("Error while convert errResponse to json.",
                    e);
        }
    }
}
