package com.sap.ariba.erpintegration.service.exception;

public class AuditFailedException extends Exception{

    public AuditFailedException(String message) {
        super(message);
    }
}
