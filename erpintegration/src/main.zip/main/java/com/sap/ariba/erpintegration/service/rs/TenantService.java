package com.sap.ariba.erpintegration.service.rs;

import java.util.Map;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.common.utility.OAuthTokenManager;
import com.sap.ariba.erpintegration.handlers.TenantHandler;
import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;
import com.sap.ariba.erpintegration.service.exception.ResourceNotFoundException;
import com.sap.ariba.erpintegration.service.exception.UnauthorizedException;

public class TenantService
{

    private static final String nameOfLogger = "com.sap.ariba.erpintegration.service.rs.TenantService";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    @Autowired
    private TenantHandler tenantHandler;

    @GET
    @Path("/{tenantIdentifier}")
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Map<String, Object> getTenant (@PathParam("tenantIdentifier") String tenantIdentifier,
                                          @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken)
        throws IntegrationServiceException,
        ResourceNotFoundException,
        UnauthorizedException

    {
        
        if (!isRequestAuthorized(authToken)) {
            throw new UnauthorizedException("Invalid Auth token : " + authToken);
        }
        return tenantHandler.getTenant(tenantIdentifier);
    }

    public boolean isRequestAuthorized (String authToken)
    {
        OAuthTokenManager oAuthTokenManager = ApplicationContextProvider.getApplicationContext().getBean(
            OAuthTokenManager.class);
        return oAuthTokenManager.getUserInfo(authToken) != null;
    }
}
