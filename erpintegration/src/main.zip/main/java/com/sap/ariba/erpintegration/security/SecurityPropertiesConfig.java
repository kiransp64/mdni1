package com.sap.ariba.erpintegration.security;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Properties;

/**
 * Constructs properties bean with security properties <br>
 * Properties bean with security configuration required for signing message.
 * 
 * @author i501987 Hanumesh
 *
 */
@Configuration
public class SecurityPropertiesConfig {

	private static final String KEYSTORE_PASSWORD = "org.apache.ws.security.crypto.merlin.keystore.password";
	private static final String KEYSTORE_FILE = "org.apache.ws.security.crypto.merlin.keystore.file";
	private static final String KEYSTORE_TYPE = "org.apache.ws.security.crypto.merlin.keystore.type";
	private static final String PRIVATE_KEY_PASSWORD = "privatekeypassword";
	private static final String KEYSTORE_ALIAS = "org.apache.ws.security.crypto.merlin.keystore.alias";
	private static final String CRYPTO_PROVIDER = "org.apache.ws.security.crypto.provider";
		
	private static final Logger logger = LoggerFactory.getLogger(SecurityPropertiesConfig.class);
	
	@Value("${org.apache.ws.security.crypto.merlin.keystore.alias:#{null}}")
	private String keyAlias;

	@Value("${privatekeypassword:#{null}}")
	private String privateKeyPass;

	@Value("${org.apache.ws.security.crypto.provider:#{null}}")
	private String cryptoProvider;

	@Value("${org.apache.ws.security.crypto.merlin.keystore.file:#{null}}")
	private String keyStoreFile;

	@Value("${org.apache.ws.security.crypto.merlin.keystore.type:#{null}}")
	private String keyStoreType;

	@Value("${org.apache.ws.security.crypto.merlin.keystore.password:#{null}}")
	private String keyStorePassword;
	
	@Value("${CERT_CONTENT}")
	private String keyStoreContent;

	@Bean
	@Qualifier("SignKeyStore")
	public Properties properties() {
		Properties properties = new Properties();
		properties.put(CRYPTO_PROVIDER, cryptoProvider);
		properties.put(KEYSTORE_ALIAS, keyAlias);
		properties.put(PRIVATE_KEY_PASSWORD, privateKeyPass);
		properties.put(KEYSTORE_TYPE, keyStoreType);
		properties.put(KEYSTORE_FILE, keyStoreFile);
		properties.put(KEYSTORE_PASSWORD, keyStorePassword);
		return properties;
	}
	
	@PostConstruct
	public void writeCertificateContentToFile() throws IOException {
	  
        try ( FileOutputStream fos = new FileOutputStream(keyStoreFile); ) {
           
            byte[] decoder = Base64.getDecoder().decode(keyStoreContent);

            fos.write(decoder);
            logger.info("Erpintegration certificate written to {}", keyStoreFile);
            
          } catch (Exception e) {
            e.printStackTrace();
          }	    
	}
}
