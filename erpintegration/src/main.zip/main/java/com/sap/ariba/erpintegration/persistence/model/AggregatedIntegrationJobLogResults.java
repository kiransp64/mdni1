package com.sap.ariba.erpintegration.persistence.model;

/**
 * Created by c5259108 on 18/12/17.
 */
public class AggregatedIntegrationJobLogResults {
    private long recordsInserted;
    private long recordsUpdated;
    private long recordsDeleted;

    public AggregatedIntegrationJobLogResults(long recordsInserted, long recordsUpdated, long recordsDeleted) {
        this.recordsInserted = recordsInserted;
        this.recordsUpdated = recordsUpdated;
        this.recordsDeleted = recordsDeleted;
    }

    public long getRecordsInserted() {
        return recordsInserted;
    }

    public void setRecordsInserted(long recordsInserted) {
        this.recordsInserted = recordsInserted;
    }

    public long getRecordsUpdated() {
        return recordsUpdated;
    }

    public void setRecordsUpdated(long recordsUpdated) {
        this.recordsUpdated = recordsUpdated;
    }

    public long getRecordsDeleted() {
        return recordsDeleted;
    }

    public void setRecordsDeleted(long recordsDeleted) {
        this.recordsDeleted = recordsDeleted;
    }
}
