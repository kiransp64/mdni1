package com.sap.ariba.erpintegration.storage;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnExpression(value = "${advanced.storage.option}")
public class CloudStorageFactory {

    private Logger logger = LoggerFactory.getLogger(CloudStorageFactory.class);

    @Autowired
    @Qualifier("AWSObjectStorage")
    private CloudStorage awsObjectStorage;

    @Autowired
    @Qualifier("AzureBlobStorage")
    private CloudStorage azureBlobStorage;

    @Autowired
    @Qualifier("GCPObjectStorage")
    private CloudStorage gcpObjectStorage;

    @Value("${cloud.storage.type}")
    private CloudStorageType cloudStorageType;

    @Autowired
    @Qualifier("MinIOObjectStorage")
    private CloudStorage minIOObjectStorage;

    @PostConstruct
    public void init(){
        logger.info("************ Configured Cloud Storage ************");
        logger.info("************ {} ************", this.cloudStorageType.getType());
        logger.info("************ ************************* ************");
    }

    public CloudStorage getCloudStorage() {
        CloudStorage cloudStorage = null;
        switch (cloudStorageType) {
            case AWS_OBJECT_STORAGE:
                logger.info("User cloud storage : {}", cloudStorageType.AWS_OBJECT_STORAGE.getType());
                cloudStorage = awsObjectStorage;
                break;
            case AZURE_BLOB_STORAGE:
                logger.info("User cloud storage : {}", cloudStorageType.AZURE_BLOB_STORAGE.getType());
                cloudStorage = azureBlobStorage;
                break;
            case GCP_OBJECT_STORAGE:
                logger.info("User cloud storage : {}", cloudStorageType.GCP_OBJECT_STORAGE.getType());
                cloudStorage = gcpObjectStorage;
                break;
            case MINIO_OBJECT_STORAGE:
                logger.info("User cloud storage : {}", cloudStorageType.MINIO_OBJECT_STORAGE.getType());
                cloudStorage = minIOObjectStorage;
                break;
            default:
                break;
        }
        return cloudStorage;
    }

}
