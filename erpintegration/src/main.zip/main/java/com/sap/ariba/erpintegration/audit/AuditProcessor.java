package com.sap.ariba.erpintegration.audit;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.ariba.erpintegration.persistence.DAOFactory;
import com.sap.ariba.erpintegration.persistence.ObjectTypes;
import com.sap.ariba.erpintegration.persistence.dao.AuditRepository;
import com.sap.ariba.erpintegration.persistence.service.InvalidTypeCodeException;

/**
 * This is a task class for a single audit record in database table. It has been
 * created as a task to be consumed by any worker thread.
 * 
 * @author i339952
 */
public class AuditProcessor implements Runnable
{
    private static final String nameOfLogger = "com.sap.ariba.erpintegration.audit.AuditProcessor";
    private static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private DAOFactory factory = null;
    private AuditRepository auditRepository = null;

    private BlockingQueue<AuditTask> auditTasks = null;

    public AuditProcessor (BlockingQueue<AuditTask> auditTasks)
    {
        this.auditTasks = auditTasks;
        factory = DAOFactory.getDAOFactory(DAOFactory.ORACLE);
        auditRepository = (AuditRepository)factory.getMiscDAO(
            ObjectTypes.Audit.getValue());
    }

    @Override
    public void run ()
    {

        while (true) {
            try {
                this.process(auditTasks.take());

                if (logger.isDebugEnabled()) {
                    logger.debug("Audit Tasks got processed");
                    logger.debug("Items left in the queue : {}", auditTasks.size());
                }
            }
            catch (InterruptedException e) {
                logger.warn("Exception occured : {}", e.getMessage(), e);
            }
        }

    }

    private void process (AuditTask auditTask)
    {
        try {

            if (logger.isDebugEnabled()) {
                logger.debug(
                    "logAudit Started. Data [tenantId: {}, OperationId: {}, OperationName: {}, Comment: {}]",
                    auditTask.getTenantId(),
                    auditTask.getOperation().getOperationId(),
                    auditTask.getOperation().getOperationName(),
                    auditTask.getComment());
            }

            auditRepository.save(
                auditTask.getTenantId(),
                auditTask.getOperation(),
                auditTask.getComment());

            if (logger.isDebugEnabled()) {
                logger.debug("logAudit Ended");
            }
        }
        catch (InvalidTypeCodeException | SQLException | UnsupportedEncodingException e) {
            logger.warn(
                "Audit failed for tenantId :  {}, openration : {}, comment : {} Exception : {}",
                auditTask.getTenantId(),
                auditTask.getOperation(),
                auditTask.getComment(),
                e.getMessage(),
                e);
        }
        catch(Exception e) {
            logger.warn(
                "Audit failed for tenantId :  {}, openration : {}, comment : {} Exception : {}",
                auditTask.getTenantId(),
                auditTask.getOperation(),
                auditTask.getComment(),
                e.getMessage(),
                e);
        }
    }

}
