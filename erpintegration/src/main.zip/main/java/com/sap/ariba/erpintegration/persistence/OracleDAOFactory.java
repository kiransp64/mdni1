package com.sap.ariba.erpintegration.persistence;

import com.sap.ariba.erpintegration.persistence.dao.AuditRepository;
import com.sap.ariba.erpintegration.persistence.dao.ConfigRepository;
import com.sap.ariba.erpintegration.persistence.dao.EntityVersionRepository;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAO;
import com.sap.ariba.erpintegration.persistence.dao.GenericDAOStageData;
import com.sap.ariba.erpintegration.persistence.dao.GenericJPADAO;
import com.sap.ariba.erpintegration.persistence.dao.IncoTermsRepository;
import com.sap.ariba.erpintegration.persistence.dao.IntegrationJobLogRepository;
import com.sap.ariba.erpintegration.persistence.dao.PurchaseOrgJPARespository;
import com.sap.ariba.erpintegration.persistence.dao.PurchaseOrgRepository;
import com.sap.ariba.erpintegration.persistence.dao.SchemaRepository;
import com.sap.ariba.erpintegration.persistence.dao.SenderBusinessSystemRepository;
import com.sap.ariba.erpintegration.persistence.dao.SequenceNumberGetter;
import com.sap.ariba.erpintegration.persistence.dao.StageXMLDataRepository;
import com.sap.ariba.erpintegration.persistence.dao.TenantIdGetter;
import com.sap.ariba.erpintegration.persistence.dao.TenantRepository;
import com.sap.ariba.erpintegration.persistence.dao.TypeMapDao;
import com.sap.ariba.erpintegration.persistence.dao.UOMCodeRepository;
import com.sap.ariba.erpintegration.persistence.model.GenericEntity;
import jakarta.annotation.Resource;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * Created by i318483 on 31/05/17.
 */
@Service
@Component("OracleDAOFactory")
public class OracleDAOFactory extends DAOFactory
{
    @Resource(name = "PurchaseOrgRepositoryComponent")
    private PurchaseOrgRepository purchaseOrgRepository;

    @Resource(name = "PurchaseOrgJPARepositoryComponent")
    private PurchaseOrgJPARespository purchaseOrgJPARespository;

    @Resource(name = "TypeMapRepositoryComponent")
    private TypeMapDao typeMapDao;

    @Resource(name = "SequenceNumberGetterComponent")
    private SequenceNumberGetter sequenceNumberGetter;

    @Resource(name = "ConfigRepositoryComponent")
    private ConfigRepository configRepository;

    @Resource(name = "StageXMLDataRepositoryComponent")
    private StageXMLDataRepository stageXMLDataRepository;

    @Resource(name = "IncoTermsRepositoryComponent")
    private IncoTermsRepository incoTermsRepository;

    @Resource(name = "TenantRepositoryComponent")
    private TenantRepository tenantRepository;

    @Resource(name = "SenderBusinessSystemRepositoryComponent")
    private SenderBusinessSystemRepository senderBusinessSystemRepository;

    @Resource(name = "TenantIdGetterComponent")
    private TenantIdGetter tenantIdGetterRepository;

    @Resource(name = "UOMCodeRepositoryComponent")
    private UOMCodeRepository uomCodeRepository;

    @Resource(name = "AuditRepositoryComponent")
    private AuditRepository auditRepository;

    @Resource(name = "SchemaRepositoryComponent")
    private SchemaRepository schemaRepository;

    @Resource(name = "IntegrationJobLogRepositoryComponent")
    private IntegrationJobLogRepository integrationJobLogRepository;

    @Resource(name = "EntityVersionRepositoryComponent")
    private EntityVersionRepository entityVersionRepository;

    @Override
    public GenericDAO<GenericEntity, Long> getDAO (String objectName)
    {
        ObjectTypes objectTypes = ObjectTypes.valueOf(objectName);
        switch (objectTypes) {
        case PurchaseOrg:
            return purchaseOrgRepository;
        case IncoTerms:
            return incoTermsRepository;
        case UOMCode:
            return uomCodeRepository;
        default:
            return null;
        }
    }

    public CrudRepository getMiscDAO (String objectName)
    {
        ObjectTypes objectTypes = ObjectTypes.valueOf(objectName);
        switch (objectTypes) {
        case TypeMap:
            return typeMapDao;
        case SequenceNumberGetter:
            return sequenceNumberGetter;
        case IntegrationConfig:
            return configRepository;
        case Tenant:
            return tenantRepository;
        case SenderBusinessSystem:
            return senderBusinessSystemRepository;
        case TenantIdGetter:
            return tenantIdGetterRepository;
        case Audit:
            return auditRepository;
        case Schema:
            return schemaRepository;
        case IntegrationJobLog:
            return integrationJobLogRepository;
        case EntityVersion:
            return entityVersionRepository;
        default:
            return null;
        }
    }

    @Override
    public GenericJPADAO getJPADAO (String objectName)
    {
        ObjectTypes objectTypes = ObjectTypes.valueOf(objectName);
        switch (objectTypes) {
        case PurchaseOrg:
            return purchaseOrgJPARespository;
        default:
            return null;
        }
    }

    public GenericDAOStageData getGenericDAOStageData (String objectName)
    {
        ObjectTypes objectTypes = ObjectTypes.valueOf(objectName);
        switch (objectTypes) {
        case XmlPayload:
            return stageXMLDataRepository;
        default:
            return null;
        }
    }
}
