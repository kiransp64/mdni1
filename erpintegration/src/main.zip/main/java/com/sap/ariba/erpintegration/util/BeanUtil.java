package com.sap.ariba.erpintegration.util;

import com.sap.ariba.erpintegration.ApplicationContextProvider;
import com.sap.ariba.erpintegration.common.metrics.MDNIServiceRegistry;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

/**
 * Bean Util class to extract bean for particular spring component from ApplicationContext
 */
public class BeanUtil {

    private static final Logger logger = LoggerFactory.getLogger(BeanUtil.class);

    public static MDNIServiceRegistry getMdniServiceRegistry() {
        try {
            ApplicationContext applicationContext = ApplicationContextProvider.getApplicationContext();
            if(applicationContext != null)
                return applicationContext.getBean(MDNIServiceRegistry.class);
            else {
                logger.error("[MDNI_CRITICAL] Application Context Provider returned null while fetching application context.");
                return null;
            }
        }
        catch(Exception e) {
            logger.error("[MDNI_CRITICAL] Could not fetch MDNI Service Registry Bean. Exception - {}", 
                    ErrorUtil.getCompleteCausedByErrors(e));
            return null;
        }
    }

    /**
     * Generic method to get the Bean from ApplicationContext
     *
     * @param tClass
     * @param <T>
     * @return Spring Bean
     */
    public static <T> T getBean (Class<T> tClass)
    {
        try {
            return ObjectUtils.isNotEmpty(ApplicationContextProvider.getApplicationContext()) ?
                            ApplicationContextProvider.getApplicationContext().getBean(tClass) :
                            null;
        }
        catch (BeansException e) {
            logger.error("[MDNI_CRITICAL] Could not fetch the Bean from Application Context for given class - {} ,Exception - {}",
                         tClass,
                         ErrorUtil.getCompleteCausedByErrors(e));
        }
        return null;
    }
}
