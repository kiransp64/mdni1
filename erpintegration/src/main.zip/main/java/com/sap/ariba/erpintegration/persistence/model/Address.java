package com.sap.ariba.erpintegration.persistence.model;

import com.sap.ariba.erpintegration.persistence.util.Utility;
import com.sap.ariba.erpintegration.util.CountryCodesMap;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.Serializable;
import java.util.Map;

public class Address extends GenericEntity implements Serializable
{

    public static final String nameOfLogger = "com.sap.ariba.erpintegration.persistence.model.Address";
    public static final Logger logger = LoggerFactory.getLogger(nameOfLogger);

    private static final long serialVersionUID = 1L;
    private static final String objectType = "Address";
    private static final String countryCodeNavigationTag = "PostalAddress.Country";

    private String plantId;

    private static String[] lookupFields = { "PlantID" };

    public String getPlantId ()
    {
        return plantId;
    }

    public void setPlantId (String uniqueName)
    {
        this.plantId = uniqueName;
    }

    @Override
    public void setLookupFields (Map<String, String> lookupDetails)
    {
        Object specialField1 = lookupDetails.get(lookupFields[0]);
        setPlantId((String)specialField1);
    }

    @Override
    public String getObjectType ()
    {
        return objectType;
    }

    @Override
    public void processCountryCode (JSONObject jsonObject)
    {
        String countryCodeValue = (String)Utility.getNestedData(jsonObject,
                                                                countryCodeNavigationTag);
        if (!StringUtils.isEmpty(countryCodeValue)) {
            String aplha2CountryCode = CountryCodesMap.getAplha2CountryCode(countryCodeValue);
            if (!StringUtils.isEmpty(aplha2CountryCode)) {
                logger.debug("Replacing alpha3CountryCode {} with aplpha3CountryCode {} for objectName {}",
                             countryCodeValue,
                             aplha2CountryCode,
                             objectType);
                Utility.setNestedData(jsonObject,
                                      countryCodeNavigationTag,
                                      aplha2CountryCode);
            }
        }
    }
}
