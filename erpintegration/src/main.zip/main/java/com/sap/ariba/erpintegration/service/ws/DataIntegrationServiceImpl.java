package com.sap.ariba.erpintegration.service.ws;

import com.sap.ariba.erpintegration.service.exception.IntegrationServiceException;

import jakarta.jws.WebMethod;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;

/**
 * Created by i318483 on 28/04/17.
 */
public class DataIntegrationServiceImpl implements DataIntegrationService
{
    @WebMethod
    public Response integrateData () throws IntegrationServiceException
    {
        return Response.status(HttpServletResponse.SC_OK).build();
    }
}
