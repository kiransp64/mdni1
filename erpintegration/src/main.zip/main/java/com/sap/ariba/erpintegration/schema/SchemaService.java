package com.sap.ariba.erpintegration.schema;

import java.util.List;

import com.sap.ariba.erpintegration.service.exception.InvalidTenantIdException;

/**
 * This interface is responsible for giving customer schema details.
 * 
 * @author i339952
 */
public interface SchemaService
{
    /**
     * This method will return the list of objects and their last modified time
     * for a tenant
     * 
     * @param tenantId
     * @return
     * @throws InvalidTenantIdException
     */
    public List<SchemaDetail> getAllSchemas (String tenantId)
        throws InvalidTenantIdException;

    /**
     * This method will return the list of objects and their last modified time
     * for a tenant filtered by senderBusinessSystemId
     * 
     * @param tenantId
     * @param senderBusinessSystemId
     * @return
     * @throws InvalidTenantIdException
     */
    public List<SchemaDetail> getAllSchemas (String tenantId,
                                             String senderBusinessSystemId)
        throws InvalidTenantIdException;

    /**
     * This method will return the object definition for a particular tenant and
     * object.
     * 
     * @param tenantId
     * @param Operation
     * @return
     * @throws InvalidTenantIdException
     */
    public String getSchemaDetail (String tenantId, String objectName)
        throws InvalidTenantIdException;

    /**
     * This method will return the the object definition for a particular
     * tenant, object and senderBusinessSystemId.
     * 
     * @param tenantId
     * @param objectName
     * @param senderBusinessSystemId
     * @return
     * @throws InvalidTenantIdException
     */
    public String getSchemaDetail (String tenantId,
                                   String objectName,
                                   String senderBusinessSystemId)
        throws InvalidTenantIdException;

}
