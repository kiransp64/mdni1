package com.sap.ariba.erpintegration.persistence.model;

import java.util.Date;

public class TenantLevelStatus extends  TenantLevel
{
    private String jobState;
    private Date jobTimestamp;
    private float jobPercent;

    public TenantLevelStatus() {

    }
    public TenantLevelStatus(String name, String id, String status, float percentage, Date updatedDate) {
        setName(name);
        setId(id);
        this.jobState = status;
        this.jobPercent = percentage;
        this.jobTimestamp = updatedDate;
    }

    public String getJobState() {
        return jobState;
    }

    public void setJobState(String jobState) {
        this.jobState = jobState;
    }

    public Date getJobTimestamp() {
        return jobTimestamp;
    }

    public void setJobTimestamp(Date jobTimestamp) {
        this.jobTimestamp = jobTimestamp;
    }

    public float getJobPercent() {
        return jobPercent;
    }

    public void setJobPercent(float jobPercent) {
        this.jobPercent = jobPercent;
    }
}
