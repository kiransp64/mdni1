package com.sap.ariba.erpintegration.onemds.entity;

import com.sap.ariba.erpintegration.mdi.common.entity.Entity;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ConditionalEntitiesOrder
{
    private List<Entity> firstOrder = new LinkedList<>();
    private EntityGraph entityGraph;

    public ConditionalEntitiesOrder (EntityGraph entityGraph)
    {
        this.entityGraph = entityGraph;
        Set<Entity> markedEntities = new HashSet<>();
        for (Entity curVertexEntity : entityGraph.getVerticies()) {
            if (!markedEntities.contains(curVertexEntity))
                sort(curVertexEntity, markedEntities);
        }
    }

    private void sort (Entity vertexEntity, Set<Entity> markedEntities)
    {
        markedEntities.add(vertexEntity);
        for (Entity curVertexEntity : this.entityGraph.getVerticiesFrom(vertexEntity)) {
            if (!markedEntities.contains(curVertexEntity)) {
                sort(curVertexEntity, markedEntities);
            }
        }
        firstOrder.add(vertexEntity);
    }

    public List<Entity> getMDIOrder ()
    {
        return new LinkedList<>(firstOrder);
    }

    public List<Entity> getSyncOrder ()
    {
        List<Entity> order = new LinkedList<>();
        if (firstOrder != null && firstOrder.size() > 0) {
            for (int i = firstOrder.size() - 1; i >= 0; i--) {
                order.add(firstOrder.get(i));
            }
        }
        return order;
    }
}
