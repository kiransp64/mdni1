/**
 * Contains classes handling integration one MDS/MDI functionality.
 */
package com.sap.ariba.erpintegration.onemds;