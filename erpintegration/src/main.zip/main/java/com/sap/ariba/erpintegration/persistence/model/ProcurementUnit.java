package com.sap.ariba.erpintegration.persistence.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

/**
 * Created by c5259108 on 04/12/17.
 */

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"uniqueName", "name","logoFileName","level","description","parent"})
public class ProcurementUnit {

    @JsonProperty("UniqueName")
    private String uniqueName;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("LogoFileName")
    private String logoFileName;

    @JsonProperty("Level")
    private String level;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("Parent")
    private String parent;

    public ProcurementUnit() {
    }

    public String getUniqueName() {
        return uniqueName;
    }

    public void setUniqueName(String uniqueName) {
        this.uniqueName = uniqueName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLogoFileName() {
        return logoFileName;
    }

    public void setLogoFileName(String logoFileName) {
        this.logoFileName = logoFileName;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }
}
