package com.ariba.data.cache;

import com.ariba.data.delete.DeleteEntity;
import com.google.gson.JsonObject;

import java.util.*;

public class MDICache {
    private Map<String, JsonObject> instanceResponseMap = new HashMap<>();
    private Map<String, JsonObject> deletedInstanceResponseMap = new HashMap<>();
    private Map<String,DeleteEntity> deleteEntityMap = new HashMap<>();
    private Set<String> deletedEntities = new HashSet<>();

    public Map<String, JsonObject> getDeletedInstanceResponseMap() {
        return deletedInstanceResponseMap;
    }

    public void setDeletedInstanceResponseMap(Map<String, JsonObject> deletedInstanceResponseMap) {
        this.deletedInstanceResponseMap = deletedInstanceResponseMap;
    }

    public Set<String> getDeletedEnties() {
        return deletedEntities;
    }

    public void setDeletedEnties(Set<String> deletedEnties) {
        this.deletedEntities = deletedEnties;
    }

    public Map<String, JsonObject> getInstanceResponseMap() {
        return instanceResponseMap;
    }

    public void setInstanceResponseMap(Map<String, JsonObject> instanceResponseMap) {
        this.instanceResponseMap = instanceResponseMap;
    }

    public Map<String,DeleteEntity> getDeleteEntityMap() {
        return deleteEntityMap;
    }

    public void setDeleteEntityMap(Map<String,DeleteEntity> deleteEntityMap) {
        this.deleteEntityMap = deleteEntityMap;
    }


}
