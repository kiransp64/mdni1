package com.ariba.helpers;

import java.util.HashMap;
import java.util.Map;

import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;

public class ConfigHelper extends BaseHelper {

	HttpRequests httpRequests = new HttpRequests();

	public RestResponse postConfig(String tenantID) throws Exception {

		Map<String, String> headerMap = new HashMap<String, String>();
		OAuthHelper oAuthHelper = new OAuthHelper();
		String token = oAuthHelper.getAccessToken(tenantID);
		
		headerMap.put("Authorization", token);
		headerMap.put("key", "CallbackURL");
		String configURL = TEST_SERVICE_URL + GETCONFIGURL + "?realm=" + tenantID; 
		headerMap.put("value", configURL);

		String URL = BASEURL + PROCESSCONFIGURL + "?tenantId=" + tenantID +"&realm=" + tenantID + "&weight=5.0"; //tenant creation URL
		RestResponse result = httpRequests.httpPost(URL, headerMap, null);
		return result;
	}
}
