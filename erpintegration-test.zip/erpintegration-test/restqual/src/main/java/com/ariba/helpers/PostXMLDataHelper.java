package com.ariba.helpers;

import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;

public class PostXMLDataHelper extends BaseHelper {

	HttpRequests httpRequests = new HttpRequests();

	public RestResponse postIncoTerms(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=Incoterms";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postIncoTerms1(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = "https://mu.ariba.com/mdni/uploadXMLData?tenantId=AN01000706987-T&operation=WBSElementMasterDataReplicationBulkRequest";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}

	public RestResponse postPurchaseGroup(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=PurchasingGroup";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}

	public RestResponse postCompanyCode(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=CompanyCode";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}

	public RestResponse postItemCategory(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=PurchaseDocumentItemCategory";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}

	public RestResponse postWbsElement(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=WBSElement";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}

	public RestResponse postPurchaseOrg(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=PurchasingOrg";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}

	public RestResponse postTaxCode(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=TaxCode";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}

	public RestResponse postCurrencyConversionRate(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=ExchangeRate";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postCostCenter(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=CostCentre";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postAccountCategory(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=AccountAssignmentCategory";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postCurrencyMapping(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=Currency";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postUOMMapping(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=UnitOfMeasurement";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postFixedAsset(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=FixedAsset";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postPaymentTerms(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=PaymentTerms";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postPaymentMethod(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=PaymentMethod";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postPlant(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=Plant";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postPlantPurchasingOrg(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=PlantPurchasingOrg";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postInternalOrder(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=InternalOrder";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postGLAccount(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=GLAccount";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postMaterialGroup(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=MaterialGroup";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postUser(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=User";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postProcurementUnits(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=ProcurementUnit";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse postGroups(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + POSTXMLDATAURL + "?tenantId=" + tenantId + "&objectName=Group";
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse fetchGroups(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + FETCHGROUPS + "?tenantId=" + tenantId;
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	
	public RestResponse fetchProcurementUnits(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + FETCHPROCUREMENTUNITS + "?tenantId=" + tenantId;
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}	
	
	public RestResponse fetchUsers(String tenantId, String xmlString, String username, String password)
			throws Exception {

		String URL = BASEURL + FETCHUSERS + "?tenantId=" + tenantId;
		String header = getEncodedString(username, password);
		RestResponse result = httpRequests.httpPost(URL, header, xmlString);
		return result;

	}
	

}
