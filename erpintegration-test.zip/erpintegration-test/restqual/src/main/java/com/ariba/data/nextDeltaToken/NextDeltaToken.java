package com.ariba.data.nextDeltaToken;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NextDeltaToken {

    @SerializedName("nextDeltaTokenCostCenter")
    @Expose
    private String nextDeltaTokenCostCenter;
    @SerializedName("nextDeltaTokenCompanyCode")
    @Expose
    private String nextDeltaTokenCompanyCode;
    @SerializedName("nextDeltaTokenProduct")
    @Expose
    private String nextDeltaTokenProduct;

    public String getNextDeltaTokenExchangeRate() {
        return nextDeltaTokenExchangeRate;
    }

    public void setNextDeltaTokenExchangeRate(String nextDeltaTokenExchangeRate) {
        this.nextDeltaTokenExchangeRate = nextDeltaTokenExchangeRate;
    }

    @SerializedName("nextDeltaTokenExchangeRate")
    @Expose
    private String nextDeltaTokenExchangeRate;
    public String getNextDeltaTokenCostCenter() {
        return nextDeltaTokenCostCenter;
    }

    public void setNextDeltaTokenCostCenter(String nextDeltaTokenCostCenter) {
        this.nextDeltaTokenCostCenter = nextDeltaTokenCostCenter;
    }

    public String getNextDeltaTokenCompanyCode() {
        return nextDeltaTokenCompanyCode;
    }

    public void setNextDeltaTokenCompanyCode(String nextDeltaTokenCompanyCode) {
        this.nextDeltaTokenCompanyCode = nextDeltaTokenCompanyCode;
    }

    public String getNextDeltaTokenProduct() {
        return nextDeltaTokenProduct;
    }

    public void setNextDeltaTokenProduct(String nextDeltaTokenProduct) {
        this.nextDeltaTokenProduct = nextDeltaTokenProduct;
    }

}