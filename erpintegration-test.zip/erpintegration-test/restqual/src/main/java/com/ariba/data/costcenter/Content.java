
package com.ariba.data.costcenter;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Content {

    @SerializedName("isBlockedForPrimaryPosting")
    @Expose
    private Boolean isBlockedForPrimaryPosting;
    @SerializedName("isBlockedForSecondaryPosting")
    @Expose
    private Boolean isBlockedForSecondaryPosting;
    @SerializedName("name")
    @Expose
    private List<Name> name = null;

    public Boolean getIsBlockedForPrimaryPosting() {
        return isBlockedForPrimaryPosting;
    }

    public void setIsBlockedForPrimaryPosting(Boolean isBlockedForPrimaryPosting) {
        this.isBlockedForPrimaryPosting = isBlockedForPrimaryPosting;
    }

    public Boolean getIsBlockedForSecondaryPosting() {
        return isBlockedForSecondaryPosting;
    }

    public void setIsBlockedForSecondaryPosting(Boolean isBlockedForSecondaryPosting) {
        this.isBlockedForSecondaryPosting = isBlockedForSecondaryPosting;
    }

    public List<Name> getName() {
        return name;
    }

    public void setName(List<Name> name) {
        this.name = name;
    }

}
