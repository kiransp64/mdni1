package com.ariba.helpers;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class XmlHelper {
    DocumentBuilderFactory dbf;
    DocumentBuilder db;
    Document doc;
    public String getValue(String xml, String path) throws ParserConfigurationException, XPathExpressionException, IOException, SAXException {
        dbf = DocumentBuilderFactory.newInstance();
        db = dbf.newDocumentBuilder();
        doc = db.parse(new ByteArrayInputStream(xml.getBytes()));
        doc.getDocumentElement().normalize();

        //Get XPath
        XPathFactory xpf = XPathFactory.newInstance();
        XPath xpath = xpf.newXPath();

        //Get first match
        String value = (String) xpath.evaluate(path, doc, XPathConstants.STRING);
        return value;
    }

    // Generic method implementation is pending

    public void getAllValues(String xml, String path) throws ParserConfigurationException, XPathExpressionException, IOException, SAXException {
        dbf = DocumentBuilderFactory.newInstance();
        db = dbf.newDocumentBuilder();
        doc = db.parse(new ByteArrayInputStream(xml.getBytes()));
        doc.getDocumentElement().normalize();

        //Get XPath
        XPathFactory xpf = XPathFactory.newInstance();
        XPath xpath = xpf.newXPath();

        //Get all matches
        NodeList nodes = (NodeList) xpath.evaluate("/employees/employee/@id", doc, XPathConstants.NODESET);

        for (int i = 0; i < nodes.getLength(); i++) {
            System.out.println(nodes.item(i).getNodeValue());   //1 2
        }
    }
}
