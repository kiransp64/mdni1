package com.ariba.services;

import com.github.dzieciou.testing.curl.CurlLoggingRestAssuredConfigFactory;
import com.google.gson.JsonObject;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static com.ariba.helpers.BaseHelper.*;

public class OAuth {


    public static String generateToken(String system, String realm, String anid){
        RestAssuredConfig config = CurlLoggingRestAssuredConfigFactory.createConfig();
        JsonObject jsonObject=new JsonObject();
        jsonObject.addProperty("requestOrigin",system);
        jsonObject.addProperty("realmId",realm);
        jsonObject.addProperty("anId",anid);
        jsonObject.addProperty("system",system);
        RestAssured.baseURI=OAUTH_URL;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization","Basic ZWZvcm1zLWNsaWVudDpwcml2YXRlZWZvcm1zMQ==");
        requestSpecification.header("Content-Type","application/x-www-form-urlencoded");
        requestSpecification.config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded",
                ContentType.URLENC))).
                param("scope", "eforms")
                .param("uniq_attr1", "PasswordAdapter1")
                .param("user_name", "arooney")
                .param("uniq_attr2", realm)
                .param("custom_attributes", jsonObject.toString());
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        System.out.println(response.getStatusCode());
        response.prettyPrint();
        return  response.jsonPath().getString("access_token");
    }
    public static String generateToken(String requestOrigin,String system, String realm, String anid){
        RestAssuredConfig config = CurlLoggingRestAssuredConfigFactory.createConfig();
        JsonObject jsonObject=new JsonObject();
        jsonObject.addProperty("requestOrigin",requestOrigin);
        jsonObject.addProperty("realmId",realm);
        jsonObject.addProperty("anId",anid);
        jsonObject.addProperty("system",system);
        RestAssured.baseURI=OAUTH_URL;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization","Basic ZWZvcm1zLWNsaWVudDpwcml2YXRlZWZvcm1zMQ==");
        requestSpecification.header("Content-Type","application/x-www-form-urlencoded");
        requestSpecification.config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded",
                ContentType.URLENC))).
                param("scope", "eforms")
                .param("uniq_attr1", "PasswordAdapter1")
                .param("user_name", "arooney")
                .param("uniq_attr2", realm)
                .param("custom_attributes", jsonObject.toString());
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        System.out.println(response.getStatusCode());
        response.prettyPrint();
        return  response.jsonPath().getString("access_token");
    }
}
