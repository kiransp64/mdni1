package com.ariba.helpers;

import java.util.HashMap;
import java.util.Map;

import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;

public class MDSSearchHelper extends BaseHelper {

	HttpRequests httpRequests = new HttpRequests();

	public RestResponse enablehanasearch(String token) throws Exception {

		String header = "bearer " + token;

		String URL = SEARCHBASEURL + "/enablehanasearch";
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;
	}

	public RestResponse disablehanasearch(String token) throws Exception {

		String header = "bearer " + token;

		String URL = SEARCHBASEURL + "/disablehanasearch";
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;
	}

	public RestResponse getEntity(String token, String entity) throws Exception {

		String header = "bearer " + token;

		String URL = SEARCHBASEURL + "/data/list/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;
	}
	
	public RestResponse getEntity(String token, String entity, String tenant, String system, String anid, String user) throws Exception {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "bearer " + token);
		headers.put("X-Tenant", tenant);
		headers.put("X-System", system);
		headers.put("X-AnId", anid);
		headers.put("X-RealUsername", user);

		String URL = SEARCHBASEURL + "/data/list/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, headers);
		return result;
	}
	
	public RestResponse getEntities(String token) throws Exception {

		String header = "bearer " + token;
		String URL = SEARCHBASEURL + "/data/entities";
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;
	}

	public RestResponse getEntityByUniqueName(String token, String entity) throws Exception {

		String header = "bearer " + token;

		String URL = SEARCHBASEURL + "/data/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;
	}
	
	public RestResponse getEntityByUniqueName(String token, String entity, String tenant, String system, String anid, String user) throws Exception {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "bearer " + token);
		headers.put("X-Tenant", tenant);
		headers.put("X-System", system);
		headers.put("X-AnId", anid);
		headers.put("X-RealUsername", user);

		String URL = SEARCHBASEURL + "/data/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, headers);
		return result;
	}

	public RestResponse getMetaInfo(String token, String entity) throws Exception {

		String header = "bearer " + token;

		String URL = SEARCHBASEURL + "/data/metainfo/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;

	}
	
	public RestResponse getMetaInfo(String token, String entity, String tenant, String system, String anid, String user) throws Exception {
		
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "bearer " + token);
		headers.put("X-Tenant", tenant);
		headers.put("X-System", system);
		headers.put("X-AnId", anid);
		headers.put("X-RealUsername", user);

		String URL = SEARCHBASEURL + "/data/metainfo/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, headers);
		return result;

	}
	
	public RestResponse searchEntity(String token, String entity, String tenant, String system, String anid, String user) throws Exception {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "bearer " + token);
		headers.put("X-Tenant", tenant);
		headers.put("X-System", system);
		headers.put("X-AnId", anid);
		headers.put("X-RealUsername", user);

		String URL = SEARCHBASEURL + "/search/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, headers);
		return result;

	}
	
	public RestResponse searchEntity(String token, String entity) throws Exception {

		String header = "bearer " + token;

		String URL = SEARCHBASEURL + "/search/" + entity;
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;
	}
	
	public RestResponse searchOpenAPIEntity(String token, String realmName, String entity) throws Exception {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put(Constants.HEADER_AUTHORIZATION, "bearer " + token);
		headers.put(Constants.HEADER_ACCEPT_LANG, "en");
		headers.put(Constants.HEADER_REALM, realmName);
		
		entity = entity.replaceAll(" ", "%20");
		String URL = SEARCHBASEURL + Constants.OPENAPI_SEARCH + entity;
		RestResponse result = httpRequests.httpGet(URL, null, headers);
		return result;
	}
	
	public RestResponse searchOpenAPIMeta(String token, String realmName, String entity) throws Exception {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put(Constants.HEADER_AUTHORIZATION, "bearer " + token);
		headers.put(Constants.HEADER_ACCEPT_LANG, "en");
		headers.put(Constants.HEADER_REALM, realmName);
		
		entity = entity.replaceAll(" ", "%20");
		String URL = SEARCHBASEURL + Constants.OPENAPI_META+ entity;
		RestResponse result = httpRequests.httpGet(URL, null, headers);
		return result;
	}
	
	public RestResponse searchEntityWithSearchURL(String token, String filterURL, String SearchBaseURL) throws Exception {

		String header = "bearer " + token;

		String URL = SearchBaseURL + "/search/" + filterURL;
		RestResponse result = httpRequests.httpGet(URL, null, header);
		return result;
	}
	
	public RestResponse searchEntityWithsenderBusinessId(String token, String filterURL, String SearchBaseURL, String SenderSystemIdValue) throws Exception {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "bearer " + token);
		headers.put("x-senderBusinessId", SenderSystemIdValue);


		String URL = SearchBaseURL + "/search/" + filterURL;
		RestResponse result = httpRequests.httpGet(URL, null, headers);
		return result;

	}
	
}
