package com.ariba.helpers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.paukov.combinatorics3.Generator;

import java.util.List;
import java.util.Stack;


public class CombinationGenerator {
    private static Logger logger = LogManager.getLogger(CombinationGenerator.class);

    private static Stack stack = new Stack();

    private static void createStack(List<String> fromTo) {
        stack.push(fromTo.get(0) + "_" + fromTo.get(1));
    }

    private static void createCombinations(String arr[]) {
        Generator.combination(arr)
                .simple(2)
                .stream()
                .forEach(combination -> Generator.permutation(combination)
                        .simple()
                        .forEach(p -> createStack(p)));
    }

    public static Stack getCombinations(String[] arr) {
        createCombinations(arr);
        logger.info("Created currency combination : "+stack.toString());
        return stack;
    }
}
