
package com.ariba.data.costcenter;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LocalId {

    @SerializedName("context")
    @Expose
    private Context context;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("localId")
    @Expose
    private String localId;

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLocalId() {
        return localId;
    }

    public void setLocalId(String localId) {
        this.localId = localId;
    }

}
