package com.ariba.pojos;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class IncoTerm {
	@SerializedName("Code")
	private String Code;

	@SerializedName("LocationMandatoryIndicator")
	private String LocationMandatoryIndicator;

	@SerializedName("Description")
	private List<Language> Description;

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}

	public String getLocationMandatoryIndicator() {
		return LocationMandatoryIndicator;
	}

	public void setLocationMandatoryIndicator(String locationMandatoryIndicator) {
		LocationMandatoryIndicator = locationMandatoryIndicator;
	}

	public List<Language> getDescription() {
		return Description;
	}

	public void setDescription(List<Language> description) {
		Description = description;
	}

	@Override
	public String toString() {
		return "IncoTerm [Code=" + Code + ", LocationMandatoryIndicator=" + LocationMandatoryIndicator
				+ ", Description=" + Description + "]";
	}
}