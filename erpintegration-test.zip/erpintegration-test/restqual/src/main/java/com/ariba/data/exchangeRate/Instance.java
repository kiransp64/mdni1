
package com.ariba.data.exchangeRate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Instance {


    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("exchangeRate")
    @Expose
    private Double rate;
    @SerializedName("fromCurrency")
    @Expose
    private FromCurrency fromCurrency;
    @SerializedName("toCurrency")
    @Expose
    private ToCurrency toCurrency;
    @SerializedName("effectiveDate")
    @Expose
    private String validFrom;

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public FromCurrency getFromCurrency() {
        return fromCurrency;
    }

    public void setFromCurrency(FromCurrency fromCurrency) {
        this.fromCurrency = fromCurrency;
    }

    public ToCurrency getToCurrency() {
        return toCurrency;
    }

    public void setToCurrency(ToCurrency toCurrency) {
        this.toCurrency = toCurrency;
    }

    public String getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(String validFrom) {
        this.validFrom = validFrom;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
