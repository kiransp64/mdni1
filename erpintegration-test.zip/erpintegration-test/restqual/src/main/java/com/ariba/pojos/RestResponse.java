package com.ariba.pojos;

public final class RestResponse {
	
    public String content;
	
    public int code;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
	
}
