 package com.ariba.helpers;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ariba.services.MDS;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import io.restassured.response.Response;
import org.apache.http.HttpHeaders;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;

public class SCIMHelper extends BaseHelper {

	HttpRequests httpRequests = new HttpRequests();

	public RestResponse postUsers(String token, String payload, String anid) throws Exception {

		String URL = SCIM_URL + Constants.URL_USERS;
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpPost(URL, headerMap, null, payload);
		return result;

	}
	
	public RestResponse ecryptionMDNIPost(String token, String payload, String encryptionAPI) throws Exception {
		
		//Calling Re-Encryption MDNI Request
		String URL = "https://qa.cobalt.ariba.com/mdnilsp/erpintegration/main/encryptionmanagement/v1/"+encryptionAPI;
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, "application/json");
		headerMap.put(HttpHeaders.ACCEPT, "*/*");
		//headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "Bearer " + token);

		RestResponse result = httpRequests.httpPost(URL, headerMap, null, payload);
		return result;

	}
	
	
	public RestResponse ecryptionMDNIPut(String token, String payload, String encryptionAPI) throws Exception {
		
		//Calling Re-Encryption MDNI Request
		String URL = "https://qa.cobalt.ariba.com/mdnilsp/erpintegration/main/encryptionmanagement/v1/"+encryptionAPI;
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, "application/json");
		headerMap.put(HttpHeaders.ACCEPT, "*/*");
		//headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "Bearer " + token);

		RestResponse result = httpRequests.httpPut(URL, headerMap, null, payload);
		return result;

	}

	public RestResponse updateUsers(String token, String payload, String anid, String username) throws Exception {

		String URL = SCIM_URL + Constants.URL_USERS + Constants.URL_SEPARATOR + username;
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpPut(URL, headerMap, null, payload);
		return result;

	}

	public RestResponse getUsersByUserName(String token, String anid, String username, String filter) throws Exception {

		String URL = SCIM_URL + Constants.URL_USERS + Constants.URL_SEPARATOR + URLEncoder.encode(username, "UTF-8").replace("+", "%20");
		if (filter != null) {
			filter = URLEncoder.encode(filter, "UTF-8");
			URL = URL + "?$filter=" + filter;
		}
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpGet(URL, null, headerMap);
		return result;

	}
	
	public RestResponse deleteUsers(String token, String anid, String username) throws Exception {

		String URL = SCIM_URL + Constants.URL_USERS + Constants.URL_SEPARATOR + URLEncoder.encode(username, "UTF-8").replace("+", "%20");
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpDelete(URL, headerMap);
		return result;

	}

	public RestResponse getUsers(String token, String anid, String filter, int StartIndex, int count) throws Exception {

		String URL = SCIM_URL + Constants.URL_USERS + "?startIndex=" + StartIndex + "&count=" + count;
		if (filter != null) {
			filter = URLEncoder.encode(filter, "UTF-8");
			URL = URL + "&filter=" + filter;
		}
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpGet(URL, null, headerMap);
		return result;

	}

	public RestResponse postGroups(String token, String payload, String anid) throws Exception {

		String URL = SCIM_URL + Constants.URL_GROUPS;
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpPost(URL, headerMap, null, payload);
		return result;

	}

	public RestResponse updateGroups(String token, String payload, String anid, String groupName) throws Exception {

		String URL = SCIM_URL + Constants.URL_GROUPS + Constants.URL_SEPARATOR + groupName;
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpPut(URL, headerMap, null, payload);
		return result;
	}

	public RestResponse deleteGroups(String token, String anid, String groupName) throws Exception {

		String URL = SCIM_URL + Constants.URL_GROUPS + Constants.URL_SEPARATOR + groupName;
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpDelete(URL, headerMap);
		return result;
	}

	public RestResponse getGroupssByUniqueName(String token, String anid, String uniquename, String filter)
			throws Exception {
		if (uniquename.contains(" "))
			uniquename = uniquename.replaceAll(" ", "%20");
		else
			uniquename = URLEncoder.encode(uniquename, "UTF-8");
		String URL = SCIM_URL + Constants.URL_GROUPS + Constants.URL_SEPARATOR + uniquename;
		if (filter != null) {
			filter = filter.replaceAll(" ", "%20");
			URL = URL + "?filter=" + filter;
		}
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpGet(URL, null, headerMap);
		return result;

	}

	public RestResponse getGroups(String token, String anid, String filter, int StartIndex, int count)
			throws Exception {

		String URL = SCIM_URL + Constants.URL_GROUPS + "?startIndex=" + StartIndex + "&count=" + count;
		if (filter != null) {
			filter = URLEncoder.encode(filter, "UTF-8");
			URL = URL + "&filter=" + filter;
		}
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
		headerMap.put(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
		headerMap.put(Constants.HEADER_ANID, anid);
		if (token != null)
			headerMap.put(Constants.AUTHORIZATION, "bearer " + token);

		RestResponse result = httpRequests.httpGet(URL, null, headerMap);
		return result;

	}

	public JSONObject createUserPayload(Object username, Map<String, Object> name, Object active, Object displayName,
			Object locale, Object timezone, Object supervisor, Map<String, Object> emails, Map<String, Object> phones, Object userUUID) {

		JSONObject user = new JSONObject();
		JSONArray schema = new JSONArray(Constants.USERS_SCHEMAS_LIST);
		user.put(Constants.SCHEMAS, schema);
		if (username != null)
			user.put(Constants.USERNAME, username);
		if (active != null) {
			user.put(Constants.ACTIVE, active);
		}
		if (displayName != null) {
			user.put(Constants.DISPLAYNAME, displayName);
		}
		if (locale != null) {
			user.put(Constants.LOCALE, locale);
		}
		if (timezone != null) {
			user.put(Constants.TIMEZONE, timezone);
		}
		JSONArray names = new JSONArray();
		if (name != null) {
			Set<String> namekeys = name.keySet();
			Iterator<String> itr = namekeys.iterator();
			while (itr.hasNext()) {
				JSONObject namelang = new JSONObject();
				String lang = itr.next();
				namelang.put(Constants.LANGUAGE, lang);
				namelang.put(Constants.DISPLAYNAME, name.get(lang));
				names.put(namelang);
			}
		}
		JSONObject profile = new JSONObject();
		profile.put(Constants.ALTERNATIVE_DISPLAYNAME, names);
//		if(userUUID !=null){
//			profile.put(Constants.USERUUID, userUUID);
//		}
		user.put(Constants.USERS_SCHEMA_PROFILE, profile);

		JSONObject customUser = new JSONObject();
		if(userUUID !=null){
			customUser.put(Constants.USERUUID, userUUID);
		}
		user.put(Constants.USERS_SCHEMA_CUSTOM, customUser);

		JSONObject enterprise = new JSONObject();
		JSONObject manager = new JSONObject();
		if (supervisor != null) {
			manager.put(Constants.VALUE_KEY, supervisor);
			enterprise.put(Constants.MANAGER, manager);
			user.put(Constants.USERS_SCHEMA_ENTERPRISE, enterprise);
		}

		if (emails != null) {
			JSONArray emailaddresses = new JSONArray();
			Set<String> emailkeys = emails.keySet();
			Iterator<String> itr = emailkeys.iterator();
			while (itr.hasNext()) {
				JSONObject email = new JSONObject();
				String type = itr.next();
				email.put(Constants.TYPE, type);
				email.put(Constants.VALUE_KEY, emails.get(type));
				if (type.equalsIgnoreCase(Constants.WORK))
					email.put(Constants.PRIMARY, Boolean.TRUE);
				emailaddresses.put(email);
			}
			user.put(Constants.EMAIL_KEY, emailaddresses);
		}
		if (phones != null) {
			JSONArray phoneNumbers = new JSONArray();
			Set<String> phonekeys = phones.keySet();
			Iterator<String> itr = phonekeys.iterator();
			while (itr.hasNext()) {
				JSONObject phone = new JSONObject();
				String type = itr.next();
				phone.put(Constants.TYPE, type);
				phone.put(Constants.VALUE_KEY, phones.get(type));
				phoneNumbers.put(phone);
			}
			user.put(Constants.PHONES_KEY, phoneNumbers);
		}
		return user;
	}

	public JSONObject createGroupPayload(Object displayName, Map<String, Object> name, List<Object> memberUsers,
			List<Object> memberGroups) {

		JSONObject group = new JSONObject();
		JSONArray schema = new JSONArray(Constants.GROUPS_SCHEMAS_LIST);
		group.put(Constants.SCHEMAS, schema);
		if (displayName != null) {
			group.put(Constants.DISPLAYNAME, displayName);
		}
		JSONArray names = new JSONArray();
		if (name != null) {
			Set<String> namekeys = name.keySet();
			Iterator<String> itr = namekeys.iterator();
			while (itr.hasNext()) {
				JSONObject namelang = new JSONObject();
				String lang = itr.next();
				namelang.put(Constants.LANGUAGE, lang);
				namelang.put(Constants.DISPLAYNAME, name.get(lang));
				names.put(namelang);
			}
			JSONObject profile = new JSONObject();
			profile.put(Constants.ALTERNATIVE_DISPLAYNAME, names);
			group.put(Constants.GROUPS_SCHEMA_PROFILE, profile);
		}

		if (memberUsers != null || memberGroups != null) {
			JSONArray members = new JSONArray();
			if (memberUsers != null) {
				for (int i = 0; i < memberUsers.size(); i++) {
					JSONObject member = new JSONObject();
					member.put(Constants.TYPE, Constants.GROUP_MEMBER_USER);
					member.put(Constants.VALUE_KEY, memberUsers.get(i));
					members.put(member);
				}
			}
			if (memberGroups != null) {
				for (int i = 0; i < memberGroups.size(); i++) {
					JSONObject member = new JSONObject();
					member.put(Constants.TYPE, Constants.GROUP_MEMBER_GROUP);
					member.put(Constants.VALUE_KEY, memberGroups.get(i));
					members.put(member);
				}
			}
			group.put(Constants.MEMBERS, members);
		}
		return group;
	}

	public RestResponse runAQLPull(String accessToken, String system, String query, String anid, String locale)
			throws Exception {

		String URL = APP_URL + system + Constants.URL_SEPARATOR + Constants.AQLPULL;

		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_URLENCODED);
		headerMap.put(Constants.HEADER_AUTHORIZATION, Constants.BEARER + accessToken);

		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		postParameters.add(new BasicNameValuePair(Constants.QUERY_KEY, query));
		postParameters.add(new BasicNameValuePair(Constants.REMOTEREALMANIDMAP, anid + ":0"));
		postParameters.add(new BasicNameValuePair(Constants.ISSSPPULL, Boolean.toString(true)));
		postParameters.add(new BasicNameValuePair(Constants.BUSINESSKEY, Constants.ACM));
		postParameters.add(new BasicNameValuePair(Constants.AUTO_JOIN_TYPE, Constants.LEFT_OUTER));
		if (locale == null)
			locale = Constants.LOCALE_EN_US;
		postParameters.add(new BasicNameValuePair(Constants.LOCALE, locale));

		RestResponse result = httpRequests.httpPost(URL, headerMap, postParameters, null);
		return result;
		
		
	}
	
	public RestResponse runAQLPullwithAppInfo(String accessToken, String system, String query, String anid, String locale, String APPURL)
			throws Exception {

		String URL = APPURL + system + Constants.URL_SEPARATOR + Constants.AQLPULL;

		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_URLENCODED);
		headerMap.put(Constants.HEADER_AUTHORIZATION, Constants.BEARER + accessToken);

		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		postParameters.add(new BasicNameValuePair(Constants.QUERY_KEY, query));
		postParameters.add(new BasicNameValuePair(Constants.REMOTEREALMANIDMAP, anid + ":0"));
		postParameters.add(new BasicNameValuePair(Constants.ISSSPPULL, Boolean.toString(true)));
		postParameters.add(new BasicNameValuePair(Constants.BUSINESSKEY, Constants.ACM));
		postParameters.add(new BasicNameValuePair(Constants.AUTO_JOIN_TYPE, Constants.LEFT_OUTER));
		if (locale == null)
			locale = Constants.LOCALE_EN_US;
		postParameters.add(new BasicNameValuePair(Constants.LOCALE, locale));

		RestResponse result = httpRequests.httpPost(URL, headerMap, postParameters, null);
		return result;
		
		
	}
	
	public JSONArray getResultsAsJson(String keys, String resultSet) throws Exception {

		JSONArray result = new JSONArray();
		keys = keys + Constants.RESULT_COLUMN;
		String[] keysArr = keys.split(",");
		int keysLength = keysArr.length;
		int j = 0;
		JSONObject obj = null;
		if(resultSet.contains("@")||resultSet.contains("Group")) {
			resultSet = resultSet.replaceAll("\"\"", "\",\"");
			resultSet = resultSet.replaceAll("\"", "");
			resultSet = resultSet.replaceAll(",,,", ",,");
			String[] resultArr = resultSet.split(",");

			for (int i = keysLength + 1; i < resultArr.length; i++) {
				if (j == 0) {
					obj = new JSONObject();
				}
				if (j < keysLength) {
					obj.put(keysArr[j], resultArr[i]);
				}
				j++;
				if (j == keysLength) {
					result.put(obj);
					j = 0;
				}
			}
		} else {
			resultSet = resultSet.replaceAll("\"", "");
			resultSet = resultSet.replaceFirst("End AQLPullSystemIdDivider", "End AQLPullSystemIdDivider,");
			String[] resultArr = resultSet.split(",");

			for (int i = keysLength; i < resultArr.length; i++) {
				if (j == 0) {
					obj = new JSONObject();
				}
				if (j < keysLength) {
					obj.put(keysArr[j], resultArr[i]);
				}
				j++;
				if (j == keysLength) {
					result.put(obj);
					j = 0;
				}
			}
		}
		return result;
	}

	public String constructQuery(String keys, String entityName, String whereCondition, boolean includeInactive) {

		String query = Constants.SELECT + Constants.SPACE + keys + Constants.SPACE + Constants.FROM + Constants.SPACE
				+ entityName;
		if (includeInactive) {
			query = query + Constants.SPACE + "INCLUDE INACTIVE";
		}
		if (whereCondition != null || whereCondition != "") {
			query = query + Constants.SPACE + Constants.WHERE + Constants.SPACE + whereCondition;
		}
		return query;
	}

	public JSONArray comparePayloads(Map<String, String> scimMap, Map<String, String> hanaMap,
			Map<String, String> buyerMap) {
		JSONArray issues = new JSONArray();
		Set<String> keys = scimMap.keySet();
		if (hanaMap != null) {
			Iterator<String> itr = keys.iterator();
			while (itr.hasNext()) {
				String key = itr.next();
				if (!scimMap.get(key).equalsIgnoreCase(hanaMap.get(key))) {
					JSONObject issue = new JSONObject();
					issue.put(key + "_HANA", "Payload and HANA values are not matching for " + key
							+ ". Payload value = " + scimMap.get(key) + " and Hana value = " + hanaMap.get(key));
					issues.put(issue);
				}
			}
		}
		if (buyerMap != null) {
			Iterator<String> itr = keys.iterator();
			while (itr.hasNext()) {
				String key = itr.next();
				if (!scimMap.get(key).equalsIgnoreCase(buyerMap.get(key))) {
					JSONObject issue = new JSONObject();
					issue.put(key + "_Buyer", "Payload and Buyer values are not matching for " + key
							+ ". Payload value = " + scimMap.get(key) + " and Hana value = " + buyerMap.get(key));
					issues.put(issue);
				}
			}
		}
		return issues;
	}
	protected JSONArray comparePayloadsForUser(JSONObject userPayload, JSONObject hanaUser, JSONObject buyerUser,
											   String locale) {
		JSONArray issues = new JSONArray();
		Map<String, String> payloadMap = new HashMap<String, String>();
		payloadMap.put("UniqueName", "");
		payloadMap.put("Name", "");
		payloadMap.put("Active", "");
		payloadMap.put("Locale", "");
		payloadMap.put("TimeZone", "");
		payloadMap.put("Supervisor", "");
		payloadMap.put("Email", "");
		payloadMap.put("Phone", "");
		payloadMap.put("Fax", "");
		payloadMap.put("UserUUID", "");

		String id = userPayload.getString(Constants.ID);
		payloadMap.put("UniqueName", userPayload.getString(Constants.ID));

		String payloadUsername = userPayload.getString(Constants.USERNAME);
		boolean payloadActive = userPayload.getBoolean(Constants.ACTIVE);
		payloadMap.put("Locale", userPayload.getBoolean(Constants.ACTIVE) + "");
		String payloadName = "";
		if (locale == Constants.LANG_EN) {
			payloadName = userPayload.getString(Constants.DISPLAYNAME);
			payloadMap.put("Name", userPayload.getString(Constants.DISPLAYNAME));
		} else {
			JSONArray names = userPayload.getJSONObject(Constants.USERS_SCHEMA_PROFILE)
					.getJSONArray(Constants.ALTERNATIVE_DISPLAYNAME);
			for (int i = 0; i < names.length(); i++) {
				JSONObject name = names.getJSONObject(i);
				if (name.getString(Constants.LANGUAGE).equalsIgnoreCase(locale) && name.has(Constants.DISPLAYNAME)) {
					payloadName = name.getString(Constants.DISPLAYNAME);
					payloadMap.put("Name", name.getString(Constants.DISPLAYNAME));
				}
			}
		}

		String payloadLocale = "";
		if (userPayload.has(Constants.LOCALE)) {
			payloadLocale = userPayload.getString(Constants.LOCALE);
			payloadMap.put("Locale", userPayload.getString(Constants.LOCALE));
		}
		String payloadTimeZone = "";
		if (userPayload.has(Constants.TIMEZONE)) {
			payloadTimeZone = userPayload.getString(Constants.TIMEZONE);
			payloadMap.put("TimeZone", userPayload.getString(Constants.TIMEZONE));
		}
		String payloadSupervisor = "";
		if (userPayload.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE).has(Constants.MANAGER)) {

			payloadSupervisor = userPayload.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE)
					.getJSONObject(Constants.MANAGER).getString(Constants.VALUE_KEY);
			payloadMap.put("Supervisor", userPayload.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE)
					.getJSONObject(Constants.MANAGER).getString(Constants.VALUE_KEY));
		}
		String payloadEmail = "";
		if (userPayload.has(Constants.EMAIL_KEY)) {
			JSONArray emails = userPayload.getJSONArray(Constants.EMAIL_KEY);
			for (int i = 0; i < emails.length(); i++) {
				JSONObject email = emails.getJSONObject(i);
				if (email.getBoolean(Constants.PRIMARY) && email.has(Constants.VALUE_KEY)) {
					payloadEmail = email.getString(Constants.VALUE_KEY);
					payloadMap.put("Email", email.getString(Constants.VALUE_KEY));
				}
			}
		}
		String payloadPhone = "";
		String payloadFax = "";
		if (userPayload.has(Constants.PHONES_KEY)) {
			JSONArray phones = userPayload.getJSONArray(Constants.PHONES_KEY);
			for (int i = 0; i < phones.length(); i++) {
				JSONObject phone = phones.getJSONObject(i);
				if (phone.getString(Constants.TYPE).equalsIgnoreCase(Constants.WORK)
						&& phone.has(Constants.VALUE_KEY)) {
					payloadPhone = phone.getString(Constants.VALUE_KEY);
					payloadMap.put("Phone", phone.getString(Constants.VALUE_KEY));
				}
				if (phone.getString(Constants.TYPE).equalsIgnoreCase(Constants.FAX) && phone.has(Constants.VALUE_KEY)) {
					payloadFax = phone.getString(Constants.VALUE_KEY);
					payloadMap.put("Fax", phone.getString(Constants.VALUE_KEY));
				}
			}
		}
		String payloadUserUUID = "";
		if (userPayload.getJSONObject(Constants.USERS_SCHEMA_CUSTOM).has(Constants.USERUUID)) {
			payloadUserUUID = userPayload.getJSONObject(Constants.USERS_SCHEMA_CUSTOM).getString(Constants.USERUUID);
			payloadMap.put("UserUUID", payloadUserUUID);
		}

		// HANA comparisons if user from HANA is not null
		Map<String, String> hanaMap = null;
		if (hanaUser != null) {
			hanaMap = new HashMap<String, String>();
			hanaMap.put("UniqueName", "");
			hanaMap.put("Name", "");
			hanaMap.put("Active", "");
			hanaMap.put("Locale", "");
			hanaMap.put("TimeZone", "");
			hanaMap.put("Supervisor", "");
			hanaMap.put("Email", "");
			hanaMap.put("Phone", "");
			hanaMap.put("Fax", "");
			hanaMap.put("UserUUID", "");

			String hanaUsername = hanaUser.getString(Constants.HANA_USER_UNIQUENAME);
			hanaMap.put("UniqueName", hanaUser.getString(Constants.HANA_USER_UNIQUENAME));
			boolean hanaActive = Boolean.parseBoolean(hanaUser.getString(Constants.HANA_BASE_ACTIVE));
			hanaMap.put("Active", hanaUser.getString(Constants.HANA_BASE_ACTIVE));
			String hanaName = hanaUser.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.NAME);
			hanaMap.put("Name", hanaUser.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.NAME));
			String hanaNameLocale = hanaUser.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.HANA_LANG_LANG);
			String hanaLocale = "";
			if (hanaUser.has(Constants.HANA_LOCALE_KEY)) {
				hanaLocale = hanaUser.getString(Constants.HANA_LOCALE_KEY);
				hanaMap.put("Locale", hanaUser.getString(Constants.HANA_LOCALE_KEY));
			}
			String hanaTimeZone = "";
			if (hanaUser.has(Constants.HANA_TIMEZONE_KEY)) {
				hanaTimeZone = hanaUser.getString(Constants.HANA_TIMEZONE_KEY);
				hanaMap.put("TimeZone", hanaUser.getString(Constants.HANA_TIMEZONE_KEY));
			}
			String hanaSupervisor = "";
			if (hanaUser.has(Constants.HANA_SUPERVISOR_UNIQUENAME)) {
				hanaSupervisor = hanaUser.getString(Constants.HANA_SUPERVISOR_UNIQUENAME);
				hanaMap.put("Supervisor", hanaUser.getString(Constants.HANA_SUPERVISOR_UNIQUENAME));
			}
			String hanaEmail = "";
			if (hanaUser.has(Constants.HANA_EMAIL_KEY)) {
				hanaEmail = hanaUser.getString(Constants.HANA_EMAIL_KEY);
				hanaMap.put("Email", hanaUser.getString(Constants.HANA_EMAIL_KEY));
			}
			String hanaPhone = "";
			if (hanaUser.has(Constants.HANA_PHONE)) {
				hanaPhone = hanaUser.getString(Constants.HANA_PHONE);
				hanaMap.put("Phone", hanaUser.getString(Constants.HANA_PHONE));
			}
			String hanaFax = "";
			if (hanaUser.has(Constants.HANA_FAX)) {
				hanaFax = hanaUser.getString(Constants.HANA_FAX);
				hanaMap.put("Fax", hanaUser.getString(Constants.HANA_FAX));
			}
			String hanaUserUUID = "";
			if (hanaUser.has(Constants.HANA_USERUUID)) {
				hanaUserUUID = hanaUser.getString(Constants.HANA_USERUUID);
				hanaMap.put("UserUUID", hanaUserUUID);
			}

			if (!id.equalsIgnoreCase(hanaUsername)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.ID + "_HANA", "Payload id is not matching with HANA uniquename. Payload id=" + id
						+ " AND HANA username=" + hanaUsername);
				issues.put(issue);
			}
			if (!payloadUsername.equalsIgnoreCase(hanaUsername)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.USERNAME + "_HANA",
						"Payload Uniquename is not matching with HANA uniquename. Payload uniqueName=" + payloadUsername
								+ " AND HANA uniqueName=" + hanaUsername);
				issues.put(issue);
			}
			if (payloadActive != hanaActive) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.ACTIVE + "_HANA", "Payload active is not matching with HANA active. Payload active="
						+ payloadActive + " AND HANA active=" + hanaActive);
				issues.put(issue);
			}
			if (!payloadName.equalsIgnoreCase(hanaName)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.DISPLAYNAME + "_HANA", "Payload name is not matching with HANA name. Payload name="
						+ payloadName + " AND HANA name=" + hanaName);
				issues.put(issue);
			}
			if (!locale.equalsIgnoreCase(hanaNameLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LANGUAGE + "_HANA",
						"Payload nameLocale is not matching with HANA nameLocale. Payload nameLocale=" + locale
								+ " AND HANA nameLocale=" + hanaNameLocale);
				issues.put(issue);
			}
			if (!payloadLocale.equalsIgnoreCase(hanaLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LOCALE + "_HANA", "Payload locale is not matching with HANA locale. Payload Locale="
						+ payloadLocale + " AND HANA Locale=" + hanaLocale);
				issues.put(issue);
			}
			if (!payloadTimeZone.equalsIgnoreCase(hanaTimeZone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_HANA",
						"Payload timezone is not matching with HANA timezone. Payload TimeZone=" + payloadTimeZone
								+ " AND HANA TimeZone=" + hanaTimeZone);
				issues.put(issue);
			}
			if (!payloadSupervisor.equalsIgnoreCase(hanaSupervisor)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.MANAGER + "_HANA",
						"Payload Supervisor is not matching with HANA Supervisor. Payload Supervisor="
								+ payloadSupervisor + " AND HANA Supervisor=" + hanaSupervisor);
				issues.put(issue);
			}
			if (!payloadEmail.equalsIgnoreCase(hanaEmail)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.EMAIL_KEY + "_HANA",
						"Payload primary EmailAddress is not matching with HANA EmailAddress. Payload EmailAddress="
								+ payloadEmail + " AND HANA EmailAddress=" + hanaEmail);
				issues.put(issue);
			}
			if (!payloadPhone.equalsIgnoreCase(hanaPhone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.PHONES_KEY + "_HANA",
						"Payload Phone is not matching with HANA Phone. Payload Phone=" + payloadPhone
								+ " AND HANA Phone=" + hanaPhone);
				issues.put(issue);
			}
			if (!payloadFax.equalsIgnoreCase(hanaFax)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.HANA_FAX + "_HANA", "Payload Fax is not matching with HANA Fax. Payload Fax="
						+ payloadFax + " AND HANA Fax=" + hanaFax);
				issues.put(issue);
			}
			if (!payloadUserUUID.equalsIgnoreCase(hanaUserUUID)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.HANA_USERUUID + "_HANA",
						"Payload UserUUID is not matching with HANA UserUUID. Payload UserUuid=" + payloadUserUUID
								+ " AND HANA UserUUID=" + hanaUserUUID);
				issues.put(issue);
			}
		}

		// Buyer comparisons if user from buyer is not null
		Map<String, String> buyerMap = null;
		if (buyerUser != null) {
			buyerMap = new HashMap<String, String>();
			buyerMap.put("UniqueName", "");
			buyerMap.put("Name", "");
			buyerMap.put("Active", Boolean.TRUE + "");
			buyerMap.put("Locale", "");
			buyerMap.put("TimeZone", "");
			buyerMap.put("Supervisor", "");
			buyerMap.put("Email", "");
			buyerMap.put("Phone", "");
			buyerMap.put("Fax", "");
			buyerMap.put("UserUUID", "");

			String buyerUsername = buyerUser.getString(Constants.UNIQUENAME);
			buyerMap.put("UniqueName", buyerUser.getString(Constants.UNIQUENAME));

			String buyerName = buyerUser.getString(Constants.NAME);
			buyerMap.put("Name", buyerUser.getString(Constants.NAME));

			String buyerLocale = buyerUser.getString(Constants.BUYER_LOCALE_KEY);
			buyerMap.put("Locale", buyerUser.getString(Constants.BUYER_LOCALE_KEY));

			String buyerTimeZone = buyerUser.getString(Constants.HANA_TIMEZONE_KEY);
			buyerMap.put("TimeZone", buyerUser.getString(Constants.HANA_TIMEZONE_KEY));

			String buyerSupervisor = buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY);
			buyerMap.put("Supervisor", buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY));

			String buyerEmail = buyerUser.getString(Constants.HANA_EMAIL_KEY);
			buyerMap.put("Email", buyerUser.getString(Constants.HANA_EMAIL_KEY));

			String buyerPhone = buyerUser.getString(Constants.HANA_PHONE);
			buyerMap.put("Phone", buyerUser.getString(Constants.HANA_PHONE));

			String buyerFax = buyerUser.getString(Constants.HANA_FAX);
			buyerMap.put("Fax", buyerUser.getString(Constants.HANA_FAX));

			String buyerUserUUID = buyerUser.getString(Constants.HANA_USERUUID);
			buyerMap.put("UserUUID", buyerUser.getString(Constants.HANA_USERUUID));

			if (!payloadUsername.equalsIgnoreCase(buyerUsername)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.USERNAME + "_" + Constants.APP,
						"Payload Uniquename is not matching with App (Buyer/Sourcing) uniquename. Payload uniqueName="
								+ payloadUsername + " AND Buyer/Sourcing UniqueName=" + buyerUsername);
				issues.put(issue);
			}
			if (!payloadName.equalsIgnoreCase(buyerName)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.DISPLAYNAME + "_" + Constants.APP,
						"Payload name is not matching with App (Buyer/Sourcing) name. Payload name=" + payloadName
								+ " AND Buyer/Sourcing name=" + buyerName);
				issues.put(issue);
			}
			if (!payloadLocale.equalsIgnoreCase(buyerLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LOCALE + "_" + Constants.APP,
						"Payload locale is not matching with App (Buyer/Sourcing) locale. Payload locale="
								+ payloadLocale + " AND Buyer/Sourcing locale=" + buyerLocale);
				issues.put(issue);
			}
			if (!payloadTimeZone.equalsIgnoreCase(buyerTimeZone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload TimeZone is not matching with App (Buyer/Sourcing) TimeZone. Payload TimeZone="
								+ payloadTimeZone + " AND Buyer/Sourcing TimeZone=" + buyerTimeZone);
				issues.put(issue);
			}
			if (!payloadSupervisor.equalsIgnoreCase(buyerSupervisor)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload TimeZone is not matching with App (Buyer/Sourcing) TimeZone. Payload TimeZone="
								+ payloadSupervisor + " AND Buyer/Sourcing TimeZone=" + buyerSupervisor);
				issues.put(issue);
			}
			if (!payloadEmail.equalsIgnoreCase(buyerEmail)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload primary Email is not matching with App (Buyer/Sourcing) Email. Payload Email="
								+ payloadEmail + " AND Buyer/Sourcing Email=" + buyerEmail);
				issues.put(issue);
			}
			if (!payloadPhone.equalsIgnoreCase(buyerPhone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload Phone is not matching with App (Buyer/Sourcing) Phone. Payload Phone=" + payloadPhone
								+ " AND Buyer/Sourcing Phone=" + buyerPhone);
				issues.put(issue);
			}
			if (!payloadFax.equalsIgnoreCase(buyerFax)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload Fax is not matching with App (Buyer/Sourcing)Fax. Payload Fax=" + payloadFax
								+ " AND Buyer/Sourcing Fax=" + buyerFax);
				issues.put(issue);
			}
			if (!payloadUserUUID.equalsIgnoreCase(buyerUserUUID)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.USERUUID + "_" + Constants.APP,
						"Payload UserUUID is not matching with App (Buyer/Sourcing) UserUUID. Payload UserUUID="
								+ payloadUserUUID + " AND Buyer/Sourcing UserUUID=" + buyerUserUUID);
				issues.put(issue);
			}
		}
		return issues;
	}

	protected JSONArray comparePayloadsForGroup(JSONObject groupPayload, JSONObject hanaGroup, JSONArray buyerGroups,
												String locale) {
		JSONArray issues = new JSONArray();
		Map<String, String> payloadMap = new HashMap<String, String>();
		payloadMap.put(Constants.DISPLAYNAME, "");

		String payloadName = "";
		if (locale == Constants.LANG_EN) {
			payloadName = groupPayload.getString(Constants.DISPLAYNAME);
			payloadMap.put(Constants.DISPLAYNAME, groupPayload.getString(Constants.DISPLAYNAME));
		} else {
			JSONArray names = groupPayload.getJSONObject(Constants.GROUPS_SCHEMA_PROFILE)
					.getJSONArray(Constants.ALTERNATIVE_DISPLAYNAME);
			for (int i = 0; i < names.length(); i++) {
				JSONObject name = names.getJSONObject(i);
				if (name.getString(Constants.LANGUAGE).equalsIgnoreCase(locale)) {
					payloadName = name.getString(Constants.DISPLAYNAME);
					payloadMap.put(Constants.DISPLAYNAME, name.getString(Constants.DISPLAYNAME));
				}
			}
		}
		JSONArray members = new JSONArray();
		List<String> users = new ArrayList<String>();
		List<String> groups = new ArrayList<String>();
		List<String> payloadUsers = new ArrayList<String>();
		List<String> payloadGroups = new ArrayList<String>();
		String payloaduserlist = "";
		String payloadgrouplist = "";
		if (groupPayload.has(Constants.MEMBERS)) {
			members = groupPayload.getJSONArray(Constants.MEMBERS);
			for (int i = 0; i < members.length(); i++) {
				if (members.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(Constants.GROUP_MEMBER_USER)
						&& members.getJSONObject(i).has(Constants.VALUE_KEY)) {
					users.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					payloadUsers.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					if (payloaduserlist == "")
						payloaduserlist = payloaduserlist + members.getJSONObject(i).getString(Constants.VALUE_KEY);
					else
						payloaduserlist = payloaduserlist + ","
								+ members.getJSONObject(i).getString(Constants.VALUE_KEY);
				} else if (members.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(
						Constants.GROUP_MEMBER_GROUP) && members.getJSONObject(i).has(Constants.VALUE_KEY)) {
					groups.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					payloadGroups.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					if (payloadgrouplist == "")
						payloadgrouplist = payloadgrouplist + members.getJSONObject(i).getString(Constants.VALUE_KEY);
					else
						payloadgrouplist = payloadgrouplist + ","
								+ members.getJSONObject(i).getString(Constants.VALUE_KEY);
				}
			}
		}
		payloadMap.put(Constants.GROUP_MEMBER_USER, payloaduserlist);
		payloadMap.put(Constants.GROUP_MEMBER_GROUP, payloadgrouplist);

		// HANA comparisons if user from HANA is not null
		if (hanaGroup != null) {
			String hanaUniqueName = hanaGroup.getString(Constants.HANA_GROUP_UNIQUENAME);
			String hanaName = hanaGroup.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.NAME);
			String hanaNameLocale = hanaGroup.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.HANA_LANG_LANG);

			if (locale.equalsIgnoreCase(Constants.LANG_EN)) {
				if (!payloadName.equalsIgnoreCase(hanaUniqueName)) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.USERNAME,
							"Payload displayName is not matching with HANA Uniquename. Payload displayName="
									+ payloadName + " AND HANA Uniquename=" + hanaUniqueName);
					issues.put(issue);
				}
			}
			if (!payloadName.equalsIgnoreCase(hanaName)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.DISPLAYNAME, "Payload name is not matching with HANA name. Payload name="
						+ payloadName + " AND HANA name=" + hanaName);
				issues.put(issue);
			}
			if (!locale.equalsIgnoreCase(hanaNameLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LANGUAGE,
						"Payload nameLocale is not matching with HANA nameLocale. Payload nameLocale=" + locale
								+ " AND HANA nameLocale=" + hanaNameLocale);
				issues.put(issue);
			}
			if (hanaGroup.has(Constants.HANA_USERS_MAP_ASSOCIATION)) {
				JSONArray groupUsers = hanaGroup.getJSONArray(Constants.HANA_USERS_MAP_ASSOCIATION);
				if (users.size() != groupUsers.length()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_USER,
							"Payload group users is not matching with HANA group users. Payload users size = "
									+ users.size() + " HANA users size = " + groupUsers.length());
					issues.put(issue);
				}
				for (int i = 0; i < groupUsers.length(); i++) {
					String hanaGroupUser = groupUsers.getJSONObject(i).getString(Constants.HANA_USER_UNIQUENAME);
					if (users.contains(hanaGroupUser)) {
						users.remove(hanaGroupUser);
					} else {
						JSONObject issue = new JSONObject();
						issue.put(Constants.GROUP_MEMBER_USER + i,
								"Group is having user " + hanaGroupUser + " in HANA, but not in Payload");
						issues.put(issue);
					}
				}
			}
			if (users.size() > 0) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.GROUP_MEMBER_USER + "-1",
						"Payload group users is not matching with HANA group users. Few users in payload are not present in HANA. Such users are "
								+ users);
				issues.put(issue);
			}
			if (hanaGroup.has(Constants.HANA_CHILDGROUP_MAP_ASSOCIATION)) {
				JSONArray hanaChildGroups = hanaGroup.getJSONArray(Constants.HANA_CHILDGROUP_MAP_ASSOCIATION);
				if (groups.size() != hanaChildGroups.length()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_GROUP,
							"Payload group childGroups is not matching with HANA group childGroups. Payload childgroups size = "
									+ groups.size() + " HANA childgroups size = " + hanaChildGroups.length());
					issues.put(issue);
				}
			}
		}

		// Buyer comparisons if user from buyer is not null
		if (buyerGroups != null) {

			List<String> buyerUsers = new ArrayList<String>();
			List<String> buyerChildGroup = new ArrayList<String>();
			for (int i = 0; i < buyerGroups.length(); i++) {
				JSONObject buyerData = buyerGroups.getJSONObject(i);
				if (buyerData.has(Constants.BUYER_GROUP_USER_KEY)) {
					if ((!buyerUsers.contains(buyerData.getString(Constants.BUYER_GROUP_USER_KEY)))
							&& (!buyerData.getString(Constants.BUYER_GROUP_USER_KEY).equalsIgnoreCase("")))
						buyerUsers.add(buyerData.getString(Constants.BUYER_GROUP_USER_KEY));
				}
				if (buyerData.has(Constants.BUYER_GROUP_CHILDGROUPS_KEY)) {
					if ((!buyerChildGroup.contains(buyerData.getString(Constants.BUYER_GROUP_CHILDGROUPS_KEY)))
							&& (!buyerData.getString(Constants.BUYER_GROUP_CHILDGROUPS_KEY).equalsIgnoreCase("")))
						buyerChildGroup.add(buyerData.getString(Constants.BUYER_GROUP_CHILDGROUPS_KEY));
				}
			}
			if (buyerGroups.length() > 0) {
				JSONObject buyerGroup = buyerGroups.getJSONObject(0);
				String buyerUniqueName = buyerGroup.getString(Constants.UNIQUENAME);

				if (!payloadName.equalsIgnoreCase(buyerUniqueName)) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.DISPLAYNAME + "_" + Constants.BUYER,
							"Payload displayName is not matching with Buyer UniqueName. Payload name=" + payloadName
									+ " AND Buyer Uniquename=" + buyerUniqueName);
					issues.put(issue);
				}
				if (payloadUsers.size() != buyerUsers.size()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_USER + "_" + Constants.BUYER,
							"Payload Member users size is not matching with Buyer users size. Payload users size="
									+ payloadUsers.size() + " AND Buyer users size =" + buyerUsers.size());
					issues.put(issue);
				}
				if (payloadGroups.size() != buyerChildGroup.size()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_GROUP + "_" + Constants.BUYER,
							"Payload Member childgroups size is not matching with Buyer childgroups size. Payload childgroups size="
									+ payloadGroups.size() + " AND Buyer childgroups size =" + buyerChildGroup.size());
					issues.put(issue);
				}
			}
		}
		return issues;
	}

	public void enableFeatureSettings(String token, String anid) {
		JsonArray featureArr;
		JsonArray finalArr = new JsonArray();
		JsonObject obj = new JsonObject();
		try {
			MDS mds = new MDS();
			Response response = mds.getFeatureSettings(token);
			featureArr = new JsonParser().parse(response.asString()).getAsJsonArray();
			for (int i = 0; i < featureArr.size(); i++) {
				obj = featureArr.get(i).getAsJsonObject();
				if (obj.get("feature").getAsString().equalsIgnoreCase("SSP_S4_PEER_REALMS_ARE_SEPARATE_TENANTS")) {
					if (!obj.get("enabled").getAsBoolean()) {
						obj.add("enabled", new JsonPrimitive(true));
					}
					String str = obj.get("anIds").getAsJsonArray().toString();
					if (str.contains(anid)) {
						finalArr.add(featureArr.get(i));
					} else {
						JsonArray anidList = obj.get("anIds").getAsJsonArray();
						anidList.add(new JsonPrimitive(anid));
						obj.add("anIds", anidList);
						finalArr.add(obj);
					}
				}else {
					finalArr.add(featureArr.get(i));
				}
			}
			mds.updateFeatureSettings(token, finalArr.toString());
			Thread.sleep(10000);
			mds.getFeatureSettings(token);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
