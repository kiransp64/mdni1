package com.ariba.helpers;

import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;

public class GetDataHelper extends BaseHelper {

	HttpRequests httpRequests = new HttpRequests();

	public RestResponse getDataByObject(String tenantId, String objectName, String minTime, String maxTime,
			String lastRecordId, String oauthToken) throws Exception {

		String URL = BASEURL + GETDATAURL + "?TenantId=" + tenantId + "&ObjectName=" + objectName + "&MinTimeUpdated="
				+ minTime.replace(" ", "%20") + "&MaxTimeUpdated=" + maxTime.replace(" ", "%20");
		if (lastRecordId != null) {
			URL = URL + "&LastRecordId=" + lastRecordId;
		}
		RestResponse restResponse = httpRequests.httpGet(URL, oauthToken);
		return restResponse;
	}

	public RestResponse getDataByObjectTimeUpdated(String tenantId, String objectName, String timeUpdated,
			String oauthToken) throws Exception {

		String URL = BASEURL + GETDATAURL + "?tenantId=" + tenantId + "&ObjectName=" + objectName + "&LastTimeUpdated="
				+ timeUpdated;
		RestResponse restResponse = httpRequests.httpGet(URL, oauthToken);
		return restResponse;

		// Gson gson = new Gson();
		// Post post = gson.fromJson(result, Post.class);
		// return post;
	}

	public RestResponse getStagedDetails(String anid, String uuid) throws Exception {

		String URL = TEST_SERVICE_URL + GETSTAGEDSTATUS + "?anid=" + anid + "&uuid=" + uuid;
		RestResponse restResponse = httpRequests.httpGet(URL, null);
		return restResponse;

	}
	
	public RestResponse getIntegrationJobLog(String tenantId, String objectName, String oauthToken) throws Exception {

		String URL = BASEURL + GETINTEGRATIONJOBLOG + "?tenantId="+tenantId+"&objectName="+objectName;
		RestResponse restResponse = httpRequests.httpGet(URL, oauthToken);
		return restResponse;
	}

}
