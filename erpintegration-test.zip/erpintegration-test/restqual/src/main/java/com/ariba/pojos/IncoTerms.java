package com.ariba.pojos;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class IncoTerms {

	@SerializedName("")
	private List<IncoTerm> incoterms;

	public List<IncoTerm> getIncoterms() {
		return incoterms;
	}

	public void setIncoterms(List<IncoTerm> incoterms) {
		this.incoterms = incoterms;
	}

	@Override
	public String toString() {
		return "IncoTerms [incoterms=" + incoterms + "]";
	}

}