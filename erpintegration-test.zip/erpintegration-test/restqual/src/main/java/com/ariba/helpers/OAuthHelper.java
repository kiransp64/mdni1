package com.ariba.helpers;

import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import io.restassured.RestAssured;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OAuthHelper extends BaseHelper {

	static HttpRequests httpRequests = new HttpRequests();

	public String getAccessToken(String tenantId) throws Exception {

		Map<String, String> headerMap = new HashMap<String, String>();
		String header = getEncodedString(OAUTH_CLIENTID, OAUTH_KEY);
		headerMap.put("Authorization", header);

		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		postParameters.add(new BasicNameValuePair("scope", "erpnativeintgsvc:fetchdata"));
		postParameters.add(new BasicNameValuePair("user_name", tenantId));
		postParameters.add(new BasicNameValuePair("uniq_attr2", tenantId));
		postParameters.add(new BasicNameValuePair("customAttributes", "{\"anId\", \"" + tenantId + "\"}"));

		RestResponse result = httpRequests.httpPost(OAUTH_URL, headerMap, postParameters);
		JSONObject jo = (JSONObject) jsonObject(result.getContent());
		String accessToken = jo.getString("access_token");
		return accessToken;

	}

	public String getAccessToken(String realmName, String username, String anid, String originSystem) throws Exception {

		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Authorization", "Basic ZWZvcm1zLWNsaWVudDpwcml2YXRlZWZvcm1zMQ==");

		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		postParameters.add(new BasicNameValuePair("scope", "eforms"));
		postParameters.add(new BasicNameValuePair("user_name", username));
		postParameters.add(new BasicNameValuePair("uniq_attr1", "PasswordAdapter1"));
		postParameters.add(new BasicNameValuePair("uniq_attr2", realmName));
		String strAttribute = "{\"realmId\" : \"" + realmName + "\",\"system\" : \"" + originSystem + "\",\"anId\" ";
		strAttribute = strAttribute + ": " + anid + "}";
		postParameters.add(new BasicNameValuePair("custom_attributes", strAttribute));
		RestResponse result = httpRequests.httpPost(OAUTH_URL, headerMap, postParameters);
		JSONObject jo = (JSONObject) jsonObject(result.getContent());
		String accessToken = jo.getString("access_token");
		return accessToken;

	}

	public static String get2LOToken_auditService() throws Exception {
        Map<String, String> headerMap = new HashMap<String, String>();
		//client id for realms SYSTEM p2pTeSap accAcwSap of scdev3 buyer host
		headerMap.put("Authorization", "Basic "+ AuditHelper.OAUTH_SECRET);
		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
        postParameters.add(new BasicNameValuePair("grant_type", "openapi_2lo"));

        RestResponse response = httpRequests.httpPost("https://svcgcpmbdev1mobile.lab-us.gcpint.ariba.com/v2/oauth/token?grant_type=openapi_2lo", headerMap, postParameters);
        RestAssured.baseURI="https://svcgcpmbdev1mobile.lab-us.gcpint.ariba.com/v2/oauth/token?grant_type=openapi_2lo";
        JSONObject jo = (JSONObject) jsonObject(response.getContent());
        String accessToken = jo.getString("access_token");
        System.out.println(accessToken);
        return accessToken;
    }
	
	public String getMDNIAccessToken(String realmName, String username, String anid, String originSystem) throws Exception {

		//MDNI Re-Encryption token access
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Authorization", "Basic ZXJwbmF0aXZlaW50Z3N2Yy0ybG8tY2xpZW50OmVycG5hdGl2ZWludGdzdmNwcml2YXRl");

		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		postParameters.add(new BasicNameValuePair("scope", "erpnativeintgsvc:encryptionmanagement"));
		postParameters.add(new BasicNameValuePair("user_name", username));
		postParameters.add(new BasicNameValuePair("uniq_attr1", "PasswordAdapter1"));
		postParameters.add(new BasicNameValuePair("uniq_attr2", realmName));
		String strAttribute = "{\"realmId\" : \"" + realmName + "\",\"system\" : \"" + originSystem + "\",\"anId\" ";
		strAttribute = strAttribute + ": " + anid + "}";
		postParameters.add(new BasicNameValuePair("custom_attributes", strAttribute));
		RestResponse result = httpRequests.httpPost(OAUTH_URL, headerMap, postParameters);
    JSONObject jo = (JSONObject) jsonObject(result.getContent());
		String accessToken = jo.getString("access_token");
		return accessToken;
	}

	public String get2loPrivateAccessToken(String encodedString) throws Exception {

		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Authorization", "Basic " + encodedString);

		RestResponse result = httpRequests.httpPost(OAUTH_URL + "?grant_type=openapi_2lo", headerMap, null);
		JSONObject jo = (JSONObject) jsonObject(result.getContent());
		String accessToken = jo.getString("access_token");
		return accessToken;

	}
}
