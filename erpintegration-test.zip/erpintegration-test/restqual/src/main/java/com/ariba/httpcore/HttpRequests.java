package com.ariba.httpcore;
 
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.security.SecureRandom;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import com.ariba.pojos.RestResponse;
 
public class HttpRequests {
 
       static CloseableHttpClient client;

       public RestResponse httpPost(String url, String header, HttpEntity inputEntity) throws Exception {
    	   
           RestResponse restResponse = new RestResponse();
           HttpClient client = getHttpsClient();
           HttpPost post = new HttpPost(url);
           System.out.println("Request URL: " + url);

           post.setHeader("Authorization", header);
//           @SuppressWarnings("deprecation")
//           HttpEntity entity = new StringEntity(xmlString, HTTP.UTF_8);
           post.setEntity(inputEntity);

           System.err.println("executing request" + post.getRequestLine());
           /*
           * BufferedReader rd1 = new BufferedReader(new
           * InputStreamReader(post.getEntity().getContent()));
           * 
           * StringBuffer result1 = new StringBuffer(); String line1 = ""; while
           * ((line1 = rd1.readLine()) != null) { result1.append(line1); }
           * System.out.println("Request Content for request " +
           * post.getRequestLine() + " is below ---------------------------- : " +
           * result1);
           */
           HttpResponse response = client.execute(post);
           System.out.println("Response Code : " + response.getStatusLine().getStatusCode());

           BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

           StringBuffer result = new StringBuffer();
           String line = "";
           while ((line = rd.readLine()) != null) {
                  result.append(line);
           }
           System.out.println("Response Content : " + result);
           restResponse.setCode(response.getStatusLine().getStatusCode());
           restResponse.setContent(result.toString());
           return restResponse;
    }
       
      
       public RestResponse httpPostWithCert(String url, String header, String xmlString, SSLConnectionSocketFactory sslSf ) throws Exception {
 
              RestResponse restResponse = new RestResponse();
              HttpPost post = new HttpPost(url);
              System.out.println("Request URL: " + url);
 
              client = HttpClients.custom().setSSLSocketFactory(sslSf).build();
              post.setHeader("Authorization", header);
              @SuppressWarnings("deprecation")
              HttpEntity entity = new StringEntity(xmlString, HTTP.UTF_8);
              post.setEntity(entity);
 
              System.err.println("executing request" + post.getRequestLine());
              /*
              * BufferedReader rd1 = new BufferedReader(new
              * InputStreamReader(post.getEntity().getContent()));
              * 
              * StringBuffer result1 = new StringBuffer(); String line1 = ""; while
              * ((line1 = rd1.readLine()) != null) { result1.append(line1); }
              * System.out.println("Request Content for request " +
              * post.getRequestLine() + " is below ---------------------------- : " +
              * result1);
              */
              HttpResponse response = client.execute(post);
              System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
 
              BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
 
              StringBuffer result = new StringBuffer();
              String line = "";
              while ((line = rd.readLine()) != null) {
                     result.append(line);
              }
              System.out.println("Response Content : " + result);
              restResponse.setCode(response.getStatusLine().getStatusCode());
              restResponse.setContent(result.toString());
              return restResponse;
       }

	public static HttpClient getHttpsClient() throws Exception {

		// if (client != null) {
		// return client;
		// }
		SSLContext sslcontext = SSLContext.getInstance("SSL");
		sslcontext.init(null, new X509TrustManager[] { new HttpsTrustManager() }, new SecureRandom());
		SSLConnectionSocketFactory factory = new SSLConnectionSocketFactory(sslcontext,
				SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
		client = HttpClients.custom().setSSLSocketFactory(factory).build();

		return client;
	}

	public RestResponse httpGet(String url, String oauthToken) throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		System.out.println("Request URL : " + url);

		int CONNECTION_TIMEOUT_MS = 60 * 1000; // Timeout in millis.
		RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(CONNECTION_TIMEOUT_MS)
				.setConnectTimeout(CONNECTION_TIMEOUT_MS).setSocketTimeout(CONNECTION_TIMEOUT_MS).build();
		HttpGet getRequest = new HttpGet(url);
		getRequest.setConfig(requestConfig);
		if (oauthToken != null) {
			getRequest.addHeader("accept", "application/json");
			getRequest.setHeader("Authorization", oauthToken);
		}

		HttpResponse response = client.execute(getRequest);

		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = br.readLine()) != null) {
			result.append(line);
		}

		System.out.println("Response Content : " + result);
		restResponse.setCode(response.getStatusLine().getStatusCode());
		restResponse
				.setContent((((result.toString()).replace("\\", "")).replace("\"{\"", "{\"")).replace("\"}\"", "\"}"));
		return restResponse;
	}
	
	public RestResponse httpGet(String url, String oauthToken, String header) throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		System.out.println("Request URL : " + url);
		HttpGet getRequest = new HttpGet(url);
		
		/*
		int CONNECTION_TIMEOUT_MS = 60 * 1000; // Timeout in millis.
		RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(CONNECTION_TIMEOUT_MS)
				.setConnectTimeout(CONNECTION_TIMEOUT_MS).setSocketTimeout(CONNECTION_TIMEOUT_MS).build();
		HttpGet getRequest = new HttpGet(url);
		getRequest.setConfig(requestConfig); */
		getRequest.addHeader("accept", "application/json");
		if (oauthToken != null) {
			getRequest.addHeader("accept", "application/json");
			getRequest.setHeader("Authorization", oauthToken);
		}
		if(header != null)
			getRequest.setHeader("Authorization", header);
		
		HttpResponse response = client.execute(getRequest);

		String content = EntityUtils.toString(response.getEntity(),"UTF-8");
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		
		restResponse.setCode(response.getStatusLine().getStatusCode());
		restResponse.setContent(content);
		return restResponse;
	}
	
	public RestResponse httpGet(String url, String oauthToken, Map<String,String> headers) throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		System.out.println("Request URL : " + url);
		HttpGet getRequest = new HttpGet(url);
		
		/*
		int CONNECTION_TIMEOUT_MS = 60 * 1000; // Timeout in millis.
		RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(CONNECTION_TIMEOUT_MS)
				.setConnectTimeout(CONNECTION_TIMEOUT_MS).setSocketTimeout(CONNECTION_TIMEOUT_MS).build();
		HttpGet getRequest = new HttpGet(url);
		getRequest.setConfig(requestConfig); */
		getRequest.addHeader("accept", "application/json");
		if (oauthToken != null) {
			getRequest.addHeader("accept", "application/json");
			getRequest.setHeader("Authorization", oauthToken);
		}
		if(headers != null){
			for (String header : headers.keySet()) {
				getRequest.setHeader(header, headers.get(header));
			}
		}
		
		HttpResponse response = client.execute(getRequest);

		String content = EntityUtils.toString(response.getEntity(),"UTF-8");
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		
		restResponse.setCode(response.getStatusLine().getStatusCode());
		restResponse.setContent(content);
		return restResponse;
	}
	
	public RestResponse httpPost(String url, String header, String xmlString) throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		HttpPost post = new HttpPost(url);
		System.out.println("Request URL: " + url);

		post.setHeader("Authorization", header);
		@SuppressWarnings("deprecation")
		HttpEntity entity = new StringEntity(xmlString, HTTP.UTF_8);
		post.setEntity(entity);

		System.err.println("executing request" + post.getRequestLine());
		/*
		 * BufferedReader rd1 = new BufferedReader(new
		 * InputStreamReader(post.getEntity().getContent()));
		 * 
		 * StringBuffer result1 = new StringBuffer(); String line1 = ""; while
		 * ((line1 = rd1.readLine()) != null) { result1.append(line1); }
		 * System.out.println("Request Content for request " +
		 * post.getRequestLine() + " is below ---------------------------- : " +
		 * result1);
		 */
		HttpResponse response = client.execute(post);
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());

		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		System.out.println("Response Content : " + result);
		restResponse.setCode(response.getStatusLine().getStatusCode());
		restResponse.setContent(result.toString());
		return restResponse;
	}
	
	public RestResponse httpPost(String url, Map<String, String> headers, List<NameValuePair> postParameters, String payload)
			throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		HttpPost post = new HttpPost(url);
		System.out.println("Request URL: " + url);

		if (headers != null) {
			for (String header : headers.keySet()) {
				post.setHeader(header, headers.get(header));
			}
		}
		if (postParameters != null) {
			post.setEntity(new UrlEncodedFormEntity(postParameters, "UTF-8"));
		}
		if(payload !=null){
			@SuppressWarnings("deprecation")
			HttpEntity entity = new StringEntity(payload, HTTP.UTF_8);
			post.setEntity(entity);
		}
		System.err.println("executing request" + post.getRequestLine());
		HttpResponse response = client.execute(post);
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		restResponse.setCode(response.getStatusLine().getStatusCode());
		restResponse.setContent(result.toString());
		return restResponse;
	}

	public RestResponse httpPost(String url, Map<String, String> headers, List<NameValuePair> postParameters)
			throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		HttpPost post = new HttpPost(url);
		System.out.println("Request URL: " + url);

		if (headers != null) {
			for (String header : headers.keySet()) {
				post.setHeader(header, headers.get(header));
				// post.setHeader("Authorization", header);
			}
			// System.err.println("Header is------------"+header);
		}
		if (postParameters != null) {
			post.setEntity(new UrlEncodedFormEntity(postParameters, "UTF-8"));
		}
		System.err.println("executing request" + post.getRequestLine());
		HttpResponse response = client.execute(post);
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		System.out.println("Response Content : " + result);
		restResponse.setCode(response.getStatusLine().getStatusCode());
		restResponse.setContent(result.toString());
		return restResponse;
	}
	
	public RestResponse httpPut(String url, Map<String, String> headers, List<NameValuePair> postParameters, String payload)
			throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		HttpPut put = new HttpPut(url);
		System.out.println("Request URL: " + url);

		if (headers != null) {
			for (String header : headers.keySet()) {
				put.setHeader(header, headers.get(header));
			}
		}
		if (postParameters != null) {
			put.setEntity(new UrlEncodedFormEntity(postParameters, "UTF-8"));
		}
		if(payload !=null){
			@SuppressWarnings("deprecation")
			HttpEntity entity = new StringEntity(payload, HTTP.UTF_8);
			put.setEntity(entity);
		}
		System.err.println("executing request" + put.getRequestLine());
		HttpResponse response = client.execute(put);
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		restResponse.setCode(response.getStatusLine().getStatusCode());
		restResponse.setContent(result.toString());
		return restResponse;
	}
	
	public RestResponse httpDelete(String url, Map<String, String> headers)
			throws Exception {

		RestResponse restResponse = new RestResponse();
		HttpClient client = getHttpsClient();
		HttpDelete delete = new HttpDelete(url);
		System.out.println("Request URL: " + url);
		if (headers != null) {
			for (String header : headers.keySet()) {
				delete.setHeader(header, headers.get(header));
			}
		}
		System.err.println("executing request" + delete.getRequestLine());
		HttpResponse response = client.execute(delete);
		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		
		restResponse.setCode(response.getStatusLine().getStatusCode());
	//	restResponse.setContent(result.toString());
		return restResponse;
	}
	
	public static byte[] encode(byte[] bytes) {
		byte[] decodedBytes = org.apache.commons.codec.binary.Base64.encodeBase64(bytes);
		return decodedBytes;
	}

}
 