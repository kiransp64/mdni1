
package com.ariba.data.costcenter;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Instance {

    @SerializedName("displayName")
    @Expose
    private String displayName;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("localIdS4")
    @Expose
    private LocalIdS4 localIdS4;
    @SerializedName("attributes")
    @Expose
    private List<Attribute> attributes = null;

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalIdS4 getLocalIdS4() {
        return localIdS4;
    }

    public void setLocalIdS4(LocalIdS4 localIdS4) {
        this.localIdS4 = localIdS4;
    }

    public List<Attribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Attribute> attributes) {
        this.attributes = attributes;
    }

}
