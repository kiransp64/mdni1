package com.ariba.helpers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BaseHelper {

	public static final String propertiesFileName = "APIConfig.properties";
	public static String BASEURL = "";
	public static String GETDATAURL = "";
	public static String GETINTEGRATIONJOBLOG = "";
	public static String POSTXMLDATAURL = "";
	public static String FETCHGROUPS = "";
	public static String FETCHPROCUREMENTUNITS = "";
	public static String FETCHUSERS = "";
	public static String PROCESSCONFIGURL = "";
	public static String OAUTH_URL = "";
	public static String OAUTH_CLIENTID = "";
	public static String OAUTH_KEY = "";
	public static String TEST_SERVICE_URL = "";
	public static String SCIM_URL = "";
	public static String APP_URL = "";
	public static String GETCONFIGURL = "";
	public static String GETSTAGEDSTATUS = "";
	public static int HTTP_200 = 200;
	public static int HTTP_201 = 201;
	public static int HTTP_401 = 401;
	public static int HTTP_400 = 400;
	public static int HTTP_404 = 404;
	public static int HTTP_500 = 500;
	public static Properties properties = new Properties();
	public static JSONArray entities;
	public static String SEARCHBASEURL = "";
	public static String SG_REALM = "";
	public static String SG_USERNAME = "";
	public static String SG_ANID = "";
	public static String ORIGIN_SYS = "";
	public static String SAP_REALM = "";
	public static String SAP_USERNAME = "";
	public static String SAP_ANID = "";
	public static String PSOFT_REALM = "";
	public static String PSOFT_USERNAME = "";
	public static String PSOFT_ANID = "";
	public static String S4_REALM = "";
	public static String S4_USERNAME = "";
	public static String S4_ANID = "";
	public static String INTEGRATED_REALM = "";
	public static String INTEGRATED_USERNAME = "";
	public static String INTEGRATED_ANID = "";
	public static String MERPPARENT_REALM = "";
	public static String MERPPARENT_USERNAME = "";
	public static String MERPPARENT_ANID = "";
	public static String MERPCHILD_REALM = "";
	public static String MERPCHILD_USERNAME = "";
	public static String MERPCHILD_ANID = "";
	public static String MULTI_DESTINATION_REALM = "";
	public static String MULTI_DESTINATION_USERNAME = "";
	public static String MULTI_DESTINATION_ANID = "";
	public static String AQL_HOST= "";
	public static String MDNI_HOST= "";
	public static String MDNI_HOSTAWS= "";
	public static String MDS_SEARCH_HOST = "";
	public static String MDNI_USER= "";
	public static String MDNI_PASS= "";
	public static String STAND_ALONE_SOURCING_REALM= "";
	public static String STAND_ALONE_SOURCING_REALM_ANID= "";
	public static String INTEGRATED_REALM_SV= "";
	public static String INTEGRATED_REALM_ANID_SV= "";
	public static String REPORTING_REALM= "";
	public static String REPORTING_REALM_ANID= "";

	public static String REPORTING_REALM_S4= "";
	public static String REPORTING_REALM_ANID_S4= "";
	public static String BUYER_REALM= "";
	public static String BUYER_REALM_ANID= "";
	public static String PEER_REALM= "";
	public static String PEER_REALM_ANID= "";

	public static String BLOCKEDUSER_BASE64="";
	public static String BLOCKUSERAPI="";
	public static String SERVICE="";

	static {
		properties = readProperties(propertiesFileName);
		BASEURL = properties.getProperty("BASEURL");
		GETDATAURL = properties.getProperty("GETDATAURL");
		GETINTEGRATIONJOBLOG = properties.getProperty("GETINTEGRATIONJOBLOG");
		POSTXMLDATAURL = properties.getProperty("POSTXMLDATAURL");
		FETCHGROUPS = properties.getProperty("FETCHGROUPS");
		FETCHPROCUREMENTUNITS = properties.getProperty("FETCHPROCUREMENTUNITS");
		FETCHUSERS = properties.getProperty("FETCHUSERS");
		PROCESSCONFIGURL = properties.getProperty("PROCESSCONFIGURL");
		OAUTH_URL = properties.getProperty("OAUTH_URL");
		OAUTH_CLIENTID = properties.getProperty("OAUTH_CLIENTID");
		OAUTH_KEY = properties.getProperty("OAUTH_KEY");
		TEST_SERVICE_URL = properties.getProperty("TEST_SERVICE_URL");
		GETCONFIGURL = properties.getProperty("GETCONFIGURL");
		GETSTAGEDSTATUS = properties.getProperty("GETSTAGEDSTATUS");
		SCIM_URL = properties.getProperty("SCIM_URL");
		APP_URL = properties.getProperty("APP_URL");
		entities = getEntities();
		SEARCHBASEURL = properties.getProperty("SEARCHBASEURL");
		SG_REALM = properties.getProperty("SG_REALM");
		SG_USERNAME = properties.getProperty("SG_USERNAME");
		SG_ANID = properties.getProperty("SG_ANID");
		ORIGIN_SYS = properties.getProperty("ORIGIN_SYS");
		SAP_REALM = properties.getProperty("SAP_REALM");
		SAP_USERNAME = properties.getProperty("SAP_USERNAME");
		SAP_ANID = properties.getProperty("SAP_ANID");
		PSOFT_REALM = properties.getProperty("PSOFT_REALM");
		PSOFT_USERNAME = properties.getProperty("PSOFT_USERNAME");
		PSOFT_ANID = properties.getProperty("PSOFT_ANID");
		S4_REALM = properties.getProperty("S4_REALM");
		S4_USERNAME = properties.getProperty("S4_USERNAME");
		S4_ANID = properties.getProperty("S4_ANID");
		INTEGRATED_REALM = properties.getProperty("INTEGRATED_REALM");
		INTEGRATED_USERNAME = properties.getProperty("INTEGRATED_USERNAME");
		INTEGRATED_ANID = properties.getProperty("INTEGRATED_ANID");
		MERPPARENT_REALM = properties.getProperty("MERPPARENT_REALM");
		MERPPARENT_USERNAME = properties.getProperty("MERPPARENT_USERNAME");
		MERPPARENT_ANID = properties.getProperty("MERPPARENT_ANID");
		MERPCHILD_REALM = properties.getProperty("MERPCHILD_REALM");
		MERPCHILD_USERNAME = properties.getProperty("MERPCHILD_USERNAME");
		MERPCHILD_ANID = properties.getProperty("MERPCHILD_ANID");
		MULTI_DESTINATION_REALM = properties.getProperty("MULTI_DESTINATION_REALM");
		MULTI_DESTINATION_USERNAME = properties.getProperty("MULTI_DESTINATION_USERNAME");
		MULTI_DESTINATION_ANID = properties.getProperty("MULTI_DESTINATION_ANID");

		AQL_HOST = properties.getProperty("aqlHost");
		MDNI_HOST= properties.getProperty("mdniHost");
		MDNI_HOSTAWS= properties.getProperty("mdniHosta");
		MDS_SEARCH_HOST = properties.getProperty("mdsSearchHost");
		MDNI_USER= properties.getProperty("user");
		MDNI_PASS= properties.getProperty("pass");
		STAND_ALONE_SOURCING_REALM= properties.getProperty("StandaloneSourcingRealm");
		STAND_ALONE_SOURCING_REALM_ANID= properties.getProperty("StandaloneSourcingRealmAnid");
		INTEGRATED_REALM_SV= properties.getProperty("IntegratedRealm");
		INTEGRATED_REALM_ANID_SV= properties.getProperty("IntegratedRealmAnid");
		REPORTING_REALM= properties.getProperty("ReportingRealm");
		REPORTING_REALM_ANID= properties.getProperty("ReportingRealmAnid");
		REPORTING_REALM_S4= properties.getProperty("ReportingRealmS4");
		REPORTING_REALM_ANID_S4= properties.getProperty("ReportingRealmAnidS4");
		BUYER_REALM= properties.getProperty("StandaloneBuyerRealm");
		BUYER_REALM_ANID= properties.getProperty("StandaloneBuyerRealmAnid");

		PEER_REALM= properties.getProperty("PEER_REALM");
		PEER_REALM_ANID= properties.getProperty("PEER_REALM_ANID");

		BLOCKEDUSER_BASE64=properties.getProperty("BLOCKEDUSER_BASE64");
		BLOCKUSERAPI=properties.getProperty("BLOCKUSERAPI");
		SERVICE=properties.getProperty("SERVICE");
	}

	public static JSONArray getEntities() {

		String rootDir = System.getProperty("user.dir");
		String filename = "entityfieldmap.json";

		JSONArray entitiesArray = new JSONArray();
		try {
			InputStream is = new FileInputStream(rootDir + "/resources/" + filename);
			String jsonTxt = IOUtils.toString(is, "UTF-8");
			JSONObject entities = new JSONObject(jsonTxt);
			entitiesArray = (JSONArray) entities.get("entities");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return entitiesArray;
	}

	public static Properties readProperties(String filename) {

		Properties props = new Properties();
		String rootDir = System.getProperty("user.dir");
		try {
			props.load(new FileInputStream(rootDir + "/resources/" + filename));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return props;
	}

	public static Object jsonObject(String content) throws JSONException {

		Object returnObj = null;

		try {
			returnObj = new JSONObject(content);
		} catch (JSONException e) {
			try {
				returnObj = new JSONArray(content);
			} catch (JSONException e1) {
				// To handle negative case where content is null
				if (!content.isEmpty()) {
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("errorMessage", extractErrorMessage(content));
					return jsonObject;
				}

			}
		}

		return returnObj;

	}

	private static String extractErrorMessage(String content) {
		String errorMessage = "";
		String pattern1 = "<title>";
		String pattern2 = "</title>";
		content = content.replace("\n", "").replace("\r", "");
		content = content.replace("\"", "");
		Pattern p = Pattern.compile(Pattern.quote(pattern1) + "(.*?)" + Pattern.quote(pattern2));
		Matcher m = p.matcher(content.toString());
		while (m.find()) {
			String c = m.group(1);
			errorMessage = c.substring(c.indexOf(' ') + 1);
		}
		return errorMessage;
	}

	public static String getStringFromXML(String filePath) throws FileNotFoundException {

		String rootDir = System.getProperty("user.dir");
		Scanner scanner = new Scanner(new File(rootDir + filePath));
		String xmlString = scanner.useDelimiter("\\A").next();
		scanner.close();
		return xmlString;

	}

	public static String getFileContentAsString(String filePath) throws FileNotFoundException {

		String rootDir = System.getProperty("user.dir");
		Scanner scanner = new Scanner(new File(rootDir + filePath));
		String xmlString = scanner.useDelimiter("\\A").next();
		scanner.close();
		return xmlString;

	}

	public static String getEncodedString(String username, String password) throws UnsupportedEncodingException {
		String header = String.format("Basic %s",
				new String(encode(String.format("%s:%s", username, password).getBytes("UTF-8"))));
		return header;
	}

	public static String getEncodedString1(String username, String password) throws UnsupportedEncodingException {
		String header = String.format("Basic %s",
				new String(encode(String.format("%s:%s", username, password).getBytes())));
		return header;
	}

	public static byte[] encode(byte[] bytes) {
		byte[] decodedBytes = org.apache.commons.codec.binary.Base64.encodeBase64(bytes);
		return decodedBytes;
	}

}
