package com.ariba.pojos;

import com.google.gson.annotations.SerializedName;

public class Language {
	@SerializedName("languageCode")
	private String languageCode;

	@SerializedName("content")
	private String content;

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "Language [languageCode=" + languageCode + ", content=" + content + "]";
	}
}