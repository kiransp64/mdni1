package com.ariba.services;

import com.ariba.helpers.Constants;
import com.github.dzieciou.testing.curl.CurlLoggingRestAssuredConfigFactory;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.ariba.helpers.BaseHelper.*;

public class MDS {
    RestAssuredConfig config = CurlLoggingRestAssuredConfigFactory.createConfig();
    private static Logger logger = LogManager.getLogger(MDS.class);

    public MDS() {

    }

    public void mdsSearch(String uri, String system, String realm, String anid, String filterParam, String randomString) {
        String access_token = OAuth.generateToken(system, realm, anid);
        RestAssured.baseURI = "https://" + MDS_SEARCH_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.queryParam("$filter", filterParam + "'" + randomString + "'");
        Response response = requestSpecification.relaxedHTTPSValidation().get("/" + uri);
        response.prettyPrint();
    }

    public Response mdsSearchWithToken(String host, String uri, String token) {
        RestAssured.baseURI = host;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + token);
        requestSpecification.headers("Accept-Language", "en");
        Response response = requestSpecification.relaxedHTTPSValidation().get(uri);
        System.out.println("Response for uri : " + uri);
        response.prettyPrint();
        return response;
    }

    public Response openApiSearch(String system, String realm, String anid, String uri, String filter) {
        String access_token = OAuth.generateToken(system, realm, anid);
        RestAssured.baseURI = "https://" + MDS_SEARCH_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);

        requestSpecification.header("Authorization", "Bearer " + access_token);
//        requestSpecification.header("X-realm", realm);
//        requestSpecification.header("X-system", system);
//        requestSpecification.header("X-anId", anid);
        requestSpecification.header("Accept-Language", "en");
//        requestSpecification.header("apiKey", "uf0QjI52caB5EKM42SwZc1egyC7VNuCC");

        requestSpecification.queryParam("$filter", filter);
        if (system.equalsIgnoreCase("s4")){
            requestSpecification.queryParam("searchConsumer", "bulk_export");
        }
        Response response = requestSpecification.relaxedHTTPSValidation().get(uri);
        logger.info("MDS search with filter : " + filter + "\n" + response.asString());
        Assert.assertEquals(response.getStatusCode(),200,"MDS search Failed get response : "+filter+"host : "+MDS_SEARCH_HOST);
        return response;
    }

    public Response openApiSearch(String requestOrigin, String system, String realm, String anid, String uri, String filter) {
        String access_token = OAuth.generateToken(requestOrigin, system, realm, anid);
        RestAssured.baseURI = "https://" + MDS_SEARCH_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);

        requestSpecification.header("Authorization", "Bearer " + access_token);
//        requestSpecification.header("X-realm", realm);
//        requestSpecification.header("X-system", system);
//        requestSpecification.header("X-anId", anid);
        requestSpecification.header("Accept-Language", "en");
        if (system.equalsIgnoreCase("s4")){
            requestSpecification.queryParam("searchConsumer", "bulk_export");
        }
//        requestSpecification.header("apiKey", "uf0QjI52caB5EKM42SwZc1egyC7VNuCC");
        requestSpecification.queryParam("$filter", filter);
        Response response = requestSpecification.relaxedHTTPSValidation().get(uri);
        logger.info("MDS search with filter : " + filter + "\n" + response.asString());
        return response;
    }

    public Response advancedApiSearchUsingUniqueName(String requestOrigin, String system, String realm, String anid, String uri, String UniqueName) {
        String access_token = OAuth.generateToken(requestOrigin, system, realm, anid);
        RestAssured.baseURI = "https://" + MDS_SEARCH_HOST;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.header("Accept-Language", "en");
        requestSpecification.queryParam("UniqueName", UniqueName);
        Response response = requestSpecification.relaxedHTTPSValidation().get(uri);
        logger.info("MDS search with filter : " + UniqueName + "\n" + response.asString());
        return response;
    }

    public Response mdsAdvancedSearchApiResponse(String system, String realm, String anid, String uri, String senderBusinessId, String filter, String expand, String locale) {
        String access_token = OAuth.generateToken(system, realm, anid);
        RestAssured.baseURI = "https://" + MDS_SEARCH_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.header("x-senderBusinessId", senderBusinessId);
        requestSpecification.header("X-system", "MDNI");
        requestSpecification.header("Accept-Language", "en");
        if (filter != null)
            requestSpecification.queryParam("$filter", filter);
        if (filter != null)
            requestSpecification.queryParam("$expand", expand);
        if (filter != null)
            requestSpecification.queryParam("$locale", locale);
        Response response = requestSpecification.relaxedHTTPSValidation().get(uri);
        logger.info("MDS search with filter : " + filter + "\n" + response.asString());
        return response;
    }

    public Response mdsQueryExecuterResponse(String anid, String uniqueName) {
        String body = "{ \"QUERY\" : \"SELECT TOP 1000 \\\"SAPCostCenterKey.UniqueName\\\", \\\"SAPCostCenterKey.CompanyCode\\\" FROM \\\"mdsHana.mdsDB.data::MDSCommon.SAPCostCenterE\\\" WHERE \\\"SAPCostCenterKey.SystemId\\\" = '" + anid + "' and \\\"SAPCostCenterKey.UniqueName\\\" ='" + uniqueName + "'\" }";
        RestAssured.baseURI = "https://ariba-mdsdev1-mdsodatamdsdev1.mdsdev.lab-us.gcpint.ariba.com:443/queryexecutor";
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.body(body);
        requestSpecification.header("Content-Type", "text/plain");
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        response.prettyPrint();
        return response;
    }

    public Response getFeatureSettings(String access_token) {
        RestAssured.baseURI = "https://" + MDS_SEARCH_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization", "Bearer " + access_token);
        Response response = requestSpecification.relaxedHTTPSValidation().get(Constants.FEATURE_SETTINGS);
        response.prettyPrint();
        return response;
    }

    public Response updateFeatureSettings(String access_token, String payload) {
        RestAssured.baseURI = "https://" + MDS_SEARCH_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.header("Content-Type", "application/json");
        requestSpecification.body(payload);
        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.FEATURE_SETTINGS);
        response.prettyPrint();
        return response;
    }
}
