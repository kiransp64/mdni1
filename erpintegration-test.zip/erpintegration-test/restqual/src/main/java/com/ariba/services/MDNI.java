package com.ariba.services;

import com.ariba.helpers.Constants;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import com.github.dzieciou.testing.curl.CurlLoggingRestAssuredConfigFactory;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
//import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.HttpHeaders;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;
import java.io.File;
import java.util.UUID;

import static com.ariba.helpers.BaseHelper.*;
import static io.restassured.RestAssured.given;

public class MDNI {
    private static Logger logger = LogManager.getLogger(MDNI.class);


    RestAssuredConfig config = CurlLoggingRestAssuredConfigFactory.createConfig();

    public MDNI() {

    }

    public String uploadXMLData(String tenantId, String objectName, String payload) {
        RestAssured.baseURI = "https://" + MDNI_HOST;
        System.err.println("Upload xml url : " + MDNI_HOST);
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.queryParam("tenantId", tenantId);
        requestSpecification.queryParam("objectName", objectName);
//        requestSpecification.queryParam("cigSource","false");
        requestSpecification.auth().preemptive().basic(MDNI_USER, MDNI_PASS);
        requestSpecification.body(payload);
        System.out.println("Payload : " + payload);
        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.MDNI_UPLOAD_XML_DATA);
        System.out.println("Response code : " + response.statusCode());
        response.prettyPrint();
        response.then().assertThat().statusCode(200);
        return response.asString().split(" ")[1];
    }

    public Response getJobStatus(String tenantId, String jobId) throws InterruptedException {
        int count = 1;
        int maxRetries = 20;
        Response response = getStatus(tenantId, jobId);
        while (true) {
            if (response.jsonPath().getString("Status").contains("Processing") && count < maxRetries) {
                if (response.jsonPath().getString("Status").equalsIgnoreCase("Needs Re-Processing")) {
                    Assert.fail(response.jsonPath().getString("Status"));
                }
                System.out.println(count * 10000);
                Thread.sleep(count * 10000);
                response = getStatus(tenantId, jobId);
                count++;
                if (response.asString().contains("RecordsInserted")) {
                    if (response.jsonPath().getInt("RecordsInserted") > 0) {
                        break;
                    }
                }
            } else {
                break;
            }
        }
        return response;
    }


    public static Response getJobStatusOfObject(String tenantId, String objectName) throws InterruptedException {
        int count = 1;
        int maxRetries = 20;
        Response response = getStatusWithObjectName(tenantId, objectName);
        while (true) {
            if (!response.jsonPath().getString("Status").contains("Needs Re-Processing") && count < maxRetries) {
                logger.info("Waiting for Needs Re-Processing current state is : " + response.jsonPath().getString("Status"));
                Thread.sleep(count * 30000);
                response = getStatusWithObjectName(tenantId, objectName);
                count++;
            } else {
                break;
            }
        }
        return response;
    }

    public static Response waitForNewInstanceOfObjectCreated(String tenantId, String objectName, String StartDate) throws InterruptedException {
        int count = 1;
        int maxRetries = 20;
        Response response = getStatusWithObjectName(tenantId, objectName);
        logger.info("Will wait for new instance to be created for : " + objectName + " after startDate : " + StartDate);
        while (true) {
            if (response.jsonPath().getString("StartDate") != null) {
                if (StartDate.equalsIgnoreCase(response.jsonPath().getString("StartDate")) && count < maxRetries) {
                    logger.info("Waiting : " + count * 30000);
                    Thread.sleep(count * 30000);
                    response = getStatusWithObjectName(tenantId, objectName);
                    count++;
                } else {
                    break;
                }
            }else {
                Thread.sleep(count * 30000);
                response = getStatusWithObjectName(tenantId, objectName);
            }
        }
        return response;
    }

    public Response getStatus(String tenantId, String jobId) {
        if (tenantId.equalsIgnoreCase("AN02000025606"))
            RestAssured.baseURI = "https://" + MDNI_HOSTAWS;
        else
            RestAssured.baseURI = "https://" + MDNI_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.queryParam("tenantId", tenantId);
        requestSpecification.queryParam("jobId", jobId);
        requestSpecification.auth().preemptive().basic(MDNI_USER, MDNI_PASS);
        System.err.println("get status url : " + MDNI_HOST + Constants.MDNI_JOB_STATUS);
        Response response = requestSpecification.relaxedHTTPSValidation().get(Constants.MDNI_JOB_STATUS);
        response.prettyPrint();
        response.then().assertThat().statusCode(200);
        return response;
    }

    public static Response getStatusWithObjectName(String tenantId, String objectName) {
        RestAssured.baseURI = "https://" + MDNI_HOST;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.queryParam("tenantId", tenantId);
        requestSpecification.queryParam("objectName", objectName);
        requestSpecification.auth().preemptive().basic(MDNI_USER, MDNI_PASS);
        System.err.println("get status url : " + MDNI_HOST + Constants.MDNI_JOB_STATUS);
        Response response = requestSpecification.relaxedHTTPSValidation().get(Constants.MDNI_JOB_STATUS);
        logger.info(response.asString());
        response.then().assertThat().statusCode(200);
        return response;
    }

    public Response createUsers(String anid, String token, String payload) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "charset=utf-8");
        requestSpecification.headers("Connection", "close");
        requestSpecification.body(payload);
        System.err.println("create users url : " + SCIM_URL + Constants.URL_USERS);
        Response response = requestSpecification.relaxedHTTPSValidation().post(SCIM_URL + Constants.URL_USERS);
        System.out.println("Create user response : ");
        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 201, "Create user has failed");
        return response;
    }

    public Response patchUsers(String anid, String token, String payload, String uri) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "charset=utf-8");
        requestSpecification.headers("Connection", "close");
        requestSpecification.body(payload);
        System.err.println("Patch users url : " + SCIM_URL + Constants.URL_USERS + "/" + uri);
        Response response = requestSpecification.relaxedHTTPSValidation().patch(SCIM_URL + Constants.URL_USERS + "/" + uri);
        System.out.println("Patch user response : ");
        response.prettyPrint();
//        Assert.assertEquals(response.getStatusCode(),200,"Patch call has failed");
        return response;
    }

    public Response getUsers(String anid, String token, String uri) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "charset=utf-8");
        requestSpecification.headers("Connection", "close");
        System.err.println("Get users url : " + SCIM_URL + Constants.URL_USERS + "/" + uri);
        Response response = requestSpecification.relaxedHTTPSValidation().get(SCIM_URL + Constants.URL_USERS + "/" + uri);
        System.out.println("Get users response : ");
        response.prettyPrint();
        return response;
    }

    public Response mdiProcess(String anid, String token) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        Response response = requestSpecification.relaxedHTTPSValidation().post("https://qa.cobalt.ariba.com/oneMDS/erpintegration/api/mdi/process/" + anid);
        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 202, "mdi process has failed");
        return response;
    }

    public Response getUsersWithPagination(String anid, String token, int startIndex, int count) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "charset=utf-8");
        requestSpecification.headers("Connection", "close");
        requestSpecification.queryParam("startIndex", startIndex);
        requestSpecification.queryParam("count", count);
        System.err.println("Get users with pagination : " + SCIM_URL + Constants.URL_USERS);
        Response response = requestSpecification.relaxedHTTPSValidation().get(SCIM_URL + Constants.URL_USERS);
        System.out.println("Get users response : ");
        response.prettyPrint();
        return response;
    }

    public Response getUsersUsingOpenApi(String anid, String token, String uri) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_FORWARDED_HOST, "openapi.com");
        System.err.println("Get users using openApi : " + SCIM_URL + Constants.URL_USERS + "/" + uri);
        Response response = requestSpecification.relaxedHTTPSValidation().get(SCIM_URL + Constants.URL_USERS + "/" + uri);
        System.out.println("Get users response : ");
        response.prettyPrint();
        return response;
    }

    public Response createGroup(String anid, String token, String payload) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "charset=utf-8");
        requestSpecification.headers("Connection", "close");
        requestSpecification.body(payload);
        System.err.println("Create group url : " + SCIM_URL + Constants.URL_GROUPS);
        Response response = requestSpecification.relaxedHTTPSValidation().post(SCIM_URL + Constants.URL_GROUPS);
        System.out.println("Create group response : ");
        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 201, "Create group has failed");
        return response;
    }

    public Response getGroup(String anid, String token, String uri) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "charset=utf-8");
        requestSpecification.headers("Connection", "close");
        System.err.println("Get group url : " + SCIM_URL + Constants.URL_GROUPS + "/" + uri);
        Response response = requestSpecification.relaxedHTTPSValidation().get(SCIM_URL + Constants.URL_GROUPS + "/" + uri);
        System.out.println("Get group response : ");
        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 200, "Patch call has failed");
        return response;
    }

    public Response patchGroup(String anid, String token, String payload, String uri) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(HttpHeaders.ACCEPT, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(Constants.HEADER_ANID, anid);
        requestSpecification.headers(Constants.AUTHORIZATION, "bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, Constants.HEADER_APP_SCIM);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "charset=utf-8");
        requestSpecification.headers("Connection", "close");
        requestSpecification.body(payload);
        System.err.println("Patch group url : " + SCIM_URL + Constants.URL_GROUPS + "/" + uri);
        Response response = requestSpecification.relaxedHTTPSValidation().patch(SCIM_URL + Constants.URL_GROUPS + "/" + uri);
        System.out.println("Patch group response : ");
        response.prettyPrint();
//        Assert.assertEquals(response.getStatusCode(),200,"Patch call has failed");
        return response;
    }

    public Response uploadWSDL(String tenantId,String objectName,String senderBusinessSystemId){
        RestAssured.baseURI="https://"+ MDNI_HOSTAWS;
        String wsdlFile = new File("resources/wsdlfiles/"+objectName+".wsdl").getAbsolutePath();
        RequestSpecification requestSpecification = given()
                .config(config)
                .queryParam("tenantId",tenantId)
                .queryParam("objectName",objectName)
                .queryParam("senderBusinessSystemId",senderBusinessSystemId)
                .contentType("multipart/form-data")
                .multiPart("",new File(wsdlFile));
        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.MDNI_UPLOAD_WSDL_FILE);
        response.prettyPrint();
        response.then().assertThat().statusCode(200);
        return response;
    }

    public Response uploadWSDL_Error(String tenantId, String objectName, String uploadObject, String senderBusinessSystemId){
        RestAssured.baseURI="https://"+ MDNI_HOSTAWS;
        String wsdlFile = new File("resources/wsdlfiles/"+uploadObject+".wsdl").getAbsolutePath();
        RequestSpecification requestSpecification = given()
                .config(config)
                .queryParam("tenantId",tenantId)
                .queryParam("objectName",objectName)
                .queryParam("senderBusinessSystemId",senderBusinessSystemId)
                .contentType("multipart/form-data")
                .multiPart("",new File(wsdlFile));
        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.MDNI_UPLOAD_WSDL_FILE);
        // System.out.println("Response code : "+response.statusCode());
        response.prettyPrint();
        response.then().assertThat().statusCode(400);
        return response;
    }

    HttpRequests httpRequests = new HttpRequests();

    public RestResponse uploadPayload(String tenantId, String xmlString, String username, String password, String objectName, String senderBusinessId)
            throws Exception {

        String URL = "https://"+ MDNI_HOSTAWS + Constants.MDNI_UPLOAD_PAYLOAD + "?tenantId=" + tenantId + "&objectName="+ objectName +"&senderBusinessSystemId="+ senderBusinessId;
        System.out.println(URL);
        String header = getEncodedString(username, password);
        RestResponse result = httpRequests.httpPost(URL, header, xmlString);
        return result;
    }

    public Response fetchUsers(String tenantId, String xmlString, String uniqueName, String username, String password) {

        RestAssured.baseURI="https://"+ MDNI_HOSTAWS;
        RequestSpecification requestSpecification = given()
                .queryParam("tenantId",tenantId)
                .queryParam("userUniqueName",uniqueName);
        requestSpecification.auth().preemptive().basic(username,password)
                .body(xmlString);
        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.MDNI_FETCH_USERS);
        return  response;
    }

    public Response fetchGroups(String tenantId, String xmlString, String username, String password) {

        RestAssured.baseURI="https://"+ MDNI_HOSTAWS;
        RequestSpecification requestSpecification = given()
                .queryParam("tenantId",tenantId);
        requestSpecification.auth().preemptive().basic(username,password)
                .body(xmlString);
        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.MDNI_FETCH_GROUPS);
        return  response;
    }

    public Response fetchProcurementUnits(String tenantId, String xmlString, String username, String password) {

        RestAssured.baseURI="https://"+ MDNI_HOSTAWS;
        RequestSpecification requestSpecification = given()
                .queryParam("tenantId",tenantId);
        requestSpecification.auth().preemptive().basic(username,password)
                .body(xmlString);
        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.MDNI_FETCH_PROCUREMENTUNITS);
        return  response;
    }

    public Response patchBlockUser(String token, String payload, String service, String realm, String productType, String uniqueName) {
        RequestSpecification requestSpecification = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("charset=utf-8", ContentType.TEXT)));
        requestSpecification.headers(Constants.AUTHORIZATION, "Bearer " + token);
        requestSpecification.headers(HttpHeaders.CONTENT_TYPE, "application/json");
        requestSpecification.body(payload);
        String URL = BLOCKUSERAPI;
        URL = URL.replace("service", service);
        URL = URL.replace("Realm", realm);
        URL = URL.replace("uniqueName", new String(encode(String.format("%s", uniqueName).getBytes())));
        URL = URL.replace("productType", productType);
        System.out.println("URL :" + URL);

        Response response = requestSpecification.relaxedHTTPSValidation().patch(URL);
        System.err.println("Patch user response : ");
        response.prettyPrint();
        return response;
    }
}
