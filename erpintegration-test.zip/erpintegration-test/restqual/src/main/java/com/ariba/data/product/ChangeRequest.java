
package com.ariba.data.product;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChangeRequest {

    @SerializedName("operation")
    @Expose
    private String operation;
    @SerializedName("changeToken")
    @Expose
    private String changeToken;
    @SerializedName("instance")
    @Expose
    private Instance instance;
    @SerializedName("previousVersionId")
    @Expose
    private String previousVersionId;

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getChangeToken() {
        return changeToken;
    }

    public void setChangeToken(String changeToken) {
        this.changeToken = changeToken;
    }

    public Instance getInstance() {
        return instance;
    }

    public void setInstance(Instance instance) {
        this.instance = instance;
    }
    public String getPreviousVersionId() {
        return previousVersionId;
    }

    public void setPreviousVersionId(String previousVersionId) {
        this.previousVersionId = previousVersionId;
    }

}
