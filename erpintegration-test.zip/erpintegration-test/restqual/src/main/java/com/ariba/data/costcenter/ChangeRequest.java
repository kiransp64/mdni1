
package com.ariba.data.costcenter;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChangeRequest {

    @SerializedName("operation")
    @Expose
    private String operation;
    @SerializedName("changeToken")
    @Expose
    private String changeToken;
    @SerializedName("previousVersionId")
    @Expose
    private String previousVersionId;
    @SerializedName("localIds")
    @Expose
    private List<LocalId> localIds = null;
    @SerializedName("instance")
    @Expose
    private Instance instance;

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getChangeToken() {
        return changeToken;
    }

    public void setChangeToken(String changeToken) {
        this.changeToken = changeToken;
    }

    public String getPreviousVersionId() {
        return previousVersionId;
    }

    public void setPreviousVersionId(String previousVersionId) {
        this.previousVersionId = previousVersionId;
    }

    public List<LocalId> getLocalIds() {
        return localIds;
    }

    public void setLocalIds(List<LocalId> localIds) {
        this.localIds = localIds;
    }

    public Instance getInstance() {
        return instance;
    }

    public void setInstance(Instance instance) {
        this.instance = instance;
    }

    public void setDisplayName(String name){
        getInstance().setDisplayName(name);
    }


}
