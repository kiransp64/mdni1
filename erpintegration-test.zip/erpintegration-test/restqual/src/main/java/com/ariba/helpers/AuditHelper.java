package com.ariba.helpers;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import org.testng.Assert;

import java.util.*;
import java.text.SimpleDateFormat;

import static io.restassured.RestAssured.given;

public class AuditHelper extends BaseHelper {

    public static Properties properties;
    public static final String propertiesFileName = "APIConfig.properties";
    public static Map<String, String> auditObjects = new HashMap<>();
    public static String startTime ;
    public static String endTime ;
    public static String filterData;
    public static String mdniService = "MDNI";

    //sync and async parameters
    public static final String TENANT_ID = "tenantId";
    public static final String AUDIT_TYPE = "auditType";
    public static final String START_TIME = "searchStartTime";
    public static final String END_TIME = "searchEndTime";
    public static final String FILTER = "$filter";
    public static final String ORDER_BY = "$orderby";
    public static final String SKIP = "$skip";
    public static final String TOP = "$top";

    //AuditObjects
    public static String typeOfAuditProp = "auditType";
    public static String documentIDProp = "documentId";
    public static String realUserProp = "realUser";
    public static String documentTypeProp = "documentType";
    public static String statusProp = "status";
    public static String purposeOfAuditProp = "purposeOfAudit";
    public static String notesProp = "notes";
    public static String tenantIdProp = "tenantId";
    public static String anidProp = "param1";
    public static String objectNameProp = "param2";
    public static String senderBusinessIdProp = "param3";
    public static String targetServiceProp = "param4";
    public static String loadTypeProp = "param5";
    public static String param6Prop = "param6";
    public static String param7Prop = "param7";
    public static String formatProp = "format";
    public static String apiUrlProp = "apiUrl";
    public static String documentStatusProp = "documentStatus";
    public static String entityProp = "entity";
    public static String traceIdProp = "traceId";

    public static String BUYER_AUDIT_REALM= "";
    public static String BUYER_AUDIT_ANID= "";
    public static String S4_AUDIT_REALM= "";
    public static String S4_AUDIT_ANID= "";
    public static String AUDIT_SERVICE_HOST= "";
    public static String AUDIT_SEARCH_URI= "";
    public static String AUDIT_PUBLISH_URI= "";
    public static String AUDIT_API_KEY = "";
    public static String OAUTH_SECRET = "";

    //Audit Type
    public static String integrationAuditType = "Integration";
    public static String securityAuditType = "Security";

    //operations
    public static String wsdl_Upload = "WSDL_UPLOAD";
    public static String process_payload = "PROCESS_XML_DATA";
    public static String fetch_users = "FETCH_USERS";
    public static String fetch_groups = "FETCH_GROUPS";
    public static String fetch_procurementUnits = "FETCH_PROCUREMENT_UNITS";
    //actions
    public static String dataImport_Action = "DATAIMPORT";
    public static String dataExport_Action = "DATAEXPORT";
    public static String security_action = "AUTHENTICATION";

    static{
        properties = readProperties(propertiesFileName);
        OAUTH_SECRET = properties.getProperty("oauthSecret");
        BUYER_AUDIT_ANID= properties.getProperty("auditSSPANId");
        S4_AUDIT_ANID= properties.getProperty("auditS4ANId");
        BUYER_AUDIT_REALM= properties.getProperty("auditSSPRealm");
        S4_AUDIT_REALM= properties.getProperty("auditS4Realm");
        AUDIT_SERVICE_HOST= properties.getProperty("auditSearchHost");
        AUDIT_SEARCH_URI= properties.getProperty("auditSearchUri");
        AUDIT_PUBLISH_URI= properties.getProperty("auditPublishUri");
        AUDIT_API_KEY = properties.getProperty("apikey");
    }

    public static String getAuditSyncSearchUri(){
        return AUDIT_SEARCH_URI;
    }

    public static String getAuditPublishUri() {
        return AUDIT_PUBLISH_URI;
    }

    public static String setAuditSearchDateFormat(String type) throws InterruptedException {
        String currentDate = null;
        if(type=="end")
            Thread.sleep(3000);
        Date date = new Date();
        System.out.println(date);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        sdf.setTimeZone(TimeZone.getTimeZone("IST"));
        switch(type){
            case "start":
                currentDate = sdf.format(date);
                break;
            case "end":
                currentDate = sdf.format(date);
                break;
        }
        System.out.println(currentDate);
        return currentDate;
    }

    public static Response auditPublish(String twoloToken){
        RestAssured.baseURI="https://"+ AUDIT_SERVICE_HOST;
        String payLoad = "{"
                + "\"messages\": ["
                + "{"
                + "\"tenantId\": \"p2pTeSap\","
                + "\"nodeName\": \"C1_UI1\","
                + "\"ip\": \"127.0.0.0.1\","
                + "\"status\":\"SUCCESS\","
                + "\"auditType\": \"GenericAction\","
                + "\"serviceName\": \"Buyer\","
                + "\"realUser\": \"adavis\","
                + "\"purposeOfAudit\": \"BusinessCritical\","
                + "\"action\": \"DOWNLOAD\""
                + "}"
                + "]"
                +"}";
        RequestSpecification requestSpecification  = given()
                .header("ContentType","application/json")
                .header("Authorization", "Bearer "+twoloToken)
                .contentType("application/json")
                .body(payLoad);
        Response response = requestSpecification.relaxedHTTPSValidation().post(getAuditPublishUri());
        response.prettyPrint();
        return response;
    }

    public static Response auditSyncSearch(String auditType, String starttime, String endTime, String filter, String twoloToken, String realmName) throws ParseException, InterruptedException {
        String realmId = realmName;
        String  orderBy = "realUser";
        String skip = "0";
        String top = "5000"; int count = 0;
        String responseBody; Response response = null; JSONArray contents;

        RestAssured.baseURI="https://"+ AUDIT_SERVICE_HOST;
        String queryParam = TENANT_ID + "=" + BUYER_AUDIT_REALM+"&"+AUDIT_TYPE+"="+auditType+"&"+START_TIME+"="+starttime;
        if(endTime!=null){
            queryParam = queryParam + "&"+END_TIME+"="+endTime;
        }
        if(filter!=null){
            queryParam = queryParam + "&"+FILTER+"="+filter;
        }
        if(orderBy!=null){
            queryParam = queryParam + "&$orderby="+orderBy;
        }
        System.out.println(RestAssured.baseURI + getAuditSyncSearchUri() +"?"+queryParam);

        RequestSpecification requestSpecification = given()
                .header("ContentType","application/json")
                .header("Authorization", "Bearer "+twoloToken)
                .header("ApiKey", AUDIT_API_KEY)
                .contentType("application/json")
                .param( TENANT_ID,realmId)
                .queryParam(AUDIT_TYPE, auditType)
                .queryParam(START_TIME, starttime)
                .queryParam(END_TIME, endTime)
                .queryParam(FILTER, filter)
                .queryParam(ORDER_BY, orderBy)
                .queryParam(SKIP, skip)
                .queryParam(TOP, top);
        for(int i=0;i<5;i++) {
            response = requestSpecification.relaxedHTTPSValidation().get(getAuditSyncSearchUri())
                    .then().contentType("application/json").extract().response();

            responseBody = response.getBody().prettyPrint();
            response.then().assertThat().statusCode(200);
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(responseBody);
            contents = (JSONArray) json.get("contents");

            if (contents.isEmpty()) Thread.sleep(5000);
            else break;
        }
        return response;
    }

    public static void validateAuditSearchJson(String responseBody, Map<String, String> auditObjects_actual) throws ParseException {
        String auditObjectKey, auditObject_actual, auditObjects_response;
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(responseBody);
        JSONArray contents = (JSONArray) json.get("contents");

        if(contents.isEmpty()) Assert.fail("Audit search returned no result");
        else {
            JSONObject auditRecord = (JSONObject) contents.get(0);
            for (Map.Entry m : auditObjects_actual.entrySet()) {
                auditObjectKey = m.getKey().toString();
                if (auditRecord.containsKey(auditObjectKey)) {
                    auditObject_actual = m.getValue().toString();
                    auditObjects_response = auditRecord.get(auditObjectKey).toString();

                    if (!auditObject_actual.equals("")) {
                        if (auditObjectKey.equalsIgnoreCase("documentId") && auditObjects_response.contains(auditObject_actual)) {
                            auditObject_actual = auditObjects_response;
                        }
                        if (auditObjectKey.equalsIgnoreCase("traceId") && auditObjects_response.contains(auditObject_actual)) {
                            auditObject_actual = auditObjects_response;
                        }
                        if (auditObjectKey.equalsIgnoreCase("apiUrl") && auditObjects_response.contains(auditObject_actual)) {
                            auditObject_actual = auditObjects_response;
                        }
                        if (auditObjectKey.equalsIgnoreCase("notes")) {
                            if (auditObjects_response.contains(auditObject_actual) || auditObjects_response.contains("/tmp/nfs/" + BUYER_AUDIT_ANID))
                                auditObject_actual = auditObjects_response;
                        }
                    }
                        Assert.assertEquals(auditObject_actual, auditObjects_response, "Properties do not match");
                }
            }
        }
    }
}
