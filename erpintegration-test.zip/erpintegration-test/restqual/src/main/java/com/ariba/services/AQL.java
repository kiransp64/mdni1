package com.ariba.services;

import com.ariba.helpers.Constants;
import com.github.dzieciou.testing.curl.CurlLoggingRestAssuredConfigFactory;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;

import static com.ariba.helpers.BaseHelper.AQL_HOST;

public class AQL {

    RestAssuredConfig config = CurlLoggingRestAssuredConfigFactory.createConfig();

    public AQL() {

    }

    public Response buyerPull(String query, String realm, String anid, String locale){
        String access_token = OAuth.generateToken("Buyer", realm, anid);
        RestAssured.baseURI= "http://"+ AQL_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization","Bearer "+access_token);
        requestSpecification.header("Content-Type","application/x-www-form-urlencoded");

        requestSpecification.queryParam("query",query);
        requestSpecification.queryParam("REMOTEREALMANIDMAP",anid+":0");
        requestSpecification.queryParam("ISSSPPULL","true");
        requestSpecification.queryParam("businessKey","ACM1");
        requestSpecification.queryParam("autoJoinType","LeftOuter");
        requestSpecification.queryParam("locale",locale);

        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.BUYER_AQL_PULL);
        System.out.println("Buyer pull response : "+response.getBody().asString());
        Assert.assertEquals(response.getStatusCode(),200,"Failed to get response from buyer");
        return response;
    }

    public Response sourcingPull(String query, String realm,String anid,String locale){
        String access_token = OAuth.generateToken("Sourcing", realm, anid);
        RestAssured.baseURI= "http://"+ AQL_HOST;
        RequestSpecification requestSpecification = RestAssured.given().config(config);
        requestSpecification.header("Authorization","Bearer "+access_token);
        requestSpecification.header("Content-Type","application/x-www-form-urlencoded");

        requestSpecification.queryParam("query",query);
        requestSpecification.queryParam("REMOTEREALMANIDMAP",anid+":0");
        requestSpecification.queryParam("ISSSPPULL","true");
        requestSpecification.queryParam("businessKey","ACM1");
        requestSpecification.queryParam("autoJoinType","LeftOuter");
        requestSpecification.queryParam("locale",locale);

        Response response = requestSpecification.relaxedHTTPSValidation().post(Constants.SOURCING_AQL_PULL);
        System.out.println("Buyer pull response : "+response.getBody().asString());
        Assert.assertEquals(response.getStatusCode(),200,"Failed to get response from buyer");
        return response;
    }
}
