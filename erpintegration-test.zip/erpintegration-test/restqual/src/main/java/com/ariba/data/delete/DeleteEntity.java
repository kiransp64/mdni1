
package com.ariba.data.delete;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DeleteEntity {

    @SerializedName("operation")
    @Expose
    private String operation;
    @SerializedName("changeToken")
    @Expose
    private String changeToken;
    @SerializedName("previousVersionId")
    @Expose
    private String previousVersionId;
    @SerializedName("instanceId")
    @Expose
    private String instanceId;

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getChangeToken() {
        return changeToken;
    }

    public void setChangeToken(String changeToken) {
        this.changeToken = changeToken;
    }

    public String getPreviousVersionId() {
        return previousVersionId;
    }

    public void setPreviousVersionId(String previousVersionId) {
        this.previousVersionId = previousVersionId;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

}
