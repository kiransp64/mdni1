
package com.ariba.data.product;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Instance {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("displayId")
    @Expose
    private String displayId;
    @SerializedName("name")
    @Expose
    private List<Name> name = null;
    @SerializedName("plants")
    @Expose
    private List<Plant> plants = null;
    @SerializedName("type")
    @Expose
    private Type type;
    @SerializedName("baseUnitOfMeasure")
    @Expose
    private BaseUnitOfMeasure baseUnitOfMeasure;
    @SerializedName("procurementAspect")
    @Expose
    private ProcurementAspect procurementAspect;
    @SerializedName("productGroupLocalIdS4")
    @Expose
    private String productGroupLocalIdS4;

    public String getDisplayId() {
        return displayId;
    }

    public void setDisplayId(String displayId) {
        this.displayId = displayId;
    }

    public List<Name> getName() {
        return name;
    }

    public void setName(List<Name> name) {
        this.name = name;
    }

    public List<Plant> getPlants() {
        return plants;
    }

    public void setPlants(List<Plant> plants) {
        this.plants = plants;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public BaseUnitOfMeasure getBaseUnitOfMeasure() {
        return baseUnitOfMeasure;
    }

    public void setBaseUnitOfMeasure(BaseUnitOfMeasure baseUnitOfMeasure) {
        this.baseUnitOfMeasure = baseUnitOfMeasure;
    }

    public ProcurementAspect getProcurementAspect() {
        return procurementAspect;
    }

    public void setProcurementAspect(ProcurementAspect procurementAspect) {
        this.procurementAspect = procurementAspect;
    }

    public String getProductGroupLocalIdS4() {
        return productGroupLocalIdS4;
    }

    public void setProductGroupLocalIdS4(String productGroupLocalIdS4) {
        this.productGroupLocalIdS4 = productGroupLocalIdS4;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
