
package com.ariba.data.product;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProcurementAspect {

    @SerializedName("orderUnit")
    @Expose
    private OrderUnit orderUnit;

    public OrderUnit getOrderUnit() {
        return orderUnit;
    }

    public void setOrderUnit(OrderUnit orderUnit) {
        this.orderUnit = orderUnit;
    }

}
