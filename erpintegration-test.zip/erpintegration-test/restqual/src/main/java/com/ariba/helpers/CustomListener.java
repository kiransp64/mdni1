package com.ariba.helpers;

import org.apache.commons.io.FileUtils;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class CustomListener extends TestListenerAdapter {
    static Map<String, String> errorMap = new LinkedHashMap<>();
    private int m_count = 0;

    @Override
    public void onTestFailure(ITestResult tr) {
        log(tr.getName() + "--Test method failed\n");
        getErrorMap(tr);
    }

    @Override
    public void onTestSkipped(ITestResult tr) {
        log(tr.getName() + "--Test method skipped\n");
        getSkippedMap(tr);
    }

    @Override
    public void onTestSuccess(ITestResult tr) {
        log(tr.getName() + "--Test method success\n");
        getPassedMap(tr);
    }

    @Override
    public void onFinish(ITestContext tr) {
        createEmailableReport();
    }

    private void log(String string) {
        System.out.print(string);
        if (++m_count % 40 == 0) {
            System.out.println("");
        }
    }

    public void getPassedMap(ITestResult tr) {
        Object[] params = tr.getParameters();
        String method;
        method = tr.getMethod().getMethodName();
        if (params.length > 0) {
            method = params[0].toString();

        }
        errorMap.put(method, "Passed");
    }

    public void getSkippedMap(ITestResult result) {
        String error="";
        try {
            error = result.getThrowable().getMessage();

        } catch (Exception e) {
            e.printStackTrace();
            error = "Test skipped with error please check logs";
        }
        Object[] params = result.getParameters();
        String method;
        method = result.getMethod().getMethodName();
        if (params.length > 0) {
            method = params[0].toString();

        }
        errorMap.put(method, error);
    }

    public void getErrorMap(ITestResult result) {
        String error="";
        try {
            error = result.getThrowable().getMessage();

        } catch (Exception e) {
            e.printStackTrace();
            error = "Test skipped with error please check logs";
        }        Object[] params = result.getParameters();
        String method;
        method = result.getMethod().getMethodName();
        if (params.length > 0) {
            method = params[0].toString();

        }
        errorMap.put(method, "Failed : " + error);
    }

    private void createEmailableReport() {
        File htmlTemplateFile = new File("./resources/template.html");
        String htmlString = null;
        try {
            htmlString = FileUtils.readFileToString(htmlTemplateFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
        int totalPass = 0;
        int totalFail = 0;
        int totalSkip = 0;

        for (Map.Entry<String, String> entry : errorMap.entrySet()) {
            if (entry.getValue().toLowerCase().contains("failed")) {
                totalFail = totalFail + 1;
            } else if (entry.getValue().toLowerCase().contains("skipped")) {
                totalSkip = totalSkip + 1;
            } else if (entry.getValue().equalsIgnoreCase("Passed")) {
                totalPass = totalPass + 1;
            }
        }
        StringBuilder buf = new StringBuilder();
        buf.append("<html>" +
                "<body>" +
                "<header>\n" +
                "    <h1 style= \"color: blue;\n" +
                "  font-family: verdana;\n" +
                "  font-size: 100%;\">Test Summary : " + totalPass + " Passed || " + totalFail + " Failed || " + totalSkip + " Skipped </h1>" +
                "</header>" +
                "<table style = \" border: 1px solid #1C6EA4;\n" +
                "  width: 100%;\n" +
                "  text-align: left;\n" +
                "  border-collapse: collapse;\">" +
                "<thead style = \"background: #1C6EA4;\n" +
                "  background: -moz-linear-gradient(top, #5592bb 0%, #327cad 66%, #1C6EA4 100%);\n" +
                "  background: -webkit-linear-gradient(top, #5592bb 0%, #327cad 66%, #1C6EA4 100%);\n" +
                "  background: linear-gradient(to bottom, #5592bb 0%, #327cad 66%, #1C6EA4 100%);\n" +
                "  border-bottom: 2px solid #444444;\">" +
                "<tr style = \"border: 1px solid #AAAAAA;\n\" +\n" +
                "                \"  padding: 3px 2px; font-size: 15px;\n" +
                "  font-weight: bold;\n" +
                "  color: #FFFFFF;\n" +
                "  border-left: 2px solid #D0E4F5;\">" +
                "<th style = \"border: 1px solid #AAAAAA;\n" +
                "  padding: 3px 2px; font-size: 15px;\n" +
                "  font-weight: bold;\n" +
                "  color: #FFFFFF;\n" +
                "  border-left: 2px solid #D0E4F5;\">Test Discription</th>" +
                "<th style = \"border: 1px solid #AAAAAA;\n" +
                "  padding: 3px 2px; font-size: 15px;\n" +
                "  font-weight: bold;\n" +
                "  color: #FFFFFF;\n" +
                "  border-left: 2px solid #D0E4F5;\">Status</th>" +
                "</tr>" + "</thead>");
        for (Map.Entry<String, String> entry : errorMap.entrySet()) {
//            System.out.println(entry.getKey() + "/" + entry.getValue());
//            System.out.println("=============="+entry.getKey().split("!")[0]);
//            System.out.println("=============="+entry.getKey().split("!")[1]);
            StringBuilder common = new StringBuilder();
            buf.append("<tr><td style = \"border: 1px solid #AAAAAA;\n" +
                    " padding: 3px 2px;\">")
                    .append(entry.getKey().split("!")[0]);
            if (entry.getValue().toLowerCase().contains("failed")) {
                common.append("</td><td style = \"border: 1px solid #AAAAAA;\n" +
                        "padding: 3px 2px; color: #ff0000;\">")
                        .append(entry.getValue())
                        .append("</td></tr>");
            } else {
                common.append("</td><td style = \"border: 1px solid #AAAAAA;\n" +
                        "padding: 3px 2px; color: #008000;\">")
                        .append(entry.getValue())
                        .append("</td></tr>");
            }
            buf.append(common);
        }
        buf.append("</table>" +
                "</body>" +
                "</html>");
        String title = "oneMDS Integration Test Report";
        String body = buf.toString();
        htmlString = htmlString.replace("$title", title);
        htmlString = htmlString.replace("$body", body);
        File newHtmlFile = new File("./logs/new.html");
        try {
            FileUtils.writeStringToFile(newHtmlFile, htmlString);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
