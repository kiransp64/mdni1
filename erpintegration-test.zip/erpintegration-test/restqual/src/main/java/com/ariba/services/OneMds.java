package com.ariba.services;

import com.ariba.data.companycode.CompanyCode;
import com.ariba.data.costcenter.CostCenter;
import com.ariba.data.delete.DeleteEntity;
import com.ariba.data.exchangeRate.ExchangeRate;
import com.ariba.data.product.Product;
import com.google.gson.Gson;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.util.List;
import java.util.Map;
import java.util.UUID;


public class OneMds {
    static String tokenUrl = "https://mdi-canary-integration.authentication.sap.hana.ondemand.com/oauth/token";
    static String clientID = "sb-95f299c6-32fc-48aa-ad18-b0d853c391d0!b20799|one-mds-master!b9046";
    static String clientSecret = "88113a05-28c4-4a05-af9b-f661d37e48ff$ZF8DjpO88hbbjAaOduYaqZ5rMffcTL_Hsr7T76DMS74=";
//Below config is for DLab use it for exchange rate
//    static String tokenUrl = "https://ies-onemasterdata.authentication.sap.hana.ondemand.com/oauth/token";
//    static String clientID = "sb-ba10bcbb-f714-4446-87b1-fffe171e3be7!b7121|one-mds-master!b9046";
//    static String clientSecret = "ebfba4aa-5573-4ba8-ba1b-b11698f49e7f$cj0AXJSIhkDAl7jsmNcYwU_e9Ws9yE8PmzbDkyZvI5A=";

    static String companyCodeChangeApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/odm/2.2.0/change/sap.odm.orgunit.CompanyCode";
    static String companyCodeLogApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/odm/2.2.0/log/sap.odm.orgunit.CompanyCode";
    static String costCenterChangeApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/change/sap.odm.finance.costobject.CostCenter";
    static String costCenterLogApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/log/sap.odm.finance.costobject.CostCenter";
    static String productChangeApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/odm/2.3.0/change/sap.odm.product.Product";
    static String productLogApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/odm/2.3.0/log/sap.odm.product.Product";
    static String exchangeRateChangeApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/odm-draft/2.4.0-20210722092204/change/sap.odm.finance.ExchangeRate";
    static String exchangeRateLogApiUrl = "https://one-mds.cfapps.sap.hana.ondemand.com/v0/odm-draft/2.4.0-20210722092204/log/sap.odm.finance.ExchangeRate";


    static String mdiProcessOauthUrl = "https://svcgcpmbdev1mobile.lab-us.gcpint.ariba.com/private/v2/oauth/token";

    private static Logger logger = LogManager.getLogger(OneMds.class);
    static Gson gson = new Gson();

    public static String getToken() {
        RestAssured.baseURI = tokenUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Content-Type", "application/x-www-form-urlencoded");
        requestSpecification.auth().preemptive().basic(clientID, clientSecret);
//        requestSpecification.formParam("client_id", "sb-95f299c6-32fc-48aa-ad18-b0d853c391d0!b20799|one-mds-master!b9046");
        requestSpecification.formParam("grant_type", "client_credentials");
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        String access_token = response.jsonPath().getString("access_token");
        logger.info("Token created : " + access_token);
        return access_token;
    }

    public static void postCompanyCode(String access_token, CompanyCode body) {
        RestAssured.baseURI = companyCodeChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        body.getChangeRequests().get(0).setChangeToken(UUID.randomUUID().toString());
        requestSpecification.body(gson.toJson(body));
        logger.info(body.getChangeRequests().get(0).getOperation()+" company code body : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info(body.getChangeRequests().get(0).getOperation()+" company code response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Unable to post company code to oneMDS (ondMDS issue)");
    }

    public static void postProduct(String access_token, Product body) {
        RestAssured.baseURI = productChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        body.getChangeRequests().get(0).setChangeToken(UUID.randomUUID().toString());
        requestSpecification.body(gson.toJson(body));
        logger.info(body.getChangeRequests().get(0).getOperation()+" product body : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info(body.getChangeRequests().get(0).getOperation()+" product response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Unable to post Product to oneMDS (ondMDS issue)");
    }
    public static void postExchangeRate(String access_token, ExchangeRate body) {
        RestAssured.baseURI = exchangeRateChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        body.getChangeRequests().get(0).setChangeToken(UUID.randomUUID().toString());
        requestSpecification.body(gson.toJson(body));
        logger.info(body.getChangeRequests().get(0).getOperation()+" ExchangeRate body : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info(body.getChangeRequests().get(0).getOperation()+" ExchangeRate response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Unable to post ExchangeRate to oneMDS (ondMDS issue)");
    }

    public static Response getCompanyCode(String access_token) {
        RestAssured.baseURI = companyCodeLogApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        Response response = requestSpecification.relaxedHTTPSValidation().get();
        logger.info("Get companyCode response : " + response.asString());
        Assert.assertEquals(response.statusCode(),200,"Failed to get company code from oneMDS (ondMDS issue)");
        return response;
    }

    public static Response getProduct(String access_token) {
        RestAssured.baseURI = productLogApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        Response response = requestSpecification.relaxedHTTPSValidation().get();
        logger.info("Get Product response : " + response.asString());
        Assert.assertEquals(response.statusCode(),200,"Failed to get product from oneMDS (ondMDS issue)");
        return response;
    }

    public static Response getCompanyCode(String access_token, String since) {
        RestAssured.baseURI = companyCodeLogApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        if (since!=null){
            requestSpecification.queryParam("since", since);
        }
        Response response = requestSpecification.relaxedHTTPSValidation().get();
        logger.info("Get companyCode response : " + response.asString());
        Assert.assertEquals(response.statusCode(),200,"Failed to get company code from oneMDS (ondMDS issue)");
        return response;
    }
    public static Response getProduct(String access_token, String since) {
        RestAssured.baseURI = productLogApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        if (since!=null){
            requestSpecification.queryParam("since", since);
        }
        Response response = requestSpecification.relaxedHTTPSValidation().get();
        logger.info("Get product response : " + response.asString());
        Assert.assertEquals(response.statusCode(),200,"Failed to get company code from oneMDS (ondMDS issue)");
        return response;
    }
    public static Response getExchangeRate(String access_token, String since) {
        RestAssured.baseURI = exchangeRateLogApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        if (since!=null){
            requestSpecification.queryParam("since", since);
        }
        Response response = requestSpecification.relaxedHTTPSValidation().get();
        logger.info("Get ExchangeRate response : " + response.asString());
        Assert.assertEquals(response.statusCode(),200,"Failed to get ExchangeRate from oneMDS (ondMDS issue)");
        return response;
    }


    public static void postCostCenter(String access_token, CostCenter body) {
        RestAssured.baseURI = costCenterChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        requestSpecification.body(gson.toJson(body));
        logger.info(body.getChangeRequests().get(0).getOperation()+" costcenter body : " + gson.toJson(body));
        Response response = requestSpecification.post();
        logger.info(body.getChangeRequests().get(0).getOperation()+" costcenter response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Failed to post Cost Center to oneMDS (ondMDS issue)");
    }

    public static void postCostCenter(String access_token, List<CostCenter> costCenterList) {
        for (CostCenter c : costCenterList) {
            postCostCenter(access_token, c);
        }
    }

    public static void postCompanyCode(String access_token, List<CompanyCode> companyCodeList) {
        for (CompanyCode c : companyCodeList) {
            postCompanyCode(access_token, c);
        }
    }
    public static void postProduct(String access_token, List<Product> productList) {
        for (Product c : productList) {
            postProduct(access_token, c);
        }
    }
    public static void postExchangeRate(String access_token, List<ExchangeRate> exchangeRateList) {
        for (ExchangeRate c : exchangeRateList) {
            postExchangeRate(access_token, c);
        }
    }

    public static Response getCostCenter(String access_token) {
        RestAssured.baseURI = costCenterLogApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        Response response = requestSpecification.relaxedHTTPSValidation().get();
        logger.info("Get cost center response : " + response.asString());
        Assert.assertEquals(response.statusCode(),200,"Failed to get CostCenter from oneMDS (ondMDS issue)");
        return response;
    }

    public static Response getCostCenter(String access_token, String since) {
        RestAssured.baseURI = costCenterLogApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        if (since!=null){
            requestSpecification.queryParam("since", since);
        }
        Response response = requestSpecification.relaxedHTTPSValidation().get();
//        logger.info("Get cost center response since : " + since);
        logger.info("Get cost center response : " + response.asString());
        Assert.assertEquals(response.statusCode(),200,"Failed to get CostCenter from oneMDS (ondMDS issue)");
        return response;
    }

    public static void deleteCostCenter(String access_token, DeleteEntity body) {
        RestAssured.baseURI = costCenterChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        requestSpecification.body(body);
        logger.info("Delete cost center payload : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
//        logger.info("Delete cost center response code : " + response.statusCode());
        logger.info("Delete cost center response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Failed to delete CostCenter from oneMDS (ondMDS issue)");

    }
    public static String getOauthForMdiProcess() {
        RestAssured.baseURI = mdiProcessOauthUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Basic ZXJwbmF0aXZlaW50Z3N2Yy0ybG8tY2xpZW50OmVycG5hdGl2ZWludGdzdmNwcml2YXRl");
        requestSpecification.queryParam("scope","erpnativeintgsvc:fetchdata");
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info("Mdi process gt token response : " + response.asString());
        String access_token = response.jsonPath().getString("access_token");
        logger.info("Token created for mdi process: " + access_token);
        return access_token;
    }

    public static void deleteCompanyCode(String access_token, DeleteEntity body) {
        RestAssured.baseURI = companyCodeChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        requestSpecification.body(body);
        logger.info("Delete company code payload : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info("Delete company code response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Failed to delete Company code from oneMDS (ondMDS issue)");
    }
    public static void deleteCompanyCodeCleanUP(String access_token, String body) {
        RestAssured.baseURI = companyCodeChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        requestSpecification.body(body);
        logger.info("Delete company code payload : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info("Delete company code response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Failed to delete Company code from oneMDS (ondMDS issue)");
    }
    public static void deleteProduct(String access_token, DeleteEntity body) {
        RestAssured.baseURI = productChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        requestSpecification.body(body);
        logger.info("Delete Product payload : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info("Delete Product response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Failed to delete Product from oneMDS (ondMDS issue)");

    }
    public static void deleteExchangeRate(String access_token, DeleteEntity body) {
        RestAssured.baseURI = exchangeRateChangeApiUrl;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.header("Authorization", "Bearer " + access_token);
        requestSpecification.headers("Content-Type", "application/json");
        requestSpecification.body(body);
        logger.info("Delete ExchangeRate payload : " + gson.toJson(body));
        Response response = requestSpecification.relaxedHTTPSValidation().post();
        logger.info("Delete ExchangeRate response : " + response.asString());
        Assert.assertEquals(response.statusCode(),202,"Failed to delete ExchangeRate from oneMDS (ondMDS issue)");

    }
    public static void deleteCostCenter(String access_token, Map<String, DeleteEntity> deleteEntityMap) {
        for (Map.Entry<String, DeleteEntity> entry : deleteEntityMap.entrySet()) {
            deleteCostCenter(access_token, entry.getValue());
        }
    }

    public static void deleteCompanyCode(String access_token, Map<String, DeleteEntity> deleteEntityMap) {
        for (Map.Entry<String, DeleteEntity> entry : deleteEntityMap.entrySet()) {
            deleteCompanyCode(access_token, entry.getValue());
        }
    }
    public static void deleteProduct(String access_token, Map<String, DeleteEntity> deleteEntityMap) {
        for (Map.Entry<String, DeleteEntity> entry : deleteEntityMap.entrySet()) {
            deleteProduct(access_token, entry.getValue());
        }
    }

    public static void deleteExchangeRate(String access_token, Map<String, DeleteEntity> deleteEntityMap) {
        for (Map.Entry<String, DeleteEntity> entry : deleteEntityMap.entrySet()) {
            deleteExchangeRate(access_token, entry.getValue());
        }
    }
    public static void deleteEntity(String entity, Map<String, DeleteEntity> deleteEntityMap, String access_token) {
        switch (entity.toLowerCase()) {
            case "costcenter":
                deleteCostCenter(access_token, deleteEntityMap);
                break;
            case "companycode":
                deleteCompanyCode(access_token, deleteEntityMap);
                break;
            case "product":
                deleteProduct(access_token, deleteEntityMap);
                break;
            case "exchangerate":
                deleteExchangeRate(access_token, deleteEntityMap);
                break;
        }
    }
}
