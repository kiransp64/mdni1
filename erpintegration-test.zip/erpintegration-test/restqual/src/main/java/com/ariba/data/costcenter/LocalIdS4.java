
package com.ariba.data.costcenter;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LocalIdS4 {

    @SerializedName("companyCode")
    @Expose
    private String companyCode;
    @SerializedName("costCenterId")
    @Expose
    private String costCenterId;
    @SerializedName("controllingArea")
    @Expose
    private String controllingArea;

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCostCenterId() {
        return costCenterId;
    }

    public void setCostCenterId(String costCenterId) {
        this.costCenterId = costCenterId;
    }

    public String getControllingArea() {
        return controllingArea;
    }

    public void setControllingArea(String controllingArea) {
        this.controllingArea = controllingArea;
    }

}
