
package com.ariba.data.companycode;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CompanyCode {

    @SerializedName("changeRequests")
    @Expose
    private List<ChangeRequest> changeRequests = null;

    public List<ChangeRequest> getChangeRequests() {
        return changeRequests;
    }

    public void setChangeRequests(List<ChangeRequest> changeRequests) {
        this.changeRequests = changeRequests;
    }

}
