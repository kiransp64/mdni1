package com.ariba.materialmastertests;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.RandomStringUtils;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.Constants;
import com.ariba.helpers.MDSSearchHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.SCIMHelper;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class materialmastertestsSuiteIntegrated {

	public static String SAP_ANID = "AN02001164948";
	String endPointURL = "https://itg.cobalt.ariba.com/mdnigcpies01/erpintegration/api/uploadXMLData?tenantId=" + SAP_ANID
			+ "&objectName=";
	String integrationJobURL = "https://itg.cobalt.ariba.com/mdnigcpies01/erpintegration/api/integrationJobs?tenantId=" + SAP_ANID
			+ "&objectName=";
	String SearchBaseURL = "https://itg.cobalt.ariba.com/gcpies01mds/mds/api";
	String APP_URL = "https://svcgcpies01ss.lab-us.gcpint.ariba.com/";
	public static String SAP_REALM = "accAcwSap";
	public static String SAP_USERNAME = "arooney";
	public static String ORIGIN_SYS = "Buyer";
	public static String KEYS = "UniqueName,\"Active\",PartitionNumber";

	OAuthHelper oauthHelper = new OAuthHelper();
	SCIMHelper scimHelper = new SCIMHelper();
	MDSSearchHelper searchHelper = new MDSSearchHelper();

	@Test
	public void incoTermsWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		System.out.print("UniqueName : "+getRandomString+"\n");

		IncoTermBodyPayload = IncoTermBodyPayload.replace("XXX", getRandomString);
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "Incoterms");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Incoterms" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.common.core.IncoTerms", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"IncoTerm with uniquename " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"IncoTerm with uniquename " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "incoterms?$filter=IncoTermsKey.UniqueName='" + getRandomString
				+ "'&$expand=IncoTermsLangAssociation";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("IncoTermsLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("IncoTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"IncoTerm with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("IncoTermsLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("IncoTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"IncoTerm with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void PaymentTermsWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String IncoTermBodyPayload = getData("testMDNIPaymentTermsWithActionCode01");
		String getRandomString = RandomStringUtils.randomNumeric(4);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("TT11", getRandomString);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("11111", getRandomString);
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PaymentTerms", IncoTermBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PaymentTerms");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PaymentTerms" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.payment.core.PaymentTerms", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PaymentTerms with uniquename " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PaymentTerms with uniquename " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "paymentterms?$filter=PaymentTermsKey.UniqueName='" + getRandomString +"'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("PaymentTermsLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PaymentTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PaymentTerms with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("PaymentTermsLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PaymentTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PaymentTerms with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void PaymentTermsWithSenderSystemBusinessIdIncreamental() throws Exception {

		/* Generating access token */
		/*Calling Full Laod*/
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String IncoTermBodyPayload = getData("testMDNIPaymentTermsWithActionCode01");

		String getRandomString = RandomStringUtils.randomNumeric(4);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("TT11", getRandomString);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("11111", getRandomString);
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PaymentTerms", IncoTermBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PaymentTerms");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PaymentTerms" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Increamental Load*/
		IncoTermBodyPayload = getData("testMDNIPaymentTermsWithActionCode02");
		IncoTermBodyPayload = IncoTermBodyPayload.replace("TT11", getRandomString);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("11111", getRandomString);
		response = retrieveStatusFromAPI(endPointURL + "PaymentTerms", IncoTermBodyPayload);
		response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		jobID = verifySuccessResponse(response1, "PaymentTerms");
		Thread.sleep(100000);
		responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PaymentTerms" + "&jobId=" + jobID);
		responseIntegrationJob = responseIntegrationJob1.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJob);
		jsonObject = json.getAsJsonObject();
		NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.payment.core.PaymentTerms", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PaymentTerms with uniquename " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PaymentTerms with uniquename " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "paymentterms?$filter=PaymentTermsKey.UniqueName='" + getRandomString +"'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("PaymentTermsLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PaymentTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PaymentTerms with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("PaymentTermsLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PaymentTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PaymentTerms with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void PlantPurchaseOrgComboWithSenderSystemBusinessId() throws Exception {
		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String addressBodyPayload = getData("testMDNIPlantWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		addressBodyPayload = addressBodyPayload.replace("XXX", getRandomString);
		addressBodyPayload = addressBodyPayload.replace("1111", getRandomInt);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", addressBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "Plant");

		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Plant" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomInt, "ariba.common.core.Address", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0, "Address with ID " + getRandomInt + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"Address with ID " + getRandomInt + " is not active in buyer");


		/*PurchaseOrg*/

		String purchaseOrgBodyPayload = getData("testMDNIPurchaseOrgWithActionCode01");
		String getRandomString1 = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt1 = getRandomint(4);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("XXX", getRandomString1);

		RestResponse response11 = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", purchaseOrgBodyPayload);
		String response2 = response11.getContent();
		Assert.assertEquals(response11.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response11.getCode());
		String jobID1 = verifySuccessResponse(response2, "PurchasingOrg");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob2 = getStatusAPI(integrationJobURL + "PurchasingOrg" + "&jobId=" + jobID1);
		String responseIntegrationJob11 = responseIntegrationJob2.getContent();
		JsonParser parser1 = new JsonParser();
		JsonElement json1 = parser1.parse(responseIntegrationJob11);
		JsonObject jsonObject1 = json1.getAsJsonObject();
		int NoOfRecordsUpdated1 = jsonObject1.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted1 = jsonObject1.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated1 + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted1 + "\n");

		Assert.assertTrue(NoOfRecordsUpdated1 == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString1 + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted1 == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString1 + " is not correct");

		/* Verifying data in Oracle database */

		String data1 = verifyOraclePushData(getRandomString1, "ariba.core.PurchaseOrg", token);
		System.out.print("DataOutput is : " + data1 + "\n");

		String buyerDataArray1[] = data1.split(",");
		Assert.assertTrue(buyerDataArray1.length > 0,
				"PurchasingOrg with UniqueName " + getRandomString1 + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray1[4] + "\n");
		Assert.assertTrue(buyerDataArray1[4].equals("true"),
				"PurchasingOrg with UniqueName " + getRandomString1 + " is not active in buyer");


		/* CREATING PLANTPORGCOMBO WITH ABOVE CREATED PORG AND PLANT*/

		String BodyPayload = getData("testMDNIPlantPurchaseOrgComboWithActionCode01");

		BodyPayload = BodyPayload.replace("XXXXX", getRandomString1);
		BodyPayload = BodyPayload.replace("YYYYY", getRandomString);

		RestResponse response3 = retrieveStatusFromAPI(endPointURL + "PlantPurchasingOrg", BodyPayload);
		String response4 = response3.getContent();
		Assert.assertEquals(response3.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response3.getCode());
		String jobID3 = verifySuccessResponse(response4, "PlantPurchasingOrg");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob3 = getStatusAPI(integrationJobURL + "PlantPurchasingOrg" + "&jobId=" + jobID3);
		String responseIntegrationJob4 = responseIntegrationJob3.getContent();
		JsonParser parser2 = new JsonParser();
		JsonElement json2 = parser2.parse(responseIntegrationJob4);
		JsonObject jsonObject2 = json2.getAsJsonObject();
		int NoOfRecordsUpdated2 = jsonObject2.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted2 = jsonObject2.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated2 + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted2 + "\n");

		Assert.assertTrue(NoOfRecordsUpdated2 == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString1 + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted2 == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString1 + " is not correct");

		/* Verifying data in HANA database */

		/* Verifying without x-senderBusinessId */

		String url = "plantpurchaseorgcombo?$filter=PlantPurchaseOrgComboKey.PurchaseOrg='" + getRandomString1
				+ "'&PlantPurchaseOrgComboKey.Address='" + getRandomString1 +"'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PlantPurchaseOrgComboKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PlantPurchaseOrg with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PlantPurchaseOrgComboKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PlantPurchaseOrg with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void addressWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String addressBodyPayload = getData("testMDNIPlantWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		addressBodyPayload = addressBodyPayload.replace("XXX", getRandomString);
		addressBodyPayload = addressBodyPayload.replace("1111", getRandomInt);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", addressBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "Plant");

		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Plant" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomInt, "ariba.common.core.Address", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0, "Address with ID " + getRandomInt + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"Address with ID " + getRandomInt + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "addresses?$filter=CommonAddressKey.UniqueName='" + getRandomInt + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("CommonAddressKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"Address with ID " + getRandomInt + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("CommonAddressKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"Address with ID " + getRandomInt + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void companyCodeWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String companycodeBodyPayload = getData("testMDNICompanyCodeWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		companycodeBodyPayload = companycodeBodyPayload.replace("XXX", getRandomString);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "CompanyCode", companycodeBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "CompanyCode");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "CompanyCode" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.core.CompanyCode", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"CompanyCode with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"CompanyCode with UniqueName " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "companycodes?$filter=CompanyCodeKey.UniqueName='" + getRandomString + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("CompanyCodeKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"CompanyCode with UniqueName " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("CompanyCodeKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"CompanyCode with UniqueName " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void purchaseOrgWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String purchaseOrgBodyPayload = getData("testMDNIPurchaseOrgWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("XXX", getRandomString);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", purchaseOrgBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PurchasingOrg");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchasingOrg" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.core.PurchaseOrg", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PurchasingOrg with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PurchasingOrg with UniqueName " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "purchseorgs?$filter=PurchaseOrgKey.UniqueName='" + getRandomString + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PurchaseOrgKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PurchaseOrgKey with UniqueName " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PurchaseOrgKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PurchaseOrgKey with UniqueName " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}
	@Test
	public void ItemCategoryWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String purchaseOrgBodyPayload = getData("testMDNIItemCategoryWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(1);
		String getRandomInt = getRandomint(4);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("AAAAA", getRandomString);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchaseDocumentItemCategory", purchaseOrgBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PurchaseDocumentItemCategory");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchaseDocumentItemCategory" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.core.ItemCategory", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PurchasingOrg with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PurchasingOrg with UniqueName " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "itemcategory?$filter=ItemCategoryKey.UniqueName='" + getRandomString + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("ItemCategoryLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("ItemCategoryKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"ItemCategory with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("ItemCategoryLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("ItemCategoryKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"ItemCategory with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void purchaseGroupWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String purchaseGrpBodyPayload = getData("testMDNIPurchaseGroupWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(5);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("XXX", getRandomString);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("11111", getRandomString);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingGroup", purchaseGrpBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PurchasingGroup");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchasingGroup" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.core.PurchaseGroup", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PurchaseGroup with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PurchaseGroup with UniqueName " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "purchasegroups?$filter=PurchaseGroupKey.UniqueName='" + getRandomString + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PurchaseGroupKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PurchasingGroup with UniqueName " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PurchaseGroupKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PurchasingGroup with UniqueName " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void MaterialGroupWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String BodyPayload = getData("testMDNIPartitionedCommodityCodeWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(5);
		// BodyPayload = BodyPayload.replace("XXX", getRandomString);
		BodyPayload = BodyPayload.replace("11111", getRandomInt);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "MaterialGroup", BodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "MaterialGroup");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "MaterialGroup" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomInt, "ariba.common.core.PartitionedCommodityCode", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PartitionedCommodityCode with UniqueName " + getRandomInt + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PartitionedCommodityCode with UniqueName " + getRandomInt + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "partitionedcommoditycodes?$filter=PartitionedCommodityCodeKey.UniqueName='" + getRandomInt + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("PartitionedCommodityCodeLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PartitionedCommodityCodeKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PartitionedCommodityCode with Name " + getRandomInt + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("PartitionedCommodityCodeLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PartitionedCommodityCodeKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PartitionedCommodityCode with Name " + getRandomInt + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void ItemMasterWithSenderSystemBusinessId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String BodyPayload = getData("testMDNIItemMasterWithIncreamentalLoad");
		String  getRandomString =  RandomStringUtils.randomAlphanumeric(7);
		BodyPayload = BodyPayload.replace("XXXXX", getRandomString);

		RestResponse response = retrieveStatusFromAPI(
				endPointURL+"Product",
				BodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same Expected 200 and Actual "+response.getCode());
		String jobID = verifySuccessResponse(response1, "Product");
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(
				integrationJobURL+"Product" +"&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : "+ NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : "+ NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0, "NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1, "NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database

		String data = verifyOraclePushData(getRandomString,"ariba.common.core.PartitionedCommodityCode", token);
		System.out.print("DataOutput is : "+ data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0, "PartitionedCommodityCode with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : "+ buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"), "PartitionedCommodityCode with UniqueName " + getRandomString + " is not active in buyer");
		*/
		/* Verifying data in MDS Database*/
		/* Verifying without  x-senderBusinessId */

		String url = "itemmaster?$filter=ItemMasterKey.ProductInternalID='" + getRandomString+ "'";

		/* Verifying with  x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : "+ content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("ItemMasterLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("ItemMasterKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"ItemMaster with UniqueName " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}


	@Test
	public void incoTermsWithSenderSystemBusinessIdIncremental() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		/* Making Full load */
		String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("XXX", getRandomString);
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "Incoterms");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Incoterms" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Making incremental load */
		IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode02");
		IncoTermBodyPayload = IncoTermBodyPayload.replace("XXX", getRandomString);
		response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		jobID = verifySuccessResponse(response.getContent(), "Incoterms");
		Thread.sleep(5000);
		responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Incoterms" + "&jobId=" + jobID);
		json = parser.parse(responseIntegrationJob1.getContent());
		jsonObject = json.getAsJsonObject();
		NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct for incremental load");
		Assert.assertTrue(NoOfRecordsInserted == 0,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct for incremental load");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.common.core.IncoTerms", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"IncoTerm with uniquename " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"IncoTerm with uniquename " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "incoterms?$filter=IncoTermsKey.UniqueName='" + getRandomString
				+ "'&$expand=IncoTermsLangAssociation";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("IncoTermsLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("IncoTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"IncoTerm with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("IncoTermsLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("IncoTermsKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"IncoTerm with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void addressWithSenderSystemBusinessIdIncremental() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		/* Making full load */
		String addressBodyPayload = getData("testMDNIPlantWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		addressBodyPayload = addressBodyPayload.replace("XXX", getRandomString);
		addressBodyPayload = addressBodyPayload.replace("1111", getRandomInt);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", addressBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "Plant");

		Thread.sleep(5000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Plant" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Making incremental load */
		addressBodyPayload = getData("testMDNIPlantWithActionCode02");
		addressBodyPayload = addressBodyPayload.replace("XXX", getRandomString);
		addressBodyPayload = addressBodyPayload.replace("1111", getRandomInt);

		response = retrieveStatusFromAPI(endPointURL + "Plant", addressBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		jobID = verifySuccessResponse(response.getContent(), "Plant");

		Thread.sleep(5000);
		responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Plant" + "&jobId=" + jobID);
		json = parser.parse(responseIntegrationJob1.getContent());
		jsonObject = json.getAsJsonObject();
		NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomInt, "ariba.common.core.Address", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0, "Address with ID " + getRandomInt + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"Address with ID " + getRandomInt + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "addresses?$filter=CommonAddressKey.UniqueName='" + getRandomInt + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("CommonAddressKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"Address with ID " + getRandomInt + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("CommonAddressKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"Address with ID " + getRandomInt + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void purchaseOrgWithSenderSystemBusinessIdIncremental() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		/* Making full load */
		String purchaseOrgBodyPayload = getData("testMDNIPurchaseOrgWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("XXX", getRandomString);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", purchaseOrgBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PurchasingOrg");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchasingOrg" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Making incremental load */
		purchaseOrgBodyPayload = getData("testMDNIPurchaseOrgWithActionCode02");
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("XXX", getRandomString);

		response = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", purchaseOrgBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		jobID = verifySuccessResponse(response.getContent(), "PurchasingOrg");
		Thread.sleep(5000);
		responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchasingOrg" + "&jobId=" + jobID);
		json = parser.parse(responseIntegrationJob1.getContent());
		jsonObject = json.getAsJsonObject();
		NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.core.PurchaseOrg", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PurchasingOrg with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PurchasingOrg with UniqueName " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "purchseorgs?$filter=PurchaseOrgKey.UniqueName='" + getRandomString + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PurchaseOrgKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PurchaseOrgKey with UniqueName " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PurchaseOrgKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PurchaseOrgKey with UniqueName " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void purchaseGroupWithSenderSystemBusinessIdIncremental() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		/* Making Full load call */
		String purchaseGrpBodyPayload = getData("testMDNIPurchaseGroupWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("XXX", getRandomString);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("11111", getRandomString);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingGroup", purchaseGrpBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PurchasingGroup");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchasingGroup" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Making incremental load call */
		purchaseGrpBodyPayload = getData("testMDNIPurchaseGroupWithActionCode02");
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("XXX", getRandomString);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("11111", getRandomString);

		response = retrieveStatusFromAPI(endPointURL + "PurchasingGroup", purchaseGrpBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		jobID = verifySuccessResponse(response.getContent(), "PurchasingGroup");
		Thread.sleep(5000);
		responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchasingGroup" + "&jobId=" + jobID);
		json = parser.parse(responseIntegrationJob1.getContent());
		jsonObject = json.getAsJsonObject();
		NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct for incremental load");
		Assert.assertTrue(NoOfRecordsInserted == 0,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct for increemntal load");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.core.PurchaseGroup", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PurchaseGroup with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PurchaseGroup with UniqueName " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "purchasegroups?$filter=PurchaseGroupKey.UniqueName='" + getRandomString + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PurchaseGroupKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PurchasingGroup with UniqueName " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PurchaseGroupKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PurchasingGroup with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void MaterialGroupWithSenderSystemBusinessIdIncremental() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		/* Making full load call */
		String BodyPayload = getData("testMDNIPartitionedCommodityCodeWithActionCode01");
		String getRandomInt = getRandomint(5);
		BodyPayload = BodyPayload.replace("11111", getRandomInt);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "MaterialGroup", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "MaterialGroup");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "MaterialGroup" + "&jobId=" + jobID);
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob1.getContent());
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Making incremental load call */
		BodyPayload = getData("testMDNIPartitionedCommodityCodeWithActionCode02");
		BodyPayload = BodyPayload.replace("11111", getRandomInt);

		response = retrieveStatusFromAPI(endPointURL + "MaterialGroup", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		jobID = verifySuccessResponse(response.getContent(), "MaterialGroup");
		Thread.sleep(5000);
		responseIntegrationJob1 = getStatusAPI(integrationJobURL + "MaterialGroup" + "&jobId=" + jobID);
		json = parser.parse(responseIntegrationJob1.getContent());
		jsonObject = json.getAsJsonObject();
		NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomInt, "ariba.common.core.PartitionedCommodityCode", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PartitionedCommodityCode with UniqueName " + getRandomInt + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PartitionedCommodityCode with UniqueName " + getRandomInt + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "partitionedcommoditycodes?$filter=PartitionedCommodityCodeKey.UniqueName='" + getRandomInt + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("PartitionedCommodityCodeLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PartitionedCommodityCodeKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PartitionedCommodityCode with Name " + getRandomInt + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("PartitionedCommodityCodeLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PartitionedCommodityCodeKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PartitionedCommodityCode with Name " + getRandomInt + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void ItemCategoryWithSenderSystemBusinessIdIncremental() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		/* Making full load call */
		String purchaseOrgBodyPayload = getData("testMDNIItemCategoryWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(1);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("AAAAA", getRandomString);

		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchaseDocumentItemCategory", purchaseOrgBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "PurchaseDocumentItemCategory");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchaseDocumentItemCategory" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		/* Making incremental load call */
		purchaseOrgBodyPayload = getData("testMDNIItemCategoryWithActionCode02");
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("AAAAA", getRandomString);

		response = retrieveStatusFromAPI(endPointURL + "PurchaseDocumentItemCategory", purchaseOrgBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		jobID = verifySuccessResponse(response.getContent(), "PurchaseDocumentItemCategory");
		Thread.sleep(5000);
		responseIntegrationJob1 = getStatusAPI(integrationJobURL + "PurchaseDocumentItemCategory" + "&jobId=" + jobID);
		json = parser.parse(responseIntegrationJob1.getContent());
		jsonObject = json.getAsJsonObject();
		NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomString + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,
				"NoOfRecordsInserted with uniquename " + getRandomString + " is not correct");

		/* Verifying data in Oracle database */

		String data = verifyOraclePushData(getRandomString, "ariba.core.ItemCategory", token);
		System.out.print("DataOutput is : " + data + "\n");

		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0,
				"PurchasingOrg with UniqueName " + getRandomString + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"PurchasingOrg with UniqueName " + getRandomString + " is not active in buyer");

		/* Verifying data in MDS Database */
		/* Verifying without x-senderBusinessId */

		String url = "itemcategory?$filter=ItemCategoryKey.UniqueName='" + getRandomString + "'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content).getJSONObject(0).getJSONArray("ItemCategoryLangAssociation");
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("ItemCategoryKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"ItemCategory with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2).getJSONObject(0).getJSONArray("ItemCategoryLangAssociation");
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("ItemCategoryKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"ItemCategory with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void PlantPurchaseOrgComboWithSenderSystemBusinessIdIncremental() throws Exception {
		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		/* Plant */
		String addressBodyPayload = getData("testMDNIPlantWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		addressBodyPayload = addressBodyPayload.replace("XXX", getRandomString);
		addressBodyPayload = addressBodyPayload.replace("1111", getRandomInt);
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", addressBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "Plant");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + "Plant" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");
		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomInt + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomInt + " is not correct");

		/* Verifying data in Oracle database */
		String data = verifyOraclePushData(getRandomInt, "ariba.common.core.Address", token);
		System.out.print("DataOutput is : " + data + "\n");
		String buyerDataArray[] = data.split(",");
		Assert.assertTrue(buyerDataArray.length > 0, "Address with ID " + getRandomInt + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray[4] + "\n");
		Assert.assertTrue(buyerDataArray[4].equals("true"),
				"Address with ID " + getRandomInt + " is not active in buyer");

		/*PurchaseOrg*/
		String purchaseOrgBodyPayload = getData("testMDNIPurchaseOrgWithActionCode01");
		String getRandomString1 = RandomStringUtils.randomAlphanumeric(3);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("XXX", getRandomString1);
		RestResponse response11 = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", purchaseOrgBodyPayload);
		String response2 = response11.getContent();
		Assert.assertEquals(response11.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response11.getCode());
		String jobID1 = verifySuccessResponse(response2, "PurchasingOrg");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob2 = getStatusAPI(integrationJobURL + "PurchasingOrg" + "&jobId=" + jobID1);
		String responseIntegrationJob11 = responseIntegrationJob2.getContent();
		JsonParser parser1 = new JsonParser();
		JsonElement json1 = parser1.parse(responseIntegrationJob11);
		JsonObject jsonObject1 = json1.getAsJsonObject();
		int NoOfRecordsUpdated1 = jsonObject1.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted1 = jsonObject1.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated1 + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted1 + "\n");
		Assert.assertTrue(NoOfRecordsUpdated1 == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString1 + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted1 == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString1 + " is not correct");

		/* Verifying data in Oracle database */
		String data1 = verifyOraclePushData(getRandomString1, "ariba.core.PurchaseOrg", token);
		System.out.print("DataOutput is : " + data1 + "\n");
		String buyerDataArray1[] = data1.split(",");
		Assert.assertTrue(buyerDataArray1.length > 0,
				"PurchasingOrg with UniqueName " + getRandomString1 + " not found in buyer");
		System.out.print("DataOutput is : " + buyerDataArray1[4] + "\n");
		Assert.assertTrue(buyerDataArray1[4].equals("true"),
				"PurchasingOrg with UniqueName " + getRandomString1 + " is not active in buyer");


		/* CREATING PLANTPORGCOMBO WITH ABOVE CREATED PORG AND PLANT full load*/
		String BodyPayload = getData("testMDNIPlantPurchaseOrgComboWithActionCode01");
		BodyPayload = BodyPayload.replace("XXXXX", getRandomString1);
		BodyPayload = BodyPayload.replace("YYYYY", getRandomString);
		RestResponse response3 = retrieveStatusFromAPI(endPointURL + "PlantPurchasingOrg", BodyPayload);
		String response4 = response3.getContent();
		Assert.assertEquals(response3.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response3.getCode());
		String jobID3 = verifySuccessResponse(response4, "PlantPurchasingOrg");
		Thread.sleep(5000);
		RestResponse responseIntegrationJob3 = getStatusAPI(integrationJobURL + "PlantPurchasingOrg" + "&jobId=" + jobID3);
		String responseIntegrationJob4 = responseIntegrationJob3.getContent();
		JsonParser parser2 = new JsonParser();
		JsonElement json2 = parser2.parse(responseIntegrationJob4);
		JsonObject jsonObject2 = json2.getAsJsonObject();
		int NoOfRecordsUpdated2 = jsonObject2.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted2 = jsonObject2.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated2 + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted2 + "\n");
		Assert.assertTrue(NoOfRecordsUpdated2 == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomString1 + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted2 == 1,
				"NoOfRecordsInserted with uniquename " + getRandomString1 + " is not correct");

		/* CREATING PLANTPORGCOMBO WITH ABOVE CREATED PORG AND PLANT incremental load*/
		BodyPayload = getData("testMDNIPlantPurchaseOrgComboWithActionCode02");
		BodyPayload = BodyPayload.replace("XXXXX", getRandomString1);
		BodyPayload = BodyPayload.replace("YYYYY", getRandomString);
		response3 = retrieveStatusFromAPI(endPointURL + "PlantPurchasingOrg", BodyPayload);
		Assert.assertEquals(response3.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response3.getCode());
		jobID3 = verifySuccessResponse(response3.getContent(), "PlantPurchasingOrg");
		Thread.sleep(5000);
		responseIntegrationJob3 = getStatusAPI(integrationJobURL + "PlantPurchasingOrg" + "&jobId=" + jobID3);
		json2 = parser2.parse(responseIntegrationJob3.getContent());
		jsonObject2 = json2.getAsJsonObject();
		NoOfRecordsUpdated2 = jsonObject2.get("RecordsUpdated").getAsInt();
		NoOfRecordsInserted2 = jsonObject2.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated2 + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted2 + "\n");
		Assert.assertTrue(NoOfRecordsUpdated2 == 1,
				"NoOfRecordsUpdated with uniquename " + getRandomString1 + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted2 == 0,
				"NoOfRecordsInserted with uniquename " + getRandomString1 + " is not correct");

		/* Verifying data in HANA database */
		/* Verifying without x-senderBusinessId */
		String url = "plantpurchaseorgcombo?$filter=PlantPurchaseOrgComboKey.PurchaseOrg='" + getRandomString1
				+ "'&PlantPurchaseOrgComboKey.Address='" + getRandomString1 +"'";
		RestResponse res = searchHelper.searchEntityWithSearchURL(token, url, SearchBaseURL);
		String content = res.getContent();

		System.out.print("MDSSearch  is : " + content + "\n");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		String senderBusinessSystemId = hanaArray.getJSONObject(0).get("PlantPurchaseOrgComboKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId, "NULL",
				"PlantPurchaseOrg with Name " + getRandomString + " not found in MDS Search");

		/* Verifying with x-senderBusinessId */
		RestResponse res2 = searchHelper.searchEntityWithsenderBusinessId(token, url, SearchBaseURL, "ER9_001");
		String content2 = res2.getContent();
		System.out.print("MDSSearch  is : " + content2 + "\n");
		Assert.assertNotNull(content2, "Null response obtained");
		Assert.assertEquals(200, res2.getCode(), "Response code is not matching");
		JSONArray hanaArray2 = new JSONArray(content2);
		String senderBusinessSystemId1 = hanaArray2.getJSONObject(0).get("PlantPurchaseOrgComboKey.SenderBusinessSystemId").toString();
		Assert.assertEquals(senderBusinessSystemId1, "ER9_001",
				"PlantPurchaseOrg with Name " + getRandomString + " and having senderBusinessSystemId not found in MDS Search");
	}

	@Test
	public void incoTermsWithoutSenderSystemBusinessId() throws Exception {

		String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("XXX", getRandomString);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());


	}

	@Test
	public void incoTermsWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode02");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("XXX", getRandomString);
		IncoTermBodyPayload = IncoTermBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());

	}


	@Test
	public void addressWithoutSenderSystemBusinessId() throws Exception {

		/* Making full load */
		String addressBodyPayload = getData("testMDNIPlantWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		addressBodyPayload = addressBodyPayload.replace("XXX", getRandomString);
		addressBodyPayload = addressBodyPayload.replace("1111", getRandomInt);
		addressBodyPayload = addressBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", addressBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());

	}

	@Test
	public void addressWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		/* Making full load */
		String addressBodyPayload = getData("testMDNIPlantWithActionCode02");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		String getRandomInt = getRandomint(4);
		addressBodyPayload = addressBodyPayload.replace("XXX", getRandomString);
		addressBodyPayload = addressBodyPayload.replace("1111", getRandomInt);
		addressBodyPayload = addressBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", addressBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,"Response message is not same Expected 500 and Actual " + response.getCode());

	}



	@Test
	public void purchaseOrgWithoutSenderSystemBusinessId() throws Exception {

		/* Making full load */
		String purchaseOrgBodyPayload = getData("testMDNIPurchaseOrgWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("XXX", getRandomString);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", purchaseOrgBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}


	@Test
	public void purchaseOrgWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		/* Making full load */
		String purchaseOrgBodyPayload = getData("testMDNIPurchaseOrgWithActionCode02");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("XXX", getRandomString);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", purchaseOrgBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}

	@Test
	public void purchaseGroupWithoutSenderSystemBusinessId() throws Exception {

		/* Making Full load call */
		String purchaseGrpBodyPayload = getData("testMDNIPurchaseGroupWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("XXX", getRandomString);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("11111", getRandomString);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingGroup", purchaseGrpBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}

	@Test
	public void purchaseGroupWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		/* Making Full load call */
		String purchaseGrpBodyPayload = getData("testMDNIPurchaseGroupWithActionCode02");
		String getRandomString = RandomStringUtils.randomAlphanumeric(3);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("XXX", getRandomString);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("11111", getRandomString);
		purchaseGrpBodyPayload = purchaseGrpBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingGroup", purchaseGrpBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}
	@Test
	public void MaterialGroupWithoutSenderSystemBusinessId() throws Exception {

		/* Making full load call */
		String BodyPayload = getData("testMDNIPartitionedCommodityCodeWithActionCode01");
		String getRandomInt = getRandomint(5);
		BodyPayload = BodyPayload.replace("11111", getRandomInt);
		BodyPayload = BodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "MaterialGroup", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());

	}

	@Test
	public void MaterialGroupWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		/* Making full load call */
		String BodyPayload = getData("testMDNIPartitionedCommodityCodeWithActionCode02");
		String getRandomInt = getRandomint(5);
		BodyPayload = BodyPayload.replace("11111", getRandomInt);
		BodyPayload = BodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "MaterialGroup", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());

	}
	@Test
	public void ItemCategoryWithoutSenderSystemBusinessId() throws Exception {

		/* Making full load call */
		String purchaseOrgBodyPayload = getData("testMDNIItemCategoryWithActionCode01");
		String getRandomString = RandomStringUtils.randomAlphanumeric(1);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("AAAAA", getRandomString);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchaseDocumentItemCategory", purchaseOrgBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}

	@Test
	public void ItemCategoryWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		/* Making full load call */
		String purchaseOrgBodyPayload = getData("testMDNIItemCategoryWithActionCode02");
		String getRandomString = RandomStringUtils.randomAlphanumeric(1);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("AAAAA", getRandomString);
		purchaseOrgBodyPayload = purchaseOrgBodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchaseDocumentItemCategory", purchaseOrgBodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}


	@Test
	public void PlantPurchaseOrgComboWithoutSenderSystemBusinessIdl() throws Exception {

		String getRandomString = RandomStringUtils.randomAlphanumeric(3);

		/* Making full load call*/
		String BodyPayload = getData("testMDNIPlantPurchaseOrgComboWithActionCode01");
		BodyPayload = BodyPayload.replace("XXXXX", getRandomString);
		BodyPayload = BodyPayload.replace("YYYYY", getRandomString);
		BodyPayload = BodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PlantPurchasingOrg", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}

	@Test
	public void PlantPurchaseOrgComboWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		String getRandomString = RandomStringUtils.randomAlphanumeric(3);

		/* Making full load call*/
		String BodyPayload = getData("testMDNIPlantPurchaseOrgComboWithActionCode02");
		BodyPayload = BodyPayload.replace("XXXXX", getRandomString);
		BodyPayload = BodyPayload.replace("YYYYY", getRandomString);
		BodyPayload = BodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PlantPurchasingOrg", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}

	@Test
	public void PaymentTermsWithoutSenderSystemBusinessId() throws Exception {

		String getRandomString = RandomStringUtils.randomAlphanumeric(3);

		/* Making full load call*/
		String BodyPayload = getData("testMDNIPaymentTermsWithActionCode01");
		BodyPayload = BodyPayload.replace("11111", getRandomString);
		BodyPayload = BodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PaymentTerms", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}

	@Test
	public void PaymentTermsWithoutSenderSystemBusinessIdIncreamental() throws Exception {

		String getRandomString = RandomStringUtils.randomAlphanumeric(3);

		/* Making full load call*/
		String BodyPayload = getData("testMDNIPaymentTermsWithActionCode02");
		BodyPayload = BodyPayload.replace("11111", getRandomString);
		BodyPayload = BodyPayload.replace("ER9_001", "");
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PaymentTerms", BodyPayload);
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500,
				"Response message is not same Expected 500 and Actual " + response.getCode());
	}

	public String verifyOraclePushData(String uniqueName, String objectFullQualName, String token) throws Exception {

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, objectFullQualName, "UniqueName='" + uniqueName + "'",
				Boolean.TRUE);

		RestResponse aqlRes = scimHelper.runAQLPullwithAppInfo(token, Constants.BUYER, query, SAP_ANID,
				Constants.LOCALE_EN_US, APP_URL);
		String response = aqlRes.getContent();
		response = response.replace("\"", "");

		return response;

	}

	public String verifyOraclePushDataWithWhereCondition(String SQLcondition, String objectFullQualName, String token) throws Exception {

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, objectFullQualName, SQLcondition,
				Boolean.TRUE);

		RestResponse aqlRes = scimHelper.runAQLPullwithAppInfo(token, Constants.BUYER, query, SAP_ANID,
				Constants.LOCALE_EN_US, APP_URL);
		String response = aqlRes.getContent();
		response = response.replace("\"", "");

		return response;

	}

	public String getData(String dataType)
			throws InvalidFormatException, IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {

		HashMap<String, String> masterData = new HashMap<String, String>();
		String rootDir = System.getProperty("user.dir");
		String filename = "mdniPayload_MaterialMaster.xlsx";
		JSONArray entitiesArray = new JSONArray();

		InputStream file = new FileInputStream(rootDir + "/resources/mdnifiles/" + filename);

		// InputStream file = new
		// FileInputStream("/Users/i330270/Downloads/mdniPayload_MaterialMaster.xlsx");
		// File file = new File("/Users/i330270/Downloads/mdniPayload1.xlsx");

		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet("PayLoad");
		int rowCount = sheet.getLastRowNum();
		for (int i = 1; i <= rowCount; i++) {
			String key = sheet.getRow(i).getCell(0).getStringCellValue();
			String value = sheet.getRow(i).getCell(1).getStringCellValue();
			masterData.put(key, value);
		}
		// wb.close();
		return masterData.get(dataType);
	}

	public String getRandomString(int length) {
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < length) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();

		System.out.print("Random UniqueName is : " + saltStr + "\n");
		return saltStr;
	}

	public String getRandomint(int length) {
		String SALTCHARS = "0123456789";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < length) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();

		System.out.print("Random UniqueNumber id is : " + saltStr + "\n");
		return saltStr;
	}

	private RestResponse retrieveStatusFromAPI(String endPointURL, String body) {

		RestResponse response = null;

		try {
			String userCredentials = "aribaws" + ":" + "aribaaribaariba";
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			HttpRequests connection = new HttpRequests();
			response = connection.httpPost(endPointURL, basicAuth, body);
			// response = connection.httpPostWithCert(endPointURL, basicAuth,
			// body, sslSf);
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}

		return response;
	}

	private RestResponse getStatusAPI(String endPointURL) {
		RestResponse response = null;

		try {
			String userCredentials = "aribaws" + ":" + "aribaaribaariba";
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			HttpRequests connection = new HttpRequests();
			response = connection.httpGet(endPointURL, null, basicAuth);
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}

		return response;
	}

	private String getHttpResponse(HttpURLConnection connection) throws IOException {
		BufferedReader in = null;
		StringBuffer response = new StringBuffer();
		try {
			if (connection.getResponseCode() != HttpURLConnection.HTTP_OK && connection.getErrorStream() != null) {
				in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
			} else {
				in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			}
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
		} finally {
			if (in != null)
				in.close();
		}

		return response.toString();
	}

	public String verifySuccessResponse(String response, String objectName) {

		String responsepattern = "JobId .*";
		Pattern pattern = Pattern.compile(responsepattern, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(response);
		String jobID = response.replace("JobId ", "");

		if (jobID.contains("+")) {
			jobID = jobID.replace("+", "%2B");
		}

		boolean matches = matcher.matches();
		assertTrue("jobID does not match", matches == true);

		// Verify the status to be Processed
		int i = 0;
		try {
			for(i=0;i<=6;i++) {

				Thread.sleep(20000);

				if (!verifyStatusforJobID(jobID, objectName).equals("Pending Processing")) {
					i = 6;
				}
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}


		return jobID;

	}

	private String verifyStatusforJobID(String jobID, String objectName) {
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + objectName + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		System.out.print("responseIntegrationJob : " + responseIntegrationJob + "\n");

		Assert.assertEquals(responseIntegrationJob1.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob1.getCode());

		if (!responseIntegrationJob.equals("{}")) {
			JSONObject json = new JSONObject(responseIntegrationJob);
			String status = json.getString("Status");
			return status;
		}

		else {
			return "";
		}

	}

}
