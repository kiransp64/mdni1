package com.ariba.resttests;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.PostXMLDataHelper;
import com.ariba.pojos.RestResponse;

public class ConcurrentPostXMLDataTests {

	PostXMLDataHelper pHelper = new PostXMLDataHelper();
	String rootDir = System.getProperty("user.dir");

	@Test(invocationCount = 2, threadPoolSize = 2)
	public void concurrentThreads() throws Exception {
		long tnum = Thread.currentThread().getId();
		System.out.println("Current Thread ID -------------" + tnum);

		String tenant1 = "AN71000002054";
		String tenant1Username = "aribaws";
		String tenant1Password = "Aribabuyingtesting123456789!";
		String tenant2 = "AN02001565602";
		String tenant2Username = "aribaws";
		String tenant2Password = "Aribabuyingtesting123456789!";

		switch ((int) tnum % 10) {
		case 1:
			String incoTermsData1 = getStringFromXML("/resources/datafiles/incoTerms.txt");
			incoTermsData1 = incoTermsData1.replace("$$$", tnum + "");
			UUID uuid = UUID.randomUUID();
			incoTermsData1 = incoTermsData1.replace("###", uuid.toString());
			System.err.println(incoTermsData1);
			RestResponse incoTerms1 = pHelper.postIncoTerms(tenant1, incoTermsData1, tenant1Username, tenant1Password);
			System.err.println(incoTerms1.getCode());
			Assert.assertEquals(incoTerms1.getCode(), BaseHelper.HTTP_200);
			break;

		case 2:
			String incoTermsData2 = getStringFromXML("/resources/datafiles/incoTerms.txt");
			incoTermsData2 = incoTermsData2.replace("$$$", tnum + "");
			uuid = UUID.randomUUID();
			incoTermsData2 = incoTermsData2.replace("###", uuid.toString());
			System.err.println(incoTermsData2);
			RestResponse incoTerms2 = pHelper.postIncoTerms(tenant2, incoTermsData2, tenant2Username, tenant2Password);
			System.err.println(incoTerms2.getCode());
			Assert.assertEquals(incoTerms2.getCode(), BaseHelper.HTTP_200);
			break;

		case 3:
			String pgData1 = getStringFromXML("/resources/datafiles/purchaseGroup.txt");
			pgData1 = pgData1.replace("$$$", "PG1" + tnum);
			System.err.println(pgData1);
			RestResponse pgResponse1 = pHelper.postPurchaseGroup(tenant1, pgData1, tenant1Username, tenant1Password);
			System.err.println(pgResponse1.getCode());
			Assert.assertEquals(pgResponse1.getCode(), BaseHelper.HTTP_200);
			break;

		case 4:
			String pgData2 = getStringFromXML("/resources/datafiles/purchaseGroup.txt");
			pgData2 = pgData2.replace("$$$", "PG2" + tnum);
			System.err.println(pgData2);
			RestResponse pgResponse2 = pHelper.postPurchaseGroup(tenant2, pgData2, tenant2Username, tenant2Password);
			System.err.println(pgResponse2.getCode());
			Assert.assertEquals(pgResponse2.getCode(), BaseHelper.HTTP_200);
			break;

		case 5:
			String wbsData1 = getStringFromXML("/resources/datafiles/wbsElement.txt");
			wbsData1 = wbsData1.replace("$$$", "WB1" + tnum);
			System.out.println(wbsData1);
			RestResponse wbsResponse1 = pHelper.postWbsElement(tenant1, wbsData1, tenant1Username, tenant1Password);
			System.err.println(wbsResponse1.getCode());
			Assert.assertEquals(wbsResponse1.getCode(), BaseHelper.HTTP_200);
			break;

		case 6:
			String wbsData2 = getStringFromXML("/resources/datafiles/wbsElement.txt");
			wbsData2 = wbsData2.replace("$$$", "WB2" + tnum);
			System.out.println(wbsData2);
			RestResponse wbsResponse2 = pHelper.postWbsElement(tenant2, wbsData2, tenant2Username, tenant2Password);
			System.err.println(wbsResponse2.getCode());
			Assert.assertEquals(wbsResponse2.getCode(), BaseHelper.HTTP_200);
			break;

		case 7:
			String poData1 = getStringFromXML("/resources/datafiles/purchaseOrg.txt");
			poData1 = poData1.replace("$$$", "PO1" + tnum);
			System.out.println(poData1);
			RestResponse poResponse1 = pHelper.postPurchaseOrg(tenant1, poData1, tenant1Username, tenant1Password);
			System.err.println(poResponse1.getCode());
			Assert.assertEquals(poResponse1.getCode(), BaseHelper.HTTP_200);
			break;

		case 8:
			String poData2 = getStringFromXML("/resources/datafiles/purchaseOrg.txt");
			poData2 = poData2.replace("$$$", "PO2" + tnum);
			System.out.println(poData2);
			RestResponse poResponse2 = pHelper.postPurchaseOrg(tenant2, poData2, tenant2Username, tenant2Password);
			System.err.println(poResponse2.getCode());
			Assert.assertEquals(poResponse2.getCode(), BaseHelper.HTTP_200);
			break;

		case 9:
			String ccrData1 = getStringFromXML("/resources/datafiles/currencyConversion.txt");
			ccrData1 = ccrData1.replace("$$$", "C" + tnum);
			System.out.println(ccrData1);
			RestResponse ccrresponse1 = pHelper.postCurrencyConversionRate(tenant1, ccrData1, tenant1Username,
					tenant1Password);
			System.err.println(ccrresponse1.getCode());
			Assert.assertEquals(ccrresponse1.getCode(), BaseHelper.HTTP_200);
			break;

		default:
			String ccrData2 = getStringFromXML("/resources/datafiles/currencyConversion.txt");
			ccrData2 = ccrData2.replace("$$$", "C" + tnum);
			System.out.println(ccrData2);
			RestResponse ccrresponse2 = pHelper.postCurrencyConversionRate(tenant2, ccrData2, tenant2Username,
					tenant2Password);
			System.err.println(ccrresponse2.getCode());
			Assert.assertEquals(ccrresponse2.getCode(), BaseHelper.HTTP_200);
			break;
		}
	}

	public String getStringFromXML(String filePath) throws FileNotFoundException {

		String rootDir = System.getProperty("user.dir");
		Scanner scanner = new Scanner(new File(rootDir + filePath));
		String xmlString = scanner.useDelimiter("\\A").next();
		scanner.close();
		return xmlString;
	}
}
