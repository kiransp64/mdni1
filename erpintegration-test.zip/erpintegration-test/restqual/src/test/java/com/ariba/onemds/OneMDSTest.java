package com.ariba.onemds;

import com.ariba.data.cache.MDICache;
import com.ariba.services.OneMds;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class OneMDSTest extends DataExecuter {
    private static Logger logger = LogManager.getLogger(OneMDSTest.class);

    @BeforeTest
    public void getFreshToken() throws InterruptedException {
        System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        access_token = OneMds.getToken();
//        dataCleanUp();
        freshDeltaTokenCostCenter = getFreshDeltaToken("costcenter");
        freshDeltaTokenCompanyCode = getFreshDeltaToken("companycode");
        freshDeltaTokenProduct = getFreshDeltaToken("product");
//        freshDeltaTokenExchangeRate = getFreshDeltaToken("exchangerate");
        nextDeltaTokenCompanyCode = freshDeltaTokenCompanyCode;
        nextDeltaTokenCostCenter = freshDeltaTokenCostCenter;
        nextDeltaTokenProduct = freshDeltaTokenProduct;
        nextDeltaTokenExchangeRate = freshDeltaTokenExchangeRate;
        logger.info("Clean state delta token for company code : " + freshDeltaTokenCompanyCode);
        logger.info("Clean state delta token for cost center : " + freshDeltaTokenCostCenter);
        logger.info("Clean state delta token for  product : " + freshDeltaTokenProduct);
        logger.info("Clean state delta token for  ExchangeRate : " + freshDeltaTokenExchangeRate);
    }

    @Test(dataProvider = "eventData", dataProviderClass = OneMdsDataProvider.class)
    public void verify(String description, MDICache mdiCache, String entity, String system, String realm, String anid) throws Exception {
        if (description.toLowerCase().contains("exception")||description.toLowerCase().contains("error")) {
            Assert.fail(description);
        }
        verifyEvents(mdiCache, entity, system, realm, anid);
    }

    @AfterTest
    public void cleanUp() throws InterruptedException {
        logger.info("Running after test cleenup : ");
        saveLatestDeltaTokens();
//        postTestDataCleanUp();
    }
}
