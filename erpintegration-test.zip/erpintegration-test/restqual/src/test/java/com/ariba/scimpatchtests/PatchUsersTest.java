package com.ariba.scimpatchtests;

import com.ariba.helpers.*;
import com.ariba.pojos.RestResponse;
import com.ariba.services.MDNI;
import com.ariba.services.MDS;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.response.Response;
//import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.skyscreamer.jsonassert.*;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

import static com.ariba.scim.SCIMGroups.GROUPNAME_EN;

public class PatchUsersTest extends SCIMHelper {
    OAuthHelper oauthHelper = new OAuthHelper();
    MDSSearchHelper searchHelper = new MDSSearchHelper();
    SCIMHelper scimHelper = new SCIMHelper();
    String supervisor;
    static JsonParser parser = new JsonParser();


    String token;
    public static JsonObject userPatchPayloads;
    public static JsonObject groupPatchPayloads;
    public static String KEYS = "Phone,Fax,EmailAddress,PersistedAlternateEmailAddresses.Address,Supervisor.UniqueName,TimeZoneID,UniqueName,Name,this,LocaleID.UniqueName,UserUUID,PartitionNumber";


    static {
        String userPath = "./resources/patchpayloads/PatchUserPayloads.json";
        String groupPath = "./resources/patchpayloads/PatchGroupPayload.json";
        BufferedReader brUser = null;
        BufferedReader brGroup = null;
        try {
            brUser = new BufferedReader(new FileReader(userPath));
            brGroup = new BufferedReader(new FileReader(groupPath));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        userPatchPayloads = parser.parse(brUser).getAsJsonObject();
        groupPatchPayloads = parser.parse(brGroup).getAsJsonObject();
    }

    private String createUser() throws Exception {
        UUID uuid = UUID.randomUUID();
        String username = "testuser" + uuid.toString();
        JsonObject userWithOutManagerPayload = userPatchPayloads.get("users").getAsJsonObject();
        JsonObject usersPayload = assignManagerToUser(userWithOutManagerPayload, supervisor);
        usersPayload.addProperty("userName", username);
        token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
        MDNI mdni = new MDNI();
        Response createUserResponse = mdni.createUsers(SAP_ANID, token, usersPayload.toString());
        return username;
    }

    private String createS4User() throws Exception {
        UUID uuid = UUID.randomUUID();
        String username = "testuser" + uuid.toString();
        createS4Manager();
        JsonObject userWithOutManagerPayload = userPatchPayloads.get("users").getAsJsonObject();
        JsonObject usersPayload = assignManagerToUser(userWithOutManagerPayload, supervisor);
        usersPayload.addProperty("userName", username);
        token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, Constants.SOURCING);
        MDNI mdni = new MDNI();
        Response createUserResponse = mdni.createUsers(S4_ANID, token, usersPayload.toString());
        return username;
    }

    private String createPeerRealmUser(String anid,String manager, String token) throws Exception {
        UUID uuid = UUID.randomUUID();
        String username = "testuser" + uuid.toString();
        JsonObject userWithOutManagerPayload = userPatchPayloads.get("users").getAsJsonObject();
        JsonObject usersPayload = assignManagerToUser(userWithOutManagerPayload, manager);
        usersPayload.addProperty("userName", username);
        MDNI mdni = new MDNI();
        Response createUserResponse = mdni.createUsers(anid, token, usersPayload.toString());
        return username;
    }

    private String createPeerRealmManager(String anid,String token) throws Exception {
        UUID uuid = UUID.randomUUID();
        String username = "testuser" + uuid.toString();
        JsonObject usersPayload = userPatchPayloads.get("usersWithoutManager").getAsJsonObject();
        usersPayload.addProperty("userName", username);
        MDNI mdni = new MDNI();
        Response createUserResponse = mdni.createUsers(anid, token, usersPayload.toString());
        return username;
    }
    private JsonObject assignManagerToUser(JsonObject usersPayload, String supervisor) throws Exception {
        JsonObject enterprise = new JsonObject();
        JsonObject manager = new JsonObject();
        manager.addProperty(Constants.VALUE_KEY, supervisor);
        enterprise.add(Constants.MANAGER, manager);
        usersPayload.add(Constants.USERS_SCHEMA_ENTERPRISE, enterprise);
        return usersPayload;
    }

    private void createManager() throws Exception {
        UUID uuid = UUID.randomUUID();
        String username = "testuser" + uuid.toString();
        JsonObject usersPayload = userPatchPayloads.get("usersWithoutManager").getAsJsonObject();
        usersPayload.addProperty("userName", username);
        token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
        MDNI mdni = new MDNI();
        Response createUserResponse = mdni.createUsers(SAP_ANID, token, usersPayload.toString());
        supervisor = username;
    }

    private void createS4Manager() throws Exception {
        UUID uuid = UUID.randomUUID();
        String username = "testuser" + uuid.toString();
        JsonObject usersPayload = userPatchPayloads.get("usersWithoutManager").getAsJsonObject();
        usersPayload.addProperty("userName", username);
        token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, Constants.SOURCING);
        MDNI mdni = new MDNI();
        Response createUserResponse = mdni.createUsers(S4_ANID, token, usersPayload.toString());
        supervisor = username;
    }

    private String createGroup() throws Exception {
        UUID uuid = UUID.randomUUID();
        String displayName = GROUPNAME_EN + uuid.toString();
        JsonObject groupPayload = userPatchPayloads.get("groupWithoutMember").getAsJsonObject();
        groupPayload.addProperty("displayName", displayName);
        token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
        MDNI mdni = new MDNI();
        Response createGroupResponse = mdni.createGroup(SAP_ANID, token, groupPayload.toString());
        return displayName;
    }

    private String createGroupWithGivenMember(String user, String group) throws Exception {
        UUID uuid = UUID.randomUUID();
        String displayName = GROUPNAME_EN + uuid.toString();
        JsonObject groupPayload = userPatchPayloads.get("groupWithoutMember").getAsJsonObject();
        groupPayload.addProperty("displayName", displayName);
        JsonArray members = new JsonArray();
        JsonObject userJsonObject = new JsonObject();
        JsonObject groupJsonObject = new JsonObject();
        userJsonObject.addProperty("type", "User");
        userJsonObject.addProperty("value", user);
        groupJsonObject.addProperty("type", "Group");
        groupJsonObject.addProperty("value", group);
        members.add(userJsonObject);
        members.add(groupJsonObject);
        groupPayload.add("members", members);
        token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
        MDNI mdni = new MDNI();
        Response createGroupResponse = mdni.createGroup(SAP_ANID, token, groupPayload.toString());
        return displayName;
    }

    @BeforeTest
    private void setup() throws Exception {
        createManager();
    }

    @Test(dataProvider = "getPatchPayloads", dataProviderClass = PatchDataProvider.class)
    public void verifyScimPatchTests(String description, JsonObject payload) throws Exception {
        String username = createUser();
        MDNI mdni = new MDNI();
        JsonParser parser = new JsonParser();
        System.out.println("Patch payload : " + payload.get("patch").toString());
        Response userResponseBeforePatch = mdni.getUsers(SAP_ANID, token, username);
        JsonObject userBeforePatch = parser.parse(userResponseBeforePatch.asString()).getAsJsonObject();
        Response patchUserResponse = mdni.patchUsers(SAP_ANID, token, payload.get("patch").toString(), username);
        Response getUserResponseAfterPatch = mdni.getUsers(SAP_ANID, token, username);
        JsonObject userAfterPatch = parser.parse(getUserResponseAfterPatch.asString()).getAsJsonObject();
        JSONObject userUpdated = (JSONObject) jsonObject(userAfterPatch.toString());
        validatePatchOperation(userBeforePatch, userAfterPatch, payload);
        userAfterPatch = parser.parse(getUserResponseAfterPatch.asString()).getAsJsonObject();
        validatePatchOperation(userAfterPatch, payload, username);
        if (userAfterPatch.get("active").getAsBoolean()) {
            System.out.println("Comparing MDS hana and buyer");
            JSONObject buyerUserUpdated = getUserFromBuyer(SAP_ANID, username, token);
            JSONObject hanaUserUpdated = getUserUsingMdsSearch(username,token);
            JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
            Assert.assertTrue(issues.length() == 0,
                    "Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
        }
    }

    @Test(dataProvider = "getPatchPayloadsForActiveAtribute", dataProviderClass = PatchDataProvider.class)
    public void verifyScimPatchOnActiveAttributeTests(String description, JsonObject payload) throws Exception {
        String username = createUser();
        MDNI mdni = new MDNI();
        JsonParser parser = new JsonParser();
        System.out.println("Patch payload : " + payload.get("patch").toString());
        Response userResponseBeforePatch = mdni.getUsers(SAP_ANID, token, username);
        JsonObject userBeforePatch = parser.parse(userResponseBeforePatch.asString()).getAsJsonObject();
        Response patchUserResponse = mdni.patchUsers(SAP_ANID, token, payload.get("patch").toString(), username);
        Assert.assertEquals(patchUserResponse.getStatusCode(), 200, "Failed to make user inactive");
        Response getUserResponseAfterPatch = mdni.getUsers(SAP_ANID, token, username);
        Assert.assertEquals(getUserResponseAfterPatch.getStatusCode(), 404, "Failed to make user inactive");

    }

    private void validatePatchOperation(JsonObject userAfterPatch, JsonObject payload, String username) {
        JsonArray patchOperations = payload.get("expectedAfterPatch").getAsJsonArray();
        JSONObject jo1 = new JSONObject(userAfterPatch.toString());
        JSONObject jo2 = new JSONObject(payload.toString());
        for (int i = 0; i < patchOperations.size(); i++) {
            String path = patchOperations.get(i).getAsJsonObject().get("path").getAsString();
            if (patchOperations.get(i).getAsJsonObject().get("value") instanceof JsonObject) {
                System.out.println("comparing" + "\n" + jo1.getJSONObject(path).toString() + "\n" + new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONObject("value"));
                JSONAssert.assertEquals(jo1.getJSONObject(path), new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONObject("value"), JSONCompareMode.LENIENT);
            } else if (patchOperations.get(i).getAsJsonObject().get("value") instanceof JsonArray) {
                System.out.println("comparing" + "\n" + jo1.getJSONArray(path).toString() + "\n" + new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONArray("value"));
                JSONAssert.assertEquals(jo1.getJSONArray(path), new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONArray("value"), JSONCompareMode.LENIENT);

            } else {
                System.out.println("comparing" + "\n" + userAfterPatch.get(path) + "\n" + payload.get("expectedAfterPatch").getAsJsonArray().get(i).getAsJsonObject().get("value"));
                if (path.equalsIgnoreCase("displayName") && payload.get("expectedAfterPatch").getAsJsonArray().get(i).getAsJsonObject().get("value").getAsString().equalsIgnoreCase("")) {
                    Assert.assertEquals(userAfterPatch.get(path).getAsString(), username, "Mismatch in expected patch value");
                } else {
                    Assert.assertEquals(userAfterPatch.get(path), payload.get("expectedAfterPatch").getAsJsonArray().get(i).getAsJsonObject().get("value"), "Mismatch in expected patch value");
                }
            }
        }
    }

    public void validatePatchOperation(JsonObject userBeforePatch, JsonObject userAfterPatch, JsonObject patchPayload) {
        JsonArray patchOperations = patchPayload.get("patch").getAsJsonObject().get("Operations").getAsJsonArray();
        for (int i = 0; i < patchOperations.size(); i++) {
            String key = patchOperations.get(i).getAsJsonObject().get("path").getAsString();
            userBeforePatch.remove(key);
            userAfterPatch.remove(key);
        }
        userBeforePatch.get("meta").getAsJsonObject().remove("lastModified");
        userBeforePatch.get("meta").getAsJsonObject().remove("version");
        userAfterPatch.get("meta").getAsJsonObject().remove("lastModified");
        userAfterPatch.get("meta").getAsJsonObject().remove("version");
        Assert.assertEquals(userBeforePatch, userAfterPatch, "Patch operation modified the attribute which was not in patch payload");
    }

    @Test(dataProvider = "getNegativeUserPatchPayloads", dataProviderClass = PatchDataProvider.class)
    public void verifyScimPatchNegativeUsersTests(String description, JsonObject payload, int responseCode, String msg) throws Exception {
        String username = createUser();
        MDNI mdni = new MDNI();
        JsonParser parser = new JsonParser();
        System.out.println("Patch payload : " + payload);
        Response getUserResponseBeforePatch = mdni.getUsers(SAP_ANID, token, username);
        JsonObject getUserBeforePatch = parser.parse(getUserResponseBeforePatch.asString()).getAsJsonObject();
        String patchPayload = payload.toString();
        if (description.contains("")) {
            patchPayload = patchPayload.replace("cnoll", username);
        }
        Response patchUserResponse;
        if (description.contains("User Which Does Not Exists")) {
            patchUserResponse = mdni.patchUsers(SAP_ANID, token, patchPayload, "invalid");
        } else {
            patchUserResponse = mdni.patchUsers(SAP_ANID, token, patchPayload, username);
        }
        Assert.assertEquals(patchUserResponse.getStatusCode(), responseCode);
        if (responseCode != 200 && responseCode != 204) {
            Assert.assertEquals(patchUserResponse.jsonPath().getString("detail"), msg, "Mismatch in the failure message");
        }
        Assert.assertEquals(patchUserResponse.getStatusCode(), responseCode);
        Response getUserResponseAfterPatch = mdni.getUsers(SAP_ANID, token, username);
        JsonObject getUserAfterPatch = parser.parse(getUserResponseAfterPatch.asString()).getAsJsonObject();
        Assert.assertEquals(getUserBeforePatch, getUserAfterPatch, "Mismatch");
    }

    @Test
    public void GroupsAttributeInGetUsersTest() throws Exception {
        MDNI mdni = new MDNI();
        String username = createUser();
        String groupWithoutMember = createGroup();
        String groupWithGivenMember1 = createGroupWithGivenMember(username, groupWithoutMember);
        Response getUserResponse = mdni.getUsers(SAP_ANID, token, username);
        Assert.assertEquals(getUserResponse.jsonPath().getList("groups").size(), 1, "User groups not present in get user response");
        Assert.assertTrue(getUserResponse.jsonPath().getString("groups").contains(groupWithGivenMember1), "Expected group " + groupWithGivenMember1 + " not present in the response");
        String groupWithGivenMember2 = createGroupWithGivenMember(username, groupWithoutMember);
        getUserResponse = mdni.getUsers(SAP_ANID, token, username);
        Assert.assertEquals(getUserResponse.jsonPath().getList("groups").size(), 2, "User groups not present in get user response");
        Assert.assertTrue(getUserResponse.jsonPath().getString("groups").contains(groupWithGivenMember1), "Expected group " + groupWithGivenMember1 + " not present in the response");
        Assert.assertTrue(getUserResponse.jsonPath().getString("groups").contains(groupWithGivenMember2), "Expected group " + groupWithGivenMember2 + " not present in the response");
    }

    @Test
    public void GetUsersWithPaginationTest() throws Exception {
        MDNI mdni = new MDNI();
        int startIndex = 1;
        Response getUserResponse = mdni.getUsersWithPagination(SAP_ANID, token, startIndex, 100);
        Assert.assertTrue(getUserResponse.jsonPath().getList("Resources").size() <= 100, "User groups not present in get user response");
        int totalResults = getUserResponse.jsonPath().getInt("totalResults");
        int currentResult = getUserResponse.jsonPath().getInt("itemsPerPage") + getUserResponse.jsonPath().getInt("startIndex");
        while (currentResult < 400) {
            getUserResponse = mdni.getUsersWithPagination(SAP_ANID, token, startIndex, 100);
            JsonObject jsonObject = new JsonParser().parse(getUserResponse.asString()).getAsJsonObject();
            JsonArray jsonArray = jsonObject.getAsJsonArray("Resources");
            for (int i = 0; i < jsonArray.size(); i++) {
                if (jsonArray.get(i).getAsJsonObject().get("groups") != null) {
                    int groupSize = jsonArray.get(i).getAsJsonObject().get("groups").getAsJsonArray().size();
                    Assert.assertTrue(groupSize <= 100, "Group size should be less than equal to 100");
                    if (jsonArray.get(i).getAsJsonObject().get("id").getAsString().contains("hu150722b")) {
                        System.out.println(jsonArray.get(i));
                    }
                }
            }
            startIndex = startIndex + 100;
            currentResult = getUserResponse.jsonPath().getInt("itemsPerPage") + getUserResponse.jsonPath().getInt("startIndex");
        }
    }

    @Test
    public void GetUsersWithRefAsOpenApi() throws Exception {
        MDNI mdni = new MDNI();
        String username = createUser();
        String groupWithoutMember = createGroup();
        createGroupWithGivenMember(username, groupWithoutMember);
        Response getUserResponse = mdni.getUsersUsingOpenApi(SAP_ANID, token, username);
        for (int i = 0; i < getUserResponse.jsonPath().getList("groups").size(); i++) {
            Assert.assertTrue(getUserResponse.jsonPath().getString("groups").contains("https://openapi.cobalt.cloud.ariba.com/api"), "Expected $ref should contain Open API url");
        }
    }

    @Test
    public void GetUsersWithLocationAsOpenApi() throws Exception {
        MDNI mdni = new MDNI();
        String username = createUser();
        String groupWithoutMember = createGroup();
        createGroupWithGivenMember(username, groupWithoutMember);
        Response getUserResponse = mdni.getUsersUsingOpenApi(SAP_ANID, token, username);
        Assert.assertTrue(getUserResponse.jsonPath().getString("meta").contains("https://openapi.cobalt.cloud.ariba.com/api"), "Expected location field should contain Open API url");

    }

    @Test
    public void PatchGroupWhichContainsDeletedMember() throws Exception {
        MDNI mdni = new MDNI();
        String username1 = createUser();
        String username2 = createUser();
        String groupWithoutMember = createGroup();
        String group=createGroupWithGivenMember(username1, groupWithoutMember);
        RestResponse result = scimHelper.deleteUsers(token, SAP_ANID, username1);
        Assert.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT, "Response code is not matching for user creation");

        String patchPayload = PatchUsersTest.userPatchPayloads.get("PatchGroupContainingDeletedMember").getAsJsonObject().toString();
        patchPayload = patchPayload.replace("cnoll", username2);

        mdni.patchGroup(SAP_ANID, token, patchPayload, group);
        Response getGroupsResponse = mdni.getGroup(SAP_ANID, token, group);
        Assert.assertTrue(!getGroupsResponse.jsonPath().getString("members").contains(username1), "");
        Assert.assertTrue(getGroupsResponse.jsonPath().getString("members").contains(username2), "");
    }


    @Test
    public void apeerRealmUserTest() throws Exception {
        String s4Realm = PEER_REALM;
        String anid = PEER_REALM_ANID;
        String s4Token = oauthHelper.getAccessToken(s4Realm, SAP_USERNAME, anid, "s4");
        String buyerToken = oauthHelper.getAccessToken(s4Realm, SAP_USERNAME, anid, "buyer");
        enableFeatureSettings(buyerToken, anid);
        Thread.sleep(10000);//waiting for for some time for feature settings to take affect
        String manager = createPeerRealmManager(anid,s4Token);
        String username = createPeerRealmUser(anid,manager,s4Token);
        MDS mds = new MDS();

        Response response = mds.mdsSearchWithToken(SEARCHBASEURL,Constants.MDS_SEARCH_USERS+"?$filter=SharedUserKey.UniqueName='" + username + "'",buyerToken);
        JsonArray jsonArray = new JsonParser().parse(response.asString()).getAsJsonArray();
        Assert.assertEquals(jsonArray.size(),1,"Search could not find the user created with buyer context: "+username);
        int buyerPartitionNumber = jsonArray.get(0).getAsJsonObject().get("SharedUserKey.PartitionNumber").getAsInt();

        response = mds.mdsSearchWithToken(SEARCHBASEURL,Constants.MDS_SEARCH_USERS+"?$filter=SharedUserKey.UniqueName='" + username + "'",s4Token);
        jsonArray = new JsonParser().parse(response.asString()).getAsJsonArray();
        Assert.assertEquals(jsonArray.size(),1,"Search could not find the user created with s4 context: "+username);
        int S4PartitionNumber = jsonArray.get(0).getAsJsonObject().get("SharedUserKey.PartitionNumber").getAsInt();
        Assert.assertTrue(S4PartitionNumber!=buyerPartitionNumber, "S4 and Buyer partition number should be different");

        MDNI mdni = new MDNI();
        Response userResponseBeforePatch = mdni.getUsers(anid, buyerToken, username);
        JsonObject userBeforePatch = parser.parse(userResponseBeforePatch.asString()).getAsJsonObject();
        JsonObject payload = PatchUsersTest.userPatchPayloads.get("ReplaceDisplayname").getAsJsonObject();
        Response patchUserResponse = mdni.patchUsers(anid, buyerToken, payload.get("patch").toString(), username);
        Response getUserResponseAfterPatch = mdni.getUsers(anid, buyerToken, username);
        JsonObject userAfterPatch = parser.parse(getUserResponseAfterPatch.asString()).getAsJsonObject();
        JSONObject userUpdated = (JSONObject) jsonObject(userAfterPatch.toString());
        validatePatchOperation(userBeforePatch, userAfterPatch, payload);
        userAfterPatch = parser.parse(getUserResponseAfterPatch.asString()).getAsJsonObject();
        validatePatchOperation(userAfterPatch, payload, username);
        if (userAfterPatch.get("active").getAsBoolean()) {
            System.out.println("Comparing MDS hana and buyer");
            JSONObject buyerUserUpdated = getUserFromBuyer(anid, username, buyerToken);
            JSONObject hanaUserUpdated = getUserUsingMdsSearch(username, buyerToken);
            JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
            Assert.assertTrue(issues.length() == 0, "Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
            JSONObject s4UserUpdated = getUserFromS4(anid, username, buyerToken);
            issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, s4UserUpdated, Constants.LANG_EN);
            Assert.assertTrue(issues.length() == 0, "Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
        }
    }

    @Test
    public void verifyScimPatchTestsAfterBlockingBuyer() throws Exception {
        MDNI mdni = new MDNI();
        JsonParser parser = new JsonParser();
        String username = createUser();

        Thread.sleep(10000);

        // Blocking user
        //Generating access token
        String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
        // Making API call to Blocked User
        Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,SAP_REALM, Constants.BUYER, username);
        Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
                "Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

        Thread.sleep(5000);

        System.out.println("Patch payload : " + PatchUsersTest.userPatchPayloads.get("UpdateTimeZoneToBlankUsingReplace").getAsJsonObject().get("patch").toString());
        Response patchUserResponse = mdni.patchUsers(SAP_ANID, token, PatchUsersTest.userPatchPayloads.get("UpdateTimeZoneToBlankUsingReplace").getAsJsonObject().get("patch").toString(), username);
        Assert.assertEquals(patchUserResponse.getStatusCode(), HttpStatus.SC_NOT_FOUND,"Status code not 404");
        Assert.assertEquals(patchUserResponse.jsonPath().getString("detail"), "Resource with given user doesn't exist",
                "Error message is not matching when Blocked user is searched");
    }

    @Test
    public void verifyScimPatchTestsAfterBlockingS4User() throws Exception {
        MDNI mdni = new MDNI();
        JsonParser parser = new JsonParser();
        String username = createS4User();

        // Blocking user
        //Generating access token
        String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
        // Making API call to Blocked User
        Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,S4_REALM, Constants.SOURCING, username);
        Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
                "Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

        Thread.sleep(5000);

        System.out.println("Patch payload : " + PatchUsersTest.userPatchPayloads.get("UpdateTimeZoneToBlankUsingReplace").getAsJsonObject().get("patch").toString());
        Response patchUserResponse = mdni.patchUsers(S4_ANID, token, PatchUsersTest.userPatchPayloads.get("UpdateTimeZoneToBlankUsingReplace").getAsJsonObject().get("patch").toString(), username);
        Assert.assertEquals(patchUserResponse.getStatusCode(), HttpStatus.SC_NOT_FOUND,"Status code not 404");
        Assert.assertEquals(patchUserResponse.jsonPath().getString("detail"), "Resource with given user doesn't exist",
                "Error message is not matching when Blocked user is searched");
    }

    private JSONObject getUserUsingMdsSearch(String username, String token) throws Exception {
        String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
        RestResponse res = searchHelper.searchEntity(token, url);
        String content = res.getContent();
        Assert.assertNotNull(res, "Null response obtained");
        Assert.assertNotNull(content, "Null response obtained");
        Assert.assertEquals(200, res.getCode(), "Response code is not matching");
        JSONArray hanaArrayUpdated = new JSONArray(content);
        System.out.println(hanaArrayUpdated);
        Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
        return hanaArrayUpdated.getJSONObject(0);

    }

    private JSONObject getUserFromS4(String anid, String username, String token) throws Exception {
        String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
        RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, anid, Constants.LOCALE_EN_US);
        JSONArray s4DataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
        System.err.println(s4DataArrayUpdated);
        Assert.assertTrue(s4DataArrayUpdated.length() > 0, "User with uniquename " + username + " not found in s4");
        return s4DataArrayUpdated.getJSONObject(0);
    }

    private JSONObject getUserFromBuyer(String anid, String username, String token) throws Exception {
        String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
        RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, anid, Constants.LOCALE_EN_US);
        JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
        System.err.println(buyerDataArray);
        Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
        return buyerDataArray.getJSONObject(0);
    }


}
