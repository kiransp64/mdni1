package com.ariba.spendvisibility;

import com.ariba.helpers.Constants;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.DataProvider;
import static com.ariba.helpers.BaseHelper.*;

public class SpendVisibilityTestDataProvider {
    @DataProvider(name = "uploadXmlTestData")
    public static Object[][] getData() {
        return new Object[][] {
//                Test data for standalone Buyer Realm
                new Object[] {"Verifying for xml upload of Account/GeneralLedger for Non Integrated Realm","buyer", BUYER_REALM,BUYER_REALM_ANID,"GLAccount",SpendVisibilityTestData.glAccount,Constants.MDS_SEARCH_GENERAL_LEDGER,"UniqueName eq 'xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.generalLedger},
                new Object[] {"Verifying for xml upload of CostCenter for Non Integrated Realm","buyer", BUYER_REALM,BUYER_REALM_ANID,"CostCentre",SpendVisibilityTestData.costCenter, Constants.MDS_SEARCH_COSTCENTER,"UniqueName eq 'xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.costCenter},
                new Object[] {"Verifying for xml upload of ERPCommodity/PartitionedCommodityCode for Non Integrated Realm","buyer", BUYER_REALM,BUYER_REALM_ANID,"MaterialGroup",SpendVisibilityTestData.partitionedCommodityCode,Constants.PARTITIONED_COMMODITY_CODES,"UniqueName eq 'xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.commodityCode},
                new Object[] {"Verifying for xml upload of CompanySite/Plant/CommonAddress for Non Integrated Realm","buyer", BUYER_REALM,BUYER_REALM_ANID,"Plant",SpendVisibilityTestData.plant,Constants.ADDRESS,"UniqueName eq 'xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.address},

//                Test data for Integrated Realm
                new Object[] {"Verifying for xml upload of Account/GeneralLedger for Integrated Realm","buyer", INTEGRATED_REALM_SV,INTEGRATED_REALM_ANID_SV,"GLAccount",SpendVisibilityTestData.glAccount,Constants.MDS_SEARCH_GENERAL_LEDGER,"UniqueName eq 'xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.generalLedger},
                new Object[] {"Verifying for xml upload of CostCenter for Integrated Realm","buyer", INTEGRATED_REALM_SV,INTEGRATED_REALM_ANID_SV,"CostCentre",SpendVisibilityTestData.costCenter, Constants.MDS_SEARCH_COSTCENTER,"UniqueName eq 'xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.costCenter},
                new Object[] {"Verifying for xml upload of ERPCommodity/PartitionedCommodityCode for Integrated Realm","buyer", INTEGRATED_REALM_SV,INTEGRATED_REALM_ANID_SV,"MaterialGroup",SpendVisibilityTestData.partitionedCommodityCode,Constants.PARTITIONED_COMMODITY_CODES,"UniqueName eq 'xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.commodityCode},
                new Object[] {"Verifying for xml upload of CompanySite/Plant/CommonAddress for Integrated Realm","buyer", INTEGRATED_REALM_SV,INTEGRATED_REALM_ANID_SV,"Plant",SpendVisibilityTestData.plant,Constants.ADDRESS,"UniqueName eq 'xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.address},

//                Test data for Reporting Realm
//                new Object[] {"Verifying for xml upload of Account/GeneralLedger for Reporting Realm","buyer", REPORTING_REALM,REPORTING_REALM_ANID,"GLAccount",SpendVisibilityTestData.glAccount,Constants.MDS_SEARCH_GENERAL_LEDGER,"UniqueName eq 'xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.generalLedger},
//                new Object[] {"Verifying for xml upload of CostCenter for Reporting Realm","buyer", REPORTING_REALM,REPORTING_REALM_ANID,"CostCentre",SpendVisibilityTestData.costCenter, Constants.MDS_SEARCH_COSTCENTER,"UniqueName eq 'xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.costCenter},
//                new Object[] {"Verifying for xml upload of ERPCommodity/PartitionedCommodityCode for Reporting Realm","buyer", REPORTING_REALM,REPORTING_REALM_ANID,"MaterialGroup",SpendVisibilityTestData.partitionedCommodityCode,Constants.PARTITIONED_COMMODITY_CODES,"UniqueName eq 'xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.commodityCode},
//                new Object[] {"Verifying for xml upload of CompanySite/Plant/CommonAddress for Reporting Realm","buyer", REPORTING_REALM,REPORTING_REALM_ANID,"Plant",SpendVisibilityTestData.plant,Constants.ADDRESS,"UniqueName eq 'xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.address},

        };
    }

    @DataProvider(name = "uploadXmlTestDataForItemMaster")
    public static Object[][] getItemMasterData() {
        return new Object[][] {
//                Test data for Integrated Realm
                new Object[] {"Verifying for xml upload of Part/ItemMaster for Integrated Realm","buyer", INTEGRATED_REALM_SV,INTEGRATED_REALM_ANID_SV,"Product",SpendVisibilityTestData.newItem,Constants.PRODUCTS,"",RandomStringUtils.randomAlphabetic(6).toUpperCase(), AQLQueries.itemMaster},
//                Test data for Reporting Realm
//                new Object[] {"Verifying for xml upload of Part/ItemMaster for Reporting Realm","s4", REPORTING_REALM_S4,REPORTING_REALM_ANID_S4,"Product",SpendVisibilityTestData.newItem, Constants.PRODUCTS,"itemmaster?$filter=ItemMasterKey.ProductInternalID='xxxx'", RandomStringUtils.randomNumeric(5), AQLQueries.itemMaster},
//                Test data for Standalone Sourcing Realm

        };
    }

    @DataProvider(name = "uploadXmlTestDataForStandAloneSourcingRealm")
    public static Object[][] getStandAloneSourcingRealmData() {
        return new Object[][] {
//                Test data for Standalone Sourcing Realm
                new Object[] {"Verifying for xml upload of Account/GeneralLedger for Standalone Sourcing Realm","S4", STAND_ALONE_SOURCING_REALM,STAND_ALONE_SOURCING_REALM_ANID,"GLAccount",SpendVisibilityTestData.glAccount,Constants.MDS_SEARCH_GENERAL_LEDGER_ADV,"GeneralLedgerKey.UniqueName='xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.generalLedger},
                new Object[] {"Verifying for xml upload of CostCenter for Standalone Sourcing Realm","S4", STAND_ALONE_SOURCING_REALM,STAND_ALONE_SOURCING_REALM_ANID,"CostCentre",SpendVisibilityTestData.costCenter, Constants.MDS_SEARCH_COSTCENTER_ADV,"UniqueName eq 'xxxx'",RandomStringUtils.randomAlphanumeric(4), AQLQueries.costCenter},
                new Object[] {"Verifying for xml upload of ERPCommodity/PartitionedCommodityCode for Standalone Sourcing Realm","S4", STAND_ALONE_SOURCING_REALM,STAND_ALONE_SOURCING_REALM_ANID,"MaterialGroup",SpendVisibilityTestData.partitionedCommodityCode,Constants.PARTITIONED_COMMODITY_CODES_ADV,"PartitionedCommodityCodeKey.UniqueName='xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.commodityCode},
                new Object[] {"Verifying for xml upload of CompanySite/Plant/CommonAddress for Standalone Sourcing Realm","S4", STAND_ALONE_SOURCING_REALM,STAND_ALONE_SOURCING_REALM_ANID,"Plant",SpendVisibilityTestData.plant,Constants.ADDRESS_ADV,"CommonAddressKey.UniqueName='xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.address},
                new Object[] {"Verifying for xml upload of Part/ItemMaster for Standalone Sourcing Realm","S4", STAND_ALONE_SOURCING_REALM,STAND_ALONE_SOURCING_REALM_ANID,"Product",SpendVisibilityTestData.newItem,Constants.PRODUCTS_ADV,"ItemMasterKey.ProductInternalID='xxxx'",RandomStringUtils.randomNumeric(5), AQLQueries.itemMaster},
        };
    }
}
