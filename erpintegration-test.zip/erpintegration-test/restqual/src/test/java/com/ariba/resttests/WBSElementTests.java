package com.ariba.resttests;

import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.ConfigHelper;
import com.ariba.helpers.GetDataHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.PostXMLDataHelper;
import com.ariba.pojos.RestResponse;
import com.ariba.utilities.DateFormatter;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class WBSElementTests {

	GetDataHelper gHelpers = new GetDataHelper();
	OAuthHelper oAuthHelper = new OAuthHelper();
	PostXMLDataHelper pHelper = new PostXMLDataHelper();
	ConfigHelper cHelper = new ConfigHelper();

	protected static final String DefaultDateFormatPatterns = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	int noOfRetries = 10;
	String validTenant = "AN71000021001";
	String warningTenant = "AN71000021002";
	String fatalErrorTenant = "AN71000021003";
	String objectName = "WBSElement";

	@BeforeClass
	public void registerTenants() throws Exception {

		RestResponse getResponse = cHelper.postConfig(validTenant);
		Assert.assertNotNull(getResponse, "Response is null");
		Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		getResponse = cHelper.postConfig(warningTenant);
		Assert.assertNotNull(getResponse, "Response is null");
		Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		getResponse = cHelper.postConfig(fatalErrorTenant);
		Assert.assertNotNull(getResponse, "Response is null");
		Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");

	}

	@Test
	public void postWBSElement() throws Exception {

		int flag = 1;
		int counter = 0;
		String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);

		// Posting
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/wbsElement.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "WBS1");
		xmlString = xmlString.replace("@@@", date);
		RestResponse response = pHelper.postWbsElement(validTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		int status = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(validTenant, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Process Timedout");
		else {
			Assert.assertEquals(status, 2, "Status is not in processed");
			String token = oAuthHelper.getAccessToken(validTenant);
			RestResponse getResponse = gHelpers.getIntegrationJobLog(validTenant, objectName, token);
			Assert.assertNotNull(getResponse, "Response is null");
			Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
			JsonParser parser = new JsonParser();
			JsonObject content = (JsonObject) parser.parse(getResponse.content);
			Assert.assertEquals(content.get("RecordsInserted").getAsInt(), 1, "Records inserted count not matching");
			Assert.assertEquals(content.get("Status").getAsString(), "Processed", "Records status is not Processed");
		}
	}

	@Test
	public void wbsElementWarningsCheck() throws Exception {

		int flag = 1;
		int counter = 0;
		String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);

		// Posting
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/wbsElement.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "WBS2");
		xmlString = xmlString.replace("@@@", date);
		RestResponse response = pHelper.postWbsElement(warningTenant, xmlString, "aribaws", "aribaws");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		int status = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(warningTenant, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Timedout before status moved to process");
		else {
			Assert.assertEquals(status, 3, "Status is not set to retry");
			String token = oAuthHelper.getAccessToken(warningTenant);
			RestResponse getResponse = gHelpers.getIntegrationJobLog(warningTenant, objectName, token);
			Assert.assertNotNull(getResponse, "Response is null");
			Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
			System.out.println("Content-----" + getResponse.content);
			JsonParser parser = new JsonParser();
			JsonObject content = (JsonObject) parser.parse(getResponse.content);
			Assert.assertEquals(content.get("RecordsInserted").getAsInt(), 0, "Records inserted count not matching");
			Assert.assertEquals(content.get("Status").getAsString(), "Processed", "Records status is not Processed");
			Assert.assertNotNull(content.get("Warnings").getAsString(), "Warning is null for Invalid realm");
		}
	}

	@Test
	public void wbsElementFatalErrorsCheck() throws Exception {

		int flag = 1;
		int counter = 0;
		String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);

		// Posting
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/wbsElement.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "WBS3");
		xmlString = xmlString.replace("@@@", date);
		RestResponse response = pHelper.postWbsElement(fatalErrorTenant, xmlString, "aribaws", "aribaws");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		int status = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(fatalErrorTenant, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Timedout before status moved to process");
		else {
			Assert.assertEquals(status, 2, "Status is not set to processed");
			String token = oAuthHelper.getAccessToken(fatalErrorTenant);
			RestResponse getResponse = gHelpers.getIntegrationJobLog(fatalErrorTenant, objectName, token);
			Assert.assertNotNull(getResponse, "Response is null");
			Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
			System.out.println("Content-----" + getResponse.content);
			JsonParser parser = new JsonParser();
			JsonObject content = (JsonObject) parser.parse(getResponse.content);
			Assert.assertEquals(content.get("RecordsInserted").getAsInt(), 0, "Records inserted count not matching");
			Assert.assertEquals(content.get("Status").getAsString(), "Processed", "Records status is not Processed");
			Assert.assertNotNull(content.get("FatalErrors").getAsString(), "Fatal errors is null for Invalid realm");
		}
	}

	@Test
	public void wbsElementInvalidXmlValidation() throws Exception {
		String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/wbsElementInvalid.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "WBS4");
		xmlString = xmlString.replace("@@@", date);
		RestResponse response = pHelper.postWbsElement(validTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response message is not same");
		String expected = "Unexpected close tag &lt;/WBSElementReplicationRequestMessage>; expected &lt;/WBSElement>.";
		Assert.assertTrue(response.getContent().contains(expected),
				"Response content doesnot contain validation error");
	}

	@Test
	public void wbsElementEarlierDate() throws Exception {

		int flag = 1;
		int counter = 0;
		String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR, -1);
		Date yesterday = cal.getTime();

		// Posting
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/wbsElement.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "WBS5");
		xmlString = xmlString.replace("@@@", date);
		RestResponse response = pHelper.postWbsElement(validTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		int status = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(validTenant, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Process Timedout");
		else {
			Assert.assertEquals(status, 2, "Status is not set correctly");
			String token = oAuthHelper.getAccessToken(validTenant);
			RestResponse getResponse = gHelpers.getIntegrationJobLog(validTenant, objectName, token);
			Assert.assertNotNull(getResponse, "Response is null");
			Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
			JsonParser parser = new JsonParser();
			JsonObject content = (JsonObject) parser.parse(getResponse.content);
			Assert.assertEquals(content.get("RecordsInserted").getAsInt(), 1, "Records inserted count not matching");
			Assert.assertEquals(content.get("Status").getAsString(), "Processed", "Records status is not Processed");
		}

		// Posting with previous date
		date = DateFormatter.getDateInFormat(yesterday, DefaultDateFormatPatterns);
		xmlString = BaseHelper.getStringFromXML("/resources/datafiles/wbsElement.txt");
		uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "WBS5");
		xmlString = xmlString.replace("@@@", date);
		response = pHelper.postWbsElement(validTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		flag = 1;
		status = 0;
		counter = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(validTenant, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}
		if (flag == 10)
			Assert.fail("Process Timedout");
		Assert.assertEquals(status, 2, "Earlier date request is ignored, which need to be processed");
	}
}
