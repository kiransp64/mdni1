package com.ariba.utilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class WriteFile {

	public static void main(String args[]) throws IOException {

		WriteFile wf = new WriteFile();
		// wf.userConsolidated();
		// wf.userGroupMapping();
		// wf.paymentTerms();
		// wf.paymentTermSteps();
		// wf.paymentTermStepDetails();
		// wf.requisitionHeader();
		// wf.requisitionDetails();
		// wf.requisitionSplitAccounting();
		// wf.userGroupMapping1();
		// wf.currencyConversionRate();
		 wf.incoTermsXML();
		// wf.purchaseGroupXML();
		// wf.companyCodeXML();
		// wf.costCenterXML();
		// wf.wbsElementXML();
		// wf.generalLedgerXML();
	}

	public static void writeFile1() throws IOException {
		File fout = new File("out.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 1000; i++) {
			bw.write("product" + i + ",pname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void accountingcombination() throws IOException {
		File fout = new File("AccountingCombination.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write(
				"UniqueName,CostCenter,SubAccount,Product,Company,BusinessUnit,Project,CombinationGroup,Region,Account");
		bw.newLine();
		int k = 0;
		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < 1000; j++) {
				for (int z = 1; z < 5; z++) {
					bw.write("accocomb" + k + ",costcenter" + i + ",saccount1,product" + j + ",company" + z
							+ ",bu1,,,,account1");
					bw.newLine();
					k++;
				}
			}
		}

		bw.close();
	}

	public static void company() throws IOException {
		File fout = new File("Company.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 10; i++) {
			bw.write("company" + i + ",comname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void account() throws IOException {
		File fout = new File("Account.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 2000000; i++) {
			bw.write("account" + i + ",aname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void subaccount() throws IOException {
		File fout = new File("SubAccount.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 10; i++) {
			bw.write("saccount" + i + ",saname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void businessUnit() throws IOException {
		File fout = new File("BusinessUnit.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 10; i++) {
			bw.write("bu" + i + ",bname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void product() throws IOException {
		File fout = new File("Product.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 1000; i++) {
			bw.write("product" + i + ",pname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void CostCenter() throws IOException {
		File fout = new File("CostCenter.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 1000; i++) {
			bw.write("costcenter" + i + ",cname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void fmd() throws IOException {
		File fout = new File("testfmd1edit.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name");
		bw.newLine();
		for (int i = 0; i < 30000; i++) {
			bw.write("fmdunique" + i + ",fnameedited" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void fmdTransactions() throws IOException {
		File fout = new File("testfmdTranslation.csv");
		FileOutputStream fos = new FileOutputStream(fout);
		String[] language = { "Danish", "Dutch", "French", "German", "Italian" };
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name,Language");
		bw.newLine();
		for (int j = 0; j < language.length; j++) {
			for (int i = 0; i < 600000; i++) {
				bw.write("fmdunique" + i + ",fname" + i + "," + language[j]);
				bw.newLine();
			}
		}

		bw.close();
	}

	public static void setID() throws IOException {
		File fout = new File("SetId.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("SETID,DESCRSHORT,DESCR,PurchasingUnit");
		bw.newLine();
		for (int i = 0; i < 1000; i++) {
			bw.write("SETID" + i + ",siddesc" + i + ",siddesc" + i + ",");
			bw.newLine();
		}

		bw.close();
	}

	public static void department() throws IOException {
		File fout = new File("Department.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("SETID,SETID_DEPTID_,DESCR,DESCRSHORT,DEPTID,PurchasingUnit");
		bw.newLine();
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 1000; j++)
				bw.write("SETID" + i + ",SETID" + i + ":DEPTID" + j + ",ddesc" + j + ",dsdesc" + j + ",DEPTID" + j
						+ ",");
			bw.newLine();
		}

		bw.close();
	}

	public static void vsoftAccountingCombination() throws IOException {
		File fout = new File("AccountingCombination.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write(
				"UniqueName,STATISTICS_CODE,SETID_DEPTID_,SETID_PRODUCT_,BUSINESS_UNIT_GL,SETID_ACCOUNT_,SETID_LOCATION_,BUSINESS_UNIT,CombinationGroup,SETID_PROJECT_");
		bw.newLine();
		for (int i = 0; i < 3000000; i++) {
			bw.write("accomb" + i + ",,,,,,,,FNC_ST,");
			bw.newLine();
		}

		bw.close();
	}

	public static void supplierLocation() throws IOException {
		File fout = new File("SupplierLocationConsolidated.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write(
				"VendorID,LocationID,Name,City,Street,PostalCode,Region,Country,Phone,Fax,EmailAddress,ContactName,ANPayEnabled,ContactID,PreferredOrderingMethod,PCardAcceptanceLevel,ChangeOrderRestrictions,AribaNetworkId,SplitOrderOnShipTo,PaymentModel,Locale");
		bw.newLine();
		for (int i = 0; i < 100000; i++) {
			bw.write("SUPPLIERRPC05,SUPPLIERRPCL" + i
					+ ",SUPPLIERRPC05,Sunnyvale,1234 12th Street,94089,CA,US,650-333-5678,650-333-1234,,,No,SUPPLIERRPC05,URL,0,0,,No,-1,");
			// bw.write("company" + i + ",comname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void purchasingOrgs() throws IOException {
		File fout = new File("PurchaseOrg.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("BUKRS,EKORG,EKOTX,PurchasingUnit");
		bw.newLine();
		for (int i = 0; i < 40000; i++) {
			bw.write("1000,PURORG" + i + ",Service Provider,");
			// bw.write("company" + i + ",comname" + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void PurchaseOrgSupplierCombo() throws IOException {
		File fout = new File("PurchasingOrgSupplierComb.csv");
		FileOutputStream fos = new FileOutputStream(fout);
		String[] suppliers = { "SUPPLIER13", "SUPPLIER11", "SUPPLIER12", "SUPPLIER14", "SUPPLIER15", "SUPPLIERRPC01",
				"SUPPLIERRPC02", "SUPPLIERRPC03", "SUPPLIERRPC04", "SUPPLIERRPC05" };
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("EKORG,LIFNR,XERSY,INCO1,ZTERM");
		bw.newLine();
		for (int j = 0; j < suppliers.length; j++) {
			for (int i = 0; i < 40000; i++) {
				bw.write("PURORG" + i + "," + suppliers[j] + ",No,,0001");
				bw.newLine();
			}
		}

		bw.close();
	}

	public static void partitionedCommodityCode() throws IOException {
		File fout = new File("ERPCommodityCode.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name,Description,CategoryId");
		bw.newLine();
		for (int i = 0; i < 40000; i++) {
			bw.write("RPCC" + i + ",RPCCName" + i + ",RPCCDesc" + i + ",");
			bw.newLine();
		}

		bw.close();
	}

	public static void commodityCode() throws IOException {
		File fout = new File("CommodityCode.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("Domain,UniqueName,Name,ParentUniqueName,Enabled");
		bw.newLine();
		for (int i = 0; i < 1000000; i++) {
			bw.write("unspsc,4111C" + i + ",instruments4111C" + i + ",41,Yes");
			bw.newLine();
		}

		bw.close();
	}

	public static void genericRelationType() throws IOException {
		File fout = new File("RelationType.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name,LeftClass,RightClass");
		bw.newLine();
		for (int i = 0; i < 8000000; i++) {
			bw.write("CCCERPCCMap" + i
					+ ",CCC to ERPCC,ariba.common.core.PartitionedCommodityCode,ariba.basic.core.CommodityCode");
			bw.newLine();
		}

		bw.close();
	}

	public static void genericRelationEntry() throws IOException {
		File fout = new File("RelationEntry.csv");
		FileOutputStream fos = new FileOutputStream(fout);
		String[] left = { "R1111", "R1112", "R1113", "R1114", "R1121", "R1122", "R1131", "R1132", "R1133", "R1134" };
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("RelationType.UniqueName,RightId,RightKey1,RightKey2,RightKey3,LeftId,LeftKey1,LeftKey2,LeftKey3");
		bw.newLine();
		for (int j = 0; j < left.length; j++) {
			for (int i = 0; i < 100000; i++) {
				bw.write("CCCERPCCMap3,4111C" + i + ",unspsc,4111C" + i + ",," + left[j] + "," + left[j] + ",,");
				bw.newLine();
			}
		}

		bw.close();
	}

	public static void userConsolidated() throws IOException {
		File fout = new File("UserConsolidated.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write(
				"PasswordAdapter,GenericSubAccount,LocaleID.UniqueName,GenericAccount,VanillaDeliverTo,ExpenseApprovalLimit,Organization.SystemID,GenericCompany,GenericProject,GenericProduct,Supervisor.PasswordAdapter,DefaultCurrency.UniqueName,GenericRegion,ManagementLevel,UniqueName,ApprovalLimit,Name,GenericBusinessUnit,Supervisor.UniqueName,PurchasingUnit,EmailAddress,GenericCostCenter");
		bw.newLine();
		for (int i = 0; i < 1000000; i++) {
			bw.write("PasswordAdapter1,1210,en_US,,TestUsera" + i + ",,[Buyer],GD,,,,USD,,8,testusera" + i
					+ ",,Test User" + i + ",US100,cnoll,US100,nobody@ansmtp.ariba.com,3300");
			bw.newLine();
		}

		bw.close();
	}

	public static void userGroupMapping() throws IOException {
		File fout = new File("UserGroupMapping.csv");
		FileOutputStream fos = new FileOutputStream(fout);
		// String[] left = {"Procurement Agent", "Contract Manager", "Budget
		// Manager", "Purchasing Manager", "Procurement Manager"};
		// String[] left = {"Supplier Collaboration User", "IT Manager",
		// "Invoice Rejection Specialist", "Spot Buy Administrator", "Receiving
		// Manager"};
		// String[] group = { "gg36", "gg37", "gg38", "gg39", "gg40", "gg41",
		// "gg42", "gg43", "gg44", "gg45", "gg46", "gg47", "gg48", "gg49"};
		String[] group = { "gg0", "gg1", "gg2", "gg3", "gg4" };
		String[] pu = { "BUY01", "BUY02", "DEU01", "DEUE1", "GBR01" };
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,User_UniqueName,PasswordAdapter,PurchasingUnit");
		bw.newLine();
		for (int j = 0; j < group.length; j++) {
			for (int i = 0; i < 1000000; i++) {
				bw.write(group[j] + ",testusera" + i + ",PasswordAdapter1," + pu[j]);
				bw.newLine();
			}
		}
		bw.close();
	}

	public static void userGroupMapping1() throws IOException {
		File fout = new File("UserGroupMapping.csv");
		FileOutputStream fos = new FileOutputStream(fout);
		String[] group = { "gg0", "gg1", "gg2", "gg3", "gg4" };
		// String[] group = { "gg0" };
		String[] pu = { "BUY01", "BUY02", "DEU01", "DEUE1", "GBR01" };
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,User_UniqueName,PasswordAdapter,PurchasingUnit");
		bw.newLine();
		for (int j = 0; j < group.length; j++) {
			for (int i = 0; i < 20000; i++) {
				bw.write(group[j] + ",testuserb" + i + ",PasswordAdapter1,");
				bw.newLine();
			}
		}

		bw.close();
	}

	public static void requisitionHeader() throws IOException {
		File fout = new File("RequisitionHeader.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("Cp1252");
		bw.newLine();
		bw.write(
				"Requisition_Number,Requester,RequesterPasswordAdapter,Preparer,PreparerPasswordAdapter,Title,OriginatingSystem,OriginatingSystemReferenceID");
		bw.newLine();
		for (int i = 100; i < 10100; i++) {
			bw.write(i + ",ghalas,PasswordAdapter1,ghalas,PasswordAdapter1,ReqImportNewk" + i + ",SG," + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void requisitionDetails() throws IOException {
		File fout = new File("RequisitionDetails.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("Cp1252,,,,,,,,,,,,,,,,,");
		bw.newLine();
		bw.write(
				"Requisition_Number,Line_Number,Supplier,Supplier_Location,Contact_Id,DeliverTo,Need_By_Date,CommonCommodity_Code,Domain,Commodity_Code,Quantity,Unit_Price,Unit_Of_Measure,Currency,Item_Description,ManPartNo,ItemPartNo,SplitAccountingType");
		bw.newLine();
		String[] splitAccType = { "", "_Quantity", "_Amount", "_Percentage" };
		for (int i = 100; i < 10100; i++) {
			for (int j = 1; j <= 1; j++) {
				bw.write(i + "," + j
						+ ",11,14,63,Sample DeliverTo,9/15/2017,51,unspsc,,10,820,EA,USD,Simple Generic Req 1 Item " + j
						+ ",SampleManPartNo,SampleItemPartNo,_Percentage");
				bw.newLine();
			}

		}

		bw.close();
	}

	public static void requisitionSplitAccounting() throws IOException {
		File fout = new File("RequisitionSplitAccounting.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("Cp1252,,,,,,,,,,,,,,");
		bw.newLine();
		bw.write(
				"Requisition_Number,Line_Number,NumberInCollection,Percentage,Amount,Currency,Quantity,Company,Business_Unit,Cost_Center,Account,Sub_Account,Product,Project,Region");
		bw.newLine();
		for (int i = 100; i < 10100; i++) {
			for (int j = 1; j <= 1; j++) {
				// if (j == 1) {
				// bw.write(i + ",1,"+j+",40,,,,02,US002,4000,7520,5009,,,");
				// } else {
				// bw.write(i + ",1,"+j+",60,,,,02,US002,4000,7752,5009,,,");
				// }
				bw.write(i + ",1," + j + ",100,,,,02,US002,4000,7752,5009,,,");
				bw.newLine();
			}

		}

		bw.close();
	}

	public static void requisitionHeaderPsoft() throws IOException {
		File fout = new File("RequisitionHeader.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("Cp1252,,,,,,");
		bw.newLine();
		bw.write(
				"Requisition_Number,Requester,RequesterPasswordAdapter,Preparer,PreparerPasswordAdapter,Title,OriginatingSystem,OriginatingSystemReferenceID");
		bw.newLine();
		for (int i = 53000; i < 58000; i++) {
			bw.write(i + ",mditka,PasswordAdapter1,cnoll,PasswordAdapter1,ReqImportByPercentage-" + i
					+ " Line-PSFT,PSoft," + i);
			bw.newLine();
		}

		bw.close();
	}

	public static void requisitionDetailsPsoft() throws IOException {
		File fout = new File("RequisitionDetails.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("Cp1252");
		bw.newLine();
		bw.write(
				"Requisition_Number,Line_Number,Supplier,Supplier_Location,SupplierLocation_SetID,Contact_Id,DeliverTo,Need_By_Date,Commodity_Code,CommonCommodity_Code, Domain, Quantity,Unit_Price,Unit_Of_Measure,Currency,Item_Description,ManPartNo,ItemPartNo,SplitAccountingType");
		bw.newLine();
		for (int i = 53000; i < 58000; i++) {
			for (int j = 1; j <= 10; j++) {
				bw.write(i + "," + j
						+ ",sid496,sid496-hq,SHARE,496-HQ,Deliver to 3,09/15/2017,SHARE:00017,14,unspsc,4,876,EA,USD,PSoft Req "
						+ i + " Item " + j + ",SampleManPartNo,SampleItemPartNo 1,_Percentage");
				bw.newLine();
			}

		}

		bw.close();
	}

	public static void requisitionSplitAccountingPsoft() throws IOException {
		File fout = new File("RequisitionSplitAccounting.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("Cp1252");
		bw.newLine();
		bw.write(
				"Requisition_Number,Line_Number,NumberInCollection,Percentage,Amount,Currency,Quantity,Account,GL_Business_Unit,Location_Code,Department,Product,Statistics_Code");
		bw.newLine();
		for (int i = 53000; i < 58000; i++) {
			for (int j = 1; j <= 10; j++) {
				bw.write(i + ",1," + j + ",10,,,,SHARE:110200,DEU01,SHARE:BUY05,SHARE:13000,SHARE:PRNTRS,");
				bw.newLine();
			}

		}

		bw.close();
	}

	public static void paymentTerms() throws IOException {
		File fout = new File("PaymentTerms.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("UniqueName,Name,Default,Description");
		bw.newLine();
		for (int i = 0; i < 1; i++) {
			bw.write("\"AT" + i + "\",\"AT" + i
					+ "\",\"No\",\"Within 10 days 2 % cash discount, Within 30 days 1 % cash discount\"");
			bw.newLine();

		}

		bw.close();
	}

	public static void paymentTermSteps() throws IOException {
		File fout = new File("PaymentTermSteps.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("Parent.UniqueName,StepJoinToken,InstallmentPercent");
		bw.newLine();
		for (int i = 0; i < 11000; i++) {
			bw.write("\"AT0\",\"15097" + i + "\",\"1\"");
			bw.newLine();

		}

		bw.close();
	}

	public static void paymentTermStepDetails() throws IOException {
		File fout = new File("PaymentTermStepDetails.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("Parent.StepJoinToken,PayInDays,Discount,DiscountType");
		bw.newLine();
		for (int i = 0; i < 11000; i++) {
			bw.write("\"15097" + i + "\",\"" + i + "\",\"0\",\"percent\"");
			bw.newLine();

		}

		bw.close();
	}

	public static void currencyConversionRate() throws IOException {
		File fout = new File("CurrencyConversionRate.csv");
		FileOutputStream fos = new FileOutputStream(fout);

		// DateFormat dateFormat = new
		// SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		DateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write("\"UTF-8\"");
		bw.newLine();
		bw.write("FromCurrency,ToCurrency,UniqueName,Rate,Date");
		bw.newLine();
		for (int i = 1; i <= 50000; i++) {
			Date date = new Date();
			String todate = dateFormat.format(date);
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -i);
			Date todate1 = cal.getTime();
			String fromdate = dateFormat.format(todate1);
			bw.write("\"USD\",\"EUR\",\"USD:EUR\",\"0." + i + "\",\"" + fromdate + "\"");
			bw.newLine();

		}

		bw.close();
	}

	public static void incoTermsXML() throws IOException {
		File fout = new File("Incoterms.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		for (int i = 65; i <= 90; i++) {
			for (int j = 65; j <= 90; j++) {
				for (int k = 65; k <= 90; k++) {

					bw.write("<Incoterms>");
					bw.newLine();
					bw.write("<Code>");
					bw.newLine();
					bw.write("<content>" + (char) i + (char) j + (char) k + "</content>");
					bw.newLine();
					bw.write("</Code>");
					bw.newLine();
					bw.write("<LocationMandatoryIndicator>true</LocationMandatoryIndicator>");
					bw.newLine();
					bw.write("<Description languageCode=\"VI\">Chi phí và phí vận chuyển</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"HI\">लागत और भाड़ा</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"SH\">Troškovi i tovar</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"CA\">Costos i ports</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"LV\">Izmaksas un vedmaksa</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"LT\">Kaina ir frachtas</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"BG\">Разходи и навло</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"SV\">C &amp; F</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"FI\">Kulut ja rahti</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"TR\">c.&amp; f.</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"ES\">Costes y flete</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"RU\">Затраты и фрахт</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"SK\">Náklady a prepravné</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"PT\">Custos e frete</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"NO\">Kostnader og frakt</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"NL\">Kosten en vracht</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"ZF\">成本和運費</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"PL\">Koszty i fracht</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"DA\">Omkostninger og fragt</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"ZH\">成本和运费</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"TH\">ต้นทุนและค่าขนส่ง</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"KO\">C&amp;F</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"RO\">Costuri şi transport</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"SL\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"EN\">Tros i zov</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VA\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VB\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VC\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VD\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VE\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VF\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VG\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VH\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VI\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VJ\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VK\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VL\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VM\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VN\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VO\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VP\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("<Description languageCode=\"VQ\">Stroški in tovor</Description>");
					bw.newLine();
					bw.write("</Incoterms>");
					bw.newLine();
					counter++;
				}
			}
		}
		System.err.println("No of entries ---------" + counter);
		bw.close();
	}

	public static void purchaseGroupXML() throws IOException {
		File fout = new File("PurchaseGroup.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:PurchasingGroupMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS98086E7B8FC398853BDF:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFBE7F1ED6ACCB473E7D11A0D4</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-be7f-1ed6-accb-473e7d11a0d4</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-11-24T15:25:29Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<PurchasingGrpReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-24T15:25:29Z</TransmissionStartDateTime>");
		bw.newLine();
		for (int k = 0; k < 2000; k++) {

			bw.write("<PurchasingGroup>");
			bw.newLine();
			bw.write("<PurchasingGroupID>A" + k + "</PurchasingGroupID>");
			bw.newLine();
			bw.write("<PurchasingGroupName>A" + k + "</PurchasingGroupName>");
			bw.newLine();
			bw.write("</PurchasingGroup>");
			bw.newLine();
			counter++;
		}
		bw.write("</PurchasingGrpReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:PurchasingGroupMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		System.err.println("No of entries ---------" + counter);
		bw.close();
	}

	public static void companyCodeXML() throws IOException {
		File fout = new File("CompanyCode.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:BNSCompanyCodeMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ERW:/1SAI/TASD11108EA78A03EF3E3D2:751\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>FA163EB372321EE6AF8BE10D95CE952D</ID>");
		bw.newLine();
		bw.write("<UUID>fa163eb3-7232-1ee6-af8b-e10d95ce952d</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-12-07T09:23:59Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>QE6CLNT910</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<CompanyCodeReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-12-07T09:23:59Z</TransmissionStartDateTime>");
		bw.newLine();

		for (int i = 65; i <= 90; i++) {
			for (int j = 65; j <= 90; j++) {
				for (int k = 65; k <= 90; k++) {
					bw.write("<CompanyCode>");
					bw.newLine();
					bw.write("<CompanyCode>" + (char) i + (char) j + (char) k + "</CompanyCode>");
					bw.newLine();
					bw.write("<CompanyCodeName>" + (char) i + (char) j + (char) k + "Name</CompanyCodeName>");
					bw.newLine();
					bw.write("</CompanyCode>");
					bw.newLine();
					counter++;
				}
			}
		}
		bw.write("</CompanyCodeReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:BNSCompanyCodeMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		System.err.println("No of entries ---------" + counter);
		bw.close();
	}

	public static void costCenterXML() throws IOException {
		File fout = new File("CostCenter.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:BNSCostCentreMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS3CD26C740073BF5A4D54:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFC5FF1ED6AFAC50B2FF9C4B98</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-c5ff-1ed6-afac-50b2ff9c4b98</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-12-08T16:22:38Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_003</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>FIELDGLASS</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();

		for (int i = 65; i <= 90; i++) {
			for (int j = 65; j <= 90; j++) {
				for (int k = 65; k <= 90; k++) {

					bw.write("<CostCentreReplicationRequestMessage>");
					bw.newLine();
					bw.write("<MessagerHeader />");
					bw.newLine();
					bw.write("<TransmissionStartDateTime>2016-12-08T16:22:38Z</TransmissionStartDateTime>");
					bw.newLine();
					bw.write("<CostCentre>");
					bw.newLine();
					bw.write("<CurrencyKey>EUR</CurrencyKey>");
					bw.newLine();
					bw.write("<CostCentreKey>");
					bw.newLine();
					bw.write("<CompanyCode>" + (char) i + (char) j + (char) k + "</CompanyCode>");
					bw.newLine();
					bw.write("<CostCentre>" + (char) i + (char) j + (char) k + "</CostCentre>");
					bw.newLine();
					bw.write(" </CostCentreKey>");
					bw.newLine();
					bw.write(" <CostCentreName languageCode=\"EN\">" + (char) i + (char) j + (char) k
							+ "Name</CostCentre>");
					bw.newLine();
					bw.write("</CostCentre>");
					bw.newLine();
					bw.write("</CostCentreReplicationRequestMessage>");
					bw.newLine();
					counter++;
				}
			}
		}

		bw.write("</n0:BNSCostCentreMasterDataReplicationBulkRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		System.err.println("No of entries ---------" + counter);
		bw.close();
	}

	public static void wbsElementXML() throws IOException {
		File fout = new File("WBSElement.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:WBSElementMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/PS\" xmlns:prx=\"urn:sap.com:proxy:CC2:/1SAI/TAE61A28A667A7D3E4E2B1E:768\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>8CDCD4008ED01ED6BD81DFE0C2BE91EA</ID>");
		bw.newLine();
		bw.write("<UUID>8cdcd400-8ed0-1ed6-bd81-dfe0c2be91ea</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-02-16T06:14:18Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>0MB85VI</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>PS_ARIBA_0111</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();

		for (int i = 0; i <= 2500; i++) {

			bw.write("<WBSElementReplicationRequestMessage>");
			bw.newLine();
			bw.write("<MessageHeader/>");
			bw.newLine();
			bw.write("<TransmissionStartDateTime>2017-02-16T06:14:18Z</TransmissionStartDateTime>");
			bw.newLine();
			bw.write("<WBSElement>");
			bw.newLine();
			bw.write("<ActionCode>01</ActionCode>");
			bw.newLine();
			bw.write("<WBSElement>" + "AWBS" + i + "</WBSElement>");
			bw.newLine();
			bw.write("<WBSElementInternalID>" + "00010" + i + "</WBSElementInternalID>");
			bw.newLine();
			bw.write("<Project>" + "AWBS" + i + "</Project>");
			bw.newLine();
			bw.write("<ProjectInternalID>" + "00010" + i + "</ProjectInternalID>");
			bw.newLine();
			bw.write("<Description>" + "AWBS" + i + "</Description>");
			bw.newLine();
			bw.write("<CompanyCode>1710</CompanyCode>");
			bw.newLine();
			bw.write("<ControllingArea>A000</ControllingArea>");
			bw.newLine();
			bw.write("<ProfitCenter>YB101</ProfitCenter>");
			bw.newLine();
			bw.write("<Currency>USD</Currency>");
			bw.newLine();
			bw.write("<ControllingObjectClass>");
			bw.newLine();
			bw.write("<content>OC</content>");
			bw.newLine();
			bw.write("</ControllingObjectClass>");
			bw.newLine();
			bw.write("<WBSElementIsPlanningElement>false</WBSElementIsPlanningElement>");
			bw.newLine();
			bw.write("<WBSIsAccountAssignmentElement>true</WBSIsAccountAssignmentElement>");
			bw.newLine();
			bw.write("<WBSElementIsBillingElement>false</WBSElementIsBillingElement>");
			bw.newLine();
			bw.write("<WBSIsStatisticalWBSElement>false</WBSIsStatisticalWBSElement>");
			bw.newLine();
			bw.write("</WBSElement>");
			bw.newLine();
			bw.write("</WBSElementReplicationRequestMessage>");
			bw.newLine();
			counter++;
		}

		bw.write("</n0:WBSElementMasterDataReplicationBulkRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		System.err.println("No of entries ---------" + counter);
		bw.close();
	}

	public static void generalLedgerXML() throws IOException {
		File fout = new File("GLAccount.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:BNSGLAccountMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ERW:/1SAI/TASD7E0953175F3927C64EA:751\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>FA163EB372321EE6AF8BF504266B553A</ID>");
		bw.newLine();
		bw.write("<UUID>fa163eb3-7232-1ee6-af8b-f504266b553a</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-12-07T09:27:51Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>QE6CLNT910</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		for (int i = 0; i <= 2500; i++) {

			bw.write("<GLAccountReplicationRequestMessage>");
			bw.newLine();
			bw.write("<MessageHeader/>");
			bw.newLine();
			bw.write("<TransmissionStartDateTime>2016-12-07T09:27:51Z</TransmissionStartDateTime>");
			bw.newLine();
			bw.write("<GLAccount>");
			bw.newLine();
			bw.write("<IsRelevantForProcurementIndicator>true</IsRelevantForProcurementIndicator>");
			bw.newLine();
			bw.write("<GLAccountKey>");
			bw.newLine();
			bw.write("<CompanyCode>3000</CompanyCode>");
			bw.newLine();
			bw.write("<GLAccount>" + "00010" + i + "</GLAccount>");
			bw.newLine();
			bw.write("</GLAccountKey>");
			bw.newLine();
			bw.write("<GLAccountName languageCode=\"EN\">" + "GL" + i + "</GLAccountName>");
			bw.newLine();
			bw.write("</GLAccount>");
			bw.newLine();
			bw.write("</GLAccountReplicationRequestMessage>");
			bw.newLine();
			counter++;
		}
		bw.write("</n0:BNSGLAccountMasterDataReplicationBulkRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		System.err.println("No of entries ---------" + counter);
		bw.close();
	}

}
