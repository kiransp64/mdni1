package com.ariba.mdssearchtests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.MDSSearchHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.pojos.RestResponse;

public class MDSSearchTests extends BaseHelper {

	OAuthHelper oAuthHelper = new OAuthHelper();
	MDSSearchHelper sHelper = new MDSSearchHelper();

	@Test
	public void sg_fieldsvalidation() throws Exception {
		JSONArray issuesArray = fieldsValidation("sg", SG_REALM, SG_USERNAME, SG_ANID);
		Assert.assertFalse(issuesArray.length() > 0, "Few fields are missing. Details: " + issuesArray.toString());
	}

	@Test
	public void sap_fieldsvalidation() throws Exception {
		JSONArray issuesArray = fieldsValidation("sap", SAP_REALM, SAP_USERNAME, SAP_ANID);
		Assert.assertFalse(issuesArray.length() > 0, "Few fields are missing. Details: " + issuesArray.toString());
	}

	@Test
	public void psoft_fieldsvalidation() throws Exception {
		JSONArray issuesArray = fieldsValidation("psoft", PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID);
		Assert.assertFalse(issuesArray.length() > 0, "Few fields are missing. Details: " + issuesArray.toString());
	}

	private JSONArray fieldsValidation(String variant, String realmName, String username, String anid)
			throws Exception {

		JSONArray issuesArray = new JSONArray();
		HashMap<String, String> missingFields = new HashMap<String, String>();
		for (int j = 0; j < entities.length(); j++) {
			JSONObject entity = (JSONObject) entities.get(j);
			String entityName = entity.get("entityName").toString().replace("\"", "");
			if (entity.get("supportedvariants").toString().contains(variant)) {
				String missFields = "";
				/* Generating access token */
				String token = oAuthHelper.getAccessToken(realmName, username, anid, ORIGIN_SYS);
				System.out.println("Token ----" + token);

				/* Enabling hana search before querying for data */
				RestResponse res = sHelper.enablehanasearch(token);
				System.out.println(res.getContent());

				/* Making Api call for each entity to get data from hana */
				String key = "";
				res = sHelper.getEntity(token, entityName + "?rows=1000");

				if (res.getCode() == 200) {
					String content = res.getContent();
					System.err.println(content);
					JSONArray entityRes = new JSONArray(content);

					System.out.println(entityRes.length());
					if (entityRes.length() > 0) {
						/*
						 * Getting expected fields for the entity in the variant
						 * and comparing all expected fields are present in API
						 * response
						 */
						JSONArray expectedFields = new JSONArray(entity.get(variant + "_fields").toString());
						System.out.println(expectedFields);
						for (int i = 0; i < expectedFields.length(); i++) {
							boolean flag = false;
							String exp = expectedFields.getString(i);
							int index = 0;
							// if
							// (entityName.equalsIgnoreCase("commoditycodes"))
							// index = 1;
							// else if (entityName.equalsIgnoreCase("users"))
							// index = entityRes.length() - 1;
							while (index < entityRes.length()) {
								JSONObject output = new JSONObject(entityRes.get(index).toString());
								Iterator<String> itr = output.keys();
								while (itr.hasNext()) {
									key = itr.next();
									if (key.equals(exp)) {
										flag = true;
										break;
									}
								}
								if (flag)
									break;
								else
									index++;
							}
							if (entityRes.length() == 0) {
								System.err.println("No data retrieved from hana for entity " + entityName);
								flag = true;
								break;
							}

							if (!flag) {
								missFields = missFields + "," + exp;
								System.err.println("Field " + exp + " is missing in entity " + entityName);
							}
						}
						if (missFields != "")
							missingFields.put(entityName + "--" + variant, missFields);
					} else {
						missingFields.put(entityName + "--" + variant, "Obtained Blank Response");
					}
				} else {
					missingFields.put(entityName + "--" + variant, res.getContent());
				}
			} else {
				System.err.println("Entity " + entityName + " is not supported in the variant " + variant);
			}
		}
		// Printing all the missing fields
		Iterator<String> missItr = missingFields.keySet().iterator();
		while (missItr.hasNext()) {
			String missingEntitiesKeys = missItr.next();
			String missingFieldsRetrieved = missingFields.get(missingEntitiesKeys);
			System.err.println("Field(s) " + missingFieldsRetrieved + " are missing in entity " + missingEntitiesKeys);
			JSONObject issue = new JSONObject();
			issue.put(missingEntitiesKeys, missingFieldsRetrieved);
			issuesArray.put(issue);
		}
		return issuesArray;
	}

	@Test
	public void sg_searchByFields() throws Exception {
		JSONArray issuesArray = fieldsSearch("sg", SG_REALM, SG_USERNAME, SG_ANID);
		Assert.assertFalse(issuesArray.length() > 0,
				"Issues when searching for few entities. Details: " + issuesArray.toString());
	}

	@Test
	public void sap_searchByFields() throws Exception {
		JSONArray issuesArray = fieldsSearch("sap", SAP_REALM, SAP_USERNAME, SAP_ANID);
		Assert.assertFalse(issuesArray.length() > 0,
				"Issues when searching for few entities. Details: " + issuesArray.toString());
	}

	@Test
	public void psoft_searchByFields() throws Exception {
		JSONArray issuesArray = fieldsSearch("psoft", PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID);
		Assert.assertFalse(issuesArray.length() > 0,
				"Issues when searching for few entities. Details: " + issuesArray.toString());
	}

	private JSONArray fieldsSearch(String variant, String realmName, String username, String anid) throws Exception {

		JSONArray issuesArray = new JSONArray();
		HashMap<String, List<String>> responseIssue = new HashMap<String, List<String>>();
		HashMap<String, String> searchIssues = new HashMap<String, String>();
		for (int i = 0; i < entities.length(); i++) {
			JSONObject entity = (JSONObject) entities.get(i);
			String entityName = entity.get("entityName").toString().replace("\"", "");
			if (entity.get("supportedvariants").toString().contains(variant)) {
				String searchIssueFields = "";
				/* Generating access token */
				String token = oAuthHelper.getAccessToken(realmName, username, anid, ORIGIN_SYS);
				System.out.println("Token ----" + token);

				/* Enabling hana search before quering for data */
				RestResponse res = sHelper.enablehanasearch(token);
				System.out.println(res.getContent());

				/* Making Api call for each entity to get data from hana */
				res = sHelper.getEntity(token, entityName);
				String content = res.getContent();

				if (res.getCode() == 200) {
					/* Getting response from main call */
					JSONArray entityRes = new JSONArray(content);
					System.out.println(entityRes.length());
					/* Iterating through each object in response */
					if (entityRes.length() > 0) {
						int index = 0;
						if (entityName.equalsIgnoreCase("commoditycodes"))
							index = 1;
						if (entityName.equalsIgnoreCase("users"))
							index = entityRes.length() - 1;
						/* retrieving keys from response obj */
						JSONObject resObj = entityRes.getJSONObject(index);
						Iterator<String> keysItr = resObj.keys();
						while (keysItr.hasNext()) {
							String key = keysItr.next();
							String value = " ";
							try {
								if (resObj.get(key) != JSONObject.NULL && !key.equalsIgnoreCase("Active"))
									value = resObj.getString(key);
							} catch (JSONException e) {
								/// TODO: Remove this try catch after list is
								/// implemented to string by dev
							}

							if (entityName.equalsIgnoreCase("paymentterms") && key.contains("Description"))
								value = "";
							/*
							 * Forming URL dynamically with field and value
							 * after excluding few filters
							 */
							if (!(value.equals(" ") || value.equals("") || value.contains("null")
									|| value.equalsIgnoreCase("NULL") || value.equals(null) || value.contains("{")
									|| value.contains(".") || value.contains("&") || value.contains("[")
									|| value.contains("=") || value.contains("/") || value.contains("+")
									|| key.contains("hana_entityName") || key.equals("Active")
									|| (key.contains("ir_classname")))) {

								String encodedValue = value;
								if (value.contains(" "))
									encodedValue = encodedValue.replaceAll(" ", "%20");
								// value = value.substring(0,
								// value.indexOf("
								// "));
								String urlParam = entityName + "?" + key + "=" + encodedValue;
								try {
									RestResponse searchRes = sHelper.getEntity(token, urlParam);
									if (searchRes.getCode() == 200) {
										JSONArray searcgResponse = new JSONArray(searchRes.getContent());
										/*
										 * Getting response and validating the
										 * search term
										 */
										if (searcgResponse.length() > 0) {
											for (int j = 0; j < searcgResponse.length(); j++) {
												JSONObject searchObj = searcgResponse.getJSONObject(j);
												boolean keyPresent = false;
												Iterator<String> keyItr = searchObj.keys();
												while (keyItr.hasNext()) {
													if (keyItr.next().equals(key))
														keyPresent = true;
												}
												if (keyPresent) {
													try {
														String searchResValue = searchObj.getString(key);
														if (!searchResValue.toLowerCase()
																.contains(value.toLowerCase())) {
															/*
															 * Search filter is
															 * not working with
															 * given key. So
															 * adding it to
															 * issue list
															 */
															searchIssueFields = searchIssueFields + "," + key;
															break;

														}
													} catch (JSONException e) {
														/*
														 * Exception occured
														 * while converting
														 */
														searchIssueFields = searchIssueFields + "," + key;
														break;
													}

												} else {
													/*
													 * Key is not present in the
													 * response
													 */
													searchIssueFields = searchIssueFields + "," + key;
													break;
												}
											}
										} else {
											/* Blank response for fields */
											searchIssueFields = searchIssueFields + "," + key;
										}
									} else {
										List<String> issueList = new ArrayList<String>();
										issueList.add(0, SEARCHBASEURL + "/data/list/" + urlParam);
										issueList.add(1, searchRes.getContent());
										responseIssue.put(entityName + "-" + key, issueList);
									}
								} catch (Exception e) {

									List<String> issueList = new ArrayList<String>();
									issueList.add(0, SEARCHBASEURL + "/data/list/" + urlParam);
									issueList.add(1, e.getLocalizedMessage());
									responseIssue.put(entityName + "-" + key, issueList);

								}
							}
						}

					} else {
						System.err.println("Blank response retrieved for entity " + entityName);
					}

					if (searchIssueFields != "")
						searchIssues.put(entityName + "--" + variant, searchIssueFields);
				} else {
					List<String> issueList = new ArrayList<String>();
					issueList.add(0, SEARCHBASEURL + "/data/list/" + entityName);
					issueList.add(1, res.getContent());
					responseIssue.put(entityName, issueList);
				}
			} else {
				System.err.println("Entity " + entityName + " is not supported in the variant " + variant);
			}
		}

		/* Printing all the fields where search is not working */

		Iterator<String> missItr = searchIssues.keySet().iterator();
		System.err.println(
				"************************* Search param(s) not returning correct data *************************");
		while (missItr.hasNext()) {
			String missingEntitiesKeys = missItr.next();
			String missingFieldsRetrieved = searchIssues.get(missingEntitiesKeys);
			System.err.println("Search on these fields - " + missingFieldsRetrieved + " is not working in entity "
					+ missingEntitiesKeys);
			System.err.println();
			JSONObject issue = new JSONObject();
			issue.put(missingEntitiesKeys, missingFieldsRetrieved);
			issuesArray.put(issue);
		}

		/* Printing all the requests for which we got errored response */
		Iterator<String> errorItr = responseIssue.keySet().iterator();
		System.err.println("************************* Request(s) giving error response *************************");
		while (errorItr.hasNext()) {
			String errorResKey = errorItr.next();
			List<String> errorList = responseIssue.get(errorResKey);
			System.err.println("Search is failing for " + errorResKey + " and below are request/response details");
			System.err.println("REQUEST: " + errorList.get(0));
			System.err.println("RESPONSE: " + errorList.get(1));
			System.err.println();
			JSONObject details = new JSONObject();
			details.put("Request", errorList.get(0));
			details.put("Response", errorList.get(1));
			JSONObject issue = new JSONObject();
			issue.put(errorResKey, details);
			issuesArray.put(issue);
		}

		return issuesArray;
	}

	@Test
	public void sg_searchByUniqueName() throws Exception {
		JSONArray issuesArray = searchByUniqueName("sg", SG_REALM, SG_USERNAME, SG_ANID);
		Assert.assertFalse(issuesArray.length() > 0,
				"Issues when searching for few entities with uniqueName url. Details: " + issuesArray.toString());
	}

	@Test
	public void sap_searchByUniqueName() throws Exception {
		JSONArray issuesArray = searchByUniqueName("sap", SAP_REALM, SAP_USERNAME, SAP_ANID);
		Assert.assertFalse(issuesArray.length() > 0,
				"Issues when searching for few entities with uniqueName url. Details: " + issuesArray.toString());
	}

	@Test
	public void psoft_searchByUniqueName() throws Exception {
		JSONArray issuesArray = searchByUniqueName("psoft", PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID);
		Assert.assertFalse(issuesArray.length() > 0,
				"Issues when searching for few entities with uniqueName url. Details: " + issuesArray.toString());
	}

	private JSONArray searchByUniqueName(String variant, String realmName, String username, String anid)
			throws Exception {

		JSONArray issuesArray = new JSONArray();
		HashMap<String, List<String>> responseIssue = new HashMap<String, List<String>>();
		HashMap<String, String> searchIssues = new HashMap<String, String>();
		for (int i = 0; i < entities.length(); i++) {
			JSONObject entity = (JSONObject) entities.get(i);
			String entityName = entity.get("entityName").toString().replace("\"", "");
			if (entity.get("supportedvariants").toString().contains(variant) && !entityName.equalsIgnoreCase("fmds")) {
				String searchIssueFields = "";
				/* Generating access token */
				String token = oAuthHelper.getAccessToken(realmName, username, anid, ORIGIN_SYS);
				System.out.println("Token ----" + token);

				/* Enabling hana search before quering for data */
				RestResponse res = sHelper.enablehanasearch(token);
				System.out.println(res.getContent());

				/* Making Api call for each entity to get data from hana */
				res = sHelper.getEntityByUniqueName(token, entityName);
				String content = res.getContent();

				if (res.getCode() == 200) {
					/* Getting response from main call */
					JSONArray entityRes = new JSONArray(content);
					System.out.println(entityRes.length());
					/* Iterating through each object in response */
					if (entityRes.length() > 0
							&& entity.get(variant + "_fields").toString().contains("ex_UniqueName")) {
						int index = 0;
						/* retrieving keys from response obj */
						JSONObject resObj = entityRes.getJSONObject(index);
						String uniqueName = resObj.getString("ex_UniqueName");
						while ((uniqueName.contains("/") || uniqueName.contains("."))
								&& (index + 1 <= entityRes.length())) {
							resObj = entityRes.getJSONObject(index++);
							uniqueName = resObj.getString("ex_UniqueName");
						}
						if (uniqueName != "") {
							/*
							 * Make call to search by UniqueName URL Ex:
							 * localhost:8888/mds/api/data/users/cnoll
							 */
							String encodedUniqueName = uniqueName;
							if (uniqueName.contains(" "))
								encodedUniqueName = uniqueName.replaceAll(" ", "%20");
							RestResponse uniqueNameRes = sHelper.getEntityByUniqueName(token,
									entityName + "/" + encodedUniqueName);
							String uniqueNameResContent = uniqueNameRes.getContent();
							if (uniqueNameRes.getCode() == 200) {

								JSONArray uniqueNameArray = new JSONArray(uniqueNameResContent);
								if (uniqueNameArray.length() == 0)
									searchIssueFields = searchIssueFields + ",Blank Response for " + uniqueName;
								for (int j = 0; j < uniqueNameArray.length(); j++) {
									JSONObject uniqueNameObj = (JSONObject) uniqueNameArray.get(j);
									if (!uniqueNameObj.get("ex_UniqueName").equals(uniqueName))
										searchIssueFields = searchIssueFields + "," + uniqueName;
								}

							} else {
								List<String> issueList = new ArrayList<String>();
								issueList.add(0, SEARCHBASEURL + "/data/" + entityName + "/" + uniqueName);
								issueList.add(1, uniqueNameResContent);
								responseIssue.put(entityName, issueList);
							}

						} else {
							System.err.println(
									"UniqueName is null for this entity " + entityName + ", hence skipping it.");
						}

					} else {
						System.err.println("Blank response retrieved for entity " + entityName);
					}

					if (searchIssueFields != "")
						searchIssues.put(entityName + "--" + variant, searchIssueFields);
				} else {
					List<String> issueList = new ArrayList<String>();
					issueList.add(0, SEARCHBASEURL + "/data/" + entityName);
					issueList.add(1, res.getContent());
					responseIssue.put(entityName, issueList);
				}
			} else {
				System.err.println("Entity " + entityName + " is not supported in the variant " + variant);
			}
		}
		// Printing all the fields where search is not working

		Iterator<String> missItr = searchIssues.keySet().iterator();
		System.err.println(
				"************************* Search param(s) not returning correct data *************************");
		while (missItr.hasNext()) {
			String missingEntitiesKeys = missItr.next();
			System.err.println("Search on uniquename is not working for these entities - " + missingEntitiesKeys);
			System.err.println();
			JSONObject issue = new JSONObject();
			issue.put(missingEntitiesKeys, "Search on uniquename is not working");
			issuesArray.put(issue);
		}

		/* Printing all the requests for which we got errored response */
		Iterator<String> errorItr = responseIssue.keySet().iterator();
		System.err.println("************************* Request(s) giving error response *************************");
		while (errorItr.hasNext()) {
			String errorResKey = errorItr.next();
			List<String> errorList = responseIssue.get(errorResKey);
			System.err.println("Search is failing for " + errorResKey + " and below are request/response details");
			System.err.println("REQUEST: " + errorList.get(0));
			System.err.println("RESPONSE: " + errorList.get(1));
			System.err.println();
			JSONObject details = new JSONObject();
			details.put("Request", errorList.get(0));
			details.put("Response", errorList.get(1));
			JSONObject issue = new JSONObject();
			issue.put(errorResKey, details);
			issuesArray.put(issue);
		}

		return issuesArray;
	}

	@Test
	public void sg_searchUsersBelongsToGroup() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SG_REALM, SG_USERNAME, SG_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "groups/Purchasing%20User/users?includeinactive=true";
		res = sHelper.getEntityByUniqueName(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " belonging to Purchasing User Group");
		}
	}

	@Test
	public void sap_searchUsersBelongsToGroup() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "groups/Purchasing%20User/users?includeinactive=true";
		res = sHelper.getEntityByUniqueName(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " belonging to Purchasing User Group");
		}
	}

	@Test
	public void psoft_searchUsersBelongsToGroup() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "groups/Purchasing%20User/users?includeinactive=true";
		res = sHelper.getEntityByUniqueName(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " belonging to Purchasing User Group");
		}
	}

	/*
	 * Test to retrieve all commodity codes with no parents in sg variant
	 */
	@Test
	public void sg_searchCommodityCodesWithNoParent() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SG_REALM, SG_USERNAME, SG_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?-ex_Parent_UniqueName=*";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Checking response contains only records which donot have parent
		 */
		if (content.contains("ex_Parent_UniqueName"))
			Assert.fail("Retrieved records having parent even when negation is used");
	}

	/*
	 * Test to retrieve all commodity codes with no parents in sap variant
	 */
	@Test
	public void sap_searchCommodityCodesWithNoParent() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?-ex_Parent_UniqueName=*";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Checking response contains only records which donot have parent
		 */
		if (content.contains("ex_Parent_UniqueName"))
			Assert.fail("Retrieved records having parent even when negation is used");
	}

	/*
	 * Test to retrieve all commodity codes with no parents in psoft variant
	 */
	@Test
	public void psoft_searchCommodityCodesWithNoParent() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?-ex_Parent_UniqueName=*";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Checking response contains only records which donot have parent
		 */
		if (content.contains("ex_Parent_UniqueName"))
			Assert.fail("Retrieved records having parent even when negation is used");
	}

	/*
	 * Test to verify negation is working in sg variant
	 */
	@Test
	public void sg_searchCommodityCodesNegation() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SG_REALM, SG_USERNAME, SG_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?-ex_Parent_UniqueName=10";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through response and checking no records with given parent
		 * are retrieved
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String parent = obj.getString("ex_Parent_UniqueName");
			if (parent.equals("10"))
				Assert.fail("Retrieved parent with uniquename 10. Negation not working");
			parent = obj.getString("Parent_UniqueName");
			if (parent.equals("10"))
				Assert.fail("Retrieved parent with uniquename 10. Negation not working");
		}
	}

	/*
	 * Test to verify negation is working in sap variant
	 */
	@Test
	public void sap_searchCommodityCodesNegation() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?-ex_Parent_UniqueName=10";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through response and checking no records with given parent
		 * are retrieved
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String parent = obj.getString("ex_Parent_UniqueName");
			if (parent.equals("10"))
				Assert.fail("Retrieved parent with uniquename 10. Negation not working");
			parent = obj.getString("Parent_UniqueName");
			if (parent.equals("10"))
				Assert.fail("Retrieved parent with uniquename 10. Negation not working");
		}
	}

	/*
	 * Test to verify negation is working in psoft variant
	 */
	@Test
	public void psoft_searchCommodityCodesNegation() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?-ex_Parent_UniqueName=10";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through response and checking no records with given parent
		 * are retrieved
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String parent = obj.getString("ex_Parent_UniqueName");
			if (parent.equals("10"))
				Assert.fail("Retrieved parent with uniquename 10. Negation not working");
			parent = obj.getString("Parent_UniqueName");
			if (parent.equals("10"))
				Assert.fail("Retrieved parent with uniquename 10. Negation not working");
		}
	}

	@Test
	public void sg_searchUsersByGroup() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SG_REALM, SG_USERNAME, SG_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "users?ex_Groups=Purchasing%20User";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
		}

		/* Making Api call for users with Groups param */
		urlParam = "users?Groups=Purchasing%20User";
		res = sHelper.getEntity(token, urlParam);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		resArray = new JSONArray(content);
		Assert.assertTrue(resArray.length() > 0, "Retrieved blank response");
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
		}
	}

	@Test
	public void sap_searchUsersByGroup() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "users?ex_Groups=Purchasing%20User";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
		}

		/* Making Api call for users with Groups param */
		urlParam = "users?Groups=Purchasing%20User";
		res = sHelper.getEntity(token, urlParam);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		resArray = new JSONArray(content);
		Assert.assertTrue(resArray.length() > 0, "Retrieved blank response");
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
		}
	}

	@Test
	public void psoft_searchUsersByGroup() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "users?ex_Groups=Purchasing%20User";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		JSONArray resArray = new JSONArray(content);
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
		}

		/* Making Api call for users with Groups param */
		urlParam = "users?Groups=Purchasing%20User";
		res = sHelper.getEntity(token, urlParam);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/*
		 * Iterating through all retrieved users and checking searched group is
		 * present
		 */
		resArray = new JSONArray(content);
		Assert.assertTrue(resArray.length() > 0, "Retrieved blank response");
		for (int i = 0; i < resArray.length(); i++) {
			JSONObject obj = resArray.getJSONObject(i);
			String groups = obj.getString("ex_Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
			groups = obj.getString("Groups");
			if (!groups.contains("Purchasing User"))
				Assert.fail("Obtained user " + obj.getString("UniqueName") + " not belonging to Purchasing User Group");
		}
	}

	@Test
	public void sg_searchByRows() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SG_REALM, SG_USERNAME, SG_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?rows=15&Name=Tempo";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Checking the length of the response is same as rows param
		 */
		JSONArray resArray = new JSONArray(content);
		Assert.assertEquals(resArray.length(), 15, "rows filter is not working");
	}

	@Test
	public void sap_searchByRows() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?rows=15&Name=Tempo";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Checking the length of the response is same as rows param
		 */
		JSONArray resArray = new JSONArray(content);
		Assert.assertEquals(resArray.length(), 15, "rows filter is not working");
	}

	@Test
	public void psoft_searchByRows() throws Exception {

		/* Generating access token */
		String token = oAuthHelper.getAccessToken(PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);

		/* Enabling hana search before quering for data */
		RestResponse res = sHelper.enablehanasearch(token);
		System.out.println(res.getContent());

		/* Making Api call for each entity to get data from hana */
		String urlParam = "commoditycodes?rows=15&Name=Tempo";
		res = sHelper.getEntity(token, urlParam);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(200, res.getCode(), "Response code is not matching");

		/* Checking data is retrieved from Hana */
		if (!content.contains("hana_entityName"))
			Assert.fail("Retriving data from Arches even when Hana is enabled");

		/*
		 * Checking the length of the response is same as rows param
		 */
		JSONArray resArray = new JSONArray(content);
		Assert.assertEquals(resArray.length(), 15, "rows filter is not working");
	}
}
