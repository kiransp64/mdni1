package com.ariba.scim;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.ariba.services.MDNI;
import io.restassured.response.Response;
//import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.Constants;
import com.ariba.helpers.MDSSearchHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.SCIMHelper;
import com.ariba.pojos.RestResponse;
import org.testng.asserts.SoftAssert;

public class SCIMGroups extends BaseHelper {

	SCIMHelper scimHelper = new SCIMHelper();
	OAuthHelper oauthHelper = new OAuthHelper();
	MDSSearchHelper searchHelper = new MDSSearchHelper();

	public static String GROUPNAME_EN = "TestGroup";
	public static String GROUPNAME_JA = "アラブ首長国連邦";
	public static String GROUPNAME_ZH = "约翰·多伊";
	public static String LOCALE_EN = "en_US";
	public static String USER_ADAVIS = "adavis";
	public static String USER_CNOLL = "cnoll";
	public static String GROUP_BUDGET_APPROVER = "Budget Approver";
	public static String GROUP_BUDGET_MANAGER = "Budget Manager";
	public static String KEYS = "UniqueName,Users.UniqueName,ChildGroups.UniqueName,Name,this,PartitionNumber";

	@Test
	public void createGroupForSAP() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");
		String resourceType = group.getJSONObject(Constants.META).getString(Constants.RESOURCE_TYPE);
		Assert.assertEquals(resourceType, Constants.GROUP_MEMBER_GROUP, "Group Resource Type is not matching");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0).getString(
				Constants.NAME), GROUPNAME_JA, "Group Name in JA locale is not matching in HANA and Payload");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createGroupWithNullDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(JSONObject.NULL, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Display Name is mandatory"),
				"Errro message is not maching when creating group without displayname");
	}

	@Test
	public void createGroupWithBlankDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload("", names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Display Name is mandatory"),
				"Errro message is not maching when creating group without displayname");
	}

	@Test
	public void createGroupWithoutDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(null, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Missing required creator property 'displayName'"),
				"Error message is not maching when creating group without displayname");
	}

	@Test
	public void createGroupDisplayNameHavingSpace() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + Constants.SPACE + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName.replace(Constants.SPACE, "%20")
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateGroupDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		displayName = displayName + GROUPNAME_EN;
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Resource with given group doesn't exist"),
				"Error message is not matching when updating group displayName");
	}

	@Test
	public void createGroupWithAlternativeDisplayNameAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, JSONObject.NULL);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(
				hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
						.getString(Constants.NAME),
				displayName,
				"Since JA locale name is given as null, MDS Search should list Name in en when searched with locale=ja");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), displayName,
				"Name is not matching in buyer");
	}

	@Test
	public void createGroupWithAlternativeDisplayNameAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, "");
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
				.getString(Constants.NAME), "", "DisplayName for JA locale is not as given in payload");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), "",
				"Name is not matching in buyer");
	}

	@Test
	public void createGroupWithoutAlternativeDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, null, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(
				hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
						.getString(Constants.NAME),
				displayName,
				"Since JA locale name is given as null, MDS Search should list Name in en when searched with locale=ja");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), displayName,
				"Name is not matching in buyer");
	}

	@Test
	public void updateGroupAlternativeDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA + GROUPNAME_JA);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());
		String resourceType = group.getJSONObject(Constants.META).getString(Constants.RESOURCE_TYPE);
		Assert.assertEquals(resourceType, Constants.GROUP_MEMBER_GROUP, "Group Resource Type is not matching");

		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(
				hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
						.getString(Constants.NAME),
				GROUPNAME_JA + GROUPNAME_JA, "Group Name in JA locale is not matching in HANA and Payload");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), GROUPNAME_JA + GROUPNAME_JA,
				"Name is not matching in buyer");
	}

	@Test
	public void updateGroupAlternativeDisplayNameAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, JSONObject.NULL);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
				.getString(Constants.NAME), displayName, "Group Name in JA locale is not matching in HANA and Payload");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), displayName,
				"Name is not matching in buyer");
	}

	@Test
	public void updateGroupAlternativeDisplayNameAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, "");
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
				.getString(Constants.NAME), "", "Group Name in JA locale is not matching in HANA and Payload");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), "",
				"Name is not matching in buyer");
	}

	@Test
	public void updateGroupWithoutAlternativeDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		groupPayload = scimHelper.createGroupPayload(displayName, null, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
				.getString(Constants.NAME), displayName, "Group Name in JA locale is not matching in HANA and Payload");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), displayName,
				"Name is not matching in buyer");
	}

	@Test
	public void updateGroupAddAlternativeDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, null, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray_ja = new JSONArray(content);
		Assert.assertEquals(hanaArray_ja.length(), 1,
				"Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
		System.err.println(hanaGroup_ja);
		Assert.assertEquals(hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0).getString(
				Constants.NAME), GROUPNAME_JA, "Group Name in JA locale is not matching in HANA and Payload");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");
		Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), GROUPNAME_JA,
				"Name is not matching in buyer");
	}

	@Test
	public void updateGroupThatDoesNotExists() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, null, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code is not matching for group creation. Response=" + result.getContent());
	}

	@Test
	public void createGroupWithUserMemberAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(JSONObject.NULL);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : [null]"),
				"Error message is not matching when group User member is null");
	}

	@Test
	public void createGroupWithUserMemberAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add("");
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : []"),
				"Error message is not matching when group User member is blank/empty");
	}

	@Test
	public void createGroupWithoutUserMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createGroupWithInvalidUserMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add("invalidUser");
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : [invalidUser]"),
				"Error message is not matching when group User member is invalid");
	}

	@Test
	public void createGroupWithSingleInvalidUserMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		memberUsers.add(USER_CNOLL);
		memberUsers.add("invalidUser");
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : [invalidUser]"),
				"Error message is not matching when group User member is invalid");
	}

	@Test
	public void createGroupWithInactiveUserMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = "TestUser" + uuid.toString();
		JSONObject userPayload = scimHelper.createUserPayload(username, null, Boolean.TRUE, "Test User", LOCALE_EN,
				null, "adavis", null, null,null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user and making him inactive
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, null, Boolean.FALSE, "Test User",
				LOCALE_EN, null, "adavis", null, null,null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String inactiveUser = userUpdated.getString(Constants.ID);

		// Creating group with inactive User
		uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(inactiveUser);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : [" + inactiveUser + "]"),
				"Error message is not matching when group User member is Inactive");
	}

	@Test
	public void createGroupWithChildGroupMemberAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(JSONObject.NULL);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : [null]"),
				"Error message is not matching when group Group member is null");
	}

	@Test
	public void createGroupWithChildGroupMemberAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add("");
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : []"),
				"Error message is not matching when group Group member is blank/empty");
	}

	@Test
	public void createGroupWithInvalidChildGroupMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add("invalid");
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : [invalid]"),
				"Error message is not matching when group Group member is invalid");
	}

	@Test
	public void createGroupWithSingleInvalidChildGroupMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		memberGroups.add(GROUP_BUDGET_MANAGER);
		memberGroups.add("invalid");
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : [invalid]"),
				"Error message is not matching when group Group member is invalid");
	}

	@Test
	public void createGroupWithoutChildGroupMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(groupPayload, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createGroupWithChildGroupMemberAsSameGroup() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(displayName);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : [" + displayName + "]"),
				"Error message is not matching when group Group member is same as group username");
	}

	@Test
	public void createGroupWithoutMembers() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(displayName);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() == 1, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(groupPayload, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateGroupUserMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateGroupAddUserMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateGroupUserMemberAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(JSONObject.NULL);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : [null]"),
				"Error message is not matching when updating group with user memeber as null");
	}

	@Test
	public void updateGroupUserMemberAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add("");
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : []"),
				"Error message is not matching when updating group with user memeber as blank/empty");
	}

	@Test
	public void updateGroupUserMemberAsInvalid() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add("invalid");
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for User : [invalid]"),
				"Error message is not matching when updating group with user memeber as invalid");
	}

	@Test
	public void updateGroupWithoutUserMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		groupPayload = scimHelper.createGroupPayload(displayName, names, null, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateGroupGroupMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group
		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		memberGroups.add(GROUP_BUDGET_MANAGER);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateGroupWithGroupMemberAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group
		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(JSONObject.NULL);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : [null]"),
				"Error message is not matching when updating group with Group memeber as null");
	}

	@Test
	public void updateGroupWithGroupMemberAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group
		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add("");
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : []"),
				"Error message is not matching when updating group with Group memeber as blank/empty");
	}

	@Test
	public void updateGroupWithGroupMemberAsinvalid() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group
		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add("invalid");
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid input for Group : [invalid]"),
				"Error message is not matching when updating group with Group memeber as invalid");
	}

	@Test
	public void updateGroupWithGroupMemberAsSameGroup() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group
		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(displayName);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(
				error.getString("detail")
						.contains("Cycle detected. Already Group " + displayName + " contains Group " + displayName),
				"Error message is not matching when updating group with Group memeber as same group");
	}

	@Test
	public void updateGroupWithoutGroupMember() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group
		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, null);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	/**
	 * Group A has Group B as child. Group B has Group C as child. We should not
	 * be able to give Group A as child for Group C
	 *
	 * @throws Exception
	 */
	@Test
	public void groupHierarchyCyclicDependencyCheck() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group A
		UUID uuid = UUID.randomUUID();
		String displayNameA = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayloadA = scimHelper.createGroupPayload(displayNameA, names, memberUsers, null);
		System.err.println(groupPayloadA);

		RestResponse result = scimHelper.postGroups(token, groupPayloadA.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayNameA, "Id in response payload is not same as displayName given");

		// Creating group B
		uuid = UUID.randomUUID();
		String displayNameB = GROUPNAME_EN + uuid.toString();
		JSONObject groupPayloadB = scimHelper.createGroupPayload(displayNameB, names, memberUsers, null);
		System.err.println(groupPayloadB);

		result = scimHelper.postGroups(token, groupPayloadB.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayNameB, "Id in response payload is not same as displayName given");

		// Creating group C
		uuid = UUID.randomUUID();
		String displayNameC = GROUPNAME_EN + uuid.toString();
		JSONObject groupPayloadC = scimHelper.createGroupPayload(displayNameC, names, memberUsers, null);
		System.err.println(groupPayloadC);

		result = scimHelper.postGroups(token, groupPayloadC.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayNameC, "Id in response payload is not same as displayName given");

		// Updating Group A with Group B as child
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(displayNameB);
		groupPayloadA = scimHelper.createGroupPayload(displayNameA, names, memberUsers, memberGroups);
		System.err.println(groupPayloadA);
		result = scimHelper.updateGroups(token, groupPayloadA.toString(), SAP_ANID, displayNameA);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Updating Group B with Group C as child
		memberGroups = new ArrayList<Object>();
		memberGroups.add(displayNameC);
		groupPayloadB = scimHelper.createGroupPayload(displayNameB, names, memberUsers, memberGroups);
		System.err.println(groupPayloadB);
		result = scimHelper.updateGroups(token, groupPayloadB.toString(), SAP_ANID, displayNameB);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Updating Group C with Group A as child
		memberGroups = new ArrayList<Object>();
		memberGroups.add(displayNameA);
		groupPayloadC = scimHelper.createGroupPayload(displayNameC, names, memberUsers, memberGroups);
		System.err.println(groupPayloadC);
		result = scimHelper.updateGroups(token, groupPayloadC.toString(), SAP_ANID, displayNameC);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
		Assert.assertTrue(result.getContent().contains("Cycle detected"), "Response error message is not matching");
	}

	@Test
	public void createGroupWithLongStringInDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating group A
		UUID uuid = UUID.randomUUID();
		String displayNameA = GROUPNAME_EN + uuid.toString() + Constants.LONG_STRING;
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		JSONObject groupPayloadA = scimHelper.createGroupPayload(displayNameA, names, memberUsers, null);
		System.err.println(groupPayloadA);

		RestResponse result = scimHelper.postGroups(token, groupPayloadA.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for group creation. Response=" + result.getContent());
	}

	@Test
	public void createAndUpdateGroupForSG() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SG_REALM, SG_USERNAME, SG_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SG_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		memberGroups.add(GROUP_BUDGET_MANAGER);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SG_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SG_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateGroupForPSOFT() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), PSOFT_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		memberGroups.add(GROUP_BUDGET_MANAGER);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), PSOFT_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, PSOFT_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateGroupForMerpParent() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(MERPPARENT_REALM, MERPPARENT_USERNAME, MERPPARENT_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), MERPPARENT_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		memberGroups.add(GROUP_BUDGET_MANAGER);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), MERPPARENT_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, MERPPARENT_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateGroupForMerpChild() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(MERPCHILD_REALM, MERPCHILD_USERNAME, MERPCHILD_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), MERPCHILD_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		memberGroups.add(GROUP_BUDGET_MANAGER);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), MERPCHILD_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, MERPCHILD_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateGroupForIntegrated() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), INTEGRATED_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		memberGroups.add(GROUP_BUDGET_MANAGER);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), INTEGRATED_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		Thread.sleep(60000);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, INTEGRATED_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);

		/* Making query to s4 db */
		Thread.sleep(60000);
		token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, "s4");
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		Thread.sleep(120000);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		JSONArray s4DataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArray);
		Assert.assertTrue(s4DataArray.length() > 0, "Group with uniquename " + groupId + " not found in s4");
	}

	@Test
	public void createAndUpdateGroupForMultiDestinations() throws Exception {

		/* Generating access token */

		String token = oauthHelper.getAccessToken(MULTI_DESTINATION_REALM, MULTI_DESTINATION_USERNAME,
				MULTI_DESTINATION_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();

		// memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), MULTI_DESTINATION_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		// memberGroups.add(GROUP_BUDGET_MANAGER);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), MULTI_DESTINATION_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, MULTI_DESTINATION_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);

		/* Making query to buyer db */
		token = oauthHelper.getAccessToken(MULTI_DESTINATION_REALM, MULTI_DESTINATION_USERNAME, MULTI_DESTINATION_ANID,
				"s4");
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, MULTI_DESTINATION_ANID,
				Constants.LOCALE_EN_US);
		JSONArray s4DataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArray);
		Assert.assertTrue(s4DataArray.length() > 0, "Group with uniquename " + groupId + " not found in s4");
	}

	@Test
	public void createAndUpdateGroupForS4() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add("Customer Administrator");
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), S4_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Updating Group
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		memberGroups.add("Contract Approver");
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), S4_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);


		/* Making query to s4 db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, S4_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in s4");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createDeletedGroup() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Deleting Group
		RestResponse deleteRes = scimHelper.deleteGroups(token, SAP_ANID, groupId);
		Assert.assertEquals(204, deleteRes.getCode(), "Response code is not matching");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 0,
				"Deleted Group with groupname " + displayName + " found in MDS Search");

		/* Making query to buyer db with includeinactive=false */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.FALSE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() == 0, "Delete Group with uniquename " + groupId + "  found in buyer");

		/* Making query to buyer db with includeinactive=true */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0,
				"Deleted Group with uniquename " + groupId + " not found in buyer even when includeinactive is passed");

		// Creating deleted group again
		result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Getting group details
		/* Making API call to get data from hana */
		url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "Group with groupname " + displayName + " not found in MDS Search");
		JSONObject hanaGroup = hanaArray.getJSONObject(0);
		System.err.println(hanaGroup);

		/* Making query to buyer db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + groupId + " not found in buyer");

		JSONArray issues = comparePayloadsForGroup(group, hanaGroup, buyerDataArray, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateDeletedGroup() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");

		// Deleting Group
		RestResponse deleteRes = scimHelper.deleteGroups(token, SAP_ANID, groupId);
		Assert.assertEquals(204, deleteRes.getCode(), "Response code is not matching");

		// Getting group details
		/* Making API call to get data from hana */
		String url = "groups?$filter=GroupKey.UniqueName='" + displayName
				+ "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 0,
				"Deleted Group with groupname " + displayName + " found in MDS Search");

		/* Making query to buyer db with includeinactive=false */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.FALSE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() == 0, "Delete Group with uniquename " + groupId + "  found in buyer");

		/* Making query to buyer db with includeinactive=true */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
				Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0,
				"Deleted Group with uniquename " + groupId + " not found in buyer even when includeinactive is passed");

		// Updating deleted group again
		memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_CNOLL);
		groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code is not matching for group updation. Response=" + result.getContent());
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Resource with given group doesn't exist"),
				"Error message is not matching when trying to update deleted group");
	}

	private JSONArray comparePayloadsForGroup(JSONObject groupPayload, JSONObject hanaGroup, JSONArray buyerGroups,
											  String locale) {
		JSONArray issues = new JSONArray();
		Map<String, String> payloadMap = new HashMap<String, String>();
		payloadMap.put(Constants.DISPLAYNAME, "");

		String payloadName = "";
		if (locale == Constants.LANG_EN) {
			payloadName = groupPayload.getString(Constants.DISPLAYNAME);
			payloadMap.put(Constants.DISPLAYNAME, groupPayload.getString(Constants.DISPLAYNAME));
		} else {
			JSONArray names = groupPayload.getJSONObject(Constants.GROUPS_SCHEMA_PROFILE)
					.getJSONArray(Constants.ALTERNATIVE_DISPLAYNAME);
			for (int i = 0; i < names.length(); i++) {
				JSONObject name = names.getJSONObject(i);
				if (name.getString(Constants.LANGUAGE).equalsIgnoreCase(locale)) {
					payloadName = name.getString(Constants.DISPLAYNAME);
					payloadMap.put(Constants.DISPLAYNAME, name.getString(Constants.DISPLAYNAME));
				}
			}
		}
		JSONArray members = new JSONArray();
		List<String> users = new ArrayList<String>();
		List<String> groups = new ArrayList<String>();
		List<String> payloadUsers = new ArrayList<String>();
		List<String> payloadGroups = new ArrayList<String>();
		String payloaduserlist = "";
		String payloadgrouplist = "";
		if (groupPayload.has(Constants.MEMBERS)) {
			members = groupPayload.getJSONArray(Constants.MEMBERS);
			for (int i = 0; i < members.length(); i++) {
				if (members.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(Constants.GROUP_MEMBER_USER)
						&& members.getJSONObject(i).has(Constants.VALUE_KEY)) {
					users.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					payloadUsers.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					if (payloaduserlist == "")
						payloaduserlist = payloaduserlist + members.getJSONObject(i).getString(Constants.VALUE_KEY);
					else
						payloaduserlist = payloaduserlist + ","
								+ members.getJSONObject(i).getString(Constants.VALUE_KEY);
				} else if (members.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(
						Constants.GROUP_MEMBER_GROUP) && members.getJSONObject(i).has(Constants.VALUE_KEY)) {
					groups.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					payloadGroups.add(members.getJSONObject(i).getString(Constants.VALUE_KEY));
					if (payloadgrouplist == "")
						payloadgrouplist = payloadgrouplist + members.getJSONObject(i).getString(Constants.VALUE_KEY);
					else
						payloadgrouplist = payloadgrouplist + ","
								+ members.getJSONObject(i).getString(Constants.VALUE_KEY);
				}
			}
		}
		payloadMap.put(Constants.GROUP_MEMBER_USER, payloaduserlist);
		payloadMap.put(Constants.GROUP_MEMBER_GROUP, payloadgrouplist);

		// HANA comparisons if user from HANA is not null
		if (hanaGroup != null) {
			String hanaUniqueName = hanaGroup.getString(Constants.HANA_GROUP_UNIQUENAME);
			String hanaName = hanaGroup.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.NAME);
			String hanaNameLocale = hanaGroup.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.HANA_LANG_LANG);

			if (locale.equalsIgnoreCase(Constants.LANG_EN)) {
				if (!payloadName.equalsIgnoreCase(hanaUniqueName)) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.USERNAME,
							"Payload displayName is not matching with HANA Uniquename. Payload displayName="
									+ payloadName + " AND HANA Uniquename=" + hanaUniqueName);
					issues.put(issue);
				}
			}
			if (!payloadName.equalsIgnoreCase(hanaName)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.DISPLAYNAME, "Payload name is not matching with HANA name. Payload name="
						+ payloadName + " AND HANA name=" + hanaName);
				issues.put(issue);
			}
			if (!locale.equalsIgnoreCase(hanaNameLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LANGUAGE,
						"Payload nameLocale is not matching with HANA nameLocale. Payload nameLocale=" + locale
								+ " AND HANA nameLocale=" + hanaNameLocale);
				issues.put(issue);
			}
			if (hanaGroup.has(Constants.HANA_USERS_MAP_ASSOCIATION)) {
				JSONArray groupUsers = hanaGroup.getJSONArray(Constants.HANA_USERS_MAP_ASSOCIATION);
				if (users.size() != groupUsers.length()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_USER,
							"Payload group users is not matching with HANA group users. Payload users size = "
									+ users.size() + " HANA users size = " + groupUsers.length());
					issues.put(issue);
				}
				for (int i = 0; i < groupUsers.length(); i++) {
					String hanaGroupUser = groupUsers.getJSONObject(i).getString(Constants.HANA_USER_UNIQUENAME);
					if (users.contains(hanaGroupUser)) {
						users.remove(hanaGroupUser);
					} else {
						JSONObject issue = new JSONObject();
						issue.put(Constants.GROUP_MEMBER_USER + i,
								"Group is having user " + hanaGroupUser + " in HANA, but not in Payload");
						issues.put(issue);
					}
				}
			}
			if (users.size() > 0) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.GROUP_MEMBER_USER + "-1",
						"Payload group users is not matching with HANA group users. Few users in payload are not present in HANA. Such users are "
								+ users);
				issues.put(issue);
			}
			if (hanaGroup.has(Constants.HANA_CHILDGROUP_MAP_ASSOCIATION)) {
				JSONArray hanaChildGroups = hanaGroup.getJSONArray(Constants.HANA_CHILDGROUP_MAP_ASSOCIATION);
				if (groups.size() != hanaChildGroups.length()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_GROUP,
							"Payload group childGroups is not matching with HANA group childGroups. Payload childgroups size = "
									+ groups.size() + " HANA childgroups size = " + hanaChildGroups.length());
					issues.put(issue);
				}
			}
		}

		// Buyer comparisons if user from buyer is not null
		if (buyerGroups != null) {

			List<String> buyerUsers = new ArrayList<String>();
			List<String> buyerChildGroup = new ArrayList<String>();
			for (int i = 0; i < buyerGroups.length(); i++) {
				JSONObject buyerData = buyerGroups.getJSONObject(i);
				if (buyerData.has(Constants.BUYER_GROUP_USER_KEY)) {
					if ((!buyerUsers.contains(buyerData.getString(Constants.BUYER_GROUP_USER_KEY)))
							&& (!buyerData.getString(Constants.BUYER_GROUP_USER_KEY).equalsIgnoreCase("")))
						buyerUsers.add(buyerData.getString(Constants.BUYER_GROUP_USER_KEY));
				}
				if (buyerData.has(Constants.BUYER_GROUP_CHILDGROUPS_KEY)) {
					if ((!buyerChildGroup.contains(buyerData.getString(Constants.BUYER_GROUP_CHILDGROUPS_KEY)))
							&& (!buyerData.getString(Constants.BUYER_GROUP_CHILDGROUPS_KEY).equalsIgnoreCase("")))
						buyerChildGroup.add(buyerData.getString(Constants.BUYER_GROUP_CHILDGROUPS_KEY));
				}
			}
			if (buyerGroups.length() > 0) {
				JSONObject buyerGroup = buyerGroups.getJSONObject(0);
				String buyerUniqueName = buyerGroup.getString(Constants.UNIQUENAME);

				if (!payloadName.equalsIgnoreCase(buyerUniqueName)) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.DISPLAYNAME + "_" + Constants.BUYER,
							"Payload displayName is not matching with Buyer UniqueName. Payload name=" + payloadName
									+ " AND Buyer Uniquename=" + buyerUniqueName);
					issues.put(issue);
				}
				if (payloadUsers.size() != buyerUsers.size()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_USER + "_" + Constants.BUYER,
							"Payload Member users size is not matching with Buyer users size. Payload users size="
									+ payloadUsers.size() + " AND Buyer users size =" + buyerUsers.size());
					issues.put(issue);
				}
				if (payloadGroups.size() != buyerChildGroup.size()) {
					JSONObject issue = new JSONObject();
					issue.put(Constants.GROUP_MEMBER_GROUP + "_" + Constants.BUYER,
							"Payload Member childgroups size is not matching with Buyer childgroups size. Payload childgroups size="
									+ payloadGroups.size() + " AND Buyer childgroups size =" + buyerChildGroup.size());
					issues.put(issue);
				}
			}
		}
		return issues;
	}

	@Test
	public void getGroupsWithFilterOnDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		// Getting user details
		String filter = "displayName eq \"" + groupId + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertTrue(groupsRes.getInt(Constants.ITEMS_PER_PAGE) <= 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject groupget = new JSONObject(getResult.getContent());
			Assert.assertEquals(groupget.getString(Constants.DISPLAYNAME), groupId,
					"Get groups with filter on displayName is not working");
		}
	}

	@Test
	public void getGroupsHavingSpaceWithFilterOnDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + " " + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		// Getting user details
		String filter = "displayName eq \"" + groupId + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertTrue(groupsRes.getInt(Constants.ITEMS_PER_PAGE) <= 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject groupget = new JSONObject(getResult.getContent());
			Assert.assertEquals(groupget.getString(Constants.DISPLAYNAME), groupId,
					"Get groups with filter on displayName is not working");
		}
	}

	@Test
	public void getGroupsWithFilterOnAlternativeDisplaynameLanguage() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "alternativeDisplayNames.language eq \"ja\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains("ja"),
					"Get groups with filter on Alternative displayNames language is not working");
		}
	}

	@Test
	public void getGroupsWithFilterOnAlternativeDisplaynames() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "alternativeDisplayNames.displayName eq \"" + GROUPNAME_JA + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains(GROUPNAME_JA),
					"Get groups with filter on Alternative displayNames language is not working");
		}
	}

	@Test
	public void getGroupsWithFilterOnUserMemberValue() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "members.value eq \"" + USER_ADAVIS + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains(USER_ADAVIS),
					"Get groups with filter on User memeber by value is not working");
		}
	}

	@Test
	public void getGroupsWithFilterOnUserMemberType() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "members.type eq \"" + Constants.GROUP_MEMBER_USER + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains(Constants.GROUP_MEMBER_USER),
					"Get groups with filter on User memeber by value is not working");
		}
	}

	@Test
	public void getGroupsWithFilterOnGroupMemberValue() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "members.value eq \"" + GROUP_BUDGET_APPROVER + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains(GROUP_BUDGET_APPROVER),
					"Get groups with filter on Group memeber by value is not working");
		}
	}

	@Test
	public void getGroupsWithFilterOnGroupMemberType() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "members.type eq \"" + Constants.GROUP_MEMBER_GROUP + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < groups.length(); i++) {
			getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID,
					groups.getJSONObject(i).getString(Constants.ID), null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains(Constants.GROUP_MEMBER_GROUP),
					"Get groups with filter on User memeber by value is not working");
		}
	}

	@Test
	public void getGroupsPagination() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, null, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 5, "Items per page size is not matching");
		String lastGroupName = groups.getJSONObject(4).getString(Constants.ID);

		getResult = scimHelper.getGroups(token, SAP_ANID, null, 5, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		groupsRes = new JSONObject(getResult.getContent());
		groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 5, "Items per page size is not matching");
		String filrstGroupName = groups.getJSONObject(0).getString(Constants.ID);

		Assert.assertEquals(filrstGroupName, lastGroupName, "Gert groups pagination without filter is not working");
	}

	@Test
	public void getGroupsPaginationWithFilter() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "alternativeDisplayNames.displayName eq \"" + GROUPNAME_JA + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 5, "Items per page size is not matching");
		String lastGroupName = groups.getJSONObject(4).getString(Constants.ID);

		getResult = scimHelper.getGroups(token, SAP_ANID, filter, 5, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		groupsRes = new JSONObject(getResult.getContent());
		groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(groupsRes.getInt(Constants.ITEMS_PER_PAGE), 5, "Items per page size is not matching");
		String filrstGroupName = groups.getJSONObject(0).getString(Constants.ID);

		Assert.assertEquals(filrstGroupName, lastGroupName, "Gert groups pagination with filter is not working");
	}

	@Test
	public void getGroupsWhichIsInactive() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		// Deleting Group
		RestResponse deleteRes = scimHelper.deleteGroups(token, SAP_ANID, groupId);
		Assert.assertEquals(204, deleteRes.getCode(), "Response code is not matching");

		// Getting group details
		RestResponse getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID, groupId, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Status code is not matching for get users call");
		Assert.assertTrue(getResult.getContent().contains("Resource with given group doesn't exist"));
	}

	@Test
	public void getGroupsWhichIsInactiveInFilter() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		// Deleting Group
		RestResponse deleteRes = scimHelper.deleteGroups(token, SAP_ANID, groupId);
		Assert.assertEquals(204, deleteRes.getCode(), "Response code is not matching");

		// Getting user details
		String filter = "displayName eq \"" + groupId + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		Assert.assertTrue(getResult.getContent().contains("totalResults\":0"));
	}

	@Test
	public void getGroupsWhichIsNotHavingMembersInFilter() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		// Getting user details
		String filter = "displayName eq \"" + groupId + "\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		Assert.assertTrue(groupsRes.getInt(Constants.ITEMS_PER_PAGE) == 1, "Items per page size is not matching");
	}

	@Test
	public void getGroupsWhichIsNotHavingMembers() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, null, null);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		// Getting user details
		RestResponse getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID, groupId, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		Assert.assertTrue(groupsRes.getString(Constants.ID).equalsIgnoreCase(groupId),
				"Get groups having no members id is not matching");
	}

	@Test
	public void getGroupsWithInvalidOperatorInFilter() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "members.value noteq \"adavis\"";
		RestResponse getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Status code is not matching for get users call");
	}

	@Test
	public void getGroupsForS4Realm() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, ORIGIN_SYS);

		// Getting user details
		RestResponse getResult = scimHelper.getGroups(token, S4_ANID, null, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject s4group = new JSONObject(getResult.getContent());
		Assert.assertTrue(s4group.getInt(Constants.ITEMS_PER_PAGE) <= 5, "Items per page is not matching");
	}

	@Test
	public void getGroupsWithFilterOnCreated() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		RestResponse getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID, GROUP_BUDGET_MANAGER, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
				"Status code is not matching for get groups by uniquename call");
		JSONObject group = new JSONObject(getResult.getContent());
		String created = group.getJSONObject(Constants.META).getString(Constants.CREATED);

		String filter = "meta.created eq \"" + created + "\"";
		getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertTrue(groups.length() > 0, "Get groups by filter on meta.created is not working.");
	}

	@Test
	public void getGroupsWithFilterOnLastModified() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		RestResponse getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID, GROUP_BUDGET_MANAGER, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
				"Status code is not matching for get groups by uniquename call");
		JSONObject group = new JSONObject(getResult.getContent());
		String lastModified = group.getJSONObject(Constants.META).getString(Constants.LAST_MODIFIED);
		System.out.println("lastModified : "+lastModified);

		String filter = "meta.lastModified eq \"" + lastModified + "\"";
		Thread.sleep(10000);
		getResult = scimHelper.getGroups(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupsRes = new JSONObject(getResult.getContent());
		JSONArray groups = groupsRes.getJSONArray(Constants.RESOURCES);
		Assert.assertTrue(groups.length() > 0, "Get groups by filter on meta.lastModified is not working.");
	}

	@Test
	public void createGroupWithGreaterThan100Users() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		for (int i = 14; i <= 5113; i++) {

			String username = "testUserAE" + i;
			// Map<String, Object> unames = new HashMap<String, Object>();
			// unames.put(Constants.LANG_JA, "NameJA");
			// Map<String, Object> uemails = new HashMap<String, Object>();
			// uemails.put(Constants.WORK, "test@test.com");
			// Map<String, Object> uphones = new HashMap<String, Object>();
			// uphones.put(Constants.WORK, "555-555-5555");
			// uphones.put(Constants.FAX, "666-666-6666");
			// JSONObject userPayload = scimHelper.createUserPayload(username,
			// unames, Boolean.TRUE, "testUserAA"+i,
			// Constants.LOCALE_EN_US, "US/Pacific", "adavis", uemails,
			// uphones);
			// System.err.println(userPayload);
			// RestResponse result = scimHelper.postUsers(token,
			// userPayload.toString(), SAP_ANID);
			// Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
			// "Response code is not matching for user creation");
			memberUsers.add(username);
			System.err.println("******************ADDED USER " + i + " ******************");
		}
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);
		Assert.assertNotNull(groupId, "id is null for newly created group");
		Assert.assertEquals(groupId, displayName, "Id in response payload is not same as displayName given");
	}

	@Test
	public void differentResponseCodeVerification() throws Exception {

		SoftAssert softAssertion= new SoftAssert();
		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(USER_ADAVIS);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);

		RestResponse result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(result.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID),
				"Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		// Create group again
		result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		softAssertion.assertEquals(HttpStatus.SC_CONFLICT, result.getCode(),
				"Response code should be "+HttpStatus.SC_CONFLICT+" when trying to create(POST) the Group which already exist");


		// Deleting Group
		result = scimHelper.deleteGroups(token, SAP_ANID, groupId);
		softAssertion.assertEquals(HttpStatus.SC_NO_CONTENT, result.getCode(),
				"Response code should be "+HttpStatus.SC_NO_CONTENT+" when trying to DELETE the Group");

		// Update group
		result = scimHelper.updateGroups(token, groupPayload.toString(), SAP_ANID, displayName);
		softAssertion.assertEquals(HttpStatus.SC_NOT_FOUND, result.getCode(),
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to update(PUT) the Group which does not exist");

		// Delete group
		result = scimHelper.deleteGroups(token, SAP_ANID, groupId);
		softAssertion.assertEquals(HttpStatus.SC_NOT_FOUND, result.getCode(),
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to DELETE the Group which does not exist");

		// Getting group details
		result = scimHelper.getGroupssByUniqueName(token, SAP_ANID, groupId, null);
		softAssertion.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to GET the Group which does not exist");

		//Patch group
		String patchPayload = "{\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"],\"Operations\":[{\"op\":\"remove\",\"path\":\"urn:sap:cloud:scim:schemas:extension:custom:2.0:profile:Group\"}]}";
		MDNI mdni = new MDNI();
		Response patchGroupResponse = mdni.patchGroup(SAP_ANID, token, patchPayload, displayName);
		softAssertion.assertEquals(HttpStatus.SC_NOT_FOUND, patchGroupResponse.statusCode(),
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to PATCH the Group which does not exist");

		//Post group
		result = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		softAssertion.assertEquals(HttpStatus.SC_CREATED, result.getCode(),
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to create(POST) the Group which does not exist");

		softAssertion.assertAll();

	}

	@Test
	public void PatchGroupWhichContainsDeletedMember() throws Exception {
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = "TestUser" + uuid.toString();
		JSONObject userPayload = scimHelper.createUserPayload(username, null, Boolean.TRUE, "Test User", LOCALE_EN,
				null, "adavis", null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");

		// Creating group and associating user
		String displayName = GROUPNAME_EN + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, GROUPNAME_JA);
		names.put(Constants.LANG_ZH, GROUPNAME_ZH);
		List<Object> memberUsers = new ArrayList<Object>();
		memberUsers.add(username);
		List<Object> memberGroups = new ArrayList<Object>();
		memberGroups.add(GROUP_BUDGET_APPROVER);
		JSONObject groupPayload = scimHelper.createGroupPayload(displayName, names, memberUsers, memberGroups);
		System.err.println(groupPayload);
		RestResponse resultGroup = scimHelper.postGroups(token, groupPayload.toString(), SAP_ANID);
		System.err.println(resultGroup.getContent());
		Assert.assertEquals(resultGroup.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for group creation. Response=" + result.getContent());
		JSONObject group = (JSONObject) jsonObject(resultGroup.getContent());
		System.err.println(group);
		Assert.assertTrue(group.has(Constants.ID), "Newly created group id is not present in response. Response is" + group);
		String groupId = group.getString(Constants.ID);

		//Delete User
		result = scimHelper.deleteUsers(token, SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT, "Response code is not matching for user creation");

		//Patch group
		String patchPayload = "{\n" +
				"      \"schemas\": [\n" +
				"        \"urn:ietf:params:scim:api:messages:2.0:PatchOp\"\n" +
				"      ],\n" +
				"      \"Operations\": [\n" +
				"        {\n" +
				"          \"op\": \"replace\",\n" +
				"          \"path\": \"members\",\n" +
				"          \"value\": [\n" +
				"            {\n" +
				"              \"value\": \"cnoll\",\n" +
				"              \"type\": \"User\"\n" +
				"            }\n" +
				"          ]\n" +
				"        }\n" +
				"      ]\n" +
				"    }";
		MDNI mdni = new MDNI();
		Response patchGroupResponse = mdni.patchGroup(SAP_ANID, token, patchPayload, displayName);
		Assert.assertEquals(HttpStatus.SC_NOT_FOUND, patchGroupResponse.statusCode(),
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to PATCH the Group which does not exist");

		RestResponse getResult = scimHelper.getGroupssByUniqueName(token, SAP_ANID, groupId, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject groupget = new JSONObject(getResult.getContent());
		Assert.assertEquals(groupget.getString(Constants.DISPLAYNAME), groupId, "Get groups with filter on displayName is not working");

	}
		/*MDNI mdni = new MDNI();
		String username1 = createUser();
		String username2 = createUser();
		String groupWithoutMember = createGroup();
		String group=createGroupWithGivenMember(username1, groupWithoutMember);
		RestResponse result = scimHelper.deleteUsers(token, SAP_ANID, username1);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT,
				"Response code is not matching for user creation");

		String patchPayload = payload.toString();
		if (description.contains("")) {
			patchPayload = patchPayload.replace("cnoll", username2);
		}
		JsonObject patchPayloadJson = parser.parse(patchPayload).getAsJsonObject();

		Response patchGroupResponse = mdni.patchGroup(SAP_ANID, token, patchPayloadJson.get("patch").toString(), group);
		Response getGroupsResponse = mdni.getGroup(SAP_ANID, token, username1);
		Assert.assertTrue(!getGroupsResponse.jsonPath().getString("members").contains(username1), "");
		Assert.assertTrue(getGroupsResponse.jsonPath().getString("members").contains(username2), "");*/
}
