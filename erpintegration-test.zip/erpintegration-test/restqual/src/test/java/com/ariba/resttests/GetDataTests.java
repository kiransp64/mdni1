package com.ariba.resttests;

import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.GetDataHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.PostXMLDataHelper;
import com.ariba.pojos.RestResponse;
import com.ariba.utilities.DateFormatter;

public class GetDataTests {

	GetDataHelper gHelpers = new GetDataHelper();
	OAuthHelper oAuthHelper = new OAuthHelper();
	PostXMLDataHelper pHelper = new PostXMLDataHelper();

	protected static final String DefaultDateFormatPatterns = "EEE MMM d HH:mm:ss z yyyy";

	@Test
	public void getDataIncoterms() throws Exception {

		String anid = "AN71000002054";
		int flag = 1;

		// Getting Incoterms Before
		String token = oAuthHelper.getAccessToken(anid);
		System.err.println("Token is---------" + token);
		RestResponse getResponse = gHelpers.getDataByObject(anid, "IncoTerms", DateFormatter.getCustomDate(-1),
				DateFormatter.getTodayDate(), null, token);
		Assert.assertNotNull(getResponse, "Response is null");
		Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
			
		JSONArray incos = (JSONArray) BaseHelper.jsonObject(getResponse.getContent());
		System.err.println(incos.length());
		for (int i = 0; i < incos.length(); i++) {
			JSONObject j = (JSONObject)incos.get(i);
			System.err.println(j.get("Code"));
		}

		// Posting
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "TC2");
		RestResponse incoTerms = pHelper.postIncoTerms(anid, xmlString, "aribaws", "aribaws12345");
		System.err.println(incoTerms.getCode());
		Assert.assertNotNull(incoTerms, "Response is null");
		Assert.assertEquals(incoTerms.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		while (flag == 1) {
			getResponse = gHelpers.getStagedDetails(anid, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			int status = stagedData.getInt("status");
			if (status == 2)
				flag = 2;
			else
				Thread.sleep(10000);
		}

		// Getting IncoTerms After
		token = oAuthHelper.getAccessToken(anid);
		System.err.println("Token is---------" + token);
		getResponse = gHelpers.getDataByObject(anid, "IncoTerms", DateFormatter.getCustomDate(-1),
				DateFormatter.getTodayDate(), null, token);
		Assert.assertNotNull(getResponse, "Response is null");
		Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
		incos = (JSONArray) BaseHelper.jsonObject(getResponse.getContent());
		System.err.println(incos.length());
		for (int i = 0; i < incos.length(); i++) {
			JSONObject j = (JSONObject)incos.get(i);
			System.err.println(j.get("Code"));
		}
	}
}
