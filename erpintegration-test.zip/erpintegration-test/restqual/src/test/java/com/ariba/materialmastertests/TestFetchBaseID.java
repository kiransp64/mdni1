package com.ariba.materialmastertests;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.RandomStringUtils;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.Constants;
import com.ariba.helpers.MDSSearchHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.SCIMHelper;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TestFetchBaseID {

	String fetchUserUrl = "https://itg.cobalt.ariba.com/mdnigcpies01/erpintegration/api/fetchUsers?tenantId=AN02001164948";
	String fetchbaseId = "&baseId=";
	String uinqueNameUrl = "https://itg.cobalt.ariba.com/mdnigcpies01/erpintegration/api/fetchUsers?tenantId=AN02001164948&userUniqueName=";
	
	
	@Test
	public void testuniqueUserName() throws Exception {
		
		String[] userList = {"cnoll","arooney","adavis"};
		
		for(int i=0;i<userList.length;i++) {
			
		System.out.println("=======================UniqueUser Iteration "+i+" Started=======================");
		
		String[] data = getResponseWithBaseID(uinqueNameUrl+userList[i],"");
		
		Assert.assertTrue(data[0].contains(userList[i]), "Failed: Response does not have " +userList[i]+ " user");	
		
		System.out.println("=======================UniqueUser Iteration "+i+" Ended=======================");
		}

	}
	
	
	@Test
	public void testFetchUsers() throws Exception {
		
		String fetchUserPayload = getData("testFetchUsers");
		
		for (int i=0;i<1;i++) {
			
			System.out.println("=======================Iteration "+i+" Started=======================");
			
			String[] currentValue = getResponseWithBaseID(fetchUserUrl,"");
			
			String[] lastestValue = getResponseWithBaseID(fetchUserUrl,fetchbaseId+currentValue[i+1]);			
			
			Assert.assertTrue(!(currentValue[i].equals(lastestValue[i])), "Failed: User details are same for both requests");
			
			Assert.assertTrue(!(currentValue[i+1].equals(lastestValue[i+1])), "Failed: LastBaseID same for both requests");
			
			System.out.println("=======================Iteration "+i+" Ended=======================");
			
		}

	}

	public String getData(String dataType)
			throws InvalidFormatException, IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {

		HashMap<String, String> masterData = new HashMap<String, String>();
		String rootDir = System.getProperty("user.dir");
		String filename = "mdniPayload_MaterialMaster.xlsx";
		JSONArray entitiesArray = new JSONArray();

		InputStream file = new FileInputStream(rootDir + "/resources/mdnifiles/" + filename);

		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet("PayLoad");
		int rowCount = sheet.getLastRowNum();
		for (int i = 1; i <= rowCount; i++) {
			String key = sheet.getRow(i).getCell(0).getStringCellValue();
			String value = sheet.getRow(i).getCell(1).getStringCellValue();
			masterData.put(key, value);
		}
		// wb.close();
		return masterData.get(dataType);
	}
	
	
	public String[] getResponseWithBaseID(String fetchUserUrl, String fetchbaseId) throws Exception {

		String fetchUserPayload = getData("testFetchUsers");
		
		String[] responseId = new String [2];
		try {
			
			String userCredentials = "aribaws" + ":" + "aribaaribaariba";
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			
			URL url = new URL(fetchUserUrl+fetchbaseId);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			//connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			connection.setRequestProperty("Content-Type","application/json");
			connection.setDoOutput(true);
			connection.setRequestProperty("Authorization",basicAuth);
			DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
			  wr.writeBytes(fetchUserPayload);		
			 
			  BufferedReader in = new BufferedReader(
			          new InputStreamReader(connection.getInputStream()));
			  String output;
			  StringBuffer response = new StringBuffer();
			 
			  while ((output = in.readLine()) != null) {
			  response.append(output);
			  }
			  in.close();			  
			 
			  //printing result from respons;
			  responseId[0] = response.toString();
			 
			  responseId[1] = connection.getHeaderField("lastBaseId");			  
			
		}catch(Exception e) {
			e.printStackTrace();
		}		
		return responseId;
	}

}

