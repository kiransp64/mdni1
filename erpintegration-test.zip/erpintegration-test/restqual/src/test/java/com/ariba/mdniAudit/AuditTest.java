package com.ariba.mdniAudit;

import com.ariba.helpers.*;
import com.ariba.pojos.RestResponse;
import com.ariba.utilities.DateFormatter;
import com.github.dzieciou.testing.curl.CurlLoggingRestAssuredConfigFactory;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.ariba.services.MDNI;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.ariba.helpers.AuditHelper.*;
import static io.restassured.RestAssured.given;

public class AuditTest {
    MDNI mdni = new MDNI();
    RestAssuredConfig config = CurlLoggingRestAssuredConfigFactory.createConfig();
    public static String twoloToken, uniqueName;
    public static String objectName, objectName_upload, senderBusinessSystemId, documentID, documentType, status, documentStatus, targetService, loadType, jobId, recordsInserted, recordsUpdated, recordsDeleted, traceId, realUser;
    static String mdniUserName = "aribaws", mdniPassword = "aribaaribaariba";
    static String purposeOfAudit = "BusinessCritical";
    public static Map<String, String> auditObjects = new HashMap<>();

    @BeforeClass
    public void setUp() throws Exception{
        twoloToken = OAuthHelper.get2LOToken_auditService();
    }

    @Test(priority = 0)
    public void auditSearchPreCheckTest() throws Exception {
        objectName = "WBSElement"; senderBusinessSystemId = "ERP001";
        startTime = setAuditSearchDateFormat("start");

        Response response = auditPublish(twoloToken);
        response.then().assertThat().statusCode(200);

        mdni.uploadWSDL(BUYER_AUDIT_ANID, objectName,senderBusinessSystemId);
        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+wsdl_Upload+"' and action eq '"+dataImport_Action+"' and traceId eq ''";
        endTime = setAuditSearchDateFormat("end");
        response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(resBody);
        JSONArray contents = (JSONArray) json.get("contents");

        if(contents.isEmpty()) Assert.fail("Audit search returned no result");
    }

    @Test(priority=1, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyWSDLUploadStartAuditTest() throws Exception {
        objectName = "WBSElement"; senderBusinessSystemId = "ERP001"; traceId = "";
        documentID = ""; documentType = "WSDL"; status = "SUCCESS";

        startTime = setAuditSearchDateFormat("start");
        mdni.uploadWSDL(BUYER_AUDIT_ANID, objectName,senderBusinessSystemId);
        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+wsdl_Upload+"' and action eq '"+dataImport_Action+"' and traceId eq ''";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(wsdl_Upload+"start");
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=2, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyWSDLUploadAuditTest() throws Exception {
        objectName = "WBSElement"; senderBusinessSystemId = "ERP001";
        documentID = objectName+"_"+senderBusinessSystemId+"##"; documentType = "WSDL"; status = "SUCCESS"; traceId = documentID;

        startTime = setAuditSearchDateFormat("start");
        mdni.uploadWSDL(BUYER_AUDIT_ANID, objectName,senderBusinessSystemId);
        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+wsdl_Upload+"' and action eq '"+dataImport_Action+"' and traceId ne ''" ;
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(wsdl_Upload);
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=3, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyWSDLUploadFailedAuditTest() throws Exception{
        objectName = "Incoterms@"; objectName_upload = "WBSElement"; senderBusinessSystemId = ""; traceId = "";
        documentID = ""; documentType = "WSDL"; status = "FAIL";

        startTime = setAuditSearchDateFormat("start");
        mdni.uploadWSDL_Error(BUYER_AUDIT_ANID, objectName, objectName_upload, senderBusinessSystemId);
        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+wsdl_Upload+"' and action eq '"+dataImport_Action+"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(wsdl_Upload);
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=4, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyProcessXMLDataStartAuditTest() throws Exception{
        objectName = "Incoterms"; senderBusinessSystemId = "ER123";  targetService = "Buyer";
        status = "SUCCESS"; documentStatus = "Pending Processing"; loadType = "Full Load"; documentType = "XML";
        String DefaultDateFormatPatterns = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);

        // Upload Payload for Incoterms
        String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
        UUID uuid = UUID.randomUUID();
        xmlString = xmlString.replace("###", uuid.toString());
        xmlString = xmlString.replace("$$$", "TC1");
        xmlString = xmlString.replace("@@@", date);
        startTime = setAuditSearchDateFormat("start");
        RestResponse payloadResponse = mdni.uploadPayload(BUYER_AUDIT_ANID, xmlString, mdniUserName, mdniPassword, objectName, senderBusinessSystemId);
        Assert.assertNotNull(payloadResponse, "Response is null");
        Assert.assertEquals(payloadResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
        jobId = payloadResponse.getContent().substring(6);
        documentID = jobId;
        traceId = documentID;

        Response res = getJobStatus(BUYER_AUDIT_ANID, jobId);
        String resBody = res.getBody().prettyPrint();
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(resBody);
        String tmpStatus = json.get("Status").toString();
        if(tmpStatus.equalsIgnoreCase("duplicate"))
            documentStatus = tmpStatus;

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+process_payload+"' and action eq '"+dataImport_Action+ "' and documentStatus eq '" + documentStatus + "'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(process_payload+"start");
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=5, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyProcessXMLDataAuditTest() throws Exception {
        objectName = "IncoTerms";senderBusinessSystemId = "ER123";status = "SUCCESS";
        String objectNameAPI = "Incoterms";
        targetService = "Buyer";loadType = "Full Load"; documentType = "XML";
        String DefaultDateFormatPatterns = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);
        Response response;

        // Upload Payload
        String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
        UUID uuid = UUID.randomUUID();
        xmlString = xmlString.replace("###", uuid.toString());
        xmlString = xmlString.replace("$$$", "TC1");
        xmlString = xmlString.replace("@@@", date);
        RestResponse payloadResponse = mdni.uploadPayload(BUYER_AUDIT_ANID, xmlString, mdniUserName, mdniPassword, objectNameAPI, senderBusinessSystemId);
        Assert.assertNotNull(payloadResponse, "Response is null");
        Assert.assertEquals(payloadResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
        jobId = payloadResponse.getContent().substring(6);
        documentID = jobId;
        traceId = documentID;

        startTime = setAuditSearchDateFormat("start");
        Response res = getJobStatus(BUYER_AUDIT_ANID, jobId);
        String resBody = res.getBody().prettyPrint();
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(resBody);
        if(json.size()>1){
            recordsInserted = json.get("RecordsInserted").toString();
            recordsUpdated = json.get("RecordsUpdated").toString();
            recordsDeleted = json.get("RecordsDeleted").toString();
        } else
            status = "FAIL";
        documentStatus = json.get("Status").toString();

        if(!documentStatus.equalsIgnoreCase("duplicate")) {
            if(status.equalsIgnoreCase("SUCCESS")) {
                filterData = "serviceName eq '" + mdniService + "' and operation eq '" + process_payload + "' and action eq '" + dataImport_Action + "' and documentStatus eq '" + documentStatus + "'";
                endTime = setAuditSearchDateFormat("end");
                response = auditSyncSearch(integrationAuditType, startTime, endTime, filterData, twoloToken, BUYER_AUDIT_REALM);
                resBody = response.getBody().prettyPrint();
                getAuditObjects_Integration(process_payload);
                validateAuditSearchJson(resBody, auditObjects);
            }
        }
    }

    @Test(priority=6, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyProcessXMLDataFailedAuditTest() throws Exception{
        objectName = "Incoterms1"; senderBusinessSystemId = "ER321"; targetService = "Buyer";
        documentID = traceId = documentStatus = ""; status = "FAIL"; documentType = "XML"; loadType = "Full Load";
        String DefaultDateFormatPatterns = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);

        // Upload Payload for Incoterms
        String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
        UUID uuid = UUID.randomUUID();
        xmlString = xmlString.replace("###", uuid.toString());
        xmlString = xmlString.replace("$$$", "TC1");
        xmlString = xmlString.replace("@@@", date);
        startTime = setAuditSearchDateFormat("start");
        RestResponse payloadResponse = mdni.uploadPayload(BUYER_AUDIT_ANID, xmlString, mdniUserName, mdniPassword, objectName, senderBusinessSystemId);
        Assert.assertNotNull(payloadResponse, "Response is null");
        Assert.assertEquals(payloadResponse.getCode(), BaseHelper.HTTP_500, "Response message is not same");
        jobId = payloadResponse.getContent().substring(6);

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+process_payload+"' and action eq '"+dataImport_Action+"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(process_payload);
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=7, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyMMProcessXMLDataAuditTest() throws Exception {
        String objectNameMM = "Product"; documentType = "XML";
        objectName = "ItemMaster";senderBusinessSystemId = "ER123";status = "SUCCESS";
        targetService = "Sourcing";loadType = "Incremental Load";
        String DefaultDateFormatPatterns = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);
        Response response;

        // Upload Payload
        String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/itemMaster.txt");

        UUID uuid = UUID.randomUUID();
        xmlString = xmlString.replace("XXXXX", uuid.toString());
        xmlString = xmlString.replace("@@@", date);

        RestResponse payloadResponse = mdni.uploadPayload(S4_AUDIT_ANID, xmlString, mdniUserName, mdniPassword, objectNameMM, senderBusinessSystemId);
        Assert.assertNotNull(payloadResponse, "Response is null");
        Assert.assertEquals(payloadResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
        if(payloadResponse.getCode() == 200) {
            jobId = payloadResponse.getContent().substring(6);
            documentID = jobId;
            traceId = documentID;

            startTime = setAuditSearchDateFormat("start");
            Response res = getJobStatus(S4_AUDIT_ANID, jobId);
            String resBody = res.getBody().prettyPrint();
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(resBody);
            if (json.size() > 1) {
                recordsInserted = json.get("RecordsInserted").toString();
                recordsUpdated = json.get("RecordsUpdated").toString();
                recordsDeleted = json.get("RecordsDeleted").toString();
            } else
                status = "FAIL";
            documentStatus = json.get("Status").toString();

            if (!documentStatus.equalsIgnoreCase("duplicate")) {
                if (status.equalsIgnoreCase("SUCCESS")) {
                    filterData = "serviceName eq '" + mdniService + "' and operation eq '" + process_payload + "' and action eq '" + dataImport_Action + "' and documentStatus eq '" + documentStatus + "'";
                    endTime = setAuditSearchDateFormat("end");
                    response = auditSyncSearch(integrationAuditType, startTime, endTime, filterData, twoloToken, S4_AUDIT_REALM);
                    resBody = response.getBody().prettyPrint();
                    getAuditObjects_Integration(process_payload);
                    validateAuditSearchJson(resBody, auditObjects);
                }
            }
        }
    }

    @Test(priority=8, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyFetchUsersAuditTest() throws Exception {
        status = "SUCCESS"; targetService = "Buyer"; realUser = "AUTH_CREDENTIAL";

        String xmlString = BaseHelper.getStringFromXML("/resources/exportfiles/users.txt");
        startTime = setAuditSearchDateFormat("start");
        Response exportResponse = mdni.fetchUsers(BUYER_AUDIT_ANID, xmlString,"", mdniUserName, mdniPassword);
        Assert.assertNotNull(exportResponse, "Response is null");
        Assert.assertEquals(exportResponse.statusCode(), BaseHelper.HTTP_200, "Response message is not same");

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+fetch_users+"' and action eq '"+dataExport_Action+"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(fetch_users);
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=9, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyFetchUserNameAuditTest() throws Exception {
        status = "SUCCESS"; targetService = "Buyer"; uniqueName = "cnoll"; realUser = "AUTH_CREDENTIAL";

        String xmlString = BaseHelper.getStringFromXML("/resources/exportfiles/users.txt");
        startTime = setAuditSearchDateFormat("start");
        Response exportResponse = mdni.fetchUsers(BUYER_AUDIT_ANID, xmlString, "cnoll", mdniUserName, mdniPassword);
        Assert.assertNotNull(exportResponse, "Response is null");
        Assert.assertEquals(exportResponse.statusCode(), BaseHelper.HTTP_200, "Response message is not same");

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+fetch_users+"' and action eq '"+dataExport_Action+"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(fetch_users+"uniqueName");
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=10, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyFetchGroupsAuditTest() throws Exception {
        status = "SUCCESS"; targetService = "Buyer"; realUser = "AUTH_CREDENTIAL";

        String xmlString = BaseHelper.getStringFromXML("/resources/exportfiles/groups.txt");
        startTime = setAuditSearchDateFormat("start");
        Response exportResponse = mdni.fetchGroups(BUYER_AUDIT_ANID, xmlString, mdniUserName, mdniPassword);
        Assert.assertNotNull(exportResponse, "Response is null");
        Assert.assertEquals(exportResponse.statusCode(), BaseHelper.HTTP_200, "Response message is not same");

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+fetch_groups+"' and action eq '"+dataExport_Action+"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(fetch_groups);
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=11, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifyFetchProcurementUnitsAuditTest() throws Exception {
        status = "SUCCESS"; targetService = "Buyer"; realUser = "AUTH_CREDENTIAL";

        String xmlString = BaseHelper.getStringFromXML("/resources/exportfiles/procurementunits.txt");
        startTime = setAuditSearchDateFormat("start");
        Response exportResponse = mdni.fetchProcurementUnits(BUYER_AUDIT_ANID, xmlString, mdniUserName, mdniPassword);
        exportResponse.prettyPrint();
        Assert.assertNotNull(exportResponse, "Response is null");
        Assert.assertEquals(exportResponse.statusCode(), BaseHelper.HTTP_200, "Response message is not same");

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+fetch_procurementUnits+"' and action eq '"+dataExport_Action+"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(integrationAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Integration(fetch_procurementUnits);
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=12, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifySecurityAuditTest() throws Exception {
        status = "SUCCESS"; realUser = "AUTH_CREDENTIAL";
        objectName = "Incoterms";
        // Upload Payload for Incoterms
        String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
        startTime = setAuditSearchDateFormat("start");
        RestResponse payloadResponse = mdni.uploadPayload(BUYER_AUDIT_ANID, xmlString, mdniUserName, mdniPassword, objectName, senderBusinessSystemId);
        Assert.assertNotNull(payloadResponse, "Response is null");
        Assert.assertEquals(payloadResponse.getCode(), BaseHelper.HTTP_500, "Response message is not same");

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+ security_action +"' and action eq '"+ security_action +"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(securityAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Security(security_action);
        validateAuditSearchJson(resBody, auditObjects);
    }

    @Test(priority=13, dependsOnMethods = {"auditSearchPreCheckTest"})
    public void verifySecurityFailedAuditTest() throws Exception {
        status = "FAIL"; realUser = "AUTH_CREDENTIAL"; mdniUserName = "aribaaws";
        objectName = "Incoterms";
        String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
        startTime = setAuditSearchDateFormat("start");
        RestResponse payloadResponse = mdni.uploadPayload(BUYER_AUDIT_ANID, xmlString, mdniUserName, mdniPassword, objectName, senderBusinessSystemId);
        Assert.assertNotNull(payloadResponse, "Response is null");
        Assert.assertEquals(payloadResponse.getCode(), BaseHelper.HTTP_500, "Response message is not same");

        filterData = "serviceName eq '"+mdniService+"' and operation eq '"+ security_action +"' and action eq '"+ security_action +"'";
        endTime = setAuditSearchDateFormat("end");
        Response response = auditSyncSearch(securityAuditType, startTime,endTime,filterData,twoloToken, BUYER_AUDIT_REALM );
        String resBody = response.getBody().prettyPrint();
        getAuditObjects_Security(security_action);
        validateAuditSearchJson(resBody, auditObjects);
    }

    public Map<String, String> getAuditObjects_Integration(String operation) {
        String notes, apiUrl, param7;

        if(!auditObjects.isEmpty())
            auditObjects.clear();

        if(operation.contains("FETCH")) {
            objectName = getPropertyValue(operation, objectNameProp, "");
            purposeOfAudit = "BusinessCritical";
        }
        if(operation.contains("FETCH_USERS"))
            purposeOfAudit = "PII";

        notes = getPropertyValue(operation, notesProp, status);
        apiUrl = getPropertyValue(operation, apiUrlProp, status);
        auditObjects.put(notesProp, notes);
        auditObjects.put(typeOfAuditProp, integrationAuditType);
        auditObjects.put(apiUrlProp, apiUrl);
        auditObjects.put(purposeOfAuditProp, purposeOfAudit);
        auditObjects.put(anidProp, BUYER_AUDIT_ANID);
        auditObjects.put(objectNameProp, objectName);
        auditObjects.put(targetServiceProp, targetService );
        auditObjects.put(formatProp, "XML");
        auditObjects.put(realUserProp, realUser);
        auditObjects.put(tenantIdProp, BUYER_AUDIT_REALM);
        auditObjects.put(entityProp, objectName);
        auditObjects.put(statusProp, status);

        if(operation.contains(wsdl_Upload)){
            realUser = "SYSTEM";
            auditObjects.put(realUserProp, realUser);
            auditObjects.put(apiUrlProp, "");
            auditObjects.put(targetServiceProp, "" );
            auditObjects.put(formatProp, "");
            auditObjects.put(documentTypeProp, documentType);
            auditObjects.put(traceIdProp, traceId);
            auditObjects.put(documentIDProp, documentID);
            auditObjects.put(senderBusinessIdProp, senderBusinessSystemId);
            if(operation.contains("start")){
                auditObjects.put(statusProp, "");
            }
        }
        else if(operation.contains(process_payload)) {
            realUser = "AUTH_CREDENTIAL";
            auditObjects.put(realUserProp, realUser);
            auditObjects.put(apiUrlProp, "");
            auditObjects.put(documentStatusProp, documentStatus);
            auditObjects.put(traceIdProp, traceId);
            auditObjects.put(loadTypeProp, loadType);
            auditObjects.put(documentIDProp, documentID);
            auditObjects.put(senderBusinessIdProp, senderBusinessSystemId);
            auditObjects.put(documentTypeProp, documentType);
            if(operation.contains("start")){
                auditObjects.put(statusProp, "");
            } else{
                if(status.equalsIgnoreCase("success")) {
                    if(!documentStatus.equalsIgnoreCase("Needs Re-Processing")) {
                        param7 = getPropertyValue(operation, param7Prop, status);
                        auditObjects.put(param7Prop, param7);
                    }
                }
            }
            if(objectName.equalsIgnoreCase("ItemMaster")) {
                auditObjects.put(anidProp, S4_AUDIT_ANID);
                auditObjects.put(tenantIdProp, S4_AUDIT_REALM);
            }
        }
        return auditObjects;
    }

    public Map<String, String> getAuditObjects_Security(String operation) {
        String notes, param6;

        if(!auditObjects.isEmpty())
            auditObjects.clear();
        notes = getPropertyValue(operation, notesProp, status);
        param6 = getPropertyValue(operation, param6Prop, status);
        auditObjects.put(notesProp, notes);
        auditObjects.put(typeOfAuditProp, securityAuditType);
        auditObjects.put(param6Prop, param6);
        auditObjects.put(purposeOfAuditProp, "SecurityEvent");
        auditObjects.put(anidProp, BUYER_AUDIT_ANID);
        auditObjects.put(objectNameProp, objectName);
        auditObjects.put(realUserProp, realUser);
        auditObjects.put(tenantIdProp, BUYER_AUDIT_REALM);
        auditObjects.put(statusProp, status);

        return auditObjects;
    }

    public String getPropertyValue(String operation, String property, String status) {
        String propertyValue = null; String apiType = null, exportType = null;

        if (operation.contains(wsdl_Upload)) {
            if (property.equalsIgnoreCase("notes")) {
                if(status.equalsIgnoreCase("success")) {
                    if (operation.contains("start"))
                        propertyValue = "upload wsdl started for tenantId: " + BUYER_AUDIT_REALM + ", Object Name: " + objectName + ", Sender Business System Id: " + senderBusinessSystemId;
                    else
                        propertyValue = "upload wsdl successful for tenantId: " + BUYER_AUDIT_REALM + ", Object Name: " + objectName + ", Sender Business System Id: " + senderBusinessSystemId;
                } else
                    propertyValue = "upload wsdl failed for tenantId: "+BUYER_AUDIT_REALM+", Object Name: "+objectName+", Sender Business System Id:  with exception: objectName "+objectName+" and attached WSDL file are not in sync";
            }
        } else if (operation.contains(process_payload)) {
            if (property.equalsIgnoreCase("notes")) {
                if (status.equalsIgnoreCase("fail"))
                    propertyValue = "process xml data failed for realmId : "+BUYER_AUDIT_REALM+" Object Name : "+objectName+" with error message class path resource [RNGFiles/Incoterms1.rng] cannot be opened because it does not exist";
                else{
                    if (operation.contains("start"))
                        propertyValue = "process xml data going to start for realmId : " + BUYER_AUDIT_REALM + " Object Name : " + objectName;
                    else if (documentStatus.equalsIgnoreCase("Processed"))
                        propertyValue = "process xml data successful for realmId : " + BUYER_AUDIT_REALM + " Object Name : " + objectName;
                    else
                        propertyValue = "Issue in processing xml data for realmId : " + BUYER_AUDIT_REALM + " Object Name : " + objectName;
                    if(objectName.equalsIgnoreCase("ItemMaster"))
                        propertyValue = "process xml data successful for realmId : " + S4_AUDIT_REALM + " Object Name : " + objectName;
                }
            } else if (property.equalsIgnoreCase("apiUrl")) {
                if (status.equalsIgnoreCase("success"))
                    propertyValue = "/Buyer/Main/ad/publishMasterData/ariba.integration.base.NativeIntegrationDirectAction?realm=" + BUYER_AUDIT_REALM + "&operation=2&object=" + objectName;
                else
                    propertyValue = "";
            } else if (property.equalsIgnoreCase("param7")) {
                if (status.equalsIgnoreCase("success"))
                    propertyValue = "Inserted " + recordsInserted + " records, updated " + recordsUpdated + " records and deleted " + recordsDeleted + " records";
                else
                    propertyValue = "";
            }
        } else if (operation.contains("FETCH")) {
            if(operation.contains("USERS")){
                apiType = "Users";
                objectName = "User";
                exportType = fetch_users;
            } else if(operation.contains("GROUPS")) {
                apiType = "Groups";
                objectName = "Group";
                exportType = fetch_groups;
            } else if(operation.contains("PROCUREMENT_UNITS")) {
                apiType = "ProcurementUnits";
                objectName = "ProcurementUnit";
                exportType = fetch_procurementUnits;
            }

            if (property.equalsIgnoreCase("notes")) {
                    propertyValue = exportType+" data successful in the realm: " + BUYER_AUDIT_REALM;
            } else if (property.equalsIgnoreCase("apiUrl")) {
                if (status.equalsIgnoreCase("success"))
                    if(operation.contains("uniqueName"))
                        propertyValue = "/Buyer/Main/ad/get"+apiType+"/ariba.integration.base.NativeIntegrationDirectAction?realm=" + BUYER_AUDIT_REALM + "&userUniqueName=" + uniqueName;
                    else
                        propertyValue = "/Buyer/Main/ad/get"+apiType+"/ariba.integration.base.NativeIntegrationDirectAction?realm=" + BUYER_AUDIT_REALM;
                else
                    propertyValue = "";
            } else if (property.equalsIgnoreCase("param7")) {
                if (status.equalsIgnoreCase("success"))
                    propertyValue = "Inserted " + recordsInserted + " records, updated " + recordsUpdated + " records and deleted " + recordsDeleted + " records";
                else
                    propertyValue = "";
            } else if (property.equalsIgnoreCase("param2")) {
                    propertyValue = objectName;
            }
        } else if (operation.equalsIgnoreCase(security_action)) {
            String apiUrl = "http://"+MDNI_HOSTAWS+"/erpintegration/api/uploadXMLData";
            if (property.equalsIgnoreCase("notes")) {
                if(status.equalsIgnoreCase("success"))
                    propertyValue = "Successfully authenticated while accessing the url "+apiUrl;
                else
                    propertyValue = "Authentication Failed while accessing the url "+apiUrl+ ", with error message Missing / Invalid Authentication Credentials";
            } else if(property.equalsIgnoreCase("param6"))
                propertyValue = apiUrl;
        }
        return propertyValue;
    }

    public Response getStatus(String tenantId, String jobId){
        if (tenantId.equalsIgnoreCase("AN02000025606") || tenantId.equalsIgnoreCase(AuditHelper.BUYER_AUDIT_ANID))
            RestAssured.baseURI="https://"+ MDNI_HOSTAWS;
        else
            RestAssured.baseURI="https://"+ MDNI_HOST;
        RequestSpecification requestSpecification = given().config(config);
        requestSpecification.queryParam("tenantId",tenantId);
        requestSpecification.queryParam("jobId",jobId);
        requestSpecification.auth().preemptive().basic(mdniUserName,mdniPassword);
        Response response = requestSpecification.relaxedHTTPSValidation().get(Constants.MDNI_JOB_STATUS_AUDIT);
        response.prettyPrint();
        response.then().assertThat().statusCode(200);
        return response;
    }

    public Response getJobStatus(String tenantId, String jobId) throws InterruptedException {
        int count = 1;
        int maxRetries = 20;
        Response response = getStatus(tenantId,jobId);
        while (true)
        {
            if (response.jsonPath().getString("Status").contains("Processing") && count<maxRetries ){
                if (response.jsonPath().getString("Status").equalsIgnoreCase("Needs Re-Processing")){
                    break;
                }
                System.out.println(count*10000);
                Thread.sleep(count*10000);
                response = getStatus(tenantId,jobId);
                count++;
                if (response.asString().contains("RecordsInserted")){
                    if (response.jsonPath().getInt("RecordsInserted")>0){
                        break;
                    }
                }
            }
            else{
                break;
            }
        }
        return response;
    }
}
