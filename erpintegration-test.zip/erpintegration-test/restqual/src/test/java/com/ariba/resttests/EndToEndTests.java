package com.ariba.resttests;

import java.util.Date;
import java.util.UUID;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.ConfigHelper;
import com.ariba.helpers.GetDataHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.PostXMLDataHelper;
import com.ariba.pojos.RestResponse;
import com.ariba.utilities.DateFormatter;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class EndToEndTests {

	GetDataHelper gHelpers = new GetDataHelper();
	OAuthHelper oAuthHelper = new OAuthHelper();
	PostXMLDataHelper pHelper = new PostXMLDataHelper();
	ConfigHelper cHelper = new ConfigHelper();

	protected static final String DefaultDateFormatPatterns = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	int noOfRetries = 10;
	String retryTenant = "AN71000000559";

	@BeforeClass
	public void registerTenants() throws Exception {

		RestResponse getResponse = cHelper.postConfig(retryTenant);
		Assert.assertNotNull(getResponse, "Response is null");
		Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");

	}

	@Test
	public void retryCheckWithDependentObject() throws Exception {

		int flag = 1;
		int counter = 0;
		String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);
		String objectPOrgName = "PurchasingOrg";

		// Posting POrg and will be marked as retry
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/purchaseOrg.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "RR1");
		xmlString = xmlString.replace("@@@", date);
		RestResponse response = pHelper.postPurchaseOrg(retryTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		int status = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(retryTenant, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Timedout before status moved to process");
		else {
			Assert.assertEquals(status, 3, "Status is not set to retry");
			String token = oAuthHelper.getAccessToken(retryTenant);
			RestResponse getResponse = gHelpers.getIntegrationJobLog(retryTenant, objectPOrgName, token);
			Assert.assertNotNull(getResponse, "Response is null");
			Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
			JsonParser parser = new JsonParser();
			JsonObject content = (JsonObject) parser.parse(getResponse.content);
			Assert.assertEquals(content.get("RecordsInserted").getAsInt(), 0, "Records inserted count not matching");
			Assert.assertEquals(content.get("Status").getAsString(), "Processed", "Records status is not Processed");
			Assert.assertNotNull(content.get("Warnings").getAsString(), "Warning is null for Invalid realm");
		}

		// Posting Company Code
		xmlString = BaseHelper.getStringFromXML("/resources/datafiles/companyCode.txt");
		UUID ccuuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", ccuuid.toString());
		xmlString = xmlString.replace("$$$", "CR2");
		xmlString = xmlString.replace("@@@", date);
		response = pHelper.postCompanyCode(retryTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		flag = 1;
		status = 0;
		counter = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(retryTenant, ccuuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Timedout before status moved to process");
		else {
			Assert.assertEquals(status, 2, "Status is not set to processed");
		}

		// Checking status of initial POrg request
		RestResponse getResponse = gHelpers.getStagedDetails(retryTenant, uuid.toString());
		JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
		System.err.println(stagedData.getInt("status"));
		status = stagedData.getInt("status");
		Assert.assertEquals(status, 0, "Status is not set to retry");
	}

	@Test
	public void retryCheckWithNonDependentObject() throws Exception {

		int flag = 1;
		int counter = 0;
		String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);
		String objectPOrgName = "PurchasingOrg";

		// Posting POrg and will be marked as retry
		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/purchaseOrg.txt");
		UUID uuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", uuid.toString());
		xmlString = xmlString.replace("$$$", "RR1");
		xmlString = xmlString.replace("@@@", date);
		RestResponse response = pHelper.  postPurchaseOrg(retryTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		int status = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(retryTenant, uuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Timedout before status moved to process");
		else {
			Assert.assertEquals(status, 3, "Status is not set to retry");
			String token = oAuthHelper.getAccessToken(retryTenant);
			RestResponse getResponse = gHelpers.getIntegrationJobLog(retryTenant, objectPOrgName, token);
			Assert.assertNotNull(getResponse, "Response is null");
			Assert.assertEquals(getResponse.getCode(), BaseHelper.HTTP_200, "Response message is not same");
			JsonParser parser = new JsonParser();
			JsonObject content = (JsonObject) parser.parse(getResponse.content);
			Assert.assertEquals(content.get("RecordsInserted").getAsInt(), 0, "Records inserted count not matching");
			Assert.assertEquals(content.get("Status").getAsString(), "Processed", "Records status is not Processed");
			Assert.assertNotNull(content.get("Warnings").getAsString(), "Warning is null for Invalid realm");
		}

		// Posting IncoTerms
		xmlString = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
		UUID inuuid = UUID.randomUUID();
		xmlString = xmlString.replace("###", inuuid.toString());
		xmlString = xmlString.replace("$$$", "RR1");
		xmlString = xmlString.replace("@@@", date);
		RestResponse incoTerms = pHelper.postIncoTerms(retryTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(incoTerms.getCode());
		Assert.assertNotNull(incoTerms, "Response is null");
		Assert.assertEquals(incoTerms.getCode(), BaseHelper.HTTP_200, "Response message is not same");

		// Waiting for request to be processed in MDNI
		flag = 1;
		status = 0;
		counter = 0;
		while (flag == 1) {
			RestResponse getResponse = gHelpers.getStagedDetails(retryTenant, inuuid.toString());
			JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
			System.err.println(stagedData.getInt("status"));
			status = stagedData.getInt("status");
			if (status > 1)
				flag = status;
			else if (counter > noOfRetries)
				flag = 10;
			else
				Thread.sleep(10000);
			counter++;
		}

		if (flag == 10)
			Assert.fail("Timedout before status moved to process");
		else {
			Assert.assertEquals(status, 2, "Status is not set to processed");
		}

		// Checking status of initial POrg request
		RestResponse getResponse = gHelpers.getStagedDetails(retryTenant, uuid.toString());
		JSONObject stagedData = (JSONObject) BaseHelper.jsonObject(getResponse.getContent());
		System.err.println(stagedData.getInt("status"));
		status = stagedData.getInt("status");
		Assert.assertEquals(status, 3, "Status is set to retry");
	}

	@Test
	public void fetchGroups() throws Exception {

		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/fetchGroups.txt");
		RestResponse response = pHelper.fetchGroups(retryTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");
	}

	@Test
	public void fetchProcurementUnits() throws Exception {

		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/fetchProcurementUnits.txt");
		RestResponse response = pHelper.fetchProcurementUnits(retryTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");
	}
	
	@Test
	public void fetchUsers() throws Exception {

		String xmlString = BaseHelper.getStringFromXML("/resources/datafiles/fetchUsers.txt");
		RestResponse response = pHelper.fetchUsers(retryTenant, xmlString, "aribaws", "aribaws12345");
		System.err.println(response.getCode());
		Assert.assertNotNull(response, "Response is null");
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same");
	}
}
