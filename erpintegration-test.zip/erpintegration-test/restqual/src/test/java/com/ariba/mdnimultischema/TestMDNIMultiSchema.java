package com.ariba.mdnimultischema;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.HashMap;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import com.ariba.helpers.BaseHelper;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.protocol.HTTP;

public class TestMDNIMultiSchema {	
	
	public static String MDNIBASEURL = "";
	
	@BeforeSuite
	public void initializeURL() {
		MDNIBASEURL = System.getProperty("testurl");
	}
	
	public HttpEntity buildMultiPart(String filepath, String filename) {
		File file = new File(filepath);
        final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
        builder.addBinaryBody("filename", file, ContentType.DEFAULT_BINARY, filename);
        final HttpEntity multiPartEntity = builder.build();
		return multiPartEntity;
	}
	
	@Test(priority= 1)
    public void loadWSDLCompanyCodeVT1() throws Exception {
		 	System.out.println("Starting test");
		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_new_wsdl.xml", "mdni_new_wsdl.xml");
        
           System.out.println("=====Start WSDL Upload without ID=====");
           
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDL");
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);      
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();     
           Assert.assertTrue(responseContent.contains("Successfully"), responseContent);
           Assert.assertTrue(responseContent.contains(getData("ConfigURL", "TenantID")), responseContent);
           Assert.assertTrue(responseContent.contains(getData("ConfigURL", "objectNameCC")), responseContent);
         
           System.out.println("=====End WSDL Upload without ID====="); 
    }
	
	@Test(priority= 2)
    public void loadWSDLCompanyCodeWithIdVT2() throws Exception {

		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_new_wsdl.xml", "mdni_new_wsdl.xml");
		   
           System.out.println("=====Start WSDL Upload with ID====="); 
           
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDLID");
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();     
           Assert.assertTrue(responseContent.contains("Successfully"), responseContent);
           Assert.assertTrue(responseContent.contains(getData("ConfigURL", "TenantID")), responseContent);
           Assert.assertTrue(responseContent.contains(getData("ConfigURL", "objectNameCC")), responseContent);
           Assert.assertTrue(responseContent.contains(getData("ConfigURL", "WSDLSystemId")), responseContent);
          
           System.out.println("=====End WSDL Upload with ID=====");      
    }
	
	
	@Test(priority= 3)
    public void loadWSDLCompanyCodeIVT3() throws Exception {

		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_wsdl_duplicateSchema.xml", "mdni_wsdl_duplicateSchema.xml");
           
           System.out.println("=====Start WSDL Upload duplicate schema=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDL");
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();     
           Assert.assertTrue(responseContent.contains("Successfully"), responseContent);
           Assert.assertTrue(responseContent.contains(getData("ConfigURL", "TenantID")), responseContent);
           Assert.assertTrue(responseContent.contains(getData("ConfigURL", "objectNameCC")), responseContent);
          
           System.out.println("=====End WSDL Upload duplicate schema=====");      
    }
	
	@Test(priority= 4)
    public void loadWSDLCompanyCodeIVT4() throws Exception {
     
		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_wsdl_NoImport.xml", "mdni_wsdl_NoImport.xml");
		
           System.out.println("=====Start WSDL Upload without importing schema in target namespace=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDL");
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();     
           Assert.assertTrue(responseContent.contains("INTERNAL_SERVER_ERROR"), responseContent);
    
           System.out.println("=====End WSDL Upload without importing schema in target namespace=====");      
    }
	
	@Test(priority= 5)
    public void loadWSDLCompanyCodeIVT5() throws Exception {

		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_wsdl_no_definition.xml", "mdni_wsdl_no_definition.xml");
		
           System.out.println("=====Start WSDL Upload without definition=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDL");
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_404, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();
           Assert.assertTrue(responseContent.isEmpty());
          
           System.out.println("=====End WSDL Upload without definition=====");      
    }
	
	@Test(priority= 6)
    public void loadWSDLCompanyCodeIVT6() throws Exception {
 
		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_wsdl_diffNameSpace.xml", "mdni_wsdl_diffNameSpace.xml");
		
           System.out.println("=====Start WSDL Upload with different namespace=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDL");
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();     
           Assert.assertTrue(responseContent.contains("INTERNAL_SERVER_ERROR"), responseContent);
          
           System.out.println("=====End WSDL Upload with different namespace=====");      
    }
	
	@Test(priority= 7)
    public void loadWSDLCompanyCodeIDIVT7() throws Exception {

  
		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_wsdl_oneImport.xml", "mdni_wsdl_oneImport.xml");
		
           System.out.println("=====Start WSDL Upload by importing one schema in target namespace=====");             
          
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDLID"); 
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();     
           Assert.assertTrue(responseContent.contains("INTERNAL_SERVER_ERROR"), responseContent);
          
           System.out.println("=====End WSDL Upload by importing one schema in target namespace=====");      
    }
	
	@Test(priority= 8)
    public void loadWSDLCompanyCodeIVT8() throws Exception {

  
		HttpEntity buildMultiPart = buildMultiPart("resources/multischema/mdni_wsdl_no_targetNamespace.xml", "mdni_wsdl_no_targetNamespace.xml");
		
           System.out.println("=====Start WSDL Upload with no target namespace=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "CCWSDL");
           RestResponse response = retrieveStatusFromAPI(URL,buildMultiPart);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();     
           Assert.assertTrue(responseContent.contains("INTERNAL_SERVER_ERROR"), responseContent);
          
           System.out.println("=====End WSDL Upload with no target namespace=====");      
    }

	
	@Test(priority= 9)
    public void payLoadCompanyCodeNoIDTest1() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeNoIDTest1");
           
           System.out.println("=====Start XML Payload=====");
           
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXML"); 
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), true, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 10)
    public void payLoadCompanyCodeNoIDTest2() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeNoIDTest2");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXML");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), true, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 11)
    public void payLoadCompanyCodeNoIDTest3() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeNoIDTest3");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXML");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), false, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 12)
    public void payLoadCompanyCodeNoIDTest4() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeNoIDTest4");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXML");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), false, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 13)
    public void payLoadCompanyCodeIDTest5() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeIDTest5");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXMLID");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), true, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 14)
    public void payLoadCompanyCodeIDTest6() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeIDTest6");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXMLID");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), true, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 15)
    public void payLoadCompanyCodeIDTest7() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeIDTest7");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXMLID");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), false, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 16)
    public void payLoadCompanyCodeIDTest8() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeIDTest8");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXMLID");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), false, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 17)
    public void payLoadCompanyCodeIDTest9() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeIDTest9");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXMLID");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), true, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
	@Test(priority= 18)
    public void payLoadCompanyCodeIDTest10() throws Exception {
          
           String CompanyCodeXML = getData("PayLoad","MSCompanyCodeIDTest10");
           
           System.out.println("=====Start XML Payload=====");             
            
           String URL = MDNIBASEURL+getData("ConfigURL", "UploadCCXMLID");
           HttpEntity entity = new StringEntity(CompanyCodeXML, HTTP.UTF_8);
           RestResponse response = retrieveStatusFromAPI(URL,entity);
           Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response Code is not same as Expected:");
           
           String responseContent = response.getContent();           
                      
           Assert.assertEquals(verifySuccessResponse(responseContent), false, "Response Message does not have JobId");
           
           Assert.assertNotNull(response, "Response is null");
          
           System.out.println("=====End XML Payload=====");
           
    }
	
 private RestResponse retrieveStatusFromAPI (String endPointURL,HttpEntity inputEntity)
                     {
                    
                     RestResponse response = null;
                    
                     try {
                     String userCredentials = "aribaws" + ":" + "aribaaribaariba";
                     String basicAuth = "Basic "+ new String(Base64.getEncoder().encode(userCredentials.getBytes()));
     
                     HttpRequests connection = new HttpRequests();
                    
                     response = connection.httpPost(endPointURL, basicAuth, inputEntity);
                    
                     } catch (Exception ioe) {
                     ioe.printStackTrace();
                    
                     }                    
                    
                     return response;
              }
 
 public boolean verifySuccessResponse (String response)
			 { 
				 
				 String[] vResponse = response.split( ":");
				 
				 boolean status = vResponse[0].contains("JobId");
				 
				 if(status)
					 return true;
				 else
					 return false;
			
			 }
 
 public String verifyWSDLResponse(String response, String resValue) {
	 
	 HashMap<String, String> responseData = new HashMap<String, String>();
	 
	 String[] splitRes = response.split(",");
	 
	 for(int i=0; i<splitRes.length;i++) {
		 
		 String[] fResponse = splitRes[i].split(":");
		 
		 String key = fResponse[0];
		 String value = fResponse[1]; 
		 
		 responseData.put(key, value);
		 
	 }
	 return responseData.get(resValue);
 }

public String getData(String sheetName, String dataType) throws InvalidFormatException, IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {                                       
        
        HashMap<String, String> masterData = new HashMap<String, String>();
       
        InputStream file = new FileInputStream("resources/multischema/MultiSchemaTestData.xlsx");
       
        XSSFWorkbook wb = new XSSFWorkbook(file);
        XSSFSheet sheet = wb.getSheet(sheetName);
        int rowCount = sheet.getLastRowNum();
            for(int i=1;i<=rowCount;i++) {     
                String key = sheet.getRow(i).getCell(0).getStringCellValue();
                String value = sheet.getRow(i).getCell(1).getStringCellValue();
                masterData.put(key, value);
                }
            //wb.close();
      return masterData.get(dataType);
    }

	
	

}
