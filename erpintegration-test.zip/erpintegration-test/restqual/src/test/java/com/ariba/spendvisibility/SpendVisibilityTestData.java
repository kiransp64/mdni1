package com.ariba.spendvisibility;

public class SpendVisibilityTestData {
    public static String purchasingGroup = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:ser=\"http://service.cxf/\">\n" +
            "   <soapenv:Header />\n" +
            "   <soapenv:Body>\n" +
            "      <n0:MaterialGroupMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS99EC7233576C6CB57CB4:752\">\n" +
            "         <MessageHeader>\n" +
            "            <ID>42F2E9AFC4EF1ED6AC984EC8769B06ED</ID>\n" +
            "            <UUID>42f2e9af-c4ef-1ed6-ac98-4ec8769b06ed</UUID>\n" +
            "            <CreationDateTime>2016-11-22T14:46:28.979Z</CreationDateTime>\n" +
            "            <SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>\n" +
            "         </MessageHeader>\n" +
            "         <ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>\n" +
            "         <TransmissionStartDateTime>2016-11-22T14:46:28.979Z</TransmissionStartDateTime>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>01</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"PL\">Grupa materiałowa 1</Description>\n" +
            "            <Description languageCode=\"ZF\">物料群組 1</Description>\n" +
            "            <Description languageCode=\"NL\">Goederengroep 1</Description>\n" +
            "            <Description languageCode=\"NO\">Varegruppe 1</Description>\n" +
            "            <Description languageCode=\"PT\">Grp.mercadorias 1</Description>\n" +
            "            <Description languageCode=\"SK\">Skupina materiálu 1</Description>\n" +
            "            <Description languageCode=\"RU\">Группа материалов 1</Description>\n" +
            "            <Description languageCode=\"ES\">Grupo de artículos 1</Description>\n" +
            "            <Description languageCode=\"TR\">Mal grubu 1</Description>\n" +
            "            <Description languageCode=\"FI\">Tavararyhmä 1</Description>\n" +
            "            <Description languageCode=\"SV\">Varugrupp 1</Description>\n" +
            "            <Description languageCode=\"BG\">Група материал 1</Description>\n" +
            "            <Description languageCode=\"LT\">1 medžiagų grupė</Description>\n" +
            "            <Description languageCode=\"LV\">1. materiālu grupa</Description>\n" +
            "            <Description languageCode=\"CA\">Grup mercaderies 1</Description>\n" +
            "            <Description languageCode=\"SH\">Grupa materijala 1</Description>\n" +
            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
            "            <Description languageCode=\"HI\">सामग्री समूह 1</Description>\n" +
            "            <Description languageCode=\"VI\">Nhóm vật tư 1</Description>\n" +
            "            <Description languageCode=\"ZH\">物料组1</Description>\n" +
            "            <Description languageCode=\"TH\">กลุ่มวัสดุ 1</Description>\n" +
            "            <Description languageCode=\"KO\">자재그룹 1</Description>\n" +
            "            <Description languageCode=\"RO\">Grup materiale 1</Description>\n" +
            "            <Description languageCode=\"SL\">Blagovna skupina 1</Description>\n" +
            "            <Description languageCode=\"HR\">Grupa materijala 1</Description>\n" +
            "            <Description languageCode=\"UK\">Група матеріалів 1</Description>\n" +
            "            <Description languageCode=\"ET\">Materjaligrupp 1</Description>\n" +
            "            <Description languageCode=\"AR\">مجموعة المواد 1</Description>\n" +
            "            <Description languageCode=\"HE\">קבוצת חומר 1</Description>\n" +
            "            <Description languageCode=\"DA\">Varegruppe 1</Description>\n" +
            "            <Description languageCode=\"JA\">品目グループ 1</Description>\n" +
            "            <Description languageCode=\"IT\">Gruppo merci 1</Description>\n" +
            "            <Description languageCode=\"HU\">1. anyagcsoport</Description>\n" +
            "            <Description languageCode=\"EL\">Ομάδα υλικών  1</Description>\n" +
            "            <Description languageCode=\"CS\">Skup.mater. 1</Description>\n" +
            "            <Description languageCode=\"DE\">Warengruppe 1</Description>\n" +
            "            <Description languageCode=\"FR\">Groupe marchand. 1</Description>\n" +
            "            <Description languageCode=\"EN\">Foods</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>01202</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
            "            <Description languageCode=\"EN\">Router</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>02</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"VI\">Nhóm vật tư 2</Description>\n" +
            "            <Description languageCode=\"HI\">सामग्री समूह 2</Description>\n" +
            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
            "            <Description languageCode=\"SH\">Grupa materijala 2</Description>\n" +
            "            <Description languageCode=\"CA\">Grup mercaderies 2</Description>\n" +
            "            <Description languageCode=\"LV\">2. materiālu grupa</Description>\n" +
            "            <Description languageCode=\"LT\">2 medžiagų grupė</Description>\n" +
            "            <Description languageCode=\"BG\">Група материал 2</Description>\n" +
            "            <Description languageCode=\"SV\">Varugrupp 2</Description>\n" +
            "            <Description languageCode=\"FI\">Tavararyhmä 2</Description>\n" +
            "            <Description languageCode=\"TR\">Mal grubu 2</Description>\n" +
            "            <Description languageCode=\"ES\">Grupo de artículos 2</Description>\n" +
            "            <Description languageCode=\"RU\">Группа материалов 2</Description>\n" +
            "            <Description languageCode=\"SK\">Skupina materiálu 2</Description>\n" +
            "            <Description languageCode=\"PT\">Grp.mercadorias 2</Description>\n" +
            "            <Description languageCode=\"NO\">Varegruppe 2</Description>\n" +
            "            <Description languageCode=\"NL\">Goederengroep 2</Description>\n" +
            "            <Description languageCode=\"ZF\">物料群組 2</Description>\n" +
            "            <Description languageCode=\"PL\">Grupa materiałowa 2</Description>\n" +
            "            <Description languageCode=\"ZH\">物料组 2</Description>\n" +
            "            <Description languageCode=\"TH\">กลุ่มวัสดุ 2</Description>\n" +
            "            <Description languageCode=\"KO\">자재그룹 2</Description>\n" +
            "            <Description languageCode=\"RO\">Grup materiale 2</Description>\n" +
            "            <Description languageCode=\"SL\">Blagovna skupina 2</Description>\n" +
            "            <Description languageCode=\"HR\">Grupa materijala 2</Description>\n" +
            "            <Description languageCode=\"UK\">Група матеріалів 2</Description>\n" +
            "            <Description languageCode=\"ET\">Materjaligrupp 2</Description>\n" +
            "            <Description languageCode=\"AR\">مجموعة المواد 2</Description>\n" +
            "            <Description languageCode=\"HE\">קבוצת חומר 2</Description>\n" +
            "            <Description languageCode=\"CS\">Skup.mater. 2</Description>\n" +
            "            <Description languageCode=\"DE\">Warengruppe 2</Description>\n" +
            "            <Description languageCode=\"EN\">Pharmaceuticals</Description>\n" +
            "            <Description languageCode=\"FR\">Groupe marchand. 2</Description>\n" +
            "            <Description languageCode=\"EL\">Ομάδα υλικών 2</Description>\n" +
            "            <Description languageCode=\"HU\">2. anyagcsoport</Description>\n" +
            "            <Description languageCode=\"IT\">Gruppo merci 2</Description>\n" +
            "            <Description languageCode=\"JA\">品目グループ 2</Description>\n" +
            "            <Description languageCode=\"DA\">Varegruppe 2</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>02001</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"EN\">Car</Description>\n" +
            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>ABAMGCH01</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"EN\">test conf hier</Description>\n" +
            "         </MaterialGroup>\n" +
            "      </n0:MaterialGroupMasterDataReplicationBundleRequest>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";

    public static String user ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:ser=\"http://service.cxf/\">\n" +
            "   <soapenv:Header />\n" +
            "   <soapenv:Body>\n" +
            "      <n0:UserMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ERW:/1SAI/TASD7E0953175F3927C64EA:751\">\n" +
            "         <MessageHeader>\n" +
            "            <ID>42F2E9AFC3DF1EE6ACA7831C60BCAEFF</ID>\n" +
            "            <UUID>42f2e9af-c3df-1ee6-aca7-831c60bcaeff</UUID>\n" +
            "            <CreationDateTime>2017-11-23T05:17:12.510Z</CreationDateTime>\n" +
            "            <SenderBusinessSystemID>ER9_500</SenderBusinessSystemID>\n" +
            "         </MessageHeader>\n" +
            "         <ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>\n" +
            "         <TransmissionStartDateTime>2017-11-23T05:17:12.510Z</TransmissionStartDateTime>\n" +
            "         <User>\n" +
            "            <ActionCode>01</ActionCode>\n" +
            "            <User>\n" +
            "               <UniqueName>USER00300</UniqueName>\n" +
            "               <PasswordAdapter>PasswordAdapter1</PasswordAdapter>\n" +
            "            </User>\n" +
            "            <Name languageCode=\"SL\">Stroški in tovor</Name>\n" +
            "            <Name languageCode=\"EN\">Stroski in tovor</Name>\n" +
            "            <PCardsList>2222222222000002,3333333333111111</PCardsList>\n" +
            "            <ShipTo>3000</ShipTo>\n" +
            "            <BillingAddress>3000</BillingAddress>\n" +
            "            <EmailAddress>abcd@sap.com</EmailAddress>\n" +
            "            <Phone>76543342373</Phone>\n" +
            "            <Fax>040-22707-101</Fax>\n" +
            "            <LocaleID>en_US</LocaleID>\n" +
            "            <TimezoneID>Asia/Katmandu</TimezoneID>\n" +
            "            <Supervisor>\n" +
            "               <UniqueName>cnoll</UniqueName>\n" +
            "               <PasswordAdapter>PasswordAdapter1</PasswordAdapter>\n" +
            "            </Supervisor>\n" +
            "            <Groups>\n" +
            "               <Group>\n" +
            "                  <GroupUniqueName>Expense Administrator</GroupUniqueName>\n" +
            "                  <ProcurementUnitUniqueName />\n" +
            "               </Group>\n" +
            "               <Group>\n" +
            "                  <GroupUniqueName>Budget Approver</GroupUniqueName>\n" +
            "                  <ProcurementUnitUniqueName>GBR01</ProcurementUnitUniqueName>\n" +
            "               </Group>\n" +
            "            </Groups>\n" +
            "            <CompanyCode>3000</CompanyCode>\n" +
            "            <CostCenter>\n" +
            "               <UniqueName>0000004120</UniqueName>\n" +
            "               <CompanyCode>3000</CompanyCode>\n" +
            "            </CostCenter>\n" +
            "            <GLAccount>\n" +
            "               <UniqueName>0000445000</UniqueName>\n" +
            "               <CompanyCode>3000</CompanyCode>\n" +
            "            </GLAccount>\n" +
            "            <Network>\n" +
            "               <UniqueName>test1</UniqueName>\n" +
            "               <CompanyCode />\n" +
            "            </Network>\n" +
            "            <PurchaseOrg>0001</PurchaseOrg>\n" +
            "            <PurchaseGroup>002</PurchaseGroup>\n" +
            "            <DeliverTo>ABC</DeliverTo>\n" +
            "            <InternalOrder>000000702133</InternalOrder>\n" +
            "            <WBSElement>L0002</WBSElement>\n" +
            "            <ProcurementUnit>GBR01</ProcurementUnit>\n" +
            "            <Account />\n" +
            "            <Asset>\n" +
            "               <UniqueName>000000003264</UniqueName>\n" +
            "               <CompanyCode>3000</CompanyCode>\n" +
            "               <SubNumber>0000</SubNumber>\n" +
            "            </Asset>\n" +
            "            <ActivityNumber>\n" +
            "               <UniqueName>tes1</UniqueName>\n" +
            "               <Network>\n" +
            "                  <UniqueName>Network001</UniqueName>\n" +
            "                  <CompanyCode>Company001</CompanyCode>\n" +
            "               </Network>\n" +
            "            </ActivityNumber>\n" +
            "            <SAPSerialNumber>SAPSerial1</SAPSerialNumber>\n" +
            "            <SAPLimitSplitValue>SAPLimitSplit1</SAPLimitSplitValue>\n" +
            "            <ApprovalLimit>10000</ApprovalLimit>\n" +
            "            <ExpenseApprovalLimit>10000</ExpenseApprovalLimit>\n" +
            "            <EmployeeSupplierID>EMPSUP1</EmployeeSupplierID>\n" +
            "            <Organization>[Buyer]</Organization>\n" +
            "            <DefaultCurrency>USD</DefaultCurrency>\n" +
            "            <LoginDate>2001-10-26T21:32:52</LoginDate>\n" +
            "            <LastLoginDate>2001-10-26T21:32:52</LastLoginDate>\n" +
            "            <PersistedAlternateEmailAddressesList>xyz@sap.com</PersistedAlternateEmailAddressesList>\n" +
            "         </User>\n" +
            "      </n0:UserMasterDataReplicationBulkRequest>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";

    public static String costCenter = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:ser=\"http://service.cxf/\">\n" +
            "   <soapenv:Header />\n" +
            "   <soapenv:Body>\n" +
            "      <n0:BNSCostCentreMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS3CD26C740073BF5A4D54:752\">\n" +
            "         <MessageHeader>\n" +
            "            <ID>42F2E9AFC5FF1ED6AFAC50B2FF9C4B98</ID>\n" +
            "            <UUID>42f2e9af-c5ff-1ed6-afac-50b2ff9c4b98</UUID>\n" +
            "            <CreationDateTime>2016-12-08T16:22:38Z</CreationDateTime>\n" +
            "            <SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>\n" +
            "            <RecipientBusinessSystemID>FIELDGLASS</RecipientBusinessSystemID>\n" +
            "         </MessageHeader>\n" +
            "         <CostCentreReplicationRequestMessage>\n" +
            "            <MessagerHeader />\n" +
            "            <TransmissionStartDateTime>2016-12-08T16:22:38Z</TransmissionStartDateTime>\n" +
            "            <CostCentre>\n" +
            "               <CurrencyKey>USD</CurrencyKey>\n" +
            "               <CostCentreKey>\n" +
            "                  <CompanyCode>ARCO</CompanyCode>\n" +
            "                  <CostCentre>@UniqueName</CostCentre>\n" +
            "               </CostCentreKey>\n" +
            "               <CostCentreName languageCode=\"EN\">D Center</CostCentreName>\n" +
            "            </CostCentre>\n" +
            "         </CostCentreReplicationRequestMessage>\n" +
            "      </n0:BNSCostCentreMasterDataReplicationBulkRequest>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";
    public static String glAccount ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">\n" +
            "   <soapenv:Header/>\n" +
            "   <soapenv:Body>\n" +
            "<n0:BNSGLAccountMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ERW:/1SAI/TASD7E0953175F3927C64EA:751\">\n" +
            "   <MessageHeader>\n" +
            "      <ID>FA163EB372321EE6AF8BF504266B553A</ID>\n" +
            "      <UUID>fa163eb3-7232-1ee6-af8b-f504266b553a</UUID>\n" +
            "      <CreationDateTime>2016-12-07T09:27:51Z</CreationDateTime>\n" +
            "      <SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>\n" +
            "      <RecipientBusinessSystemID>QE6CLNT910</RecipientBusinessSystemID>\n" +
            "   </MessageHeader>\n" +
            "   <GLAccountReplicationRequestMessage>\n" +
            "      <MessagerHeader />\n" +
            "      <TransmissionStartDateTime>2016-12-07T09:27:51Z</TransmissionStartDateTime>\n" +
            "      <GLAccount>\n" +
            "         <IsRelevantForProcurementIndicator>true</IsRelevantForProcurementIndicator>\n" +
            "         <GLAccountKey>\n" +
            "            <CompanyCode>ARCO</CompanyCode>\n" +
            "            <GLAccount>@UniqueName</GLAccount>\n" +
            "         </GLAccountKey>\n" +
            "         <GLAccountName languageCode=\"EN\">Input tax clearing - down payments on tang. assets</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"ZH\">进项税清算 - 有形资产的预付定金</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"TH\">การหักล้างภ/ษซื้อ-การชำระเงินดาวน์ในส/ทที่มีตัวตน</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"KO\">매입 부가가치세 반제 - 유형 자산에 대한 선금</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"RO\">Compensare TVA ded. - avansuri la imob.corp.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"SL\">Obračun predhodnega davka na predplačila za OOS</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"HR\">Obračun akontacije poreza - predujmi za mater.srd.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"UK\">Розрах.вхідного податку - аванси на матер.активи</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"ET\">Sisendkäibemaksu sidumine - mat. põhiv. ettemaksed</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"AR\">مقاصة ضريبة إدخال - دفعات مقدمة عن أصول مادية</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"HE\">התאמת מע\"מ תשומות - מקדמות על נכסים מוחשיים</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"CS\">Zúčtování vstupní DPH na zálohu pro hmotný IM</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"DE\">Vorsteuer-Verrechnung auf Anzahl. fuer Sachanlagen</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"FR\">Elimination TVA déductible sur acomptes imm. corp.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"EL\">Εκκαθ.φόρ.εισροών - προκαταβολές σε υλικά πάγια</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"HU\">Előzetesen felszám. ÁFA elszámolás előlegre TE-re</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"IT\">Comp. IVA acquisti su anticipi su immob. mat.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"JA\">仮払消費税消込 - 前払金 (固定資産)</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"DA\">Afregning af købsmoms på forudbet. på mat. anlAkt.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"PL\">Rozl. podat. nalicz. na zal. dla skł. akt. rzecz.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"ZF\">進項稅結清 - 有形資產訂金</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"NL\">Verrekening te vord. BTW op vooruitb. mat. activa</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"NO\">Avr. av inng. mva. ved forskudd på var. driftsmid.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"PT\">Compens.IVA suportado em adiant.p/bens materiais</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"SK\">Zúčtovanie vstupnej DPH na zálohu pre hmotný IM</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"RU\">Перерасчет пред. налога по авансам на мат. цен-ти</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"ES\">Compensación IVA soportado con anticipos AF mat.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"TR\">İndirilecek KDV mahsuplaştırması - MDV için pşnt.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"FI\">Selv: ALV/ostot, aineell.hyöd. ennakkomaksuista</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"SV\">Avräkn. ing.moms på förskott för matr. anl.tillg.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"BG\">Изчиставане на дакък покупки-Ав. плащ. по мат. акт</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"LT\">Pirkimo PVM sudeng. - išank.dal.mokėj. už mater.t.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"LV\">Priekšnodokļa klīrings - av. maks. par mater. ieg.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"CA\">Compens.IVA suportat sb.actes.p.actius fixos mat.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"SH\">Zatvaranje ulaznog poreza - akontacije za mat.sr.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"HI\">मनपुट कर समाशोधन - अमूर्त संपत्तियों पर तत्काल भु.</GLAccountName>\n" +
//            "         <GLAccountName languageCode=\"VI\">B.trừ thuế đvào - khoản t.tr vào t.s h.hình</GLAccountName>\n" +
            "      </GLAccount>\n" +
            "   </GLAccountReplicationRequestMessage>\n" +
            "</n0:BNSGLAccountMasterDataReplicationBulkRequest>\n" +
            "</soapenv:Body>\n" +
            "</soapenv:Envelope>\n";
    public static String itemMaster ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
            "   <SOAP-ENV:Header>\n" +
            "      <msgID:messageId xmlns:msgID=\"http://www.sap.com/webas/640/features/messageId/\">uuid:1cba9341-a7af-433c-9007-940696118482</msgID:messageId>\n" +
            "   </SOAP-ENV:Header>\n" +
            "   <SOAP-ENV:Body>\n" +
            "      <n0:ProductMDMBulkReplicateRequestMessage xmlns:n0=\"http://sap.com/xi/SAPGlobal20/Global\">\n" +
            "         <MessageHeader>\n" +
            "            <ID>aff7f92e20864e0b90b962bb46f34d90</ID>\n" +
            "            <UUID>aff7f92e-2086-4e0b-90b9-62bb46f34d90</UUID>\n" +
            "            <CreationDateTime>2019-11-12T06:48:02.874Z</CreationDateTime>\n" +
            "            <SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>\n" +
            "            <RecipientBusinessSystemID>QM7_930</RecipientBusinessSystemID>\n" +
            "         </MessageHeader>\n" +
            "         <ProductMDMReplicateRequestMessage>\n" +
            "            <MessageHeader>\n" +
            "               <ID>0751275ba77047c594ecde7962a0a7b0</ID>\n" +
            "               <UUID>0751275b-a770-47c5-94ec-de7962a0a7b0</UUID>\n" +
            "               <CreationDateTime>2019-11-12T10:18:33.635Z</CreationDateTime>\n" +
            "               <SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>\n" +
            "               <RecipientBusinessSystemID>QM7_930</RecipientBusinessSystemID>\n" +
            "            </MessageHeader>\n" +
            "            <Product changeOrdinalNumberValue=\"10\" descriptionListCompleteTransmissionIndicator=\"true\" globalTradeItemNumberListCompleteTransmissionIndicator=\"true\" plantIndependentProcurementSpecificationListCompleteTransmissionIndicator=\"true\" plantListCompleteTransmissionIndicator=\"true\" quantityCharacteristicListCompleteTransmissionIndicator=\"true\" quantityConversionListCompleteTransmissionIndicator=\"true\" reconciliationPeriodCounterValue=\"1\" salesSpecificationListCompleteTransmissionIndicator=\"true\">\n" +
            "               <ProductInternalID>@UniqueName</ProductInternalID>\n" +
            "               <ProductUUID>8ead0eed-4dc2-4e13-8115-da9b3bc83da6</ProductUUID>\n" +
            "               <ReceiverProductInternalID />\n" +
            "               <UnformattedReceiverProductInternalID />\n" +
            "                                                   <ReceiverProductUUID />\n" +
            "               <ProductTypeCode>FERT</ProductTypeCode>\n" +
            "               <IndustrySectorCode>M</IndustrySectorCode>\n" +
            "               <RetailProductCategoryCode>C1</RetailProductCategoryCode>\n" +
            "               <DeletedIndicator>false</DeletedIndicator>\n" +
            "               <ProductGroupInternalID>123</ProductGroupInternalID>\n" +
            "               <BaseMeasureUnitCode>EA</BaseMeasureUnitCode>\n" +
            "               <AuthorisationGroupCode />\n" +
            "               <ProductSalesProcessUsabilityProfileCode>P1</ProductSalesProcessUsabilityProfileCode>\n" +
            "               <DangerousGoodsIndicatorProfileCode />\n" +
            "               <Description actionCode=\"04\">\n" +
            "                  <Description languageCode=\"de\">Description in german update</Description>\n" +
            "               </Description>\n" +
            "               <Description actionCode=\"04\">\n" +
            "                  <Description languageCode=\"en\">Description of Product update</Description>\n" +
            "               </Description>\n" +
            "               <GlobalTradeItemNumber actionCode=\"04\">\n" +
            "                  <ProductStandardID>2174780000000</ProductStandardID>\n" +
            "                  <MeasureUnitCode>CT</MeasureUnitCode>\n" +
            "                  <ProductStandardMainIndicator>true</ProductStandardMainIndicator>\n" +
            "               </GlobalTradeItemNumber>\n" +
            "               <GlobalTradeItemNumber actionCode=\"04\">\n" +
            "                  <ProductStandardID>2174770000000</ProductStandardID>\n" +
            "                  <MeasureUnitCode>BG</MeasureUnitCode>\n" +
            "                  <ProductStandardMainIndicator>true</ProductStandardMainIndicator>\n" +
            "               </GlobalTradeItemNumber>\n" +
            "               <GlobalTradeItemNumber actionCode=\"04\">\n" +
            "                  <ProductStandardID>2174760000000</ProductStandardID>\n" +
            "                  <MeasureUnitCode>EA</MeasureUnitCode>\n" +
            "                  <ProductStandardMainIndicator>true</ProductStandardMainIndicator>\n" +
            "               </GlobalTradeItemNumber>\n" +
            "               <QuantityConversion actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">2</Quantity>\n" +
            "                  <CorrespondingQuantity unitCode=\"CT\">1</CorrespondingQuantity>\n" +
            "               </QuantityConversion>\n" +
            "               <QuantityConversion actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">5</Quantity>\n" +
            "                  <CorrespondingQuantity unitCode=\"BG\">1</CorrespondingQuantity>\n" +
            "               </QuantityConversion>\n" +
            "               <QuantityConversion actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                  <CorrespondingQuantity unitCode=\"EA\">1</CorrespondingQuantity>\n" +
            "               </QuantityConversion>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"CT\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"GRM\">1000.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>GROSS_WT</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"CT\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">15.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>WIDTH</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"CT\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">18.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>HEIGHT</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"CT\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">12.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>LENGTH</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"CT\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"CMQ\">18.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>VOLUME</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"BG\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"CMQ\">19.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>VOLUME</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"BG\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">16.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>WIDTH</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"BG\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"GRM\">1000.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>GROSS_WT</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"BG\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">19.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>HEIGHT</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"BG\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">13.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>LENGTH</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">11.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>LENGTH</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">17.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>HEIGHT</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"GRM\">11.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>GROSS_WT</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"GRM\">10.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>NET_WEIGHT</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"INH\">14.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>WIDTH</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <QuantityCharacteristic actionCode=\"04\">\n" +
            "                  <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                  <CharacteristicQuantity unitCode=\"CMQ\">17.000</CharacteristicQuantity>\n" +
            "                  <CharacteristicQuantityTypeCode>VOLUME</CharacteristicQuantityTypeCode>\n" +
            "               </QuantityCharacteristic>\n" +
            "               <TextCollection actionCode=\"04\">\n" +
            "                  <TextExistsIndicator>true</TextExistsIndicator>\n" +
            "                  <Text actionCode=\"04\">\n" +
            "                     <ID />\n" +
            "                     <TypeCode>IVER</TypeCode>\n" +
            "                     <LanguageCode>en</LanguageCode>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>1</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText />\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>2</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Text 1</SAPScriptLineText>\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>3</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Text 2</SAPScriptLineText>\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>4</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Text 3</SAPScriptLineText>\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>5</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText />\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>6</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Text 4</SAPScriptLineText>\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>7</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText />\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>8</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText />\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>9</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText />\n" +
            "                     </SAPScriptLine>\n" +
            "                     <SAPScriptLine actionCode=\"04\">\n" +
            "                        <OrdinalNumberValue>10</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText />\n" +
            "                     </SAPScriptLine>\n" +
            "                  </Text>\n" +
            "               </TextCollection>\n" +
            "               <DistributionChainIndependentSalesSpecification actionCode=\"04\">\n" +
            "                  <TransportProductGroupCode>01</TransportProductGroupCode>\n" +
            "               </DistributionChainIndependentSalesSpecification>\n" +
            "               <PlantIndependentProcurementSpecification actionCode=\"04\">\n" +
            "                  <ManufacturerID>0000103854</ManufacturerID>\n" +
            "                  <ProductManufacturerID>11111</ProductManufacturerID>\n" +
            "                  <OrderMeasureUnitCode>10</OrderMeasureUnitCode>\n" +
            "               </PlantIndependentProcurementSpecification>\n" +
            "               <SalesSpecification actionCode=\"04\">\n" +
            "                  <MinimumOrderQuantity>12.000</MinimumOrderQuantity>\n" +
            "                  <SalesOrganizationID>0001</SalesOrganizationID>\n" +
            "                  <DistributionChannelCode>01</DistributionChannelCode>\n" +
            "                  <CustomerTransactionDocumentItemProcessingTypeDeterminationProductGroupCode>NORM</CustomerTransactionDocumentItemProcessingTypeDeterminationProductGroupCode>\n" +
            "                  <SalesMeasureUnitCode>ST</SalesMeasureUnitCode>\n" +
            "                  <DeliveryNoteProcessingMinimumDeliveryQuantity>12.000</DeliveryNoteProcessingMinimumDeliveryQuantity>\n" +
            "                  <ProductSalesProcessUsabilityProfileCode>03</ProductSalesProcessUsabilityProfileCode>\n" +
            "                  <DeliveryQuantity unitCode=\"ST\">12.000</DeliveryQuantity>\n" +
            "                  <ProductSalesProcessUsabilityProfileValidityDate>1993-07-18</ProductSalesProcessUsabilityProfileValidityDate>\n" +
            "                  <SalesSpecificationText actionCode=\"04\">\n" +
            "                     <TypeCode>0001</TypeCode>\n" +
            "                     <LanguageCode>en</LanguageCode>\n" +
            "                     <SalesSpecificationTextSAPScriptLine>\n" +
            "                        <OrdinalNumberValue>1</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Sales text</SAPScriptLineText>\n" +
            "                     </SalesSpecificationTextSAPScriptLine>\n" +
            "                  </SalesSpecificationText>\n" +
            "                  <SalesSpecificationText actionCode=\"04\">\n" +
            "                     <TypeCode>0001</TypeCode>\n" +
            "                     <LanguageCode>af</LanguageCode>\n" +
            "                     <SalesSpecificationTextSAPScriptLine>\n" +
            "                        <OrdinalNumberValue>1</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Sales text afrikanaas</SAPScriptLineText>\n" +
            "                     </SalesSpecificationTextSAPScriptLine>\n" +
            "                  </SalesSpecificationText>\n" +
            "               </SalesSpecification>\n" +
            "               <SalesSpecification actionCode=\"04\">\n" +
            "                  <MinimumOrderQuantity>12.000</MinimumOrderQuantity>\n" +
            "                  <SalesOrganizationID>0003</SalesOrganizationID>\n" +
            "                  <DistributionChannelCode>01</DistributionChannelCode>\n" +
            "                  <CustomerTransactionDocumentItemProcessingTypeDeterminationProductGroupCode>NORM</CustomerTransactionDocumentItemProcessingTypeDeterminationProductGroupCode>\n" +
            "                  <SalesMeasureUnitCode>ST</SalesMeasureUnitCode>\n" +
            "                  <DeliveryNoteProcessingMinimumDeliveryQuantity>12.000</DeliveryNoteProcessingMinimumDeliveryQuantity>\n" +
            "                  <ProductSalesProcessUsabilityProfileCode>03</ProductSalesProcessUsabilityProfileCode>\n" +
            "                  <DeliveryQuantity unitCode=\"ST\">12.000</DeliveryQuantity>\n" +
            "                  <ProductSalesProcessUsabilityProfileValidityDate>1993-07-18</ProductSalesProcessUsabilityProfileValidityDate>\n" +
            "                  <SalesSpecificationText actionCode=\"04\">\n" +
            "                     <TypeCode>0001</TypeCode>\n" +
            "                     <LanguageCode>en</LanguageCode>\n" +
            "                     <SalesSpecificationTextSAPScriptLine>\n" +
            "                        <OrdinalNumberValue>1</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Sales text</SAPScriptLineText>\n" +
            "                     </SalesSpecificationTextSAPScriptLine>\n" +
            "                  </SalesSpecificationText>\n" +
            "                  <SalesSpecificationText actionCode=\"04\">\n" +
            "                     <TypeCode>0001</TypeCode>\n" +
            "                     <LanguageCode>af</LanguageCode>\n" +
            "                     <SalesSpecificationTextSAPScriptLine>\n" +
            "                        <OrdinalNumberValue>1</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Sales text afrikanaas</SAPScriptLineText>\n" +
            "                     </SalesSpecificationTextSAPScriptLine>\n" +
            "                  </SalesSpecificationText>\n" +
            "               </SalesSpecification>\n" +
            "               <SalesSpecification actionCode=\"04\">\n" +
            "                  <MinimumOrderQuantity>12.000</MinimumOrderQuantity>\n" +
            "                  <SalesOrganizationID>0001</SalesOrganizationID>\n" +
            "                  <DistributionChannelCode>10</DistributionChannelCode>\n" +
            "                  <CustomerTransactionDocumentItemProcessingTypeDeterminationProductGroupCode>NORM</CustomerTransactionDocumentItemProcessingTypeDeterminationProductGroupCode>\n" +
            "                  <SalesMeasureUnitCode>ST</SalesMeasureUnitCode>\n" +
            "                  <DeliveryNoteProcessingMinimumDeliveryQuantity>12.000</DeliveryNoteProcessingMinimumDeliveryQuantity>\n" +
            "                  <ProductSalesProcessUsabilityProfileCode>03</ProductSalesProcessUsabilityProfileCode>\n" +
            "                  <DeliveryQuantity unitCode=\"ST\">12.000</DeliveryQuantity>\n" +
            "                  <ProductSalesProcessUsabilityProfileValidityDate>1993-07-18</ProductSalesProcessUsabilityProfileValidityDate>\n" +
            "                  <SalesSpecificationText actionCode=\"04\">\n" +
            "                     <TypeCode>0001</TypeCode>\n" +
            "                     <LanguageCode>en</LanguageCode>\n" +
            "                     <SalesSpecificationTextSAPScriptLine>\n" +
            "                        <OrdinalNumberValue>1</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Sales text</SAPScriptLineText>\n" +
            "                     </SalesSpecificationTextSAPScriptLine>\n" +
            "                  </SalesSpecificationText>\n" +
            "                  <SalesSpecificationText actionCode=\"04\">\n" +
            "                     <TypeCode>0001</TypeCode>\n" +
            "                     <LanguageCode>af</LanguageCode>\n" +
            "                     <SalesSpecificationTextSAPScriptLine>\n" +
            "                        <OrdinalNumberValue>1</OrdinalNumberValue>\n" +
            "                        <SAPScriptLineFormatCode>*</SAPScriptLineFormatCode>\n" +
            "                        <SAPScriptLineText>Sales text afrikanaas</SAPScriptLineText>\n" +
            "                     </SalesSpecificationTextSAPScriptLine>\n" +
            "                  </SalesSpecificationText>\n" +
            "               </SalesSpecification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>MY</CountryCode>\n" +
            "                  <TaxTypeCode>MWST</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>ES</CountryCode>\n" +
            "                  <TaxTypeCode>MWST</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>HU</CountryCode>\n" +
            "                  <TaxTypeCode>MWST</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>DE</CountryCode>\n" +
            "                  <TaxTypeCode>MWST</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>CN</CountryCode>\n" +
            "                  <TaxTypeCode>Q000</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>JP</CountryCode>\n" +
            "                  <TaxTypeCode>Q000</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>IN</CountryCode>\n" +
            "                  <TaxTypeCode>JTX3</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>AU</CountryCode>\n" +
            "                  <TaxTypeCode>ATX1</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode />\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>IN</CountryCode>\n" +
            "                  <TaxTypeCode>JTX1</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>US</CountryCode>\n" +
            "                  <TaxTypeCode>UTXJ</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>IN</CountryCode>\n" +
            "                  <TaxTypeCode>JTX2</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>US</CountryCode>\n" +
            "                  <TaxTypeCode>ZSON</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>CZ</CountryCode>\n" +
            "                  <TaxTypeCode>MWST</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode>0</TaxRateTypeCode>\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <SalesSpecificTaxClassification actionCode=\"04\">\n" +
            "                  <CountryCode>CH</CountryCode>\n" +
            "                  <TaxTypeCode>ZSON</TaxTypeCode>\n" +
            "                  <TaxRateTypeCode />\n" +
            "               </SalesSpecificTaxClassification>\n" +
            "               <Plant actionCode=\"04\">\n" +
            "                  <PlantID>0001</PlantID>\n" +
            "                  <DeletedIndicator>false</DeletedIndicator>\n" +
            "               </Plant>\n" +
            "            </Product>\n" +
            "         </ProductMDMReplicateRequestMessage>\n" +
            "      </n0:ProductMDMBulkReplicateRequestMessage>\n" +
            "   </SOAP-ENV:Body>\n" +
            "</SOAP-ENV:Envelope>";
    public static String partitionedCommodityCode ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:ser=\"http://service.cxf/\">\n" +
            "   <soapenv:Header />\n" +
            "   <soapenv:Body>\n" +
            "      <n0:MaterialGroupMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS99EC7233576C6CB57CB4:752\">\n" +
            "         <MessageHeader>\n" +
            "            <ID>42F2E9AFC4EF1ED6AC984EC8769B06ED</ID>\n" +
            "            <UUID>42f2e9af-c4ef-1ed6-ac98-4ec8769b06ed</UUID>\n" +
            "            <CreationDateTime>2020-11-22T14:46:28.979Z</CreationDateTime>\n" +
            "            <SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>\n" +
            "         </MessageHeader>\n" +
            "         <ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>\n" +
            "         <TransmissionStartDateTime>2020-11-22T14:46:28.979Z</TransmissionStartDateTime>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>@UniqueName</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"EN\">Foods</Description>\n" +
//            "            <Description languageCode=\"PL\">Grupa materiałowa 1</Description>\n" +
//            "            <Description languageCode=\"ZF\">物料群組 1</Description>\n" +
//            "            <Description languageCode=\"NL\">Goederengroep 1</Description>\n" +
//            "            <Description languageCode=\"NO\">Varegruppe 1</Description>\n" +
//            "            <Description languageCode=\"PT\">Grp.mercadorias 1</Description>\n" +
//            "            <Description languageCode=\"SK\">Skupina materiálu 1</Description>\n" +
//            "            <Description languageCode=\"RU\">Группа материалов 1</Description>\n" +
//            "            <Description languageCode=\"ES\">Grupo de artículos 1</Description>\n" +
//            "            <Description languageCode=\"TR\">Mal grubu 1</Description>\n" +
//            "            <Description languageCode=\"FI\">Tavararyhmä 1</Description>\n" +
//            "            <Description languageCode=\"SV\">Varugrupp 1</Description>\n" +
//            "            <Description languageCode=\"BG\">Група материал 1</Description>\n" +
//            "            <Description languageCode=\"LT\">1 medžiagų grupė</Description>\n" +
//            "            <Description languageCode=\"LV\">1. materiālu grupa</Description>\n" +
//            "            <Description languageCode=\"CA\">Grup mercaderies 1</Description>\n" +
//            "            <Description languageCode=\"SH\">Grupa materijala 1</Description>\n" +
//            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
//            "            <Description languageCode=\"HI\">सामग्री समूह 1</Description>\n" +
//            "            <Description languageCode=\"VI\">Nhóm vật tư 1</Description>\n" +
//            "            <Description languageCode=\"ZH\">物料组1</Description>\n" +
//            "            <Description languageCode=\"TH\">กลุ่มวัสดุ 1</Description>\n" +
//            "            <Description languageCode=\"KO\">자재그룹 1</Description>\n" +
//            "            <Description languageCode=\"RO\">Grup materiale 1</Description>\n" +
//            "            <Description languageCode=\"SL\">Blagovna skupina 1</Description>\n" +
//            "            <Description languageCode=\"HR\">Grupa materijala 1</Description>\n" +
//            "            <Description languageCode=\"UK\">Група матеріалів 1</Description>\n" +
//            "            <Description languageCode=\"ET\">Materjaligrupp 1</Description>\n" +
//            "            <Description languageCode=\"AR\">مجموعة المواد 1</Description>\n" +
//            "            <Description languageCode=\"HE\">קבוצת חומר 1</Description>\n" +
//            "            <Description languageCode=\"DA\">Varegruppe 1</Description>\n" +
//            "            <Description languageCode=\"JA\">品目グループ 1</Description>\n" +
//            "            <Description languageCode=\"IT\">Gruppo merci 1</Description>\n" +
//            "            <Description languageCode=\"HU\">1. anyagcsoport</Description>\n" +
//            "            <Description languageCode=\"EL\">Ομάδα υλικών  1</Description>\n" +
//            "            <Description languageCode=\"CS\">Skup.mater. 1</Description>\n" +
//            "            <Description languageCode=\"DE\">Warengruppe 1</Description>\n" +
//            "            <Description languageCode=\"FR\">Groupe marchand. 1</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>01202</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
            "            <Description languageCode=\"EN\">Router</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>02</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"VI\">Nhóm vật tư 2</Description>\n" +
            "            <Description languageCode=\"HI\">सामग्री समूह 2</Description>\n" +
            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
            "            <Description languageCode=\"SH\">Grupa materijala 2</Description>\n" +
            "            <Description languageCode=\"CA\">Grup mercaderies 2</Description>\n" +
            "            <Description languageCode=\"LV\">2. materiālu grupa</Description>\n" +
            "            <Description languageCode=\"LT\">2 medžiagų grupė</Description>\n" +
            "            <Description languageCode=\"BG\">Група материал 2</Description>\n" +
            "            <Description languageCode=\"SV\">Varugrupp 2</Description>\n" +
            "            <Description languageCode=\"FI\">Tavararyhmä 2</Description>\n" +
            "            <Description languageCode=\"TR\">Mal grubu 2</Description>\n" +
            "            <Description languageCode=\"ES\">Grupo de artículos 2</Description>\n" +
            "            <Description languageCode=\"RU\">Группа материалов 2</Description>\n" +
            "            <Description languageCode=\"SK\">Skupina materiálu 2</Description>\n" +
            "            <Description languageCode=\"PT\">Grp.mercadorias 2</Description>\n" +
            "            <Description languageCode=\"NO\">Varegruppe 2</Description>\n" +
            "            <Description languageCode=\"NL\">Goederengroep 2</Description>\n" +
            "            <Description languageCode=\"ZF\">物料群組 2</Description>\n" +
            "            <Description languageCode=\"PL\">Grupa materiałowa 2</Description>\n" +
            "            <Description languageCode=\"ZH\">物料组 2</Description>\n" +
            "            <Description languageCode=\"TH\">กลุ่มวัสดุ 2</Description>\n" +
            "            <Description languageCode=\"KO\">자재그룹 2</Description>\n" +
            "            <Description languageCode=\"RO\">Grup materiale 2</Description>\n" +
            "            <Description languageCode=\"SL\">Blagovna skupina 2</Description>\n" +
            "            <Description languageCode=\"HR\">Grupa materijala 2</Description>\n" +
            "            <Description languageCode=\"UK\">Група матеріалів 2</Description>\n" +
            "            <Description languageCode=\"ET\">Materjaligrupp 2</Description>\n" +
            "            <Description languageCode=\"AR\">مجموعة المواد 2</Description>\n" +
            "            <Description languageCode=\"HE\">קבוצת חומר 2</Description>\n" +
            "            <Description languageCode=\"CS\">Skup.mater. 2</Description>\n" +
            "            <Description languageCode=\"DE\">Warengruppe 2</Description>\n" +
            "            <Description languageCode=\"EN\">Pharmaceuticals</Description>\n" +
            "            <Description languageCode=\"FR\">Groupe marchand. 2</Description>\n" +
            "            <Description languageCode=\"EL\">Ομάδα υλικών 2</Description>\n" +
            "            <Description languageCode=\"HU\">2. anyagcsoport</Description>\n" +
            "            <Description languageCode=\"IT\">Gruppo merci 2</Description>\n" +
            "            <Description languageCode=\"JA\">品目グループ 2</Description>\n" +
            "            <Description languageCode=\"DA\">Varegruppe 2</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>02001</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"EN\">Car</Description>\n" +
            "            <Description languageCode=\"LQ\">TADC ---T023T*+</Description>\n" +
            "         </MaterialGroup>\n" +
            "         <MaterialGroup>\n" +
            "            <Code>\n" +
            "               <content>ABAMGCH01</content>\n" +
            "            </Code>\n" +
            "            <Description languageCode=\"EN\">test conf hier</Description>\n" +
            "         </MaterialGroup>\n" +
            "      </n0:MaterialGroupMasterDataReplicationBundleRequest>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";
    public static String plant ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:ser=\"http://service.cxf/\">\n" +
            "   <soapenv:Header />\n" +
            "   <soapenv:Body>\n" +
            "      <n0:PlantMasterDataReplicationBundleRequest>\n" +
            "         <MessageHeader>\n" +
            "            <ID>8CDCD4000C701EE79C93F28F78225669</ID>\n" +
            "            <UUID>8cdcd400-0c70-1ee7-9c93-f28f78225669</UUID>\n" +
            "            <CreationDateTime>2021-08-24T18:40:34Z</CreationDateTime>\n" +
            "            <SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>\n" +
            "         </MessageHeader>\n" +
            "         <PlantReplicationRequestMessage>\n" +
            "            <ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>\n" +
            "            <TransmissionStartDateTime>2021-08-24T18:40:34Z</TransmissionStartDateTime>\n" +
            "            <Plant>\n" +
            "               <PlantID>@UniqueName</PlantID>\n" +
            "               <PlantName>Plant 2</PlantName>\n" +
            "               <PostalAddress>\n" +
            "                  <Street>bass ct</Street>\n" +
            "                  <HouseNumber>122</HouseNumber>\n" +
            "                  <City>Walldorf225</City>\n" +
            "                  <PostalCode>69191</PostalCode>\n" +
            "                  <Region>NY</Region>\n" +
            "                  <Country>MA</Country>\n" +
            "               </PostalAddress>\n" +
            "               <CompanyCode>0001</CompanyCode>\n" +
            "               <CurrencyCode>EUR</CurrencyCode>\n" +
            "            </Plant>\n" +
            "         </PlantReplicationRequestMessage>\n" +
            "      </n0:PlantMasterDataReplicationBundleRequest>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";
    public static String newItem="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
            "  <SOAP-ENV:Header>\n" +
            "     <msgID:messageId xmlns:msgID=\"http://www.sap.com/webas/640/features/messageId/\">uuid:1cba9341-a7af-433c-9007-940696118482</msgID:messageId>\n" +
            "  </SOAP-ENV:Header>\n" +
            "  <SOAP-ENV:Body>\n" +
            "  <ns3:ProductMDMBulkReplicateRequestMessage xmlns:ns3=\"http://sap.com/xi/SAPGlobal20/Global\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
            "   <MessageHeader>\n" +
            "       <ID>014f680502734ee282d3b95aebb4562a</ID>\n" +
            "       <UUID>014f6805-0273-4ee2-82d3-b95aebb4562a</UUID>\n" +
            "       <CreationDateTime>2021-02-28T03:20:18.467Z</CreationDateTime>\n" +
            "       <SenderBusinessSystemID>ERW_602</SenderBusinessSystemID>\n" +
            "       <RecipientBusinessSystemID>S4Hana1</RecipientBusinessSystemID>\n" +
            "   </MessageHeader>\n" +
            "        <ProductMDMReplicateRequestMessage>\n" +
            "                <MessageHeader>\n" +
            "                    <ID>08a8c21683654e259864be23b2df428c</ID>\n" +
            "                    <UUID>08a8c216-8365-4e25-9864-be23b2df428c</UUID>\n" +
            "                    <CreationDateTime>2021-02-28T03:20:12.753Z</CreationDateTime>\n" +
            "                    <SenderBusinessSystemID>ERW_602</SenderBusinessSystemID>\n" +
            "                    <RecipientBusinessSystemID>CIG_ENDPOINT_2</RecipientBusinessSystemID>\n" +
            "                </MessageHeader>\n" +
            "                <Product changeOrdinalNumberValue=\"1\" descriptionListCompleteTransmissionIndicator=\"true\" globalTradeItemNumberListCompleteTransmissionIndicator=\"true\" plantIndependentProcurementSpecificationListCompleteTransmissionIndicator=\"true\" plantListCompleteTransmissionIndicator=\"true\" quantityCharacteristicListCompleteTransmissionIndicator=\"true\" quantityConversionListCompleteTransmissionIndicator=\"true\" reconciliationPeriodCounterValue=\"1\" salesSpecificationListCompleteTransmissionIndicator=\"true\">\n" +
            "                    <ProductInternalID>TEST_MM_A02</ProductInternalID>\n" +
            "                    <ProductUUID>7dd7005d-e872-43f1-affd-1eb940bda275</ProductUUID>\n" +
            "                    <ReceiverProductInternalID />\n" +
            "                    <UnformattedReceiverProductInternalID />\n" +
            "                    <SourceBusinessSystemID>@UniqueName_02</SourceBusinessSystemID>\n" +
            "                    <ProductTypeCode>FERN</ProductTypeCode>\n" +
            "                    <IndustrySectorCode>M</IndustrySectorCode>\n" +
            "                    <RetailProductCategoryCode />\n" +
            "                    <DeletedIndicator>false</DeletedIndicator>\n" +
            "               <ProductGroupInternalID>123</ProductGroupInternalID>\n" +
            "                    <BaseMeasureUnitCode>EA</BaseMeasureUnitCode>\n" +
            "                    <AuthorisationGroupCode />\n" +
            "                    <ProductSalesProcessUsabilityProfileCode />\n" +
            "                    <DangerousGoodsIndicatorProfileCode />\n" +
            "                    <Description actionCode=\"04\">\n" +
            "                        <Description languageCode=\"en\">Test</Description>\n" +
            "                    </Description>\n" +
            "                    <QuantityConversion actionCode=\"04\">\n" +
            "                        <Quantity unitCode=\"EA\">1</Quantity>\n" +
            "                        <CorrespondingQuantity unitCode=\"EA\">1</CorrespondingQuantity>\n" +
            "                    </QuantityConversion>\n" +
            "                    <DistributionChainIndependentSalesSpecification actionCode=\"04\">\n" +
            "                        <TransportProductGroupCode />\n" +
            "                    </DistributionChainIndependentSalesSpecification>\n" +
            "                    <PlantIndependentProcurementSpecification actionCode=\"04\">\n" +
            "                        <ManufacturerID />\n" +
            "                        <ProductManufacturerID />\n" +
            "                    </PlantIndependentProcurementSpecification>\n" +
            "                    <Plant actionCode=\"04\">\n" +
            "                        <PlantID>0010</PlantID>\n" +
            "                        <DeletedIndicator>false</DeletedIndicator>\n" +
            "                    </Plant>\n" +
            "                    <Plant actionCode=\"04\">\n" +
            "                        <PlantID>0011</PlantID>\n" +
            "                        <DeletedIndicator>false</DeletedIndicator>\n" +
            "                    </Plant>\n" +
            "                </Product>\n" +
            "            </ProductMDMReplicateRequestMessage>\n" +
            "</ns3:ProductMDMBulkReplicateRequestMessage>\n" +
            "</SOAP-ENV:Body>\n" +
            "</SOAP-ENV:Envelope>";

}
