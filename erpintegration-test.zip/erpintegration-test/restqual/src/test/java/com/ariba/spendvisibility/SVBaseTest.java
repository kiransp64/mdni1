package com.ariba.spendvisibility;

import com.ariba.helpers.XmlHelper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.response.Response;
import org.testng.Assert;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

public class SVBaseTest {
    public void verifyGeneralLedgerFields(String xml, Response mdsSearchResponse)throws ParserConfigurationException, XPathExpressionException, IOException, SAXException {
        XmlHelper xmlHelper = new XmlHelper();
        String AccountId = xmlHelper.getValue(xml,"//GLAccountKey/GLAccount");
        String CompanyCode = xmlHelper.getValue(xml,"//GLAccountKey/CompanyCode");
        String AccountName = xmlHelper.getValue(xml,"//GLAccount/GLAccountName");

        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String AccountIdInResponse = jsonArray.get(0).getAsJsonObject().get("UniqueName").getAsString();
        String CompanyCodeInResponse = jsonArray.get(0).getAsJsonObject().get("CompanyCode").getAsString();
        String AccountNameInResponse = jsonArray.get(0).getAsJsonObject().get("GeneralLedgerDescription_en").getAsString();
        Assert.assertEquals(AccountIdInResponse,AccountId);
        Assert.assertEquals(CompanyCodeInResponse,CompanyCode);
        Assert.assertEquals(AccountNameInResponse,AccountName);
    }
    public void CostCenterFields(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String CostCenterId = xmlHelper.getValue(xml,"//CostCentreKey/CostCentre");
        String CompanyCode = xmlHelper.getValue(xml,"//CostCentreKey/CompanyCode");
        String CostCenterName = xmlHelper.getValue(xml,"//CostCentre/CostCentreName");

        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String CostCenterIdInResponse = jsonArray.get(0).getAsJsonObject().get("UniqueName").getAsString();
        String CompanyCodeInResponse = jsonArray.get(0).getAsJsonObject().get("CompanyCode").getAsString();
        String CostCenterNameInResponse = jsonArray.get(0).getAsJsonObject().get("CostCenterDescription_en").getAsString();

        Assert.assertEquals(CostCenterIdInResponse,CostCenterId);
        Assert.assertEquals(CompanyCodeInResponse,CompanyCode);
        Assert.assertEquals(CostCenterNameInResponse,CostCenterName);

    }
    void verifyPartitionedCommodityCodeFields(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String CommodityId = xmlHelper.getValue(xml,"//Code/content");
        String CommodityName = xmlHelper.getValue(xml,"//MaterialGroup/Description");
//        String CommodityType = xmlHelper.getValue(xml,"//User/User/UniqueName");

        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String CommodityIdInResponse = jsonArray.get(0).getAsJsonObject().get("UniqueName").getAsString();
        String CommodityNameInResponse = jsonArray.get(0).getAsJsonObject().get("Name_en").getAsString();

        Assert.assertEquals(CommodityIdInResponse,CommodityId);
        Assert.assertEquals(CommodityNameInResponse,CommodityName);

    }
    void verifyPlantFields(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String SiteId = xmlHelper.getValue(xml,"//PlantID");
        String SiteName = xmlHelper.getValue(xml,"//PlantName");
        String StreetAddress = xmlHelper.getValue(xml,"//PostalAddress/HouseNumber")+xmlHelper.getValue(xml,"//PostalAddress/Street");
        String City = xmlHelper.getValue(xml,"//PostalAddress/City");
        String State = xmlHelper.getValue(xml,"//PostalAddress/Region");
        String Country = xmlHelper.getValue(xml,"//PostalAddress/Country");
        String PostalCode = xmlHelper.getValue(xml,"//PostalAddress/PostalCode");
    }
    void verifyItemMasterFields(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String PartNumber = xmlHelper.getValue(xml,"//Product/ProductInternalID");
        String RevisionNumber = xmlHelper.getValue(xml,"//ProductGroupInternalID");
        String Description1 = xmlHelper.getValue(xml,"//Description/Description");
        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String partNumberInResponse = jsonArray.get(0).getAsJsonObject().getAsJsonArray("ItemMasterLangAssociation").get(0).getAsJsonObject().get("ItemMasterKey.ProductInternalID").getAsString();
        String RevisionNumberInResponse = jsonArray.get(0).getAsJsonObject().get("ProductGroupInternalID").getAsString();
        String Description1InResponse = jsonArray.get(0).getAsJsonObject().getAsJsonArray("ItemMasterLangAssociation").get(0).getAsJsonObject().get("Description").getAsString();
        Assert.assertEquals(partNumberInResponse,PartNumber);
        Assert.assertEquals(RevisionNumberInResponse,RevisionNumber);
        Assert.assertEquals(Description1InResponse,Description1);
    }

    public void verifyGeneralLedgerFieldsMM(String xml, Response mdsSearchResponse)throws ParserConfigurationException, XPathExpressionException, IOException, SAXException {
        XmlHelper xmlHelper = new XmlHelper();
        String AccountId = xmlHelper.getValue(xml,"//GLAccountKey/GLAccount");
        String CompanyCode = xmlHelper.getValue(xml,"//GLAccountKey/CompanyCode");
        String AccountName = xmlHelper.getValue(xml,"//GLAccount/GLAccountName");

        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String AccountIdInResponse = jsonArray.get(0).getAsJsonObject().get("GeneralLedgerKey.UniqueName").getAsString();
        String CompanyCodeInResponse = jsonArray.get(0).getAsJsonObject().get("GeneralLedgerKey.CompanyCode").getAsString();
//        String AccountNameInResponse = jsonArray.get(0).getAsJsonObject().get("GeneralLedgerDescription_en").getAsString();
        Assert.assertEquals(AccountIdInResponse,AccountId);
        Assert.assertEquals(CompanyCodeInResponse,CompanyCode);
//        Assert.assertEquals(AccountNameInResponse,AccountName);
    }
    public void CostCenterFieldsMM(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String CostCenterId = xmlHelper.getValue(xml,"//CostCentreKey/CostCentre");
        String CompanyCode = xmlHelper.getValue(xml,"//CostCentreKey/CompanyCode");
        String CostCenterName = xmlHelper.getValue(xml,"//CostCentre/CostCentreName");

        JsonObject jsonObject = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonObject();
        JsonArray jsonArray = jsonObject.get("value").getAsJsonArray();
        String CostCenterIdInResponse = jsonArray.get(0).getAsJsonObject().get("SAPCostCenterKey.UniqueName").getAsString();
        String CompanyCodeInResponse = jsonArray.get(0).getAsJsonObject().get("SAPCostCenterKey.CompanyCode").getAsString();
//        String CostCenterNameInResponse = jsonArray.get(0).getAsJsonObject().get("CostCenterDescription_en").getAsString();
//
        Assert.assertEquals(CostCenterIdInResponse,CostCenterId);
        Assert.assertEquals(CompanyCodeInResponse,CompanyCode);
//        Assert.assertEquals(CostCenterNameInResponse,CostCenterName);

    }
    void verifyPartitionedCommodityCodeFieldsMM(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String CommodityId = xmlHelper.getValue(xml,"//Code/content");
        String CommodityName = xmlHelper.getValue(xml,"//MaterialGroup/Description");
//        String CommodityType = xmlHelper.getValue(xml,"//User/User/UniqueName");

        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String CommodityIdInResponse = jsonArray.get(0).getAsJsonObject().get("PartitionedCommodityCodeKey.UniqueName").getAsString();
        String CommodityNameInResponse = jsonArray.get(0).getAsJsonObject().getAsJsonArray("PartitionedCommodityCodeLangAssociation").get(0).getAsJsonObject().get("Description").getAsString();

        Assert.assertEquals(CommodityIdInResponse,CommodityId);
        Assert.assertEquals(CommodityNameInResponse,CommodityName);

    }
    void verifyPlantFieldsMM(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String SiteId = xmlHelper.getValue(xml,"//PlantID");
        String SiteName = xmlHelper.getValue(xml,"//PlantName");
        String StreetAddress = xmlHelper.getValue(xml,"//PostalAddress/HouseNumber")+" "+xmlHelper.getValue(xml,"//PostalAddress/Street");
        String City = xmlHelper.getValue(xml,"//PostalAddress/City");
        String State = xmlHelper.getValue(xml,"//PostalAddress/Region");
        String Country = xmlHelper.getValue(xml,"//PostalAddress/Country");
        String PostalCode = xmlHelper.getValue(xml,"//PostalAddress/PostalCode");

        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String SiteIdInResponse = jsonArray.get(0).getAsJsonObject().get("CommonAddressKey.UniqueName").getAsString();
        String SiteNameInResponse = jsonArray.get(0).getAsJsonObject().get("BasicAddressFields.Name").getAsString();
        String StreetAddressInResponse = jsonArray.get(0).getAsJsonObject().get("BasicAddressFields.PostalAddress.Lines").getAsString();
        String CityInResponse = jsonArray.get(0).getAsJsonObject().get("BasicAddressFields.PostalAddress.City").getAsString();
        String StateInResponse = jsonArray.get(0).getAsJsonObject().get("BasicAddressFields.PostalAddress.State").getAsString();
        String CountryInResponse = jsonArray.get(0).getAsJsonObject().get("BasicAddressFields.PostalAddress.CountryKey.UniqueName").getAsString();
        String PostalCodeInResponse = jsonArray.get(0).getAsJsonObject().get("BasicAddressFields.PostalAddress.PostalCode").getAsString();

        Assert.assertEquals(SiteId,SiteIdInResponse,"Mismatch in PlantID");
        Assert.assertEquals(SiteName,SiteNameInResponse,"Mismatch in PlantName");
        Assert.assertEquals(StreetAddress,StreetAddressInResponse,"Mismatch in HouseNumber");
        Assert.assertEquals(City,CityInResponse,"Mismatch in City");
        Assert.assertEquals(State,StateInResponse,"Mismatch in Region");
        Assert.assertEquals(Country,CountryInResponse,"Mismatch in Country");
        Assert.assertEquals(PostalCode,PostalCodeInResponse,"Mismatch in PostalCode");


    }
    void verifyItemMasterFieldsMM(String xml, Response mdsSearchResponse) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        XmlHelper xmlHelper = new XmlHelper();
        String PartNumber = xmlHelper.getValue(xml,"//Product/ProductInternalID");
        String RevisionNumber = xmlHelper.getValue(xml,"//ProductGroupInternalID");
        String Description1 = xmlHelper.getValue(xml,"//Description/Description");
        JsonArray jsonArray = new JsonParser().parse(mdsSearchResponse.asString()).getAsJsonArray();
        String partNumberInResponse = jsonArray.get(0).getAsJsonObject().getAsJsonArray("ItemMasterLangAssociation").get(0).getAsJsonObject().get("ItemMasterKey.ProductInternalID").getAsString();
        String RevisionNumberInResponse = jsonArray.get(0).getAsJsonObject().get("ProductGroupInternalID").getAsString();
        String Description1InResponse = jsonArray.get(0).getAsJsonObject().getAsJsonArray("ItemMasterLangAssociation").get(0).getAsJsonObject().get("Description").getAsString();
        Assert.assertEquals(partNumberInResponse,PartNumber);
        Assert.assertEquals(RevisionNumberInResponse,RevisionNumber);
        Assert.assertEquals(Description1InResponse,Description1);
    }
}
