 
package com.ariba.mdnimultischema;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.httpcore.HttpRequests;

import com.ariba.pojos.RestResponse;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.protocol.HTTP;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.RandomStringUtils;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.Constants;
import com.ariba.helpers.MDSSearchHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.SCIMHelper;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TestERPMDNIService {	
	
	public static String MDNIBASEURL = "";
	public static String SAP_ANID = "AN71000004081";
	String endPointURL = "https://devfarm.cobalt.ariba.com/mdni/erpintegration/api/uploadXMLData?tenantId=" + SAP_ANID
            + "&objectName=";
	String integrationJobURL = "https://devfarm.cobalt.ariba.com/mdni/erpintegration/api/integrationJobs?tenantId=" + SAP_ANID
            + "&objectName=";
	
	OAuthHelper oauthHelper = new OAuthHelper();
	
	@BeforeSuite
	public void initializeURL() {
		MDNIBASEURL = System.getProperty("testurl");
	}
	
	
	@Test
	public void testIncotermsActionC0de01() throws Exception {
		
		String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode01");

		IncoTermBodyPayload = IncoTermBodyPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start IncoTerms Action 01=====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "Incoterms");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "Incoterms" + "&jobId=" + jobID);
		
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob.getContent());
		JsonObject jsonObject = json.getAsJsonObject();
		String jobStatus  = jsonObject.toString();
		System.out.println("Value is:"+jobStatus);
		
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 2, "NoOfRecordsUpdated is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,"NoOfRecordsInserted is not correct");

		
		System.out.println("=====End IncoTerms Action 01=====");
		
	}
	
	@Test
	public void testMDNIIncotermsWithActionCode02() throws Exception {
		
		String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode02");

		IncoTermBodyPayload = IncoTermBodyPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start IncoTerms Action 02=====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "Incoterms");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "Incoterms" + "&jobId=" + jobID);
		
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob.getContent());
		JsonObject jsonObject = json.getAsJsonObject();
		String jobStatus  = jsonObject.toString();
		System.out.println("Value is:"+jobStatus);
		
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 2, "NoOfRecordsUpdated is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,"NoOfRecordsInserted is not correct");

		
		System.out.println("=====End IncoTerms Action 02=====");
		
	}
	
	@Test
	public void testMDNIIncotermsWithNoActionCode() throws Exception {
		
		String IncoTermBodyPayload = getData("testMDNIIncotermsWithNoActionCode");

		IncoTermBodyPayload = IncoTermBodyPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start IncoTerms =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "Incoterms");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "Incoterms" + "&jobId=" + jobID);
		
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob.getContent());
		JsonObject jsonObject = json.getAsJsonObject();
		String jobStatus  = jsonObject.toString();
		System.out.println("Value is:"+jobStatus);
		
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 2, "NoOfRecordsUpdated is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 0,"NoOfRecordsInserted is not correct");

		
		System.out.println("=====End IncoTerms=====");
		
	}
	
	@Test
	public void testMDNIIncotermsWithActionCode03() throws Exception {
		
		String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode03");

		IncoTermBodyPayload = IncoTermBodyPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start IncoTerms Action 03=====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Incoterms", IncoTermBodyPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "Incoterms");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "Incoterms" + "&jobId=" + jobID);
		
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob.getContent());
		JsonObject jsonObject = json.getAsJsonObject();
		String jobStatus  = jsonObject.toString();
		System.out.println("Value is:"+jobStatus);
		
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsInserted == 0, "NoOfRecordsInserted is not correct");

		
		System.out.println("=====End IncoTerms Action 03=====");
		
	} 
	
	@Test
	public void testMDNIPurchaseGroupWithActionCode01() throws Exception {
		
		String PurchaseGroupPayload = getData("testMDNIPurchaseGroupWithActionCode01");

		PurchaseGroupPayload = PurchaseGroupPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start Purchase Group =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingGroup", PurchaseGroupPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "PurchasingGroup");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "PurchasingGroup" + "&jobId=" + jobID);
		
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob.getContent());
		JsonObject jsonObject = json.getAsJsonObject();
		String jobStatus  = jsonObject.toString();
		System.out.println("Value is:"+jobStatus);
		
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		
		if(NoOfRecordsInserted ==5 ) {
		Assert.assertTrue(NoOfRecordsInserted == 5, "NoOfRecordsInserted is not correct");
		}else {
			Assert.assertTrue(NoOfRecordsUpdated == 5, "NoOfRecordsUpdated is not correct");
			
		}
		
		System.out.println("=====End Purchase Group=====");
		
	}
	
	@Test
	public void testMDNICurrencyWithActionCode01() throws Exception {
		
		String CurrencyPayload = getData("testMDNICurrencyWithActionCode01");

		CurrencyPayload = CurrencyPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start Currency=====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Currency", CurrencyPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "Currency");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "Currency" + "&jobId=" + jobID);
		
				Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
	"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		System.out.println("=====End Currency=====");
		
	}
	
	@Test
	public void testMDNIPurchaseOrgWithActionCode01() throws Exception {
		
		String PurchasingOrgPayload = getData("testMDNIPurchaseOrgWithActionCode01");

		PurchasingOrgPayload = PurchasingOrgPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start Purchasing Org =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchasingOrg", PurchasingOrgPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "PurchasingOrg");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "PurchasingOrg" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());

		
		System.out.println("=====End Purchasing Org=====");
		
	}
	
	@Test
	public void testMDNIWBSElementWitoutActionCode() throws Exception {
		
		String WBSElementPayload = getData("testMDNIWBSElementWitoutActionCode");

		WBSElementPayload = WBSElementPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start WBSElement =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "WBSElement", WBSElementPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "WBSElement");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "WBSElement" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());

		
		System.out.println("=====End WBSElement=====");
		
	}
	
	@Test
	public void testMDNIMaterialCodeWithoutActionCode() throws Exception {
		
		String MaterialGroupPayload = getData("testMDNIMaterialCodeWithoutActionCode");

		MaterialGroupPayload = MaterialGroupPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start WBSElement =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "MaterialGroup", MaterialGroupPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "MaterialGroup");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "WBSElement" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End WBSElement=====");
		
	}
	
	
	@Test
	public void testMDNIGLAccountWithActionCode02() throws Exception {
		
		String GLAccountPayload = getData("testMDNIGLAccountWithActionCode02");

		GLAccountPayload = GLAccountPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start GLAccount =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "GLAccount", GLAccountPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "GLAccount");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "GLAccount" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End GLAccount=====");
		
	}
	
	@Test
	public void testMDNIInternalOrderWithoutActionCode() throws Exception {
		
		String InternalOrderPayload = getData("testMDNIInternalOrderWithoutActionCode");

		InternalOrderPayload = InternalOrderPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start InternalOrder =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "InternalOrder", InternalOrderPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "InternalOrder");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "InternalOrder" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End InternalOrder=====");
		
	}
	
	@Test
	public void testMDNICostCenterWithoutActionCode() throws Exception {
		
		String CostCentrePayload = getData("testMDNICostCenterWithoutActionCode");

		CostCentrePayload = CostCentrePayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start CostCentre =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "CostCentre", CostCentrePayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "CostCentre");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "CostCentre" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End CostCentre=====");
		
	}
	
	@Test
	public void testMDNIPlantPurchasingOrgWithActionCode01() throws Exception {
		
		String PlantPurchasingOrgPayload = getData("testMDNIPlantPurchasingOrgWithActionCode01");

		PlantPurchasingOrgPayload = PlantPurchasingOrgPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start PlantPurchasingOrgPayload =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PlantPurchasingOrg", PlantPurchasingOrgPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "PlantPurchasingOrg");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "PlantPurchasingOrg" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End PlantPurchasingOrgPayload=====");
		
	}
	
	@Test
	public void testMDNIPlantWithoutActionCode() throws Exception {
		
		String PlantPayload = getData("testMDNIPlantWithoutActionCode");

		PlantPayload = PlantPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start Plant =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", PlantPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "Plant");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "Plant" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End Plant=====");
		
	}
	
	@Test
	public void testMDNIPaymentMethodWithActionCode02() throws Exception {
		
		String PaymentMethodPayload = getData("testMDNIPaymentMethodWithActionCode02");

		PaymentMethodPayload = PaymentMethodPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start PaymentMethod =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PaymentMethod", PaymentMethodPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "PaymentMethod");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "PaymentMethod" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End PaymentMethod=====");
		
	}
	
	@Test
	public void testMDNIUnitOfMeasureWithoutActionCode() throws Exception {
		
		String UnitOfMeasurementPayload = getData("testMDNIUnitOfMeasureWithoutActionCode");

		UnitOfMeasurementPayload = UnitOfMeasurementPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start UnitOfMeasurement =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "UnitOfMeasurement", UnitOfMeasurementPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "UnitOfMeasurement");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "UnitOfMeasurement" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End UnitOfMeasurement =====");
		
	}
	
	@Test
	public void testMDNIFixedAssetWithActionCode01() throws Exception {
		
		String FixedAssetPayload = getData("testMDNIFixedAssetWithActionCode01");

		FixedAssetPayload = FixedAssetPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start FixedAsset =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "FixedAsset", FixedAssetPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "FixedAsset");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "FixedAsset" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End FixedAsset =====");
		
	}
	
	@Test
	public void testMDNIProcurementUnitWithActionCode02() throws Exception {
		
		String ProcurementUnitPayload = getData("testMDNIProcurementUnitWithActionCode02");

		ProcurementUnitPayload = ProcurementUnitPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start ProcurementUnit =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "ProcurementUnit", ProcurementUnitPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "ProcurementUnit");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "ProcurementUnit" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End ProcurementUnit =====");
		
	}
	
	@Test
	public void testMDNICompanyCodeWithoutActionCode() throws Exception {
		
		String CompanyCodePayload = getData("testMDNICompanyCodeWithoutActionCode");

		CompanyCodePayload = CompanyCodePayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start CompanyCode =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "CompanyCode", CompanyCodePayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "CompanyCode");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "CompanyCode" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End CompanyCode =====");
		
	}
	
	@Test
	public void testPlantWithPostOfficebox() throws Exception {
		
		String PlantPOPayload = getData("testPlantWithPostOfficebox");

		PlantPOPayload = PlantPOPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start Plant =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "Plant", PlantPOPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "Plant");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "Plant" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End Plant =====");
		
	}
	
	@Test
	public void testMDNIItemCategoryWithActionCode01() throws Exception {
		
		String PurchaseDocumentItemCategoryPayload = getData("testMDNIItemCategoryWithActionCode01");

		PurchaseDocumentItemCategoryPayload = PurchaseDocumentItemCategoryPayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start PurchaseDocumentItemCategory =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "PurchaseDocumentItemCategory", PurchaseDocumentItemCategoryPayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "PurchaseDocumentItemCategory");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "PurchaseDocumentItemCategory" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End PurchaseDocumentItemCategory =====");
		
	}
	
	@Test
	public void testMDNITaxCodeWithActionCode01() throws Exception {
		
		String TaxCodePayLoad = getData("testMDNITaxCodeWithActionCode01");

		TaxCodePayLoad = TaxCodePayLoad.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start TaxCode =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "TaxCode", TaxCodePayLoad);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "TaxCode");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "TaxCode" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End TaxCode =====");
	}
	
	@Test
	public void testMDNICurrencyConversionRateWithoutActionCode() throws Exception {
		
		String ExchangeRatePayload = getData("testMDNICurrencyConversionRateWithoutActionCode");

		ExchangeRatePayload = ExchangeRatePayload.replace("CRETIMEDATE", creationDateTime());
			
		System.out.println("=====Start ExchangeRate =====");
		
		RestResponse response = retrieveStatusFromAPI(endPointURL + "ExchangeRate", ExchangeRatePayload);
		
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response.getContent(), "ExchangeRate");
		
		Thread.sleep(100000);
		
		RestResponse responseIntegrationJob = getStatusAPI(integrationJobURL + "ExchangeRate" + "&jobId=" + jobID);
		
		Assert.assertEquals(responseIntegrationJob.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob.getCode());
		
		
		System.out.println("=====End ExchangeRate =====");
	}
	

	
	 private RestResponse retrieveStatusFromAPI (String endPointURL,HttpEntity inputEntity)
	                     {
	                    
	                     RestResponse response = null;
	                    
	                     try {
	                     String userCredentials = "aribaws" + ":" + "aribaaribaariba";
	                     String basicAuth = "Basic "+ new String(Base64.getEncoder().encode(userCredentials.getBytes()));
	     
	                     HttpRequests connection = new HttpRequests();
	                    
	                     response = connection.httpPost(endPointURL, basicAuth, inputEntity);
	                    
	                     } catch (Exception ioe) {
	                     ioe.printStackTrace();
	                    
	                     }                    
	                    
	                     return response;
	              }
	 
	 public boolean verifySuccessResponse (String response)
				 { 
					 
					 String[] vResponse = response.split( ":");
					 
					 boolean status = vResponse[0].contains("JobId");
					 
					 if(status)
						 return true;
					 else
						 return false;
				
				 }
	 
	 public String verifyWSDLResponse(String response, String resValue) {
		 
		 HashMap<String, String> responseData = new HashMap<String, String>();
		 
		 String[] splitRes = response.split(",");
		 
		 for(int i=0; i<splitRes.length;i++) {
			 
			 String[] fResponse = splitRes[i].split(":");
			 
			 String key = fResponse[0];
			 String value = fResponse[1]; 
			 
			 responseData.put(key, value);
			 
		 }
		 return responseData.get(resValue);
	 }
	
	
		private RestResponse retrieveStatusFromAPI(String endPointURL, String body) {
	
			RestResponse response = null;
	
			try {
				String userCredentials = "aribaws" + ":" + "aribaaribaariba";
				String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
				HttpRequests connection = new HttpRequests();
				response = connection.httpPost(endPointURL, basicAuth, body);
				// response = connection.httpPostWithCert(endPointURL, basicAuth,
				// body, sslSf);
			} catch (Exception ioe) {
				ioe.printStackTrace();
			}
	
			return response;
		}
		
		public String verifySuccessResponse(String response, String objectName) {
	
			String responsepattern = "JobId .*";
			Pattern pattern = Pattern.compile(responsepattern, Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(response);
			String jobID = response.replace("JobId ", "");
	
			if (jobID.contains("+")) {
				jobID = jobID.replace("+", "%2B");
			}
	
			boolean matches = matcher.matches();
			assertTrue("jobID does not match", matches == true);
	
			// Verify the status to be Processed
			int i = 0;
			try {
				for(i=0;i<=6;i++) {
	
					Thread.sleep(20000);
					
					if (!verifyStatusforJobID(jobID, objectName).equals("Pending Processing")) {
							i = 6;
					}
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
			
			
			return jobID;
	
		}
		
		private RestResponse getStatusAPI(String endPointURL) {
			RestResponse response = null;
	
			try {
				String userCredentials = "aribaws" + ":" + "aribaaribaariba";
				String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
				HttpRequests connection = new HttpRequests();
				response = connection.httpGet(endPointURL, null, basicAuth);
			} catch (Exception ioe) {
				ioe.printStackTrace();
			}
	
			return response;
		}
		
		
		private String verifyStatusforJobID(String jobID, String objectName) {
			RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + objectName + "&jobId=" + jobID);
			String responseIntegrationJob = responseIntegrationJob1.getContent();
			System.out.print("responseIntegrationJob : " + responseIntegrationJob + "\n");

			Assert.assertEquals(responseIntegrationJob1.getCode(), BaseHelper.HTTP_200,
					"Response message is not same Expected 200 and Actual " + responseIntegrationJob1.getCode());

			if (!responseIntegrationJob.equals("{}")) {
				JSONObject json = new JSONObject(responseIntegrationJob);
				String status = json.getString("Status");
				return status;
			}

			else {
				return "";
			}

		}

		
		
		public String getData(String dataType)
				throws InvalidFormatException, IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {
	
			HashMap<String, String> masterData = new HashMap<String, String>();
			String rootDir = System.getProperty("user.dir");
			String filename = "mdniPayload.xlsx";
			JSONArray entitiesArray = new JSONArray();
	
			InputStream file = new FileInputStream(rootDir + "/resources/mdnifiles/" + filename);
	
			// InputStream file = new
			// FileInputStream("/Users/i330270/Downloads/mdniPayload_MaterialMaster.xlsx");
			// File file = new File("/Users/i330270/Downloads/mdniPayload1.xlsx");
	
			XSSFWorkbook wb = new XSSFWorkbook(file);
			XSSFSheet sheet = wb.getSheet("PayLoad");
			int rowCount = sheet.getLastRowNum();
			for (int i = 1; i <= rowCount; i++) {
				String key = sheet.getRow(i).getCell(0).getStringCellValue();
				String value = sheet.getRow(i).getCell(1).getStringCellValue();
				masterData.put(key, value);
			}
			// wb.close();
			return masterData.get(dataType);
		}
		
		private String creationDateTime() {
			
			String dateTime = java.time.LocalDate.now().toString() +"T"+java.time.LocalTime.now().toString()+"Z";
			return dateTime;
		}

	
	

}
