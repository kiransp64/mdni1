package com.ariba.onemds;

public class Data {
    public static String createCostCenterPayload = "{\n" +
            "  \"changeRequests\": [\n" +
            "    {\n" +
            "      \"operation\": \"update\",\n" +
            "      \"changeToken\": \"0b21fad9-4f-4a61-8ba3-0618755ba0f5\",\n" +
            "      \"localIds\": [\n" +
            "        {\n" +
            "          \"context\": {\n" +
            "            \"application\": \"S/4Finance\",\n" +
            "            \"tenant\": \"us-tenant\",\n" +
            "            \"type\": \"sap.odm.finance.costobject.CostCenter\"\n" +
            "          },\n" +
            "          \"status\": \"active\",\n" +
            "          \"localId\": \"1710-0001\"\n" +
            "        }\n" +
            "      ],\n" +
            "      \"instance\": {\n" +
            "        \"displayName\": \"Automation new01 0001\",\n" +
            "        \"localIdS4\": {\n" +
            "          \"companyCode\": \"1720\",\n" +
            "          \"costCenterId\": \"1710-0001\",\n" +
            "          \"controllingArea\": \"US\"\n" +
            "        },\n" +
            "        \"attributes\": [\n" +
            "          {\n" +
            "            \"valid_from\": \"2001-01-02\",\n" +
            "            \"valid_to\": \"2001-01-03\",\n" +
            "            \"content\": {\n" +
            "              \"isBlockedForPrimaryPosting\": false,\n" +
            "              \"isBlockedForSecondaryPosting\": false,\n" +
            "              \"name\": [\n" +
            "                {\n" +
            "                  \"lang\": \"en\",\n" +
            "                  \"content\": \"My CostCenter\"\n" +
            "                },\n" +
            "                {\n" +
            "                  \"lang\": \"de\",\n" +
            "                  \"content\": \"Mein Kostensteller\"\n" +
            "                }\n" +
            "              ]\n" +
            "            }\n" +
            "          },\n" +
            "          {\n" +
            "            \"valid_from\": \"2001-01-03\",\n" +
            "            \"valid_to\": \"2001-02-03\",\n" +
            "            \"content\": {\n" +
            "              \"isBlockedForPrimaryPosting\": false,\n" +
            "              \"isBlockedForSecondaryPosting\": false,\n" +
            "              \"name\": [\n" +
            "                {\n" +
            "                  \"lang\": \"en\",\n" +
            "                  \"content\": \"My CostCenter\"\n" +
            "                }\n" +
            "              ]\n" +
            "            }\n" +
            "          }\n" +
            "        ]\n" +
            "      }\n" +
            "    }\n" +
            "  ]\n" +
            "}";
    public static String createCompanyCodePayload = "{\n" +
            "    \"changeRequests\": [\n" +
            "        {\n" +
            "            \"operation\": \"update\",\n" +
            "            \"changeToken\": \"ff2b033c-6015-4656-b141-63b7c431eaeb\",\n" +
            "            \"localIds\": [\n" +
            "                {\n" +
            "                    \"context\": {\n" +
            "                        \"application\": \"S/4Finance\",\n" +
            "                        \"tenant\": \"de-tenant\",\n" +
            "                        \"type\": \"sap.odm.orgunit.CompanyCode\"\n" +
            "                    },\n" +
            "                    \"status\": \"active\",\n" +
            "                    \"localId\": \"1010\"\n" +
            "                }\n" +
            "            ],\n" +
            "            \"instance\": {\n" +
            "                \"displayId\": \"1023\",\n" +
            "                \"name\": \"Germany New10 1022\",\n" +
            "                \"company\": \"SAP\"\n" +
            "            }\n" +
            "        }\n" +
            "    ]\n" +
            "}";
}
