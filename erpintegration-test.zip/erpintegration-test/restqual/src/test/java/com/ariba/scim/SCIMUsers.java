package com.ariba.scim;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.ariba.services.MDNI;
import io.restassured.response.Response;
//import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.Constants;
import com.ariba.helpers.MDSSearchHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.SCIMHelper;
import com.ariba.pojos.RestResponse;
import com.google.gson.JsonObject;
import org.testng.asserts.SoftAssert;

public class SCIMUsers extends BaseHelper {

	SCIMHelper scimHelper = new SCIMHelper();
	OAuthHelper oauthHelper = new OAuthHelper();
	MDSSearchHelper searchHelper = new MDSSearchHelper();

	public static String USERNAME = "testUser";
	public static String NAME_EN = "B Jensen";
	public static String NAME_JA = "アラブ首長国連邦";
	public static String NAME_ZH = "约翰·多伊";
	//	public static String TIMEZONE_AMERICA = "US/Pacific";
	public static String TIMEZONE_AMERICA = "America/Los_Angeles";
	public static String KEYS = "Phone,Fax,EmailAddress,PersistedAlternateEmailAddresses.Address,Supervisor.UniqueName,TimeZoneID,UniqueName,Name,this,LocaleID.UniqueName,UserUUID,PartitionNumber";
	public static String MANAGER_ADAVIS = "adavis";
	public static String EMAIL_WORK = "work@test.com";
	public static String EMAIL_HOME = "home@test.com";
	public static String EMAIL_OTHER = "other@test.com";
	public static String PHONE_WORK = "555-555-5555";
	public static String PHONE_FAX = "444-444-4444";
	public static String PHONE_OTHER = "333-333-3333";

	@Test
	public void createUserForSAP() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=zh_cn";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser_zh = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(user, hanaUser_zh, null, Constants.LANG_ZH);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithActiveFalse() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.FALSE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Inactive users cannot be created"),
				"Error message is not matching when trying to create user with Active as false");
	}

	@Test
	public void createUserAlreadyExists() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CONFLICT,
				"Response code is not matching for user creation with same payload");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Resource with given user already exists"),
				"Error message is not matching when creating user with same  uniquename");
	}

	@Test
	public void createUserWithBlankUniqueName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		String username = "";
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("User Name is mandatory"),
				"Error message is not matching when trying to create user with username as blank");
	}

	@Test
	public void createUserWithUniqueNameAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(JSONObject.NULL, names, Boolean.TRUE, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("User Name is mandatory"),
				"Error message is not matching when trying to create user with username as blank");
	}

	@Test
	public void createUserWithOutUniqueName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(null, names, Boolean.TRUE, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Missing required creator property 'userName'"),
				"Error message is not matching when trying to create user with username as blank");
	}

	@Test
	public void createUserWithActiveAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, JSONObject.NULL, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Active Flag is mandatory"),
				"Error message is not matching when trying to create user with username as blank");
	}

	@Test
	public void createUserWithOutActive() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, null, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Active Flag is mandatory"),
				"Error message is not matching when trying to create user with username as blank");
	}

	@Test
	public void createUserInvalidPayload() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);
		userPayload.remove(Constants.SCHEMAS);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Missing required creator property 'schemas'"),
				"Error message is not matching when trying to create user with username as blank");
	}

	@Test
	public void createUserInvalidOAuth() throws Exception {

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers("invalid", userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_UNAUTHORIZED,
				"Response code is not matching for user creation");
		Assert.assertEquals(result.getContent(), "Invalid OAuth token",
				"Error message is not matching when trying to create user with invalid oauth");
	}

	@Test
	public void createUserNullOAuth() throws Exception {

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);

		RestResponse result = scimHelper.postUsers(null, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_UNAUTHORIZED,
				"Response code is not matching for user creation");
		Assert.assertEquals(result.getContent(), "Invalid OAuth token",
				"Error message is not matching when trying to create user with invalid oauth");
	}

	@Test
	public void updateDisplayNameForUser() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateAlternativeDisplayNameForUser() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating user
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH + NAME_ZH);
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=" + Constants.LANG_ZH;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_ZH);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_ZH);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserRemoveAlternativeDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		names = new HashMap<String, Object>();
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);
		Assert.assertTrue(
				hanaUserUpdated.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
						.getString(Constants.HANA_LANG_LANG).equalsIgnoreCase(Constants.LANG_EN),
				"Removed locale is not removed from HANA");

		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=" + Constants.LANG_ZH;
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(), 200,"Response code is not matching");
		hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_ZH);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_ZH);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserMakeAlternativeDisplayNameNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, JSONObject.NULL);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);
		System.err.println(hanaUserUpdated);
		Assert.assertTrue(
				hanaUserUpdated.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
						.getString(Constants.NAME).equalsIgnoreCase(NAME_EN),
				"Removed locale is not removed from HANA");
	}

	@Test
	public void updateUserMakeAlternativeDisplayNameBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, "");
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);
		System.err.println(hanaUserUpdated);
		Assert.assertTrue(hanaUserUpdated.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
				.getString(Constants.NAME).equalsIgnoreCase(""), "Removed locale is not removed from HANA");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_JA);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithoutAlternativeDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, null, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);
		Assert.assertTrue(
				hanaUserUpdated.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
						.getString(Constants.NAME).equalsIgnoreCase(NAME_EN),
				"Removed locale is not removed from HANA");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertEquals(buyerUser.getString(Constants.NAME), NAME_EN, "Buyer Name is not matching");
	}

	@Test
	public void updateUserMakeInactive() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.FALSE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.FALSE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() == 0, "Found user as Active in buyer");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWhichDoesNotExists() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null, null,
				MANAGER_ADAVIS, null, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Resource with given user doesn't exist"),
				"Error message is not matching when updating user which doesnot exists");
	}

	@Test
	public void createUserWithDisplayNameAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, null, Boolean.TRUE, JSONObject.NULL,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.DISPLAYNAME, username);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithDisplayNameAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, null, Boolean.TRUE, "", Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.DISPLAYNAME, username);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithoutDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, null, Boolean.TRUE, null,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.DISPLAYNAME, username);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithAlternativeDisplayNameAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, JSONObject.NULL);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=" + Constants.LANG_JA;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		Assert.assertTrue(hanaUser.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
				.getString(Constants.NAME).equalsIgnoreCase(NAME_EN), "Removed locale is not removed from HANA");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LANG_JA);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertEquals(buyerUser.getString(Constants.NAME), NAME_EN,
				"Name is not matching when User is created with Altrernative display name as null");
	}

	@Test
	public void createUserWithDisplayNameAndAlternativeDisplayNameInEn() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_EN, NAME_EN + NAME_EN);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserAddDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, null,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserDisplayNameAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, JSONObject.NULL,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayloadUpdated);
		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		userUpdated.put(Constants.DISPLAYNAME, username);
		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithoutSendingDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, null,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayloadUpdated);
		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		userUpdated.put(Constants.DISPLAYNAME, username);
		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithBlankDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, "",
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayloadUpdated);
		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		userUpdated.put(Constants.DISPLAYNAME, username);
		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithLocaleNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, JSONObject.NULL,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		Thread.sleep(60000);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.LOCALE, Constants.LOCALE_EN_US);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithoutLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.LOCALE, Constants.LOCALE_EN_US);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithNonEnLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LANG_ZH,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithBlankLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, "",
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.LOCALE, Constants.LOCALE_EN_US);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithInvalidLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, "invalid",
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid locale"),
				"Error message is not valid when creating User with invalid locale");
	}

	@Test
	public void updateUserLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LANG_ZH,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserAddLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LANG_ZH,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserLocaleAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LANG_ZH,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, JSONObject.NULL,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.LOCALE, Constants.LOCALE_EN_US);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithoutSendingLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LANG_ZH,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, null, TIMEZONE_AMERICA,
				MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.LOCALE, Constants.LOCALE_EN_US);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithBlankLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LANG_ZH,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, "", TIMEZONE_AMERICA,
				MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.LOCALE, Constants.LOCALE_EN_US);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithInvalidLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LANG_ZH,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, "invalid",
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid locale"),
				"Error message is not valid when creating User with invalid locale");
	}

	@Test
	public void createUserWithTimezoneNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, JSONObject.NULL, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.TIMEZONE, TIMEZONE_AMERICA);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithoutTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, null, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.TIMEZONE, TIMEZONE_AMERICA);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithNonUsPacificTimeZone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithBlankTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, "", MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.TIMEZONE, TIMEZONE_AMERICA);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithInvalidTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, "invalid", MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid Timezone"),
				"Error message is not valid when creating User with invalid locale");
	}

	@Test
	public void updateUserTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserAddTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, null, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User locale
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserTimezoneAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User timezone
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				JSONObject.NULL, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.TIMEZONE, TIMEZONE_AMERICA);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithoutTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User timezone
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US, null,
				MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.TIMEZONE, TIMEZONE_AMERICA);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserTimezoneAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User timezone
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US, "",
				MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		user.put(Constants.TIMEZONE, TIMEZONE_AMERICA);
		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithInvalidTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User timezone
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				"invalid", MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Invalid Timezone"),
				"Error message is not valid when creating User with invalid locale");
	}

	@Test
	public void createUserWithSupervisorNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, JSONObject.NULL, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertFalse(hanaUser.has(Constants.HANA_SUPERVISOR_UNIQUENAME),
				"Supervisor key is present in HANA even when payload is not having supervisor");
	}

	@Test
	public void createUserWithoutSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, null, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertFalse(hanaUser.has(Constants.HANA_SUPERVISOR_UNIQUENAME),
				"Supervisor key is present in HANA even when payload is not having supervisor");
	}

	@Test
	public void createUserWithSupervisorBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "", emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		Assert.assertFalse(hanaUser.has(Constants.HANA_SUPERVISOR_UNIQUENAME),
				"Supervisor key is present in HANA even when payload is not having supervisor");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertEquals(buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY), "",
				"Supervisor is mapped to user in buyer even when payload is not having supervisor");
	}

	@Test
	public void createUserWithNonExistingSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "supervisor", null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Given supervisor doesn't exist"),
				"Error message is not matching when creating user with supervisor who doesnot exists");
	}

	@Test
	public void createUserWithInActiveSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user and making him inactive
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.FALSE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String supervisor = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(supervisor, "id is null for newly created user");
		Assert.assertEquals(supervisor, username, "Id in response payload is not same as username given");

		// Creating User with inactive supervisor
		uuid = UUID.randomUUID();
		username = USERNAME + uuid.toString();
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, supervisor, null, null, null);
		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Given supervisor doesn't exist"),
				"Error message is not matching when creating user with inactive supervisor");
	}

	@Test
	public void createUserWithSameUserAsSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, username, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Given supervisor doesn't exist"),
				"Error message is not matching when creating user with inactive supervisor");
	}

	@Test
	public void updateUserSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, "cnoll", emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserAddSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, null, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserSupervisorAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, JSONObject.NULL, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		Assert.assertFalse(hanaUser.has(Constants.HANA_SUPERVISOR_UNIQUENAME),
				"Supervisor key is present in HANA even when payload is not having supervisor");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertEquals(buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY), "",
				"Supervisor is mapped to user in buyer even when payload is not having supervisor");
	}

	@Test
	public void updateUserSupervisorAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, "", emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		Assert.assertFalse(hanaUser.has(Constants.HANA_SUPERVISOR_UNIQUENAME),
				"Supervisor key is present in HANA even when payload is not having supervisor");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertEquals(buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY), "",
				"Supervisor is mapped to user in buyer even when payload is not having supervisor");
	}

	@Test
	public void updateUserWithoutSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, null, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		Assert.assertFalse(hanaUser.has(Constants.HANA_SUPERVISOR_UNIQUENAME),
				"Supervisor key is present in HANA even when payload is not having supervisor");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertEquals(buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY), "",
				"Supervisor is mapped to user in buyer even when payload is not having supervisor");
	}

	@Test
	public void updateUserSupervisorAsSameUser() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, username, null, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Cyclic depedency detected on supervisor"),
				"Error message is not matching when creating user with inactive supervisor");
	}

	@Test
	public void updateUserWithNonExistingSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, "invalid", null, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Given supervisor doesn't exist"),
				"Error message is not matching when creating user with inactive supervisor");
	}

	@Test
	public void updateUserWithInActiveSupervisor() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user and making him inactive
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.FALSE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		System.err.println(userUpdated);
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String inactivesupervisor = userUpdated.getString(Constants.ID);

		// Creating User
		uuid = UUID.randomUUID();
		username = USERNAME + uuid.toString();
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User with inactive supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, inactivesupervisor, null, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Given supervisor doesn't exist"),
				"Error message is not matching when creating user with inactive supervisor");
	}

	@Test
	public void createUserWithNullEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, JSONObject.NULL);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
	}

	@Test
	public void createUserWithoutEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		if (hanaUser.has(Constants.HANA_EMAIL_KEY))
			Assert.assertTrue(hanaUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(""),
					"Email addess is not blank in HANA");
	}

	@Test
	public void createUserWithBlankInPrimaryEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, "");
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Email is not valid"),
				"Error message is not matching when trying to create user with blank primary email");
	}

	@Test
	public void createUserWithInvalidPrimaryEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, "invalid");
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Email is not valid - com.sap.scimono.entity.Email"),
				"Error message is not matching");
	}

	@Test
	public void createUserWithEmailOtherthanWorkAndHome() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		emails.put("other", "other@test.com");
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
		Assert.assertTrue(hanaUser.getJSONArray(Constants.HANA_PERSISTED_EMAIL_ADDRESS).length() == emails.size() - 1,
				"Email of type other is also added to HANA");
		Assert.assertTrue(buyerDataArray.length() == emails.size() - 1, "Email of type other is also added to Buyer");
	}

	@Test
	public void createUserWithNoPrimaryEmailButAlternativeEmail() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		if (hanaUser.has(Constants.HANA_EMAIL_KEY)) {
			Assert.assertTrue(hanaUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(""),
					"Email Address is not blank in HANA");
		}
		Assert.assertTrue(
				hanaUser.getJSONArray(Constants.HANA_PERSISTED_EMAIL_ADDRESS).getJSONObject(0)
						.getString("AlternateEmailAddressKey").equalsIgnoreCase(EMAIL_HOME),
				"Persisted email address is not matching in payload and HANA");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertTrue(buyerUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(""),
				"Email Address is not blank in HANA");
		Assert.assertTrue(buyerUser.getString(Constants.BUYER_PERSISTED_EMAIL_ADDRESS).equalsIgnoreCase(EMAIL_HOME),
				"Persisted email address is not matching in payload and buyer");
	}

	@Test
	public void updateUserEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_HOME);
		emails.put(Constants.HOME, EMAIL_WORK);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserAddEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserMakePrimaryEmailAddressNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User
		emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, JSONObject.NULL);
		emails.put(Constants.HOME, EMAIL_HOME);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
	}

	@Test
	public void updateUserWithoutPrimaryEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		emails = new HashMap<String, Object>();
		emails.put(Constants.HOME, EMAIL_HOME);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		if (hanaUser.has(Constants.HANA_EMAIL_KEY)) {
			Assert.assertTrue(hanaUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(""),
					"Email Address is not blank in HANA");
		}
		if (hanaUser.has(Constants.HANA_PERSISTED_EMAIL_ADDRESS)) {
			Assert.assertTrue(
					hanaUser.getJSONArray(Constants.HANA_PERSISTED_EMAIL_ADDRESS).getJSONObject(0)
							.getString("AlternateEmailAddressKey").equalsIgnoreCase(EMAIL_HOME),
					"Persisted email address is not matching in payload and HANA");
		}
		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertTrue(buyerUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(""),
				"Email Address is not blank in HANA");
		Assert.assertTrue(buyerUser.getString(Constants.BUYER_PERSISTED_EMAIL_ADDRESS).equalsIgnoreCase(EMAIL_HOME),
				"Persisted email address is not matching in payload and buyer");
	}

	@Test
	public void updateUserMakeNonPrimaryEmailAddressNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User Email to NULL
		emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, JSONObject.NULL);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
	}

	@Test
	public void updateUserWithoutNonPrimaryEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		Assert.assertTrue(hanaUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(EMAIL_WORK),
				"Email Address is not blank in HANA");
		Assert.assertFalse(hanaUser.has(Constants.HANA_PERSISTED_EMAIL_ADDRESS),
				"Persisted email address is not made as blank in HANA");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertTrue(buyerUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(EMAIL_WORK),
				"Email Address is not blank in HANA");
		Assert.assertTrue(buyerUser.getString(Constants.BUYER_PERSISTED_EMAIL_ADDRESS).equalsIgnoreCase(""),
				"Persisted email address is not made as blank in buyer");
	}

	@Test
	public void updateUserWithoutEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User supervisor
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		if (hanaUser.has(Constants.HANA_EMAIL_KEY)) {
			Assert.assertTrue(hanaUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(""),
					"Email Address is not blank in HANA");
		}
		Assert.assertTrue(
				hanaUser.getJSONArray(Constants.HANA_PERSISTED_EMAIL_ADDRESS).getJSONObject(0)
						.getString("AlternateEmailAddressKey").equalsIgnoreCase(""),
				"Persisted email address is not made as blank in HANA");

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);
		Assert.assertTrue(buyerUser.getString(Constants.HANA_EMAIL_KEY).equalsIgnoreCase(""),
				"Email Address is not blank in HANA");
		Assert.assertTrue(buyerUser.getString(Constants.BUYER_PERSISTED_EMAIL_ADDRESS).equalsIgnoreCase(""),
				"Persisted email address is not made as blank in buyer");
	}

	@Test
	public void createUserWithoutPhone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithPhoneAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, JSONObject.NULL);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Phone Number cannot be blank or null"),
				"Error message is not matching. Obtained message is " + error.getString("detail"));
	}

	@Test
	public void createUserWithoutFax() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithFaxAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, JSONObject.NULL);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Phone Number cannot be blank or null"),
				"Error message is not matching. Obtained message is " + error.getString("detail"));
	}

	@Test
	public void createUserWithPhoneAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, "");
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Phone Number cannot be blank or null"),
				"Error message is not as expected. Response is " + error.getString("detail"));
	}

	@Test
	public void createUserWithFaxAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, "");
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Phone Number cannot be blank or null"),
				"Error message is not as expected. Response is " + error.getString("detail"));
	}

	@Test
	public void createUserWithOtherPhoneNumbers() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put("other", PHONE_OTHER);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserWithoutPhoneAndFax() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserPhoneAndFax() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User phones
		phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_OTHER);
		phones.put(Constants.FAX, PHONE_OTHER);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserAddPhoneAndFax() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User phones
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserMakePhoneAndFaxAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User phones
		phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, JSONObject.NULL);
		phones.put(Constants.FAX, JSONObject.NULL);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Phone Number cannot be blank or null"),
				"Error message is not matching. Obtained message is " + error.getString("detail"));
	}

	@Test
	public void updateUserwithoutPhoneAndFax() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User phones
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithoutPhone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User phones
		phones = new HashMap<String, Object>();
		phones.put(Constants.FAX, PHONE_FAX);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithoutFax() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User phones
		phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserMakePhoneAndFaxAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating User phones
		phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, "");
		phones.put(Constants.FAX, "");
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, userId);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject error = new JSONObject(result.getContent());
		Assert.assertTrue(error.getString("detail").contains("Phone Number cannot be blank or null"),
				"Error message is not as expected. Response is " + error.getString("detail"));
	}

	@Test
	public void createAndUpdateUserForS4() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), S4_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to s4 db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, S4_ANID, Constants.LOCALE_EN_US);
		JSONArray s4DataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArrayUpdated);
		Assert.assertTrue(s4DataArrayUpdated.length() > 0, "User with uniquename " + username + " not found in s4");
		JSONObject s4UserUpdated = s4DataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, s4UserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserForSG() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SG_REALM, SG_USERNAME, SG_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SG_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SG_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserForPSOFT() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(PSOFT_REALM, PSOFT_USERNAME, PSOFT_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), PSOFT_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, PSOFT_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserForMERPParent() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(MERPPARENT_REALM, MERPPARENT_USERNAME, MERPPARENT_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), MERPPARENT_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, MERPPARENT_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserForMERPChild() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(MERPCHILD_REALM, MERPCHILD_USERNAME, MERPCHILD_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), MERPCHILD_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), MERPCHILD_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, MERPCHILD_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserForIntegrated() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), INTEGRATED_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), INTEGRATED_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for user updation. Response is " + result.getContent());
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, "s4");
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		Thread.sleep(60000);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, INTEGRATED_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		/* Making query to s4 db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		Thread.sleep(60000);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		JSONArray s4DataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArrayUpdated);
		Assert.assertTrue(s4DataArrayUpdated.length() > 0, "User with uniquename " + username + " not found in s4");
		JSONObject s4UserUpdated = s4DataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, s4UserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and S4. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserForMultiDestinations() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(MULTI_DESTINATION_REALM, MULTI_DESTINATION_USERNAME,
				MULTI_DESTINATION_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), MULTI_DESTINATION_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), MULTI_DESTINATION_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for user updation. Response is " + result.getContent());
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, MULTI_DESTINATION_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		/* Making query to s4 db */
		token = oauthHelper.getAccessToken(MULTI_DESTINATION_REALM, MULTI_DESTINATION_USERNAME, MULTI_DESTINATION_ANID,
				"s4");
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, MULTI_DESTINATION_ANID,
				Constants.LOCALE_EN_US);
		JSONArray s4DataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArrayUpdated);
		Assert.assertTrue(s4DataArrayUpdated.length() > 0, "User with uniquename " + username + " not found in s4");
		Assert.assertEquals(s4DataArrayUpdated.getJSONObject(0).getString(Constants.UNIQUENAME),
				buyerDataArrayUpdated.getJSONObject(0).getString(Constants.UNIQUENAME),
				"User UniqueName's in buyer and s4 realms are not matching");
		JSONObject s4UserUpdated = s4DataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, s4UserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Sourcing. Issues - " + issues);
	}

	private JSONArray comparePayloadsForUser(JSONObject userPayload, JSONObject hanaUser, JSONObject buyerUser,
											 String locale) {
		JSONArray issues = new JSONArray();
		Map<String, String> payloadMap = new HashMap<String, String>();
		payloadMap.put("UniqueName", "");
		payloadMap.put("Name", "");
		payloadMap.put("Active", "");
		payloadMap.put("Locale", "");
		payloadMap.put("TimeZone", "");
		payloadMap.put("Supervisor", "");
		payloadMap.put("Email", "");
		payloadMap.put("Phone", "");
		payloadMap.put("Fax", "");
		payloadMap.put("UserUUID", "");

		String id = userPayload.getString(Constants.ID);
		payloadMap.put("UniqueName", userPayload.getString(Constants.ID));

		String payloadUsername = userPayload.getString(Constants.USERNAME);
		boolean payloadActive = userPayload.getBoolean(Constants.ACTIVE);
		payloadMap.put("Locale", userPayload.getBoolean(Constants.ACTIVE) + "");
		String payloadName = "";
		if (locale == Constants.LANG_EN) {
			payloadName = userPayload.getString(Constants.DISPLAYNAME);
			payloadMap.put("Name", userPayload.getString(Constants.DISPLAYNAME));
		} else {
			JSONArray names = userPayload.getJSONObject(Constants.USERS_SCHEMA_PROFILE)
					.getJSONArray(Constants.ALTERNATIVE_DISPLAYNAME);
			for (int i = 0; i < names.length(); i++) {
				JSONObject name = names.getJSONObject(i);
				if (name.getString(Constants.LANGUAGE).equalsIgnoreCase(locale) && name.has(Constants.DISPLAYNAME)) {
					payloadName = name.getString(Constants.DISPLAYNAME);
					payloadMap.put("Name", name.getString(Constants.DISPLAYNAME));
				}
			}
		}

		String payloadLocale = "";
		if (userPayload.has(Constants.LOCALE)) {
			payloadLocale = userPayload.getString(Constants.LOCALE);
			payloadMap.put("Locale", userPayload.getString(Constants.LOCALE));
		}
		String payloadTimeZone = "";
		if (userPayload.has(Constants.TIMEZONE)) {
			payloadTimeZone = userPayload.getString(Constants.TIMEZONE);
			payloadMap.put("TimeZone", userPayload.getString(Constants.TIMEZONE));
		}
		String payloadSupervisor = userPayload.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE)
				.getJSONObject(Constants.MANAGER).getString(Constants.VALUE_KEY);
		payloadMap.put("Supervisor", userPayload.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE)
				.getJSONObject(Constants.MANAGER).getString(Constants.VALUE_KEY));

		String payloadEmail = "";
		if (userPayload.has(Constants.EMAIL_KEY)) {
			JSONArray emails = userPayload.getJSONArray(Constants.EMAIL_KEY);
			for (int i = 0; i < emails.length(); i++) {
				JSONObject email = emails.getJSONObject(i);
				if (email.getBoolean(Constants.PRIMARY) && email.has(Constants.VALUE_KEY)) {
					payloadEmail = email.getString(Constants.VALUE_KEY);
					payloadMap.put("Email", email.getString(Constants.VALUE_KEY));
				}
			}
		}
		String payloadPhone = "";
		String payloadFax = "";
		if (userPayload.has(Constants.PHONES_KEY)) {
			JSONArray phones = userPayload.getJSONArray(Constants.PHONES_KEY);
			for (int i = 0; i < phones.length(); i++) {
				JSONObject phone = phones.getJSONObject(i);
				if (phone.getString(Constants.TYPE).equalsIgnoreCase(Constants.WORK)
						&& phone.has(Constants.VALUE_KEY)) {
					payloadPhone = phone.getString(Constants.VALUE_KEY);
					payloadMap.put("Phone", phone.getString(Constants.VALUE_KEY));
				}
				if (phone.getString(Constants.TYPE).equalsIgnoreCase(Constants.FAX) && phone.has(Constants.VALUE_KEY)) {
					payloadFax = phone.getString(Constants.VALUE_KEY);
					payloadMap.put("Fax", phone.getString(Constants.VALUE_KEY));
				}
			}
		}
		String payloadUserUUID = "";
		if (userPayload.getJSONObject(Constants.USERS_SCHEMA_CUSTOM).has(Constants.USERUUID)) {
			payloadUserUUID = userPayload.getJSONObject(Constants.USERS_SCHEMA_CUSTOM).getString(Constants.USERUUID);
			payloadMap.put("UserUUID", payloadUserUUID);
		}

		// HANA comparisons if user from HANA is not null
		Map<String, String> hanaMap = null;
		if (hanaUser != null) {
			hanaMap = new HashMap<String, String>();
			hanaMap.put("UniqueName", "");
			hanaMap.put("Name", "");
			hanaMap.put("Active", "");
			hanaMap.put("Locale", "");
			hanaMap.put("TimeZone", "");
			hanaMap.put("Supervisor", "");
			hanaMap.put("Email", "");
			hanaMap.put("Phone", "");
			hanaMap.put("Fax", "");
			hanaMap.put("UserUUID", "");

			String hanaUsername = hanaUser.getString(Constants.HANA_USER_UNIQUENAME);
			hanaMap.put("UniqueName", hanaUser.getString(Constants.HANA_USER_UNIQUENAME));
			boolean hanaActive = Boolean.parseBoolean(hanaUser.getString(Constants.HANA_BASE_ACTIVE));
			hanaMap.put("Active", hanaUser.getString(Constants.HANA_BASE_ACTIVE));
			String hanaName = hanaUser.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.NAME);
			hanaMap.put("Name", hanaUser.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.NAME));
			String hanaNameLocale = hanaUser.getJSONArray(Constants.HANA_USER_LANG_ASSOCIATION).getJSONObject(0)
					.getString(Constants.HANA_LANG_LANG);
			String hanaLocale = "";
			if (hanaUser.has(Constants.HANA_LOCALE_KEY)) {
				hanaLocale = hanaUser.getString(Constants.HANA_LOCALE_KEY);
				hanaMap.put("Locale", hanaUser.getString(Constants.HANA_LOCALE_KEY));
			}
			String hanaTimeZone = "";
			if (hanaUser.has(Constants.HANA_TIMEZONE_KEY)) {
				hanaTimeZone = hanaUser.getString(Constants.HANA_TIMEZONE_KEY);
				hanaMap.put("TimeZone", hanaUser.getString(Constants.HANA_TIMEZONE_KEY));
			}
			String hanaSupervisor = hanaUser.getString(Constants.HANA_SUPERVISOR_UNIQUENAME);
			hanaMap.put("Supervisor", hanaUser.getString(Constants.HANA_SUPERVISOR_UNIQUENAME));
			String hanaEmail = "";
			if (hanaUser.has(Constants.HANA_EMAIL_KEY)) {
				hanaEmail = hanaUser.getString(Constants.HANA_EMAIL_KEY);
				hanaMap.put("Email", hanaUser.getString(Constants.HANA_EMAIL_KEY));
			}
			String hanaPhone = "";
			if (hanaUser.has(Constants.HANA_PHONE)) {
				hanaPhone = hanaUser.getString(Constants.HANA_PHONE);
				hanaMap.put("Phone", hanaUser.getString(Constants.HANA_PHONE));
			}
			String hanaFax = "";
			if (hanaUser.has(Constants.HANA_FAX)) {
				hanaFax = hanaUser.getString(Constants.HANA_FAX);
				hanaMap.put("Fax", hanaUser.getString(Constants.HANA_FAX));
			}
			String hanaUserUUID = "";
			if (hanaUser.has(Constants.HANA_USERUUID)) {
				hanaUserUUID = hanaUser.getString(Constants.HANA_USERUUID);
				hanaMap.put("UserUUID", hanaUserUUID);
			}

			if (!id.equalsIgnoreCase(hanaUsername)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.ID + "_HANA", "Payload id is not matching with HANA uniquename. Payload id=" + id
						+ " AND HANA username=" + hanaUsername);
				issues.put(issue);
			}
			if (!payloadUsername.equalsIgnoreCase(hanaUsername)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.USERNAME + "_HANA",
						"Payload Uniquename is not matching with HANA uniquename. Payload uniqueName=" + payloadUsername
								+ " AND HANA uniqueName=" + hanaUsername);
				issues.put(issue);
			}
			if (payloadActive != hanaActive) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.ACTIVE + "_HANA", "Payload active is not matching with HANA active. Payload active="
						+ payloadActive + " AND HANA active=" + hanaActive);
				issues.put(issue);
			}
			if (!payloadName.equalsIgnoreCase(hanaName)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.DISPLAYNAME + "_HANA", "Payload name is not matching with HANA name. Payload name="
						+ payloadName + " AND HANA name=" + hanaName);
				issues.put(issue);
			}
			if (!locale.equalsIgnoreCase(hanaNameLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LANGUAGE + "_HANA",
						"Payload nameLocale is not matching with HANA nameLocale. Payload nameLocale=" + locale
								+ " AND HANA nameLocale=" + hanaNameLocale);
				issues.put(issue);
			}
			if (!payloadLocale.equalsIgnoreCase(hanaLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LOCALE + "_HANA", "Payload locale is not matching with HANA locale. Payload Locale="
						+ payloadLocale + " AND HANA Locale=" + hanaLocale);
				issues.put(issue);
			}
			if (!payloadTimeZone.equalsIgnoreCase(hanaTimeZone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_HANA",
						"Payload timezone is not matching with HANA timezone. Payload TimeZone=" + payloadTimeZone
								+ " AND HANA TimeZone=" + hanaTimeZone);
				issues.put(issue);
			}
			if (!payloadSupervisor.equalsIgnoreCase(hanaSupervisor)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.MANAGER + "_HANA",
						"Payload Supervisor is not matching with HANA Supervisor. Payload Supervisor="
								+ payloadSupervisor + " AND HANA Supervisor=" + hanaSupervisor);
				issues.put(issue);
			}
			if (!payloadEmail.equalsIgnoreCase(hanaEmail)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.EMAIL_KEY + "_HANA",
						"Payload primary EmailAddress is not matching with HANA EmailAddress. Payload EmailAddress="
								+ payloadEmail + " AND HANA EmailAddress=" + hanaEmail);
				issues.put(issue);
			}
			if (!payloadPhone.equalsIgnoreCase(hanaPhone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.PHONES_KEY + "_HANA",
						"Payload Phone is not matching with HANA Phone. Payload Phone=" + payloadPhone
								+ " AND HANA Phone=" + hanaPhone);
				issues.put(issue);
			}
			if (!payloadFax.equalsIgnoreCase(hanaFax)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.HANA_FAX + "_HANA", "Payload Fax is not matching with HANA Fax. Payload Fax="
						+ payloadFax + " AND HANA Fax=" + hanaFax);
				issues.put(issue);
			}
			if (!payloadUserUUID.equalsIgnoreCase(hanaUserUUID)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.HANA_USERUUID + "_HANA",
						"Payload UserUUID is not matching with HANA UserUUID. Payload UserUuid=" + payloadUserUUID
								+ " AND HANA UserUUID=" + hanaUserUUID);
				issues.put(issue);
			}
		}

		// Buyer comparisons if user from buyer is not null
		Map<String, String> buyerMap = null;
		if (buyerUser != null) {
			buyerMap = new HashMap<String, String>();
			buyerMap.put("UniqueName", "");
			buyerMap.put("Name", "");
			buyerMap.put("Active", Boolean.TRUE + "");
			buyerMap.put("Locale", "");
			buyerMap.put("TimeZone", "");
			buyerMap.put("Supervisor", "");
			buyerMap.put("Email", "");
			buyerMap.put("Phone", "");
			buyerMap.put("Fax", "");
			buyerMap.put("UserUUID", "");

			String buyerUsername = buyerUser.getString(Constants.UNIQUENAME);
			buyerMap.put("UniqueName", buyerUser.getString(Constants.UNIQUENAME));

			String buyerName = buyerUser.getString(Constants.NAME);
			buyerMap.put("Name", buyerUser.getString(Constants.NAME));

			String buyerLocale = buyerUser.getString(Constants.BUYER_LOCALE_KEY);
			buyerMap.put("Locale", buyerUser.getString(Constants.BUYER_LOCALE_KEY));

			String buyerTimeZone = buyerUser.getString(Constants.HANA_TIMEZONE_KEY);
			buyerMap.put("TimeZone", buyerUser.getString(Constants.HANA_TIMEZONE_KEY));

			String buyerSupervisor = buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY);
			buyerMap.put("Supervisor", buyerUser.getString(Constants.BUYER_SUPERVISOR_KEY));

			String buyerEmail = buyerUser.getString(Constants.HANA_EMAIL_KEY);
			buyerMap.put("Email", buyerUser.getString(Constants.HANA_EMAIL_KEY));

			String buyerPhone = buyerUser.getString(Constants.HANA_PHONE);
			buyerMap.put("Phone", buyerUser.getString(Constants.HANA_PHONE));

			String buyerFax = buyerUser.getString(Constants.HANA_FAX);
			buyerMap.put("Fax", buyerUser.getString(Constants.HANA_FAX));

			String buyerUserUUID = buyerUser.getString(Constants.HANA_USERUUID);
			buyerMap.put("UserUUID", buyerUser.getString(Constants.HANA_USERUUID));

			if (!payloadUsername.equalsIgnoreCase(buyerUsername)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.USERNAME + "_" + Constants.APP,
						"Payload Uniquename is not matching with App (Buyer/Sourcing) uniquename. Payload uniqueName="
								+ payloadUsername + " AND Buyer/Sourcing UniqueName=" + buyerUsername);
				issues.put(issue);
			}
			if (!payloadName.equalsIgnoreCase(buyerName)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.DISPLAYNAME + "_" + Constants.APP,
						"Payload name is not matching with App (Buyer/Sourcing) name. Payload name=" + payloadName
								+ " AND Buyer/Sourcing name=" + buyerName);
				issues.put(issue);
			}
			if (!payloadLocale.equalsIgnoreCase(buyerLocale)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.LOCALE + "_" + Constants.APP,
						"Payload locale is not matching with App (Buyer/Sourcing) locale. Payload locale="
								+ payloadLocale + " AND Buyer/Sourcing locale=" + buyerLocale);
				issues.put(issue);
			}
			if (!payloadTimeZone.equalsIgnoreCase(buyerTimeZone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload TimeZone is not matching with App (Buyer/Sourcing) TimeZone. Payload TimeZone="
								+ payloadTimeZone + " AND Buyer/Sourcing TimeZone=" + buyerTimeZone);
				issues.put(issue);
			}
			if (!payloadSupervisor.equalsIgnoreCase(buyerSupervisor)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload TimeZone is not matching with App (Buyer/Sourcing) TimeZone. Payload TimeZone="
								+ payloadSupervisor + " AND Buyer/Sourcing TimeZone=" + buyerSupervisor);
				issues.put(issue);
			}
			if (!payloadEmail.equalsIgnoreCase(buyerEmail)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload primary Email is not matching with App (Buyer/Sourcing) Email. Payload Email="
								+ payloadEmail + " AND Buyer/Sourcing Email=" + buyerEmail);
				issues.put(issue);
			}
			if (!payloadPhone.equalsIgnoreCase(buyerPhone)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload Phone is not matching with App (Buyer/Sourcing) Phone. Payload Phone=" + payloadPhone
								+ " AND Buyer/Sourcing Phone=" + buyerPhone);
				issues.put(issue);
			}
			if (!payloadFax.equalsIgnoreCase(buyerFax)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.TIMEZONE + "_" + Constants.APP,
						"Payload Fax is not matching with App (Buyer/Sourcing)Fax. Payload Fax=" + payloadFax
								+ " AND Buyer/Sourcing Fax=" + buyerFax);
				issues.put(issue);
			}
			if (!payloadUserUUID.equalsIgnoreCase(buyerUserUUID)) {
				JSONObject issue = new JSONObject();
				issue.put(Constants.USERUUID + "_" + Constants.APP,
						"Payload UserUUID is not matching with App (Buyer/Sourcing) UserUUID. Payload UserUUID="
								+ payloadUserUUID + " AND Buyer/Sourcing UserUUID=" + buyerUserUUID);
				issues.put(issue);
			}
		}
		return issues;
	}

	@Test(invocationCount = 5, threadPoolSize = 5)
	public void createUsersConcurrently() throws Exception {
		long tnum = Thread.currentThread().getId();
		System.out.println("Current Thread ID -------------" + tnum);

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString() + tnum;
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println("POST CALL RESPONSE --------------" + user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");
	}

	@Test
	public void getUserResponseCompareWithCreateUser() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject cuser = (JSONObject) jsonObject(result.getContent());
		System.err.println(cuser);
		Assert.assertTrue(cuser.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + cuser);
		String userId = cuser.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		RestResponse getResult = scimHelper.getUsersByUserName(token, SAP_ANID, username, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject gUser = new JSONObject(getResult.getContent());
		System.err.println(gUser);
		JSONArray issues = verifyGetUserPayload(gUser, cuser);
		System.err.println(issues);
		Assert.assertTrue(issues.length() == 0,
				"Create user and get user responses are not matching. Issues - " + issues);
	}

	@Test
	public void getUserResponseCompareWithUpdatedUser() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");

		// Updating user
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		JSONObject cuser = (JSONObject) jsonObject(result.getContent());
		System.err.println(cuser);
		Assert.assertTrue(cuser.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + cuser);
		String userId = cuser.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		RestResponse getResult = scimHelper.getUsersByUserName(token, SAP_ANID, username, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject gUser = new JSONObject(getResult.getContent());

		JSONArray issues = verifyGetUserPayload(gUser, cuser);
		System.err.println(issues);
		Assert.assertTrue(issues.length() == 0,
				"Create user and get user responses are not matching. Issues - " + issues);
	}

	@Test
	public void getUsersWithoutParams() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, null, 1, 10);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		Assert.assertEquals(usersRes.getJSONArray(Constants.RESOURCES).length(), 10,
				"Default page size 10 is not matching");
		Assert.assertTrue(usersRes.has(Constants.TOTAL_RESULTS),
				Constants.TOTAL_RESULTS + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.ITEMS_PER_PAGE),
				Constants.ITEMS_PER_PAGE + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.START_INDEX),
				Constants.START_INDEX + " field is missing in Get Users response");
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 10, "Default page size 10 is not matching");
		Assert.assertEquals(usersRes.getInt(Constants.START_INDEX), 1, "Default Start Index 1 is not matching");
	}

	@Test
	public void getUsersWithStartIndexAndCount() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, null, 5, 20);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		Assert.assertEquals(usersRes.getJSONArray(Constants.RESOURCES).length(), 20, "page size 20 is not matching");
		Assert.assertTrue(usersRes.has(Constants.TOTAL_RESULTS),
				Constants.TOTAL_RESULTS + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.ITEMS_PER_PAGE),
				Constants.ITEMS_PER_PAGE + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.START_INDEX),
				Constants.START_INDEX + " field is missing in Get Users response");
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 20, "Items per page size is not matching");
		Assert.assertEquals(usersRes.getInt(Constants.START_INDEX), 5, "Start Index is not matching");
	}

	@Test
	public void getUsersPaginationWithoutFilters() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, null, 1, 10);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		Assert.assertEquals(usersRes.getJSONArray(Constants.RESOURCES).length(), 10, "page size 20 is not matching");
		Assert.assertTrue(usersRes.has(Constants.TOTAL_RESULTS),
				Constants.TOTAL_RESULTS + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.ITEMS_PER_PAGE),
				Constants.ITEMS_PER_PAGE + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.START_INDEX),
				Constants.START_INDEX + " field is missing in Get Users response");
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 10, "Items per page size is not matching");
		Assert.assertEquals(usersRes.getInt(Constants.START_INDEX), 1, "Start Index is not matching");
		String page1LastId = usersRes.getJSONArray(Constants.RESOURCES).getJSONObject(9).getString(Constants.ID);

		getResult = scimHelper.getUsers(token, SAP_ANID, null, 10, 10);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		usersRes = new JSONObject(getResult.getContent());
		Assert.assertEquals(usersRes.getJSONArray(Constants.RESOURCES).length(), 10, "page size 20 is not matching");
		String page2FirstId = usersRes.getJSONArray(Constants.RESOURCES).getJSONObject(0).getString(Constants.ID);
		Assert.assertEquals(page2FirstId, page1LastId, "Pagination is not working");
	}

	@Test
	public void getUsersPaginationWithFilters() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "manager.value eq \"adavis\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 10);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		Assert.assertEquals(usersRes.getJSONArray(Constants.RESOURCES).length(), 10, "page size 20 is not matching");
		Assert.assertTrue(usersRes.has(Constants.TOTAL_RESULTS),
				Constants.TOTAL_RESULTS + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.ITEMS_PER_PAGE),
				Constants.ITEMS_PER_PAGE + " field is missing in Get Users response");
		Assert.assertTrue(usersRes.has(Constants.START_INDEX),
				Constants.START_INDEX + " field is missing in Get Users response");
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 10, "Items per page size is not matching");
		Assert.assertEquals(usersRes.getInt(Constants.START_INDEX), 1, "Start Index is not matching");
		String page1LastId = usersRes.getJSONArray(Constants.RESOURCES).getJSONObject(9).getString(Constants.ID);

		getResult = scimHelper.getUsers(token, SAP_ANID, filter, 10, 10);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		usersRes = new JSONObject(getResult.getContent());
		Assert.assertEquals(usersRes.getJSONArray(Constants.RESOURCES).length(), 10, "page size 20 is not matching");
		String page2FirstId = usersRes.getJSONArray(Constants.RESOURCES).getJSONObject(0).getString(Constants.ID);
		Assert.assertEquals(page2FirstId, page1LastId, "Pagination is not working");
	}

	@Test
	public void getUsersWithFilterOnManager() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "manager.value eq \"adavis\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject gUser = new JSONObject(getResult.getContent());
			Assert.assertEquals(gUser.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE).getJSONObject(Constants.MANAGER)
					.getString(Constants.VALUE_KEY), "adavis", "Manager value is not matching");
		}
	}

	@Test
	public void getUsersWithFilterOnDisplayName() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "displayName eq \"" + NAME_EN + "\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 5, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject gUser = new JSONObject(getResult.getContent());
			Assert.assertEquals(gUser.getString(Constants.DISPLAYNAME), NAME_EN, "Displayname value is not matching");
		}
	}

	@Test
	public void getUsersWithFilterOnTimezone() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "timezone eq \"" + TIMEZONE_AMERICA + "\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject gUser = new JSONObject(getResult.getContent());
			Assert.assertEquals(gUser.getString(Constants.TIMEZONE), TIMEZONE_AMERICA,
					"Timezone value is not matching");
		}
	}

	@Test
	public void getUsersWithFilterOnLocale() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "locale eq \"" + Constants.LOCALE_EN_US + "\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject gUser = new JSONObject(getResult.getContent());
			Assert.assertEquals(gUser.getString(Constants.LOCALE), Constants.LOCALE_EN_US,
					"locale value is not matching");
		}
	}

	@Test
	public void getUsersWithFilterOnUsername() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "userName eq \"" + MANAGER_ADAVIS + "\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 1, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject gUser = new JSONObject(getResult.getContent());
			Assert.assertEquals(gUser.getString(Constants.USERNAME), MANAGER_ADAVIS, "Username value is not matching");
		}
	}

	@Test
	public void getUsersWithFilterOnId() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "id eq \"" + MANAGER_ADAVIS + "\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 1, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject gUser = new JSONObject(getResult.getContent());
			Assert.assertEquals(gUser.getString(Constants.ID), MANAGER_ADAVIS, "ID value is not matching");
		}
	}

	@Test
	public void getUsersWithFilterOnActiveTrue() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "active eq true";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject gUser = new JSONObject(getResult.getContent());
			Assert.assertEquals(gUser.getBoolean(Constants.ACTIVE), true, "Active value is not matching");
		}
	}

	@Test
	public void getUsersWithFilterOnActiveFalse() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "active eq false";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		Assert.assertTrue(getResult.getContent().contains("\"totalResults\":0"),"Expected mgs : "+"\"totalResults\":0"+" but found "+getResult.getContent());
	}

	@Test
	public void getUsersWithFilterOnEmail() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "emails.value eq \"" + EMAIL_WORK + "\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 15);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 15, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains(EMAIL_WORK),
					"Email value is not present for this User " + users.getJSONObject(i).getString(Constants.ID));
		}
	}

	@Test
	public void getUsersWithFilterOnAlternativeDisplayNames() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "alternativeDisplayNames.displayName eq \"" + NAME_JA + "\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 12);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 12, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains(NAME_JA),
					"Alternative displayname in ja value is not present for this User "
							+ users.getJSONObject(i).getString(Constants.ID));
		}
	}

	@Test
	public void getUsersWithFilterOnAlternativeDisplayNamesLang() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "alternativeDisplayNames.language eq \"ja\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 12);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 12, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			Assert.assertTrue(getResult.getContent().contains("ja"),
					"Alternative displayname language in ja is not present for this User "
							+ users.getJSONObject(i).getString(Constants.ID));
		}
	}

	@Test
	public void getUsersWithAndFilterOnAlternativeDisplayNames() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Getting user details
		String filter = "alternativeDisplayNames.displayName eq \"" + NAME_JA
				+ "\" and alternativeDisplayNames.language eq \"ja\"";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 12);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject usersRes = new JSONObject(getResult.getContent());
		JSONArray users = usersRes.getJSONArray(Constants.RESOURCES);
		Assert.assertEquals(usersRes.getInt(Constants.ITEMS_PER_PAGE), 12, "Items per page size is not matching");
		for (int i = 0; i < users.length(); i++) {
			getResult = scimHelper.getUsersByUserName(token, SAP_ANID, users.getJSONObject(i).getString(Constants.ID),
					null);
			Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK,
					"Status code is not matching for get users call");
			JSONObject user = new JSONObject(getResult.getContent());
			JSONArray names = user.getJSONObject(Constants.USERS_SCHEMA_PROFILE)
					.getJSONArray(Constants.ALTERNATIVE_DISPLAYNAME);
			String name = "";
			for (int j = 0; j < names.length(); j++) {
				if (names.getJSONObject(j).getString(Constants.LANGUAGE).equalsIgnoreCase("ja"))
					name = names.getJSONObject(j).getString(Constants.DISPLAYNAME);
			}
			Assert.assertEquals(name, NAME_JA, "JA language Name is not matching");
		}
	}

	@Test
	public void getUsersWithInvalidUsername() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		RestResponse getResult = scimHelper.getUsersByUserName(token, SAP_ANID, "invalid", null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Status code is not matching for get users call");
		System.err.println(getResult.getContent());
		Assert.assertEquals(getResult.getContent(), "{\"status\":404,\"detail\":\"Resource with given user doesn't exist\",\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:Error\"]}",
				"Error message is not matching when invalid user is searched");
	}

	@Test
	public void getUsersWithInvalidANID() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		RestResponse getResult = scimHelper.getUsersByUserName(token, "invalid", MANAGER_ADAVIS, null);
		System.err.println(getResult.getContent());
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Status code is not matching for get users call");
	}

	@Test
	public void getUserWithoutEmailAddress() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		RestResponse getResult = scimHelper.getUsersByUserName(token, SAP_ANID, userId, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject guser = new JSONObject(getResult.getContent());
		Assert.assertEquals(guser.getString(Constants.ID), userId,
				"User retrieved through Get is not as given in URL param");
	}

	@Test
	public void createUserWithUserUuidForSAP() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=zh_cn";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser_zh = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(user, hanaUser_zh, null, Constants.LANG_ZH);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createUserAlreadyExistsWithUUID() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, uuid.toString());

		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CONFLICT,
				"Response code is not matching for user creation with same payload");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("Resource with given user already exists"),
				"Error message is not matching when creating user with same  uniquename");
	}

	@Test
	public void createUserWithUUIDAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, JSONObject.NULL);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");
	}

	@Test
	public void createUserWithUUIDAsBlankl() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, "");
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("userUUID needs to meet RFC 4122 format for - "),
				"Error message is not matching when trying to create user with useruuid value as blank");
	}

	@Test
	public void createUserWithUUIDAsInvalidl() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, null, null, "Invalid");
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user creation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("userUUID needs to meet RFC 4122 format for - Invalid"),
				"Error message is not matching when trying to create user with useruuid value as blank");
	}

	@Test
	public void createAndUpdateUserWithUuidForIntegrated() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), INTEGRATED_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		uuid = UUID.randomUUID();
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), INTEGRATED_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK,
				"Response code is not matching for user updation. Response is " + result.getContent());
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, "s4");
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, INTEGRATED_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		/* Making query to s4 db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		Thread.sleep(60000);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		JSONArray s4DataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArrayUpdated);
		Assert.assertTrue(s4DataArrayUpdated.length() > 0, "User with uniquename " + username + " not found in s4");
		JSONObject s4UserUpdated = s4DataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, s4UserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and S4. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserWithUuidForMERPChild() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(MERPCHILD_REALM, MERPCHILD_USERNAME, MERPCHILD_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), MERPCHILD_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		uuid = UUID.randomUUID();
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), MERPCHILD_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, MERPCHILD_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserWithUuidForS4() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		uuid = UUID.randomUUID();
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), S4_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to s4 db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, S4_ANID, Constants.LOCALE_EN_US);
		JSONArray s4DataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArrayUpdated);
		Assert.assertTrue(s4DataArrayUpdated.length() > 0, "User with uniquename " + username + " not found in s4");
		JSONObject s4UserUpdated = s4DataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, s4UserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void createAndUpdateUserWithUuidForSAP() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		uuid = UUID.randomUUID();
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithUuidAsNull() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, JSONObject.NULL);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
	}

	@Test
	public void updateUserWithUuidAsBlank() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, "");

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user updation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("userUUID needs to meet RFC 4122 format for - "),
				"Error message is not matching when trying to update user with useruuid value as blank");
	}

	@Test
	public void updateUserWithUuidAsInvalid() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, "Invalid");

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_BAD_REQUEST,
				"Response code is not matching for user updation");
		JSONObject res = new JSONObject(result.getContent());
		Assert.assertTrue(res.getString("detail").contains("userUUID needs to meet RFC 4122 format for - Invalid"),
				"Error message is not matching when trying to update user with useruuid value as Invalid");
	}

	@Test
	public void updateUserWithRemovingUuidInBuyer() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(), 200,"Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArrayUpdated);
		Assert.assertTrue(buyerDataArrayUpdated.length() > 0,
				"User with uniquename " + username + " not found in buyer");
		JSONObject buyerUserUpdated = buyerDataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, buyerUserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithRemovingUuidInS4() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), S4_ANID, username);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject userUpdated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(userUpdated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user);
		String userIdUpdated = userUpdated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, S4_ANID, Constants.LOCALE_EN_US);
		JSONArray s4DataArrayUpdated = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(s4DataArrayUpdated);
		Assert.assertTrue(s4DataArrayUpdated.length() > 0, "User with uniquename " + username + " not found in s4");
		JSONObject s4UserUpdated = s4DataArrayUpdated.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(userUpdated, hanaUserUpdated, s4UserUpdated, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and S4. Issues - " + issues);
	}

	@Test
	public void createTwoUsersWithSameUuid() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username1 = USERNAME + "1" + uuid.toString();
		String username2 = USERNAME + "2" + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);

		// Creating User-1
		JSONObject userPayload = scimHelper.createUserPayload(username1, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user1 = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user1.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user1);
		String userId = user1.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username1, "Id in response payload is not same as username given");

		// Creating User-2
		userPayload = scimHelper.createUserPayload(username2, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user2 = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user2.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user2);
		String userId2 = user2.getString(Constants.ID);
		Assert.assertNotNull(userId2, "id is null for newly created user");
		Assert.assertEquals(userId2, username2, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana for user-1 */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username1 + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username1 + " not found in Search");
		JSONObject hanaUser1 = hanaArray.getJSONObject(0);

		/* Making API call to get data from hana for user-2 */
		url = "users?$filter=SharedUserKey.UniqueName='" + username2 + "'";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username2 + " not found in Search");
		JSONObject hanaUser2 = hanaArray.getJSONObject(0);

		/* Making query to buyer db for user-1 */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username1 + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username1 + " not found in buyer");
		JSONObject buyerUser1 = buyerDataArray.getJSONObject(0);

		/* Making query to buyer db for user-2 */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username2 + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username2 + " not found in buyer");
		JSONObject buyerUser2 = buyerDataArray.getJSONObject(0);

		Assert.assertTrue(
				buyerUser1.getString(Constants.HANA_USERUUID)
						.equalsIgnoreCase(buyerUser2.getString(Constants.HANA_USERUUID)),
				"Both users UserUUID field in Buyer is not same");

		JSONArray issues = comparePayloadsForUser(user1, hanaUser1, buyerUser1, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(user2, hanaUser2, buyerUser2, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void updateUserWithUuidSameAsOtherUser() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username1 = USERNAME + "1" + uuid.toString();
		String username2 = USERNAME + "2" + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);

		// Creating User-1
		JSONObject userPayload = scimHelper.createUserPayload(username1, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, "cnoll", emails, null, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user1 = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user1.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user1);
		String userId = user1.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username1, "Id in response payload is not same as username given");

		// Creating User-2
		userPayload = scimHelper.createUserPayload(username2, names, Boolean.TRUE, NAME_EN, Constants.LOCALE_EN_US,
				TIMEZONE_AMERICA, "cnoll", emails, null, null);
		System.err.println(userPayload);
		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user2 = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user2.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user2);
		String userId2 = user2.getString(Constants.ID);
		Assert.assertNotNull(userId2, "id is null for newly created user");
		Assert.assertEquals(userId2, username2, "Id in response payload is not same as username given");

		// Updating User-2 with uuid of User-1
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username2, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());

		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username2);
		System.err.println(result.getContent());
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user updation");
		JSONObject user2Updated = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user2Updated.has(Constants.ID),
				"Updated user id is not present in response. Response is" + user2Updated);
		String userIdUpdated = user2Updated.getString(Constants.ID);
		Assert.assertNotNull(userIdUpdated, "id is null for newly created user");
		Assert.assertEquals(userIdUpdated, username2, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana for user-1 */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username1 + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username1 + " not found in Search");
		JSONObject hanaUser1 = hanaArray.getJSONObject(0);

		/* Making API call to get data from hana for user-2 */
		url = "users?$filter=SharedUserKey.UniqueName='" + username2 + "'";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username2 + " not found in Search");
		JSONObject hanaUser2 = hanaArray.getJSONObject(0);

		/* Making query to buyer db for user-1 */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username1 + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username1 + " not found in buyer");
		JSONObject buyerUser1 = buyerDataArray.getJSONObject(0);

		/* Making query to buyer db for user-2 */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username2 + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username2 + " not found in buyer");
		JSONObject buyerUser2 = buyerDataArray.getJSONObject(0);

		Assert.assertTrue(
				buyerUser1.getString(Constants.HANA_USERUUID)
						.equalsIgnoreCase(buyerUser2.getString(Constants.HANA_USERUUID)),
				"Both users UserUUID field in Buyer is not same");

		JSONArray issues = comparePayloadsForUser(user1, hanaUser1, buyerUser1, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(user2Updated, hanaUser2, buyerUser2, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void getUserResponseCompareWithCreateUserWithUuid() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject cuser = (JSONObject) jsonObject(result.getContent());
		System.err.println(cuser);
		Assert.assertTrue(cuser.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + cuser);
		String userId = cuser.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		RestResponse getResult = scimHelper.getUsersByUserName(token, SAP_ANID, username, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject gUser = new JSONObject(getResult.getContent());
		System.err.println(gUser);
		JSONArray issues = verifyGetUserPayload(gUser, cuser);
		System.err.println(issues);
		Assert.assertTrue(issues.length() == 0,
				"Create user and get user responses are not matching. Issues - " + issues);
	}

	@Test
	public void getUserResponseCompareWithUpdatedUserWithUuid() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");

		// Updating user
		userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, uuid.toString());
		System.err.println(userPayload);
		result = scimHelper.updateUsers(token, userPayload.toString(), SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_OK, "Response code is not matching for user creation");
		JSONObject cuser = (JSONObject) jsonObject(result.getContent());
		System.err.println(cuser);
		Assert.assertTrue(cuser.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + cuser);
		String userId = cuser.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		RestResponse getResult = scimHelper.getUsersByUserName(token, SAP_ANID, username, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		JSONObject gUser = new JSONObject(getResult.getContent());

		JSONArray issues = verifyGetUserPayload(gUser, cuser);
		System.err.println(issues);
		Assert.assertTrue(issues.length() == 0,
				"Create user and get user responses are not matching. Issues - " + issues);
	}

	@Test
	public void advSearchAPIWithUserUUID() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertTrue(hanaUser.has(Constants.HANA_USERUUID), "User UUID Field is Not present in Search Response");

		/* Making MDS Search api call with filter on UUID */
		url = "users?$filter=UserUUID='" + uuid.toString() + "'";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertTrue(hanaUser.has(Constants.HANA_USERUUID), "User UUID Field is Not present in Search Response");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_USERUUID), uuid.toString(),
				"UserUUID retrieved in MDS Search is not matching");

		/* Making MDS Search api call with select on UUID */
		url = "users?$filter=UserUUID='" + uuid.toString() + "'&$select=SharedUserKey.UniqueName,UserUUID";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertTrue(hanaUser.has(Constants.HANA_USERUUID), "User UUID Field is Not present in Search Response");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_USERUUID), uuid.toString(),
				"UserUUID retrieved in MDS Search is not matching");
	}

	@Test
	public void openApiSearchWithUserUUID() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, uuid.toString());
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making meta API call */
		String url = "users";
		RestResponse res = searchHelper.searchOpenAPIMeta(token, SAP_REALM, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONObject meta = new JSONObject(content);
		meta = meta.getJSONObject("properties");
		Assert.assertTrue(meta.has(Constants.HANA_USERUUID), "UserUUID field is not present in Search OpenAPI meta");

		/* Making API call to get data from hana */
		url = "users?$filter=UniqueName eq '" + username + "'";
		res = searchHelper.searchOpenAPIEntity(token, SAP_REALM, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertTrue(hanaUser.has(Constants.HANA_USERUUID), "User UUID Field is Not present in Search Response");

		/* Making MDS Search api call with filter on UUID */
		url = "users?$filter=UserUUID eq '" + uuid.toString() + "'";
		res = searchHelper.searchOpenAPIEntity(token, SAP_REALM, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertTrue(hanaUser.has(Constants.HANA_USERUUID), "User UUID Field is Not present in Search Response");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_USERUUID), uuid.toString(),
				"UserUUID retrieved in MDS Search is not matching");

		/* Making MDS Search api call with select on UUID */
		url = "users?$filter=UserUUID eq '" + uuid.toString() + "'&$select=UniqueName,UserUUID";
		res = searchHelper.searchOpenAPIEntity(token, SAP_REALM, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);
		Assert.assertTrue(hanaUser.has(Constants.HANA_USERUUID), "User UUID Field is Not present in Search Response");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_USERUUID), uuid.toString(),
				"UserUUID retrieved in MDS Search is not matching");
	}

	@Test
	public void deleteUserSAPVariant() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");



		// Get User details
		result = scimHelper.getUsersByUserName(token, SAP_ANID, username, null);
		Assert.assertNotNull(result, "Null response obtained");
		user = (JSONObject) jsonObject(result.getContent());

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.FALSE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() == 1, "Found user as Active in buyer");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		// Deleting User
		result = scimHelper.deleteUsers(token, SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT,
				"Response code is not matching for user creation");

		//Get user after deleting
		String filter = "active eq false";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		Assert.assertTrue(getResult.getContent().contains("\"totalResults\":0"),"Expected mgs : "+"\"totalResults\":0"+" but found "+getResult.getContent());


		// assert get user response "no response"
		// hana call and assert for is active is false
		// make a buyer call and assert for active

		// Getting user details
		/* Making API call to get data from hana */
		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);
		Assert.assertEquals(hanaUserUpdated.getString(Constants.HANA_BASE_ACTIVE),"false","Mismatch in the active status");

		/* Making query to buyer db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.FALSE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() == 0, "Found user as Active in buyer");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");

	}

	@Test
	public void deleteUserWithUserUuidSAPVariant() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Get User details
		result = scimHelper.getUsersByUserName(token, SAP_ANID, username, null);
		Assert.assertNotNull(result, "Null response obtained");
		user = (JSONObject) jsonObject(result.getContent());

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.FALSE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() == 1, "Found user as Active in buyer");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		// Deleting User
		result = scimHelper.deleteUsers(token, SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT,
				"Response code is not matching for user creation");

		//Get user after deleting
		String filter = "active eq false";
		RestResponse getResult = scimHelper.getUsers(token, SAP_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		Assert.assertTrue(getResult.getContent().contains("\"totalResults\":0"),"Expected mgs : "+"\"totalResults\":0"+" but found "+getResult.getContent());


		// assert get user response "no response"
		// hana call and assert for is active is false
		// make a buyer call and assert for active

		// Getting user details
		/* Making API call to get data from hana */
		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);
		Assert.assertEquals(hanaUserUpdated.getString(Constants.HANA_BASE_ACTIVE),"false","Mismatch in the active status");

		/* Making query to buyer db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.FALSE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() == 0, "Found user as Active in buyer");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");


	}

	@Test
	public void deleteUserWithUserUuidIntegrated() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), INTEGRATED_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");


		// Get User details
		result = scimHelper.getUsersByUserName(token, INTEGRATED_ANID, username, null);
		Assert.assertNotNull(result, "Null response obtained");
		user = (JSONObject) jsonObject(result.getContent());
		Thread.sleep(20000);
		// Getting user details
		/* Making API call to get data from hana */
		token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, ORIGIN_SYS);
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.FALSE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, INTEGRATED_ANID,
				Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() == 1, "Found user as Active in buyer");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		/* Making query to sourcing db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.FALSE);
		Thread.sleep(100000);
		token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, ORIGIN_SYS);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		JSONArray s4DataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(s4DataArray.length() == 1, "Found user as Active in s4");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		s4DataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(s4DataArray.length() > 0, "User with uniquename " + username + " not found in s4");
		JSONObject s4User = buyerDataArray.getJSONObject(0);

		issues = comparePayloadsForUser(user, hanaUserUpdated, s4User, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);

		// Deleting User
		result = scimHelper.deleteUsers(token, INTEGRATED_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT,
				"Response code is not matching for user creation");

		//Get user after deleting
		String filter = "active eq false";
		RestResponse getResult = scimHelper.getUsers(token, INTEGRATED_ANID, filter, 1, 5);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_OK, "Status code is not matching for get users call");
		Assert.assertTrue(getResult.getContent().contains("\"totalResults\":0"),"Expected mgs : "+"\"totalResults\":0"+" but found "+getResult.getContent());


		// assert get user response "no response"
		// hana call and assert for is active is false
		// make a buyer call and assert for active

		// Getting user details
		/* Making API call to get data from hana */
		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);
		Assert.assertEquals(hanaUserUpdated.getString(Constants.HANA_BASE_ACTIVE),"false","Mismatch in the active status");

		/* Making query to buyer db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.FALSE);
		Thread.sleep(200000);
		token = oauthHelper.getAccessToken(INTEGRATED_REALM, INTEGRATED_USERNAME, INTEGRATED_ANID, ORIGIN_SYS);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() == 0, "Found user as Active in buyer");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");

		/* Making query to sourcing db */
		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.FALSE);
		Thread.sleep(200000);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		s4DataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(s4DataArray.length() == 0, "Found user as Active in s4");

		query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'", Boolean.TRUE);
		aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, INTEGRATED_ANID, Constants.LOCALE_EN_US);
		s4DataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(s4DataArray.length() > 0, "User with uniquename " + username + " not found in s4");
	}

	@Test
	public void createDeletedUserWithUserUuidSAPVariant() throws Exception {

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, uuid.toString());
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Deleting User
		result = scimHelper.deleteUsers(token, SAP_ANID, username);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT,
				"Response code is not matching for user creation");

		// Creating Same User again
		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(), 200, "Response code is not matching");
		JSONArray hanaArrayUpdated = new JSONArray(content);
		Assert.assertEquals(hanaArrayUpdated.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUserUpdated = hanaArrayUpdated.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.FALSE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUserUpdated, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user updated in HANA and Buyer. Issues - " + issues);
	}

	@Test
	public void differentResponseCodeVerification() throws Exception {
		SoftAssert softAssertion= new SoftAssert();

		/* Generating access token */
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		// Creating User
		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		//Create user again
		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		softAssertion.assertEquals(result.getCode(), HttpStatus.SC_CONFLICT,
				"Response code should be "+HttpStatus.SC_CONFLICT+" when creating(POST) user with existing username");

		// Delete User
		result = scimHelper.deleteUsers(token, SAP_ANID, username);
		softAssertion.assertEquals(result.getCode(), HttpStatus.SC_NO_CONTENT,
				"Response code should be "+HttpStatus.SC_NO_CONTENT+" when deleting a existing user");

		//Update deleted User
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		result = scimHelper.updateUsers(token, userPayloadUpdated.toString(), MERPCHILD_ANID, username);
		softAssertion.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when updating(PUT) user which doesn't exist");

		// Delete already deleted User
		result = scimHelper.deleteUsers(token, SAP_ANID, username);
		softAssertion.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when deleting user which doesn't exist");

		// Get deleted User
		result = scimHelper.getUsersByUserName(token, SAP_ANID, username, null);
		softAssertion.assertEquals(result.getCode(), HttpStatus.SC_NOT_FOUND,
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to GET the user which doesn't exist");

		// Patch on deleted user
		MDNI mdni = new MDNI();
		String samplePatchPayload = "{\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"],\"Operations\":[{\"op\":\"remove\",\"path\":\"members\"}]}";
		Response patchUserResponse = mdni.patchUsers(SAP_ANID, token, samplePatchPayload, username);
		softAssertion.assertEquals(patchUserResponse.getStatusCode(), HttpStatus.SC_NOT_FOUND,
				"Response code should be "+HttpStatus.SC_NOT_FOUND+" when trying to PATCH the user which doesn't exist");

		// Create the deleted user again
		result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		softAssertion.assertEquals(result.getCode(), HttpStatus.SC_CREATED,
				"Response code should be "+HttpStatus.SC_CREATED+" when trying to create(POST) the user which doesn't exist");

		softAssertion.assertAll();

		// Getting user details
		/* Making API call to get data from hana */
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$expand="
				+ Constants.HANA_PERSISTED_EMAIL_ADDRESS;
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(), 200,"Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$locale=zh_cn";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals(res.getCode(),200,  "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser_zh = hanaArray.getJSONObject(0);

		/* Making query to buyer db */
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		JSONArray issues = comparePayloadsForUser(user, hanaUser, buyerUser, Constants.LANG_EN);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);

		issues = comparePayloadsForUser(user, hanaUser_zh, null, Constants.LANG_ZH);
		Assert.assertTrue(issues.length() == 0,
				"Issues when compared payload with user created in HANA and Buyer. Issues - " + issues);


	}

	@Test
	public void creationBlockedBuyerUser() throws Exception {
		MDNI mdni = new MDNI();

		//Generating access token
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		System.out.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Blocking user
		//Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,SAP_REALM, Constants.BUYER, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		RestResponse resultAfterBlocked = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(resultAfterBlocked.getCode(), HttpStatus.SC_CONFLICT, "Response code is not matching for user creation with same payload");
		JSONObject res = new JSONObject(resultAfterBlocked.getContent());
		System.err.println(resultAfterBlocked.getContent());
		Assert.assertTrue(res.getString("detail").contains("Resource with given user is Blocked"),
				"Error message is not matching when creation of blocked user with same  uniquename");
	}

	@Test
	public void creationBlockedS4User() throws Exception {
		MDNI mdni = new MDNI();

		//Generating access token
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, Constants.SOURCING);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		System.out.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,S4_REALM, Constants.SOURCING, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		RestResponse resultAfterBlocked = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		Assert.assertEquals(resultAfterBlocked.getCode(), HttpStatus.SC_CONFLICT, "Response code is not matching for user creation with same payload");
		JSONObject res = new JSONObject(resultAfterBlocked.getContent());
		System.err.println(resultAfterBlocked.getContent());
		Assert.assertTrue(res.getString("detail").contains("Resource with given user is Blocked"),
				"Error message is not matching when creation of blocked user with same  uniquename");
	}

	@Test
	public void validateBlockedUserBuyerForSAPFromCoreStack() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		System.out.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,SAP_REALM, Constants.BUYER, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Getting user details
		// Making query to buyer db
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, SAP_ANID, Constants.LOCALE_EN_US);
		JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(buyerDataArray);
		Assert.assertTrue(buyerDataArray.length() > 0, "User with uniquename " + username + " not found in buyer");
		JSONObject buyerUser = buyerDataArray.getJSONObject(0);

		Assert.assertEquals(buyerUser.getString(Constants.UNIQUENAME),username, "UniqueName does not match as expected");
		Assert.assertEquals(buyerUser.getString(Constants.HANA_EMAIL_KEY),"*******", "Email not masked after blocking user");
		Assert.assertEquals(buyerUser.getString(Constants.HANA_PHONE),"*******", "Phone not masked after blocking user");
		Assert.assertEquals(buyerUser.getString(Constants.HANA_FAX),"*******", "Fax not masked after blocking user");
	}

	@Test
	public void validateBlockedUserBuyerForSAPFromHANA() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		System.out.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,SAP_REALM, Constants.BUYER, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Making API call to get data from hana after blocking user
		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		Assert.assertEquals(hanaUser.getString(Constants.HANA_USER_UNIQUENAME), username, "Username does not match as expected ") ;
		Assert.assertEquals(hanaUser.getString(Constants.HANA_EMAIL_KEY),"*******", "Email not masked after blocking user");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_PRIVACYREVOKEDVERSION),"*******", "Email not masked after blocking user");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_ACCEPTEDPRIVACYAGREEMENTVERSION),"*******", "Email not masked after blocking user");
		Assert.assertFalse(Boolean.parseBoolean(hanaUser.getString(Constants.HANA_BASE_ACTIVE)), "IsActive not false after blocking user");
	}

	@Test
	public void validateBlockedUserS4ForSAPFromCoreStack() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,S4_REALM, Constants.SOURCING, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Getting user details
		// Making query to S4 db
		String query = scimHelper.constructQuery(KEYS, "ariba.user.core.User", "UniqueName='" + username + "'",
				Boolean.TRUE);
		RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, S4_ANID, Constants.LOCALE_EN_US);
		JSONArray sourcingDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
		System.err.println(sourcingDataArray);
		Assert.assertTrue(sourcingDataArray.length() > 0, "User with uniquename " + username + " not found in s4");
		JSONObject s4User = sourcingDataArray.getJSONObject(0);

		Assert.assertEquals(s4User.getString(Constants.UNIQUENAME),username, "UniqueName does not match as expected ");
		Assert.assertEquals(s4User.getString(Constants.HANA_EMAIL_KEY),"*******", "Email not masked after blocking user");
		Assert.assertEquals(s4User.getString(Constants.HANA_PHONE),"*******", "Phone not masked after blocking user");
		Assert.assertEquals(s4User.getString(Constants.HANA_FAX),"*******", "Fax not masked after blocking user");
	}

	@Test
	public void validateBlockedUserS4ForSAPFromHANA() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,S4_REALM, Constants.SOURCING, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Getting user details
		// Making API call to get data from hana after blocking user
		url = "users?$filter=SharedUserKey.UniqueName='" + username + "'&$includeinactive=true";
		res = searchHelper.searchEntity(token, url);
		content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		Assert.assertEquals(hanaUser.getString(Constants.HANA_USER_UNIQUENAME), username, "Username does not match as expected ") ;
		Assert.assertEquals(hanaUser.getString(Constants.HANA_EMAIL_KEY),"*******", "Email not masked after blocking user");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_PRIVACYREVOKEDVERSION),"*******", "Email not masked after blocking user");
		Assert.assertEquals(hanaUser.getString(Constants.HANA_ACCEPTEDPRIVACYAGREEMENTVERSION),"*******", "Email not masked after blocking user");
		Assert.assertFalse(Boolean.parseBoolean(hanaUser.getString(Constants.HANA_BASE_ACTIVE)), "IsActive not false after blocking user");
	}

	@Test
	public void getDetailsBlockedUserBuyer() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,SAP_REALM, Constants.BUYER, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		RestResponse getResult = scimHelper.getUsersByUserName(token, SAP_ANID,username, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Status code is not matching for get users call");
		System.err.println(getResult.getContent());
		Assert.assertEquals(getResult.getContent(), "{\"status\":404,\"detail\":\"Resource with given user doesn't exist\",\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:Error\"]}",
				"Error message is not matching when Blocked user is searched");
	}

	@Test
	public void getDetailsBlockedUserSourcing() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,S4_REALM, Constants.SOURCING, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		RestResponse getResult = scimHelper.getUsersByUserName(token, S4_ANID,username, null);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Status code is not matching for get users call");
		System.err.println(getResult.getContent());
		Assert.assertEquals(getResult.getContent(), "{\"status\":404,\"detail\":\"Resource with given user doesn't exist\",\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:Error\"]}",
				"Error message is not matching when Blocked user is searched");
	}

	@Test
	public void updationBlockedUserBuyer() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,SAP_REALM, Constants.BUYER, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse getResult = scimHelper.updateUsers(token, userPayloadUpdated.toString(), SAP_ANID, username);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Status code is not matching for get users call");
		System.err.println(getResult.getContent());
		Assert.assertEquals(getResult.getContent(), "{\"status\":404,\"detail\":\"Resource with given user doesn't exist\",\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:Error\"]}",
				"Error message is not matching when Blocked user is searched");
	}

	@Test
	public void updationBlockedUserSourcing() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,S4_REALM, Constants.SOURCING, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Updating user
		JSONObject userPayloadUpdated = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN + NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, null, null);
		RestResponse getResult = scimHelper.updateUsers(token, userPayloadUpdated.toString(), S4_ANID, username);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Status code is not matching for get users call");
		System.err.println(getResult.getContent());
		Assert.assertEquals(getResult.getContent(), "{\"status\":404,\"detail\":\"Resource with given user doesn't exist\",\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:Error\"]}",
				"Error message is not matching when Blocked user is searched");
	}

	@Test
	public void deletionBlockedUserBuyer() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), SAP_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,SAP_REALM, Constants.BUYER, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Deleting User
		RestResponse getResult  = scimHelper.deleteUsers(token, SAP_ANID, username);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Response code is not matching for blocked user deletion");
	}

	@Test
	public void deletionBlockedUserSourcing() throws Exception {
		MDNI mdni = new MDNI();

		// Generating access token
		String token = oauthHelper.getAccessToken(S4_REALM, S4_USERNAME, S4_ANID, "s4");

		UUID uuid = UUID.randomUUID();
		String username = USERNAME + uuid.toString();
		Map<String, Object> names = new HashMap<String, Object>();
		names.put(Constants.LANG_JA, NAME_JA);
		names.put(Constants.LANG_ZH, NAME_ZH);
		Map<String, Object> emails = new HashMap<String, Object>();
		emails.put(Constants.WORK, EMAIL_WORK);
		emails.put(Constants.HOME, EMAIL_HOME);
		Map<String, Object> phones = new HashMap<String, Object>();
		phones.put(Constants.WORK, PHONE_WORK);
		phones.put(Constants.FAX, PHONE_FAX);
		JSONObject userPayload = scimHelper.createUserPayload(username, names, Boolean.TRUE, NAME_EN,
				Constants.LOCALE_EN_US, TIMEZONE_AMERICA, MANAGER_ADAVIS, emails, phones, null);
		System.err.println(userPayload);
		RestResponse result = scimHelper.postUsers(token, userPayload.toString(), S4_ANID);
		Assert.assertEquals(result.getCode(), HttpStatus.SC_CREATED, "Response code is not matching for user creation");
		JSONObject user = (JSONObject) jsonObject(result.getContent());
		System.err.println(user);
		Assert.assertTrue(user.has(Constants.ID),
				"Newly created user id is not present in response. Response is" + user);
		String userId = user.getString(Constants.ID);
		Assert.assertNotNull(userId, "id is null for newly created user");
		Assert.assertEquals(userId, username, "Id in response payload is not same as username given");

		// Getting user details before Blocking User
		// Making API call to get data from hana
		String url = "users?$filter=SharedUserKey.UniqueName='" + username + "'";
		RestResponse res = searchHelper.searchEntity(token, url);
		String content = res.getContent();
		Assert.assertNotNull(res, "Null response obtained");
		Assert.assertNotNull(content, "Null response obtained");
		Assert.assertEquals( res.getCode(),200, "Response code is not matching");
		JSONArray hanaArray = new JSONArray(content);
		Assert.assertEquals(hanaArray.length(), 1, "User with username " + username + " not found in Search");
		JSONObject hanaUser = hanaArray.getJSONObject(0);
		System.err.println(hanaUser);

		// Blocking user
		// Generating access token
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		// Making API call to Blocked User
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE ,S4_REALM, Constants.SOURCING, username);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(5000);

		// Deleting User
		RestResponse getResult  = scimHelper.deleteUsers(token, S4_ANID, username);
		Assert.assertEquals(getResult.getCode(), HttpStatus.SC_NOT_FOUND, "Response code is not matching for blocked user deletion");
	}


	private JSONArray verifyGetUserPayload(JSONObject getUser, JSONObject user) {
		JSONArray issues = new JSONArray();

		String id = "";
		String gid = "";
		if (user.has(Constants.ID)) {
			id = user.getString(Constants.ID);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.ID + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.has(Constants.ID)) {
			gid = getUser.getString(Constants.ID);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.ID + " field is not present in Get user response");
			issues.put(issue);
		}
		if (!id.equalsIgnoreCase(gid)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.ID + " field is not matching in user and Get user response");
			issues.put(issue);
		}

		String username = "";
		String getUsername = "";
		if (user.has(Constants.USERNAME)) {
			username = user.getString(Constants.USERNAME);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.USERNAME + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.has(Constants.USERNAME)) {
			getUsername = getUser.getString(Constants.USERNAME);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.USERNAME + " field is not present in get user response");
			issues.put(issue);
		}
		if (!username.equalsIgnoreCase(getUsername)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.USERNAME + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String displayname = "";
		String getDisplayname = "";
		if (user.has(Constants.DISPLAYNAME)) {
			displayname = user.getString(Constants.DISPLAYNAME);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.DISPLAYNAME + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.has(Constants.DISPLAYNAME)) {
			getDisplayname = getUser.getString(Constants.DISPLAYNAME);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.DISPLAYNAME + " field is not present in get user response");
			issues.put(issue);
		}
		if (!displayname.equalsIgnoreCase(getDisplayname)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.DISPLAYNAME + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String locale = "";
		String getLocale = "";
		if (user.has(Constants.LOCALE)) {
			locale = user.getString(Constants.LOCALE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LOCALE + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.has(Constants.LOCALE)) {
			getLocale = getUser.getString(Constants.LOCALE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LOCALE + " field is not present in get user response");
			issues.put(issue);
		}
		if (!locale.equalsIgnoreCase(getLocale)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LOCALE + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String timezone = "";
		String getTimezone = "";
		if (user.has(Constants.TIMEZONE)) {
			timezone = user.getString(Constants.TIMEZONE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.TIMEZONE + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.has(Constants.TIMEZONE)) {
			getTimezone = getUser.getString(Constants.TIMEZONE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.TIMEZONE + " field is not present in get user response");
			issues.put(issue);
		}
		if (!timezone.equalsIgnoreCase(getTimezone)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.TIMEZONE + " field is not matching in user and get user response");
			issues.put(issue);
		}

		boolean active = false;
		boolean getActive = false;
		if (user.has(Constants.ACTIVE)) {
			active = user.getBoolean(Constants.ACTIVE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.ACTIVE + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.has(Constants.ACTIVE)) {
			getActive = getUser.getBoolean(Constants.ACTIVE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.ACTIVE + " field is not present in get user response");
			issues.put(issue);
		}
		if (active != getActive) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.ACTIVE + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String manager = "";
		String getManager = "";
		if (user.has(Constants.USERS_SCHEMA_ENTERPRISE)) {
			manager = user.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE).getJSONObject(Constants.MANAGER)
					.getString(Constants.VALUE_KEY);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.MANAGER + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.has(Constants.USERS_SCHEMA_ENTERPRISE)) {
			getManager = getUser.getJSONObject(Constants.USERS_SCHEMA_ENTERPRISE).getJSONObject(Constants.MANAGER)
					.getString(Constants.VALUE_KEY);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.MANAGER + " field is not present in get user response");
			issues.put(issue);
		}
		if (!manager.equalsIgnoreCase(getManager)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.MANAGER + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String resourceType = "";
		String getResourceType = "";
		if (user.getJSONObject(Constants.META).has(Constants.RESOURCE_TYPE)) {
			resourceType = user.getJSONObject(Constants.META).getString(Constants.RESOURCE_TYPE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.RESOURCE_TYPE + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.getJSONObject(Constants.META).has(Constants.RESOURCE_TYPE)) {
			getResourceType = getUser.getJSONObject(Constants.META).getString(Constants.RESOURCE_TYPE);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.RESOURCE_TYPE + " field is not present in get user response");
			issues.put(issue);
		}
		if (!resourceType.equalsIgnoreCase(getResourceType)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.RESOURCE_TYPE + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String version = "";
		String getVersion = "";
		if (user.getJSONObject(Constants.META).has(Constants.VERSION)) {
			version = user.getJSONObject(Constants.META).getString(Constants.VERSION);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.VERSION + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.getJSONObject(Constants.META).has(Constants.VERSION)) {
			getVersion = getUser.getJSONObject(Constants.META).getString(Constants.VERSION);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.VERSION + " field is not present in get user response");
			issues.put(issue);
		}
		if (Integer.parseInt(getVersion) < Integer.parseInt(version)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.VERSION + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String location = "";
		String getLocation = "";
		if (user.getJSONObject(Constants.META).has(Constants.LOCATION)) {
			location = user.getJSONObject(Constants.META).getString(Constants.LOCATION);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LOCATION + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.getJSONObject(Constants.META).has(Constants.LOCATION)) {
			getLocation = getUser.getJSONObject(Constants.META).getString(Constants.LOCATION);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LOCATION + " field is not present in get user response");
			issues.put(issue);
		}
		if (!location.equalsIgnoreCase(getLocation)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LOCATION + " field is not matching in user and get user response");
			issues.put(issue);
		}

		String created = "";
		String getCreated = "";
		if (user.getJSONObject(Constants.META).has(Constants.CREATED)) {
			created = user.getJSONObject(Constants.META).getString(Constants.CREATED);
		}
		if (getUser.getJSONObject(Constants.META).has(Constants.CREATED)) {
			getCreated = getUser.getJSONObject(Constants.META).getString(Constants.CREATED);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.CREATED + " field is not present in get user response");
			issues.put(issue);
		}
		if (!created.equalsIgnoreCase("")) {
			if (!(created.substring(0, created.length() - 3))
					.equalsIgnoreCase(getCreated.substring(0, getCreated.length() - 3))) {
				JSONObject issue = new JSONObject();
				issue.put("REASON", Constants.CREATED + " field is not matching in user and get user response");
				issues.put(issue);
			}
		}

		String modified = "";
		String getModified = "";
		if (user.getJSONObject(Constants.META).has(Constants.LAST_MODIFIED)) {
			modified = user.getJSONObject(Constants.META).getString(Constants.LAST_MODIFIED);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LAST_MODIFIED + " field is not present in user response");
			issues.put(issue);
		}
		if (getUser.getJSONObject(Constants.META).has(Constants.LAST_MODIFIED)) {
			getModified = getUser.getJSONObject(Constants.META).getString(Constants.LAST_MODIFIED);
		} else {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LAST_MODIFIED + " field is not present in get user response");
			issues.put(issue);
		}
		if (!(modified.substring(0, modified.length() - 7))
				.equalsIgnoreCase(getModified.substring(0, getModified.length() - 7))) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.LAST_MODIFIED + " field is not matching in user and get user response");
			issues.put(issue);
		}

		List<String> emails = new ArrayList<String>();
		String notInGetEmails = "";
		if (user.has(Constants.EMAIL_KEY)) {
			JSONArray emailArr = user.getJSONArray(Constants.EMAIL_KEY);
			for (int i = 0; i < emailArr.length(); i++) {
				emails.add(emailArr.getJSONObject(i).getString(Constants.VALUE_KEY));
			}
		}
		if (getUser.has(Constants.EMAIL_KEY)) {
			JSONArray emailArr = getUser.getJSONArray(Constants.EMAIL_KEY);
			for (int i = 0; i < emailArr.length(); i++) {
				String email = emailArr.getJSONObject(i).getString(Constants.VALUE_KEY);
				if (emails.contains(email))
					emails.remove(email);
				else
					notInGetEmails = notInGetEmails + email + ",";
			}
		}
		if (emails.size() > 0) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.EMAIL_KEY + " in user response are more than in get response");
			issues.put(issue);
		}
		if (!notInGetEmails.equalsIgnoreCase("")) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.EMAIL_KEY + " in get user response are not in user response");
			issues.put(issue);
		}

		String workPhone = "";
		String getWorkPhone = "";
		String fax = "";
		String getFax = "";
		if (user.has(Constants.PHONES_KEY)) {
			JSONArray phones = user.getJSONArray(Constants.PHONES_KEY);
			for (int i = 0; i < phones.length(); i++) {
				if (phones.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(Constants.WORK))
					workPhone = phones.getJSONObject(i).getString(Constants.VALUE_KEY);
				if (phones.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(Constants.FAX))
					fax = phones.getJSONObject(i).getString(Constants.VALUE_KEY);
			}
		}
		if (getUser.has(Constants.PHONES_KEY)) {
			JSONArray phones = getUser.getJSONArray(Constants.PHONES_KEY);
			for (int i = 0; i < phones.length(); i++) {
				if (phones.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(Constants.WORK))
					getWorkPhone = phones.getJSONObject(i).getString(Constants.VALUE_KEY);
				if (phones.getJSONObject(i).getString(Constants.TYPE).equalsIgnoreCase(Constants.FAX))
					getFax = phones.getJSONObject(i).getString(Constants.VALUE_KEY);
			}
		}
		if (!workPhone.equalsIgnoreCase(getWorkPhone)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.PHONES_KEY + " for work is not matching");
			issues.put(issue);
		}
		if (!fax.equalsIgnoreCase(getFax)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.PHONES_KEY + " for Fax is not matching");
			issues.put(issue);
		}

		String userUUID = "";
		String getUserUUID = "";
		if (user.has(Constants.USERS_SCHEMA_PROFILE)) {
			if (user.getJSONObject(Constants.USERS_SCHEMA_PROFILE).has(Constants.USERUUID)) {
				userUUID = user.getJSONObject(Constants.USERS_SCHEMA_PROFILE).getString(Constants.USERUUID);
			}
		}
		if (getUser.has(Constants.USERS_SCHEMA_PROFILE)) {
			if (getUser.getJSONObject(Constants.USERS_SCHEMA_PROFILE).has(Constants.USERUUID)) {
				getUserUUID = getUser.getJSONObject(Constants.USERS_SCHEMA_PROFILE).getString(Constants.USERUUID);
			}
		}
		if (!userUUID.equalsIgnoreCase(getUserUUID)) {
			JSONObject issue = new JSONObject();
			issue.put("REASON", Constants.USERUUID + " field is not matching in user and get user response");
			issues.put(issue);
		}
		return issues;
	}
}
