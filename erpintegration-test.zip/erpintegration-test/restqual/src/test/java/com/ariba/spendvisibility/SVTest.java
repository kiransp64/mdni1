package com.ariba.spendvisibility;

import com.ariba.helpers.XmlHelper;
import com.ariba.services.AQL;
import com.ariba.services.MDNI;
import com.ariba.services.MDS;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

public class SVTest extends SVBaseTest{

    /** This test is for SV flow for below types of Realm :
     * Integrated Realm,
     * Reporting Realm,
     * Non Integrated Realm
     * */
    @Test(dataProvider = "uploadXmlTestData", dataProviderClass = SpendVisibilityTestDataProvider.class)
    public void svFlowTest(String Description, String system, String realm, String tenantId, String objectName,String payload,String mdsSearchUri, String filterParam, String randomString, String aqlQuery) throws InterruptedException, ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        MDNI mdni = new MDNI();
        String requestPayload = payload.replace("@UniqueName",randomString);
        String jobId = mdni.uploadXMLData(tenantId,objectName,requestPayload);
        Response jobResponse = mdni.getJobStatus(tenantId,jobId);
        int recordsInserted = jobResponse.jsonPath().getInt("RecordsInserted");
        AQL aql = new AQL();
        Response aqlPullResponse;
        MDS mds = new MDS();
        Response mdsOpenApiResponse;
        mdsOpenApiResponse = mds.openApiSearch(system, realm,tenantId, mdsSearchUri,filterParam.replace("xxxx",randomString));
        aqlPullResponse = aql.buyerPull(aqlQuery.replace("@UniqueName",randomString),realm,tenantId,"en_US");
        verifyRecordInBuyer(aqlPullResponse,randomString,recordsInserted);
        verifyRecordInMdsHana(mdsOpenApiResponse,randomString,recordsInserted,objectName,requestPayload);
    }

    /** This test is for SV flow of Item Master for below types of Realm :
     * Integrated Realm,
     * Reporting Realm,
     * */
    @Test(dataProvider = "uploadXmlTestDataForItemMaster", dataProviderClass = SpendVisibilityTestDataProvider.class)
    public void svItemMasterTest(String Description, String system, String realm, String tenantId, String objectName,String payload,String mdsSearchUri, String filterParam, String randomString, String aqlQuery) throws InterruptedException, ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        MDNI mdni = new MDNI();
        String requestPayload = payload.replace("@UniqueName",randomString);
        String jobId = mdni.uploadXMLData(tenantId,objectName,requestPayload);
        Response jobResponse = mdni.getJobStatus(tenantId,jobId);
        int recordsInserted = jobResponse.jsonPath().getInt("RecordsInserted");
        MDS mds = new MDS();
        Response mdsAdvancedSearchApiResponse;
        mdsAdvancedSearchApiResponse = mds.mdsAdvancedSearchApiResponse(system, realm,tenantId,mdsSearchUri,randomString+"_02",null,null,null);
        verifyRecordInMdsHana(mdsAdvancedSearchApiResponse,randomString,recordsInserted,objectName,requestPayload);
    }

    /** This test is for SV flow for below types of Realm :
     * Standalone Sourcing Realm
     * */
    @Test(dataProvider = "uploadXmlTestDataForStandAloneSourcingRealm", dataProviderClass = SpendVisibilityTestDataProvider.class)
    public void svStandaloneSourcingRealTest(String Description, String system, String realm, String tenantId, String objectName,String payload,String mdsSearchUri, String filterParam, String randomString, String aqlQuery) throws InterruptedException, ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        MDNI mdni = new MDNI();
        String requestPayload = payload.replace("@UniqueName",randomString);
        String jobId = mdni.uploadXMLData(tenantId,objectName,requestPayload);
        Response jobResponse = mdni.getJobStatus(tenantId,jobId);
        int recordsInserted = jobResponse.jsonPath().getInt("RecordsInserted");
        MDS mds = new MDS();
        Response mdsOpenApiResponse;
        if (objectName.equalsIgnoreCase("product"))
            mdsOpenApiResponse = mds.mdsAdvancedSearchApiResponse(system, realm,tenantId,mdsSearchUri,randomString+"_02",null,null,null);
        else if (objectName.equalsIgnoreCase("CostCentre"))
            mdsOpenApiResponse = mds.mdsQueryExecuterResponse(tenantId,randomString);
        else
            mdsOpenApiResponse = mds.mdsAdvancedSearchApiResponse(system, realm,tenantId,mdsSearchUri,"ERW_600",filterParam.replace("xxxx",randomString),null,null);
        verifyRecordInMdsHanaForMM(mdsOpenApiResponse,randomString,recordsInserted,objectName,requestPayload);
    }

    private void verifyRecordInMdsHana(Response mdsSearchResponse, String randomString, int recordsInserted,String objectName, String payload) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, InterruptedException {
        int recordsFetchedFromMds = mdsSearchResponse.jsonPath().getList("$").size();
        Assert.assertTrue(recordsFetchedFromMds==recordsInserted,"Record not found in MDS for UniqueName : "+randomString);

        switch (objectName){
            case "GLAccount":
                verifyGeneralLedgerFields(payload,mdsSearchResponse);
                break;
            case "CostCentre":
                CostCenterFields(payload, mdsSearchResponse);
                break;
            case "MaterialGroup":
                verifyPartitionedCommodityCodeFields(payload, mdsSearchResponse);
                break;
            case "Plant":
                verifyPlantFields(payload, mdsSearchResponse);
                break;
            case "Product":
                verifyItemMasterFields(payload, mdsSearchResponse);
                break;

        }

    }

    private void verifyRecordInMdsHanaForMM(Response mdsSearchResponse, String randomString, int recordsInserted,String objectName, String payload) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, InterruptedException {
//        int recordsFetchedFromMds = mdsSearchResponse.jsonPath().getList("$").size();
//        Assert.assertTrue(recordsFetchedFromMds==recordsInserted,"Record not found in MDS for UniqueName : "+randomString);

        switch (objectName){
            case "GLAccount":
                verifyGeneralLedgerFieldsMM(payload,mdsSearchResponse);
                break;
            case "CostCentre":
                CostCenterFieldsMM(payload, mdsSearchResponse);
                break;
            case "MaterialGroup":
                verifyPartitionedCommodityCodeFieldsMM(payload, mdsSearchResponse);
                break;
            case "Plant":
                verifyPlantFieldsMM(payload, mdsSearchResponse);
                break;
            case "Product":
                verifyItemMasterFieldsMM(payload, mdsSearchResponse);
                break;

        }

    }
    private void verifyRecordInBuyer(Response aqlPullResponse, String randomString, int recordsInserted) {
        String data = aqlPullResponse.asString();
        String[] resultArr = data.split("\n");
        for (int i=resultArr.length-1 ; i>=resultArr.length-recordsInserted;i--){
            Assert.assertTrue(resultArr[i].contains(randomString),"Record not found in Buyer for UniqueName : "+randomString);
        }
    }


}
