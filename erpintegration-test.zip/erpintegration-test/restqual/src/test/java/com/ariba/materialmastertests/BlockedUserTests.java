package com.ariba.materialmastertests;

import com.ariba.helpers.*;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import com.ariba.services.MDNI;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.response.Response;
//import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.*;
import java.util.Base64;
import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.Assert.assertTrue;

public class BlockedUserTests extends BaseHelper{

	public static String SAP_ANID = "AN02000919981";
	public static String S4_ANID = "AN02000920006";
	String endPointURLBuyer = "https://qa.cobalt.ariba.com/mdnilsp/erpintegration/api/uploadXMLData?tenantId=" + SAP_ANID
              + "&objectName=";
	String integrationJobURLBuyer = "https://qa.cobalt.ariba.com/mdnilsp/erpintegration/api/integrationJobs?tenantId=" + SAP_ANID
              + "&objectName=";
	String endPointURLSourcing = "https://qa.cobalt.ariba.com/mdnilsp/erpintegration/api/uploadXMLData?tenantId=" + S4_ANID
			+ "&objectName=";
	String integrationJobURLSourcing = "https://qa.cobalt.ariba.com/mdnilsp/erpintegration/api/integrationJobs?tenantId=" + S4_ANID
			+ "&objectName=";
	public static String SAP_REALM = "p2pTeSap-2";
	public static String S4_REALM = "s4All-4";
	public static String SAP_USERNAME = "arooney";
	public static String SERVICE_BUYER="svcgcpic01ss.lab-us.gcpint";
	public static String SERVICE_SOURCING="svcgcpic01ss.lab-us.gcpint";

	OAuthHelper oauthHelper = new OAuthHelper();
	SCIMHelper scimHelper = new SCIMHelper();
	MDSSearchHelper searchHelper = new MDSSearchHelper();
	MDNI mdni = new MDNI();

	@Test
	public void createBlockedUserWithFullLoadInsertionBuyer() throws Exception {
		
		String userBodyPayload = getData("testMDNIUserWithActionCode01");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_BUYER ,SAP_REALM, Constants.BUYER, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+ HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLBuyer);
		Thread.sleep(180000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void createBlockedUserWithIncrementalLoadInsertionBuyer() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode02");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_BUYER ,SAP_REALM, Constants.BUYER, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void updationBlockedUserWithFullLoadBuyer() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode01");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_BUYER ,SAP_REALM, Constants.BUYER, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		userBodyPayload = userBodyPayload.replace("nobody@ansmtp.ariba.com", getRandomUniqueName+"@sap.com");
		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void updationBlockedUserWithIncrementalLoadBuyer() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode02");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_BUYER ,SAP_REALM, Constants.BUYER, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		userBodyPayload = userBodyPayload.replace("nobody@ansmtp.ariba.com", getRandomUniqueName+"@sap.com");
		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void deleteBlockedUserWithIncrementalLoadInsertionBuyer() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode02");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeleted = jsonObject.get("RecordsDeleted").getAsInt();

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeleted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeleted == 0,
				"NoOfRecordsDeleted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_BUYER ,SAP_REALM, Constants.BUYER, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);
		userBodyPayload = getData("testMDNIUserWithIncrementalLoadActionCode03");
		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLBuyer + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLBuyer);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLBuyer + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 1,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
	}

	@Test
	public void createBlockedUserWithFullLoadInsertionSourcing() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode01");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLSourcing);
		Thread.sleep(180000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_SOURCING ,S4_REALM, Constants.SOURCING, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void createBlockedUserWithIncrementalLoadInsertionSourcing() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode02");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_SOURCING ,S4_REALM, Constants.SOURCING, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void updationBlockedUserWithFullLoadSourcing() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode01");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_SOURCING ,S4_REALM, Constants.SOURCING, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		userBodyPayload = userBodyPayload.replace("nobody@ansmtp.ariba.com", getRandomUniqueName+"@sap.com");
		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void updationBlockedUserWithIncrementalLoadSourcing() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode02");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_SOURCING ,S4_REALM, Constants.SOURCING, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);

		userBodyPayload = userBodyPayload.replace("nobody@ansmtp.ariba.com", getRandomUniqueName+"@sap.com");
		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();
		boolean nonFatalExceptionIsPresent =jsonObject.get("NonFatalExceptions").getAsString().contains("Cannot load or update user with uniqueName "+getRandomUniqueName+", because user is blocked by DPO");

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 0,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(nonFatalExceptionIsPresent,"NonFatalExceptions does not match");
	}

	@Test
	public void deleteBlockedUserWithIncrementalLoadInsertionSourcing() throws Exception {

		String userBodyPayload = getData("testMDNIUserWithActionCode02");
		String getRandomUniqueName = RandomStringUtils.randomAlphanumeric(5);
		System.out.print("UniqueName : "+getRandomUniqueName+"\n");

		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse response = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String response1 = response.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobID = verifySuccessResponse(response1, "User",integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		JsonParser parser = new JsonParser();
		JsonElement json = parser.parse(responseIntegrationJob);
		JsonObject jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdated = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInserted = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeleted = jsonObject.get("RecordsDeleted").getAsInt();

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdated + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInserted + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeleted + "\n");

		Assert.assertTrue(NoOfRecordsUpdated == 0,
				"NoOfRecordsUpdated with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInserted == 1,
				"NoOfRecordsInserted with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeleted == 0,
				"NoOfRecordsDeleted with uniquename " + getRandomUniqueName + " is not correct");

		// Blocking user
		/* Generating access token */
		String tokenForBlockedUserApi = oauthHelper.get2loPrivateAccessToken(BLOCKEDUSER_BASE64);
		/* Making API call to Blocked User */
		Response patchBlockedUserResponse = mdni.patchBlockUser(tokenForBlockedUserApi, "{\"status\":\"blocked\"}", SERVICE_SOURCING ,S4_REALM, Constants.SOURCING, getRandomUniqueName);
		Assert.assertEquals(patchBlockedUserResponse.getStatusCode(), HttpStatus.SC_OK,
				"Response code should be "+HttpStatus.SC_OK+" when trying to PATCH block user");

		Thread.sleep(100000);
		userBodyPayload = getData("testMDNIUserWithIncrementalLoadActionCode03");
		userBodyPayload = userBodyPayload.replace("XXX", getRandomUniqueName);
		RestResponse responseAfterBlocked = retrieveStatusFromAPI(endPointURLSourcing + "User", userBodyPayload);
		String responseAfterBlocked1 = responseAfterBlocked.getContent();
		Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + response.getCode());
		String jobIDAfterBlocked = verifySuccessResponse(responseAfterBlocked1, "User", integrationJobURLSourcing);
		Thread.sleep(100000);
		RestResponse responseIntegrationJobAfterBlocked = getStatusAPI(integrationJobURLSourcing + "User" + "&jobId=" + jobIDAfterBlocked);
		String responseIntegrationJobAfterBlocked1 = responseIntegrationJobAfterBlocked.getContent();
		parser = new JsonParser();
		json = parser.parse(responseIntegrationJobAfterBlocked1);
		jsonObject = json.getAsJsonObject();
		int NoOfRecordsUpdatedAfterBlocked = jsonObject.get("RecordsUpdated").getAsInt();
		int NoOfRecordsInsertedAfterBlocked = jsonObject.get("RecordsInserted").getAsInt();
		int NoOfRecordsDeletedAfterBlocked = jsonObject.get("RecordsDeleted").getAsInt();

		System.out.print("NoOfRecordsUpdated is : " + NoOfRecordsUpdatedAfterBlocked + "\n");
		System.out.print("NoOfRecordsDeleted is : " + NoOfRecordsDeletedAfterBlocked + "\n");
		System.out.print("NoOfRecordsInserted is : " + NoOfRecordsInsertedAfterBlocked + "\n");

		Assert.assertTrue(NoOfRecordsUpdatedAfterBlocked == 0,
				"NoOfRecordsUpdatedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsInsertedAfterBlocked == 0,
				"NoOfRecordsInsertedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
		Assert.assertTrue(NoOfRecordsDeletedAfterBlocked == 1,
				"NoOfRecordsDeletedAfterBlocked with uniquename " + getRandomUniqueName + " is not correct");
	}

	public String getData(String dataType)
			throws InvalidFormatException, IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {

		HashMap<String, String> masterData = new HashMap<String, String>();
		String rootDir = System.getProperty("user.dir");
		String filename = "mdniPayload_MaterialMaster.xlsx";
		JSONArray entitiesArray = new JSONArray();

		InputStream file = new FileInputStream(rootDir + "/resources/mdnifiles/" + filename);

		// InputStream file = new
		// FileInputStream("/Users/i330270/Downloads/mdniPayload_MaterialMaster.xlsx");
		// File file = new File("/Users/i330270/Downloads/mdniPayload1.xlsx");

		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet("PayLoad");
		int rowCount = sheet.getLastRowNum();
		for (int i = 1; i <= rowCount; i++) {
			String key = sheet.getRow(i).getCell(0).getStringCellValue();
			String value = sheet.getRow(i).getCell(1).getStringCellValue();
			masterData.put(key, value);
		}
		// wb.close();
		return masterData.get(dataType);
	}

	public String getRandomString(int length) {
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < length) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();

		System.out.print("Random UniqueName is : " + saltStr + "\n");
		return saltStr;
	}

	public String getRandomint(int length) {
		String SALTCHARS = "0123456789";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < length) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();

		System.out.print("Random UniqueNumber id is : " + saltStr + "\n");
		return saltStr;
	}

	private RestResponse retrieveStatusFromAPI(String endPointURL, String body) {

		RestResponse response = null;

		try {
			String userCredentials = "aribaws" + ":" + "aribaaribaariba";
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			HttpRequests connection = new HttpRequests();
			response = connection.httpPost(endPointURL, basicAuth, body);
			// response = connection.httpPostWithCert(endPointURL, basicAuth,
			// body, sslSf);
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}

		return response;
	}

	private RestResponse getStatusAPI(String endPointURL) {
		RestResponse response = null;

		try {
			String userCredentials = "aribaws" + ":" + "aribaaribaariba";
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			HttpRequests connection = new HttpRequests();
			response = connection.httpGet(endPointURL, null, basicAuth);
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}

		return response;
	}

	public String verifySuccessResponse(String response, String objectName, String integrationJobURL) {

		String responsepattern = "JobId .*";
		Pattern pattern = Pattern.compile(responsepattern, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(response);
		String jobID = response.replace("JobId ", "");

		if (jobID.contains("+")) {
			jobID = jobID.replace("+", "%2B");
		}

		boolean matches = matcher.matches();
		assertTrue("jobID does not match", matches == true);

		// Verify the status to be Processed
		int i = 0;
		try {
			for(i=0;i<=6;i++) {

				Thread.sleep(20000);
				
				if (!verifyStatusforJobID(jobID, objectName,integrationJobURL).equals("Pending Processing")) {
						i = 6;
				}
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
		
		
		return jobID;

	}

	private String verifyStatusforJobID(String jobID, String objectName,String integrationJobURL ) {

		RestResponse responseIntegrationJob1 = getStatusAPI(integrationJobURL + objectName + "&jobId=" + jobID);
		String responseIntegrationJob = responseIntegrationJob1.getContent();
		System.out.print("responseIntegrationJob : " + responseIntegrationJob + "\n");

		Assert.assertEquals(responseIntegrationJob1.getCode(), BaseHelper.HTTP_200,
				"Response message is not same Expected 200 and Actual " + responseIntegrationJob1.getCode());

		if (!responseIntegrationJob.equals("{}")) {
			JSONObject json = new JSONObject(responseIntegrationJob);
			String status = json.getString("Status");
			return status;
		}

		else {
			return "";
		}

	}

}
