package com.ariba.resttests;

import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.PostXMLDataHelper;
import com.ariba.pojos.RestResponse;

public class ConcurrentPostXMLDataTests2 {

	PostXMLDataHelper pHelper = new PostXMLDataHelper();
	String rootDir = System.getProperty("user.dir");

	@Test(invocationCount = 10, threadPoolSize = 10)
	public void concurrentIncoTerms() throws Exception {
		long tnum = Thread.currentThread().getId();
		System.out.println("Current Thread ID -------------" + tnum);
		
		//String incoTermsData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\"><soapenv:Header/><soapenv:Body><n0:IncotermsMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS1BC60951EFD2657D810E:752\"><MessageHeader><ID>42F2E9AFC3DF1EE6ACA7831C60BCAEFF</ID><UUID>42f2e9af-c3df-1ee6-aca7-831c60bcaeff</UUID><CreationDateTime>2016-11-23T05:17:12.510Z</CreationDateTime><SenderBusinessSystemID>ER9_001</SenderBusinessSystemID></MessageHeader><ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator><TransmissionStartDateTime>2016-11-23T05:17:12.510Z</TransmissionStartDateTime><Incoterms><Code><content>$$$</content></Code><LocationMandatoryIndicator>true</LocationMandatoryIndicator><Description languageCode=\"EN\">Costs and freight</Description></Incoterms></n0:IncotermsMasterDataReplicationBundleRequest></soapenv:Body></soapenv:Envelope>";
		String incoTermsData = BaseHelper.getStringFromXML("/resources/datafiles/incoTerms.txt");
		incoTermsData = incoTermsData.replace("$$$", tnum + "");

		switch ((int) tnum % 10) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			RestResponse incoTerms1 = pHelper.postIncoTerms("AN71000002054", incoTermsData, "aribaws", "aribaws12345");
			//String incoTerms1 = pHelper.postIncoTerms("ANXXX0002", incoTermsData, "ariba", "aribaariba123");
			System.err.println(incoTerms1.getCode());
			break;

		default:
			RestResponse incoTerms2 = pHelper.postIncoTerms("AN71000000764", incoTermsData, "aribaws", "aribaws12345");
			//String incoTerms2 = pHelper.postIncoTerms("ANXXX0002", incoTermsData, "ariba", "aribaariba123");
			System.err.println(incoTerms2.getCode());
			break;

		}
	}
	
	@Test(invocationCount = 10, threadPoolSize = 10)
	public void concurrentPurchaseGroups() throws Exception {
		long tnum = Thread.currentThread().getId();
		System.out.println("Current Thread ID -------------" + tnum);
		
	//	String poData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\"><soapenv:Header/><soapenv:Body><n0:PurchasingGroupMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS98086E7B8FC398853BDF:752\"><MessageHeader><ID>42F2E9AFBE7F1ED6ACCB473E7D11A0D4</ID><UUID>42f2e9af-be7f-1ed6-accb-473e7d11a0d4</UUID><CreationDateTime>2016-11-24T15:25:29Z</CreationDateTime><SenderBusinessSystemID>ER9_001</SenderBusinessSystemID></MessageHeader><PurchasingGrpReplicationRequestMessage><ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator><TransmissionStartDateTime>2016-11-24T15:25:29Z</TransmissionStartDateTime><PurchasingGroup><PurchasingGroupID>$$$</PurchasingGroupID><PurchasingGroupName>Einkaufer 1</PurchasingGroupName></PurchasingGroup></PurchasingGrpReplicationRequestMessage></n0:PurchasingGroupMasterDataReplicationBundleRequest></soapenv:Body></soapenv:Envelope>";
		String poData = BaseHelper.getStringFromXML("/resources/datafiles/purchaseGroup.txt");
		poData = poData.replace("$$$", "PO"+tnum);
		
		switch ((int) tnum % 10) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			RestResponse po1 = pHelper.postPurchaseGroup("AN71000002054", poData, "aribaws", "aribaws12345");
		//	String po1 = pHelper.postPurchaseGroup("ANXXX0002", poData, "ariba", "aribaariba123");
			System.err.println(po1.getCode());
			break;

		default:
			RestResponse po2 = pHelper.postPurchaseGroup("AN71000000764", poData, "aribaws", "aribaws12345");
		//	String po2 = pHelper.postPurchaseGroup("ANXXX0002", poData, "ariba", "aribaariba123");
			System.err.println(po2.getCode());
			break;

		}
	}
}
