package com.ariba.utilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class CSVUtils {

	private static final char DEFAULT_SEPARATOR = ',';
	private static final char DEFAULT_QUOTE = '"';

	public static void main(String[] args) throws Exception {

		CSVUtils cv = new CSVUtils();
		// cv.incoTermsXML();
		// cv.purchaseGroupXML();
		// cv.companyCodeXML();
		// cv.itemCategoryXML();
		// cv.currencyConversionXML();
		// cv.materialGroupXML();
		// cv.purchaseOrgXML();
		// cv.accountCategoryXML();
		// cv.currencyMappingXML();
		// cv.uomMappingXML();
		// cv.costCenterXML();
		// cv.generalLedgerXML();
		 cv.wbsElementXML();
		// cv.plantPurchaseOrgXML();
		// cv.plantXML();
		// cv.paymentTermsXML();
	}

	public static List<String> parseLine(String cvsLine) {
		return parseLine(cvsLine, DEFAULT_SEPARATOR, DEFAULT_QUOTE);
	}

	public static List<String> parseLine(String cvsLine, char separators) {
		return parseLine(cvsLine, separators, DEFAULT_QUOTE);
	}

	public static List<String> parseLine(String cvsLine, char separators, char customQuote) {

		List<String> result = new ArrayList<String>();

		// if empty, return!
		if (cvsLine == null && cvsLine.isEmpty()) {
			return result;
		}

		if (customQuote == ' ') {
			customQuote = DEFAULT_QUOTE;
		}

		if (separators == ' ') {
			separators = DEFAULT_SEPARATOR;
		}

		StringBuffer curVal = new StringBuffer();
		boolean inQuotes = false;
		boolean startCollectChar = false;
		boolean doubleQuotesInColumn = false;

		char[] chars = cvsLine.toCharArray();

		for (char ch : chars) {

			if (inQuotes) {
				startCollectChar = true;
				if (ch == customQuote) {
					inQuotes = false;
					doubleQuotesInColumn = false;
				} else {

					// Fixed : allow "" in custom quote enclosed
					if (ch == '\"') {
						if (!doubleQuotesInColumn) {
							curVal.append(ch);
							doubleQuotesInColumn = true;
						}
					} else {
						curVal.append(ch);
					}

				}
			} else {
				if (ch == customQuote) {

					inQuotes = true;

					// Fixed : allow "" in empty quote enclosed
					if (chars[0] != '"' && customQuote == '\"') {
						curVal.append('"');
					}

					// double quotes in column will hit this!
					if (startCollectChar) {
						curVal.append('"');
					}

				} else if (ch == separators) {

					result.add(curVal.toString());

					curVal = new StringBuffer();
					startCollectChar = false;

				} else if (ch == '\r') {
					// ignore LF characters
					continue;
				} else if (ch == '\n') {
					// the end, break!
					break;
				} else {
					curVal.append(ch);
				}
			}

		}

		result.add(curVal.toString());

		return result;
	}

	public static void incoTermsXML() throws IOException {

		File fout = new File("Incoterms.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/IncoTermsExport.csv";
		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:IncotermsMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS1BC60951EFD2657D810E:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFC3DF1EE6ACA7831C60BCAEFF</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-c3df-1ee6-aca7-831c60bcaeff</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-11-23T05:17:12.510Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-23T05:17:12.510Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("Incoterms [content= " + line.get(0) + ", LocationMandatoryIndicator= " + line.get(1)
						+ " , Description=" + line.get(2) + "]");
				bw.write("<Incoterms>");
				bw.newLine();
				bw.write("<Code>");
				bw.newLine();
				bw.write("<content>" + line.get(0) + "</content>");
				bw.newLine();
				bw.write("</Code>");
				bw.newLine();
				bw.write("<LocationMandatoryIndicator>" + line.get(1) + "</LocationMandatoryIndicator>");
				bw.newLine();
				bw.write("<Description languageCode=\"EN\">" + line.get(2) + "</Description>");
				bw.newLine();
				bw.write("</Incoterms>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));

		bw.write("</n0:IncotermsMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}

	public static void purchaseGroupXML() throws IOException {

		File fout = new File("PurchaseGroup.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/PurchaseGroupExport.csv";
		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:PurchasingGroupMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS98086E7B8FC398853BDF:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFBE7F1ED6ACCB473E7D11A0D4</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-be7f-1ed6-accb-473e7d11a0d4</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-11-24T15:25:29Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<PurchasingGrpReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-24T15:25:29Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("PurchaseGroup [Name= " + line.get(0) + ", ID= " + line.get(1) + "]");
				bw.write("<PurchasingGroup>");
				bw.newLine();
				bw.write("<PurchasingGroupID>" + line.get(1) + "</PurchasingGroupID>");
				bw.newLine();
				bw.write("<PurchasingGroupName>" + line.get(0) + "</PurchasingGroupName>");
				bw.newLine();
				bw.write("</PurchasingGroup>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));

		bw.write("</PurchasingGrpReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:PurchasingGroupMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}

	public static void companyCodeXML() throws IOException {

		File fout = new File("CompanyCode.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/CompanyCodeExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:BNSCompanyCodeMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ERW:/1SAI/TASD11108EA78A03EF3E3D2:751\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>FA163EB372321EE6AF8BE10D95CE952D</ID>");
		bw.newLine();
		bw.write("<UUID>fa163eb3-7232-1ee6-af8b-e10d95ce952d</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-11-24T15:25:29Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>QE6CLNT910</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<CompanyCodeReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-12-07T09:23:59Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("CompanyCode [ID= " + line.get(0) + ", Name= " + line.get(1) + "]");
				bw.write("<CompanyCode>");
				bw.newLine();
				bw.write("<CompanyCode>" + line.get(0) + "</CompanyCode>");
				bw.newLine();
				bw.write("<CompanyCodeName>" + line.get(1) + "</CompanyCodeName>");
				bw.newLine();
				bw.write("</CompanyCode>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));

		bw.write("</CompanyCodeReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:BNSCompanyCodeMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}

	public static void itemCategoryXML() throws IOException {

		File fout = new File("ItemCategory.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/ItemCategoryExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:PurchaseDocumentItemCategoryMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS5EAFE55415A486D98B0B:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFBE7F1EE6ACC099562EB1BFF4</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-be7f-1ee6-acc0-99562eb1bff4</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-11-24T05:13:55.071Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-24T05:13:55.071Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("ItemCategory [Content= " + line.get(0) + ", Description= " + line.get(1) + "]");
				bw.write("<PurchaseDocumentItemCategory>");
				bw.newLine();
				bw.write("<Code>");
				bw.newLine();
				bw.write("<content>" + line.get(0) + "</content>");
				bw.newLine();
				bw.write("</Code>");
				bw.newLine();
				bw.write("<Description languageCode=\"EN\">" + line.get(1) + "</Description>");
				bw.newLine();
				bw.write("</PurchaseDocumentItemCategory>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));

		bw.write("</n0:PurchaseDocumentItemCategoryMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}

	public static void currencyConversionXML() throws IOException {

		File fout = new File("CurrencyConversion.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/CurrencyConversionRateExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:ExchangeRateMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TASACD6C4417150B2C9D3AC:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFBE7F1ED6ACC3D5E72AD352C2</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-be7f-1ed6-acc3-d5e72ad352c2</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2016-11-24T08:19:15.605Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-24T08:19:15.605Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				String content = line.get(0);
				content = "" + line.get(3).substring(0, 2) + line.get(1).substring(0, 2);
				System.out.println("CurrencyConversion [Content= " + content + ", ToCurrency= " + line.get(1)
						+ ", ConversionDate= " + line.get(2) + ", FromCurrency= " + line.get(3) + ", ConversionRate= "
						+ line.get(4) + "]");
				bw.write("<ExchangeRate>");
				bw.newLine();
				String cr = (line.get(4)).replaceAll("\"", "");
				if(cr.length()>14)
					cr = cr.substring(0, 14);
				bw.write("<ConversionRate>" + cr + "</ConversionRate>");
				String d = (line.get(2)).replaceAll("\"", "");
				Date dd = new Date(d);
				String d1 = DateFormatter.getDateInFormat(dd, "yyyy-MM-dd");
				System.out.println("Date------"+d1);
				bw.newLine();
				bw.write("<ConversionDate>" + d1 + "</ConversionDate>");
				bw.newLine();
				bw.write("<TypeCode>");
				bw.newLine();
				bw.write("<content>" + content.replaceAll("\"", "") + "</content>");
				bw.newLine();
				bw.write("</TypeCode>");
				bw.newLine();
				bw.write("<ToCurrencyCode>");
				bw.newLine();
				bw.write("<content>" + (line.get(1)).replaceAll("\"", "") + "</content>");
				bw.newLine();
				bw.write("</ToCurrencyCode>");
				bw.newLine();
				bw.write("<FromCurrencyCode>");
				bw.newLine();
				bw.write("<content>" + (line.get(3)).replaceAll("\"", "") + "</content>");
				bw.newLine();
				bw.write("</FromCurrencyCode>");
				bw.newLine();
				bw.write("</ExchangeRate>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));

		bw.write("</n0:ExchangeRateMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}

	public static void materialGroupXML() throws IOException {

		File fout = new File("MaterialGroup.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/PartitionedCommodityCodeExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:MaterialGroupMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS99EC7233576C6CB57CB4:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFC4EF1ED6AC984EC8769B06ED</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-c4ef-1ed6-ac98-4ec8769b06ed</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-31T14:46:28.979Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-22T14:46:28.979Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("MaterialGroup [Content= " + line.get(1) + ", Description= " + line.get(2) + "]");
				bw.write("<MaterialGroup>");
				bw.newLine();
				bw.write("<Code>");
				bw.newLine();
				bw.write("<content>" + line.get(1) + "</content>");
				bw.newLine();
				bw.write("</Code>");
				bw.newLine();
				bw.write("<Description languageCode=\"EN\">" + line.get(2) + "</Description>");
				bw.newLine();
				bw.write("</MaterialGroup>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));

		bw.write("</n0:MaterialGroupMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void purchaseOrgXML() throws IOException {

		File fout = new File("PurchaseOrg.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/PurchaseOrgExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:PurchasingOrganisationMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS8DA5EC19A75BCEFCC26C:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFC4EF1ED6ACCC1C09220ECFFF</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-c4ef-1ed6-accc-1c09220ecfff</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-31T16:13:00Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<PurchasingOrgReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-22T14:46:28.979Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("PurchasingOrg [ID= " + line.get(2) + ", Name = "+line.get(0) +"CompanyCode= " + line.get(1) + "]");
				bw.write("<PurchasingOrg>");
				bw.newLine();
				bw.write("<PurchasingOrgID>" + line.get(2) + "</PurchasingOrgID>");
				bw.newLine();
				bw.write("<PurchasingOrgName>" + line.get(0) + "</PurchasingOrgName>");
				bw.newLine();
				bw.write("<CompanyCode>" + line.get(1) + "</CompanyCode>");
				bw.newLine();
				bw.write("</PurchasingOrg>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</PurchasingOrgReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:PurchasingOrganisationMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void accountCategoryXML() throws IOException {

		File fout = new File("AccountCategory.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/AccountCategoryExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:AccountAssignmentCategoryMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ERW:/1SAI/TASD7E0953175F3927C64EA:751\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFC4EF1ED6ACCC1C09220ECFFF</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-c4ef-1ed6-accc-1c09220ecfff</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-31T16:13:00Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>0MB85UO</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<AccountAssignmentCategoryReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-12-07T09:27:51Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("AccountCategory [ID= " + line.get(0) + ", Description = "+line.get(2) +"]");
				bw.write("<AccountAssignmentCategory>");
				bw.newLine();
				bw.write("<AccountAssignmentCategoryID>" + line.get(0) + "</AccountAssignmentCategoryID>");
				bw.newLine();
				bw.write("<AccountAssignmentCategoryDescription>" + line.get(2) + "</AccountAssignmentCategoryDescription>");
				bw.newLine();
				bw.write("</AccountAssignmentCategory>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</AccountAssignmentCategoryReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:AccountAssignmentCategoryMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void currencyMappingXML() throws IOException {

		File fout = new File("CurrencyMap.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/CurrencyMapExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:CurrencyMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS142CDEEC82258D646DD9:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFC3DF1ED6ACC29F9876BA1923</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-c3df-1ed6-acc2-9f9876ba1923</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-31T16:13:00Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-24T07:09:47.115Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("CurrencyMap [Code= " + line.get(3) + ", ISOCode = "+line.get(2) +", Description = "+ line.get(1) +"]");
				bw.write("<Currency>");
				bw.newLine();
				bw.write("<Code>");
				bw.newLine();
				bw.write("<content>" + line.get(3) + "</content>");
				bw.newLine();
				bw.write("</Code>");
				bw.newLine();
				bw.write("<ISOCurrencyCode>");
				bw.newLine();
				bw.write("<content>" + line.get(2) + "</content>");
				bw.newLine();
				bw.write("</ISOCurrencyCode>");
				bw.newLine();
				bw.write("<NumberOfDecimalPlaces>0</NumberOfDecimalPlaces>");
				bw.newLine();
				bw.write("<LongDescription languageCode=\"EN\">" + line.get(1) + "</LongDescription>");
				bw.newLine();
				bw.write("<ShortDescription languageCode=\"EN\">" + line.get(1) + "</ShortDescription>");
				bw.newLine();
				bw.write("</Currency>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</n0:CurrencyMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void uomMappingXML() throws IOException {

		File fout = new File("UOMMap.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/UnitOfMeasureMapExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:UnitOfMeasurementMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:QEX:/1SAI/TAEDB851441ECDFC014E0FF:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>0894EF301CCD1EE7B8A0EB331632CD82</ID>");
		bw.newLine();
		bw.write("<UUID>0894ef30-1ccd-1ee7-b8a0-eb331632cd82</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-31T16:13:00Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>QEX_910</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<UnitOfMeasurementReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-24T07:09:47.115Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("UOMMap [Code= " + line.get(2) + ", ISOCode = "+line.get(1) +", Description = "+ line.get(0) +", Preferred = "+line.get(3) +"]");
				bw.write("<UnitOfMeasurement>");
				bw.newLine();
				bw.write("<Code>");
				bw.newLine();
				bw.write("<content>" + line.get(2) + "</content>");
				bw.newLine();
				bw.write("</Code>");
				bw.newLine();
				bw.write("<ISOCode>");
				bw.newLine();
				bw.write("<content>" + line.get(1) + "</content>");
				bw.newLine();
				bw.write("</ISOCode>");
				bw.newLine();
				bw.write("<CommercialDescription languageCode=\"EN\">" + line.get(0) + "</CommercialDescription>");
				bw.newLine();
				bw.write("<LongDescription languageCode=\"EN\">" + line.get(0) + "</LongDescription>");
				bw.newLine();
				bw.write("<AllownonwholeIndicator>true</AllownonwholeIndicator>");
				bw.newLine();
				if((line.get(3)).equalsIgnoreCase("no"))
					bw.write("<PreferredMappingIndicator>"+false+"</PreferredMappingIndicator>");
				else
					bw.write("<PreferredMappingIndicator>"+true+"</PreferredMappingIndicator>");
				bw.newLine();
				bw.write("<Category>1</Category>");
				bw.newLine();
				bw.write("<NumberOfDecimalPlaces>1</NumberOfDecimalPlaces>");
				bw.newLine();
				bw.write("</UnitOfMeasurement>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</UnitOfMeasurementReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:UnitOfMeasurementMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void costCenterXML() throws IOException {

		File fout = new File("CostCenter.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/CostCenterExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:BNSCostCentreMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS3CD26C740073BF5A4D54:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>42F2E9AFC5FF1ED6AFAC50B2FF9C4B98</ID>");
		bw.newLine();
		bw.write("<UUID>42f2e9af-c5ff-1ed6-afac-50b2ff9c4b98</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-08T16:22:38Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_003</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>FIELDGLASS</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("CostCenter [ID= " + line.get(0) + ", Description = "+line.get(2) +", CompanyCode = "+line.get(3) +"]");
				bw.write("<CostCentreReplicationRequestMessage>");
				bw.newLine();
				bw.write("<MessagerHeader />");
				bw.newLine();
				bw.write("<TransmissionStartDateTime>2016-12-08T16:22:38Z</TransmissionStartDateTime>");
				bw.newLine();
				bw.write("<CostCentre>");
				bw.newLine();
				bw.write("<CurrencyKey>USD</CurrencyKey>");
				bw.newLine();
				bw.write("<CostCentreKey>");
				bw.newLine();
				bw.write("<CompanyCode>" + line.get(3) + "</CompanyCode>");
				bw.newLine();
				bw.write("<CostCentre>" + line.get(0) + "</CostCentre>");
				bw.newLine();
				bw.write("</CostCentreKey>");
				bw.newLine();
				String name=line.get(2);
				if(name.equalsIgnoreCase(""))
					bw.write("<CostCentreName languageCode=\"EN\">cname</CostCentreName>");
				else
					bw.write("<CostCentreName languageCode=\"EN\">" + name.replaceAll("\"", "").replaceAll("<", "ls") + "</CostCentreName>");
				bw.newLine();
				bw.write("</CostCentre>");
				bw.newLine();
				bw.write("</CostCentreReplicationRequestMessage>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</n0:BNSCostCentreMasterDataReplicationBulkRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void generalLedgerXML() throws IOException {

		File fout = new File("GLAccount.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/GeneralLedgerExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:BNSGLAccountMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/APPL/BNSFINMDR\" xmlns:prx=\"urn:sap.com:proxy:ERW:/1SAI/TASD7E0953175F3927C64EA:751\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>FA163EB372321EE6AF8BF504266B553A</ID>");
		bw.newLine();
		bw.write("<UUID>fa163eb3-7232-1ee6-af8b-f504266b553a</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-07T09:27:51Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ERW_600</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>QE6CLNT910</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("GLAccount [ID= " + line.get(0) + ", Name = "+line.get(2) +", CompanyCode = "+line.get(3) +"]");
				bw.write("<GLAccountReplicationRequestMessage>");
				bw.newLine();
				bw.write("<MessagerHeader />");
				bw.newLine();
				bw.write("<TransmissionStartDateTime>2016-12-07T09:27:51Z</TransmissionStartDateTime>");
				bw.newLine();
				bw.write("<GLAccount>");
				bw.newLine();
				bw.write("<IsRelevantForProcurementIndicator>true</IsRelevantForProcurementIndicator>");
				bw.newLine();
				bw.write("<GLAccountKey>");
				bw.newLine();
				if(line.get(3).equalsIgnoreCase(""))
					bw.write("<CompanyCode>0001</CompanyCode>");
				else
					bw.write("<CompanyCode>" + line.get(3) + "</CompanyCode>");
				/*
				if(((line.get(3))!=null)||((line.get(3))!=""))
					bw.write("<CompanyCode>" + line.get(3) + "</CompanyCode>");
				else
					bw.write("<CompanyCode>0001</CompanyCode>");
					*/
				bw.newLine();
				bw.write("<GLAccount>" + line.get(0) + "</GLAccount>");
				bw.newLine();
				bw.write("</GLAccountKey>");
				bw.newLine();
				bw.write("<GLAccountName languageCode=\"EN\">" + line.get(2) + "</GLAccountName>");
				bw.newLine();
				bw.write("</GLAccount>");
				bw.newLine();
				bw.write("</GLAccountReplicationRequestMessage>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</n0:BNSGLAccountMasterDataReplicationBulkRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void wbsElementXML() throws IOException {

		File fout = new File("WBSElement4.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/WBS4.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:WBSElementMasterDataReplicationBulkRequest xmlns:n0=\"http://sap.com/xi/PS\" xmlns:prx=\"urn:sap.com:proxy:CC2:/1SAI/TAE61A28A667A7D3E4E2B1E:768\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>8CDCD4008ED01ED6BD81DFE0C2BE91EA</ID>");
		bw.newLine();
		bw.write("<UUID>8cdcd400-8ed0-1ed6-bd81-dfe0c2be91ea</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-12-16T06:14:18Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>0MB85VI</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("<RecipientBusinessSystemID>PS_ARIBA_0111</RecipientBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("WBSElement [WBSElement= " + line.get(0) + ", ID = "+line.get(1) +", Description = "+line.get(2) +"]");
				bw.write("<WBSElementReplicationRequestMessage>");
				bw.newLine();
				bw.write("<MessagerHeader />");
				bw.newLine();
				bw.write("<TransmissionStartDateTime>2017-02-16T06:14:18Z</TransmissionStartDateTime>");
				bw.newLine();
				bw.write("<WBSElement>");
				bw.newLine();
				bw.write("<IsRelevantForProcurementIndicator>true</IsRelevantForProcurementIndicator>");
				bw.newLine();
				bw.write("<ActionCode>01</ActionCode>");
				bw.newLine();
				bw.write("<WBSElement>" + line.get(0) + "</WBSElement>");
				bw.newLine();
				bw.write("<WBSElementInternalID>" + line.get(1) + "</WBSElementInternalID>");
				bw.newLine();
				bw.write("<Project>" + line.get(0) + "</Project>");
				bw.newLine();
				bw.write("<ProjectInternalID>" + line.get(1) + "</ProjectInternalID>");
				bw.newLine();
				String desc = line.get(2);
				if(desc.equalsIgnoreCase(""))
					bw.write("<Description>desc</Description>");
				else
					bw.write("<Description>" + desc.replaceAll("\"", "").replaceAll("&", "") + "</Description>");
				bw.newLine();
				bw.write("<CompanyCode>3000</CompanyCode>");
				bw.newLine();
				bw.write("<ControllingArea>A000</ControllingArea>");
				bw.newLine();
				bw.write("<ProfitCenter>YB101</ProfitCenter>");
				bw.newLine();
				bw.write("<Currency>USD</Currency>");
				bw.newLine();
				bw.write("<ControllingObjectClass>");
				bw.newLine();
				bw.write("<content>OC</content>");
				bw.newLine();
				bw.write("</ControllingObjectClass>");
				bw.newLine();
				bw.write("<WBSElementIsPlanningElement>false</WBSElementIsPlanningElement>");
				bw.newLine();
				bw.write("<WBSIsAccountAssignmentElement>true</WBSIsAccountAssignmentElement>");
				bw.newLine();
				bw.write("<WBSElementIsBillingElement>false</WBSElementIsBillingElement>");
				bw.newLine();
				bw.write("<WBSIsStatisticalWBSElement>false</WBSIsStatisticalWBSElement>");
				bw.newLine();
				bw.write("</WBSElement>");
				bw.newLine();
				bw.write("</WBSElementReplicationRequestMessage>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</n0:WBSElementMasterDataReplicationBulkRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void plantPurchaseOrgXML() throws IOException {

		File fout = new File("PlantPOrgCombo.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/PlantPurchaseOrgComboExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.cxf/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:PlantPurchasingOrgMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAE4C4402FC5B19557CA9EA:753\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>8CDCD4000C701EE79C93FB3B24B036EE</ID>");
		bw.newLine();
		bw.write("<UUID>8cdcd400-0c70-1ee7-9c93-fb3b24b036ee</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-07-24T18:42:32Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<PlantPurchasingOrgReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2017-07-24T18:42:32Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				System.out.println("PlantPOrgCombo [POrgID= " + line.get(0) + ", PlantID = "+line.get(1) +"]");
				bw.write("<PlantPurchasingOrg>");
				bw.newLine();
				if(line.get(0).equalsIgnoreCase(""))
					bw.write("<PurchasingOrgID>Z200</PurchasingOrgID>");
				else
					bw.write("<PurchasingOrgID>" + line.get(0) + "</PurchasingOrgID>");
				bw.newLine();
				String plantId = line.get(1);
				plantId = plantId.replaceAll("\"", "");
				bw.write("<PlantID>" + plantId
						+ "</PlantID>");
				bw.newLine();
				bw.write("</PlantPurchasingOrg>");
				bw.newLine();
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		
		bw.write("</PlantPurchasingOrgReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:PlantPurchasingOrgMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void plantXML() throws IOException {

		File fout = new File("Plant.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		int err = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/PlantExport1.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:ser=\"http://service.cxf/\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:PlantMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<ID>8CDCD4000C701EE79C93F28F78225669</ID>");
		bw.newLine();
		bw.write("<UUID>8cdcd400-0c70-1ee7-9c93-f28f78225669</UUID>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-07-24T18:40:34Z</CreationDateTime>");
		bw.newLine();
		bw.write("<SenderBusinessSystemID>ER9_001</SenderBusinessSystemID>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<PlantReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>true</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2017-07-24T18:40:34Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				try{
				System.out.println("Plant [ID= " + line.get(1) + ", Name = "+line.get(9) +", City = "+line.get(0) +", postal = "+line.get(8) +", CompanyCode = "+line.get(11) +"]");
				bw.write("<Plant>");
				bw.newLine();
				bw.write("<PlantID>"+ line.get(1) +"</PlantID>");
				bw.newLine();
				bw.write("<PlantName>"+line.get(9)+"</PlantName>");
				bw.newLine();
				bw.write("<PostalAddress>");
				bw.newLine();
				String street = line.get(4) + line.get(5);
				street = street.replaceAll("\"", "");
				if(!street.equalsIgnoreCase(""))
					bw.write("<Street>"+ street +"</Street>");
				bw.newLine();
				bw.write("<HouseNumber>122</HouseNumber>");
				bw.newLine();
				String city = line.get(0);
				city = city.replaceAll("\"", "");
				if(!city.equalsIgnoreCase(""))
					bw.write("<City>"+ city +"</City>");
				bw.newLine();
				String postal = line.get(8);
				postal = postal.replaceAll("\"", "");
				if(!postal.equalsIgnoreCase(""))
					bw.write("<PostalCode>"+ postal +"</PostalCode>");
				bw.newLine();
				bw.write("<Region>01</Region>");
				bw.newLine();
				bw.write("<Country>MA</Country>");
				bw.newLine();
				bw.write("</PostalAddress>");
				bw.newLine();
				String companyCode = line.get(11);
				companyCode = companyCode.replaceAll("\"", "");
				if(companyCode.equalsIgnoreCase(""))
					bw.write("<CompanyCode>3000</CompanyCode>");
				else
					bw.write("<PostalCode>"+ companyCode +"</PostalCode>");
				bw.newLine();
				bw.write("<CurrencyCode>EUR</CurrencyCode>");
				bw.newLine();
				bw.write("</Plant>");
				bw.newLine();
				}catch (Exception e) {
					System.err.println(line);
					err++;
				}
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		System.err.println("No of errors ---------"+err);
		
		bw.write("</PlantReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:PlantMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
	
	public static void paymentTermsXML() throws IOException {

		File fout = new File("PaymentTerms.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		int counter = 0;
		int err = 0;
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		String csvFile = System.getProperty("user.dir") + "/resources/csvfiles/PaymentTermsConsolidatedExport.csv";

		bw.write(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:n0=\"http://sap.com/xi/APPL/LogMDR\" xmlns:ser=\"http://service.cxf/\">");
		bw.newLine();
		bw.write("<soapenv:Header/>");
		bw.newLine();
		bw.write("<soapenv:Body>");
		bw.newLine();
		bw.write(
				"<n0:BNSPaymentTermsMasterDataReplicationBundleRequest xmlns:n0=\"http://sap.com/xi/FNDEI\" xmlns:prx=\"urn:sap.com:proxy:ER9:/1SAI/TAS1BC60951EFD2657D810E:752\">");
		bw.newLine();
		bw.write("<MessageHeader>");
		bw.newLine();
		bw.write("<CreationDateTime>2017-11-24T15:29:29Z</CreationDateTime>");
		bw.newLine();
		bw.write("</MessageHeader>");
		bw.newLine();
		bw.write("<PaymentTermsReplicationRequestMessage>");
		bw.newLine();
		bw.write("<ListCompleteTransmissionIndicator>1</ListCompleteTransmissionIndicator>");
		bw.newLine();
		bw.write("<TransmissionStartDateTime>2016-11-24T15:25:29Z</TransmissionStartDateTime>");
		bw.newLine();

		Scanner scanner = new Scanner(new File(csvFile));
		while (scanner.hasNext()) {
			List<String> line = parseLine(scanner.nextLine());
			if (counter > 1) {
				try{
				System.out.println("PaymentTerms [UniqueName= " + line.get(2) + ", Description = "+line.get(3) +"]");
				bw.write("<PaymentTerms>");
				bw.newLine();
				bw.write("<Key>");
				bw.newLine();
				bw.write("<UniqueName>"+line.get(2)+"</UniqueName>");
				bw.newLine();
				bw.write("<DayLimit>01</DayLimit>");
				bw.newLine();
				bw.write("</Key>");
				bw.newLine();
				bw.write("<Item>");
				bw.newLine();
				bw.write("<ID>223091</ID>");
				bw.newLine();
				bw.write("<Discount>1</Discount>");
				bw.newLine();
				bw.write("<PayInDays>1</PayInDays>");
				bw.newLine();
				bw.write("<FixedDay>1</FixedDay>");
				bw.newLine();
				bw.write("<AdditionalMonth>1</AdditionalMonth>");
				bw.newLine();
				bw.write("<DiscountType>percent</DiscountType>");
				bw.newLine();
				bw.write("</Item>");
				bw.newLine();
				bw.write("<Description languageCode=\"EN\">");
				bw.newLine();
				if(line.get(3).equalsIgnoreCase(""))
					bw.write("<Description> desc</Description>");
				else	
					bw.write("<Description>"+ line.get(3) +"</Description>");
				bw.newLine();
				bw.write("<Explanation>Explanation1</Explanation>");
				bw.newLine();
				bw.write("</Description>");
				bw.newLine();
				bw.write("</PaymentTerms>");
				bw.newLine();
				}catch (Exception e) {
					System.err.println(line);
					err++;
				}
			}
			counter++;
		}
		scanner.close();
		System.err.println("No of entries ---------" + (counter - 2));
		System.err.println("No of errors ---------"+err);
		
		bw.write("</PaymentTermsReplicationRequestMessage>");
		bw.newLine();
		bw.write("</n0:BNSPaymentTermsMasterDataReplicationBundleRequest>");
		bw.newLine();
		bw.write("</soapenv:Body>");
		bw.newLine();
		bw.write("</soapenv:Envelope>");
		bw.newLine();
		bw.close();
	}
}