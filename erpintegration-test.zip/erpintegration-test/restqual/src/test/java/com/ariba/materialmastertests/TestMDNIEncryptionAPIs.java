package com.ariba.materialmastertests;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.RandomStringUtils;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.Constants;
import com.ariba.helpers.MDSSearchHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.SCIMHelper;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.response.Response;
import org.apache.commons.httpclient.HttpStatus;
import com.ariba.pojos.RestResponse;
import com.google.gson.JsonObject;
import org.testng.asserts.SoftAssert;

public class TestMDNIEncryptionAPIs extends BaseHelper {
	
	OAuthHelper oAuthHelper = new OAuthHelper();
	SCIMHelper scimHelper = new SCIMHelper();
	
	
	@Test
	public void testStartEncryptionJobsScheduleAPI() throws Exception {
		
		System.out.println("=======================Encryption Started=======================");

		/* Generating access token */
		String token = oAuthHelper.getMDNIAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);
		
		
		String getreportJobPayload = getData("testReportEncryptionJob");  
		
		RestResponse result = scimHelper.ecryptionMDNIPost(token, getreportJobPayload,"startEncryptionJobsSchedule");
		System.out.println(result.getContent());
		
		Assert.assertEquals(result.getCode(), 200, "Response code is not matching for Report API Job");
		JSONObject reportJob = (JSONObject) jsonObject(result.getContent());
		
		System.out.println("=======================Encryption Ended=======================");
		
	}
	
	@Test
	public void testEncryptionJobsScheduleAPI() throws Exception {
		
		System.out.println("=======================Encryption Started=======================");

		/* Generating access token */
	/*	String token = oAuthHelper.getMDNIAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);
		
		
		String getreportJobPayload = getData("testReportEncryptionJob");  
		
		RestResponse result = scimHelper.ecryptionMDNIPost(token, getreportJobPayload,"startEncryptionJobsSchedule");
		System.out.println(result.getContent());
		
		//Assert.assertEquals(result.getCode(), 200, "Response code is not matching for Report API Job");
		JSONObject reportJob = (JSONObject) jsonObject(result.getContent());
		
		System.out.println("=======================Encryption Ended=======================");*/
		
	}
	
	@Test
	public void testReportEncryptionJobsProgressAPI() throws Exception {
		
		System.out.println("=======================Report Encryption Started =======================");

		String token = oAuthHelper.getMDNIAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);
		
		
		String getreportJobPayload = getData("testReportEncryptionJob");  
		
		RestResponse result = scimHelper.ecryptionMDNIPost(token, getreportJobPayload,"reportEncryptionJobsProgress");
		System.out.println(result.getContent());
		
		Assert.assertEquals(result.getCode(), 200, "Response code is not matching for Report API Job");
		JSONObject reportJob = (JSONObject) jsonObject(result.getContent());
		
		System.out.println("=======================Report Encryption Ended =======================");
		
	}
	
	@Test
	public void testPauseEncryptionJobsImmediatelyAPI() throws Exception {
		
		System.out.println("=======================Pause Encryption Started=======================");

		String token = oAuthHelper.getMDNIAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);
		
		
		String getreportJobPayload = getData("testReportEncryptionJob");  
		
		RestResponse result = scimHelper.ecryptionMDNIPost(token, getreportJobPayload,"pauseEncryptionJobsImmediately");
		System.out.println(result.getContent());
		
		Assert.assertEquals(result.getCode(), 200, "Response code is not matching for Report API Job");
		JSONObject reportJob = (JSONObject) jsonObject(result.getContent());
		
		System.out.println("=======================Pause Encryption Ended=======================");
		
	}
	
	@Test
	public void testAbortEncryptionJobsImmediatelyAPI() throws Exception {
		
		System.out.println("=======================Abort Encryption Started=======================");

		String token = oAuthHelper.getMDNIAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);
		
		
		String getreportJobPayload = getData("testReportEncryptionJob");  
		
		RestResponse result = scimHelper.ecryptionMDNIPost(token, getreportJobPayload,"abortEncryptionJobsImmediately");
		System.out.println(result.getContent());
		
		Assert.assertEquals(result.getCode(), 200, "Response code is not matching for Report API Job");
		JSONObject reportJob = (JSONObject) jsonObject(result.getContent());
		
		System.out.println("=======================Abort Encryption Ended=======================");
		
	}
	
	@Test
	public void testResumeEncryptionJobsImmediatelyAPI() throws Exception {
		
		System.out.println("=======================Resume Encryption Started=======================");

		String token = oAuthHelper.getMDNIAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
		System.out.println("Token ----" + token);
		
		
		String getreportJobPayload = getData("testReportEncryptionJob");  
		
		RestResponse result = scimHelper.ecryptionMDNIPut(token, getreportJobPayload,"resumeEncryptionJobsImmediately");
		System.out.println(result.getContent());
		
		Assert.assertEquals(result.getCode(), 200, "Response code is not matching for Report API Job");
		JSONObject reportJob = (JSONObject) jsonObject(result.getContent());
		
		System.out.println("=======================Resume Encryption Ended=======================");
		
	}

	public String getData(String dataType)
			throws InvalidFormatException, IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {

		HashMap<String, String> masterData = new HashMap<String, String>();
		String rootDir = System.getProperty("user.dir");
		String filename = "mdniencryptionpayload.xlsx";
		JSONArray entitiesArray = new JSONArray();

		InputStream file = new FileInputStream(rootDir + "/resources/mdnifiles/" + filename);

		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet("PayLoad");
		int rowCount = sheet.getLastRowNum();
		for (int i = 1; i <= rowCount; i++) {
			String key = sheet.getRow(i).getCell(0).getStringCellValue();
			String value = sheet.getRow(i).getCell(1).getStringCellValue();
			masterData.put(key, value);
		}
		// wb.close();
		return masterData.get(dataType);
	}
	
	
	public String[] getResponseWithBaseID(String fetchUserUrl, String fetchbaseId) throws Exception {

		String fetchUserPayload = getData("testFetchUsers");
		
		String[] responseId = new String [2];
		try {
			
			String userCredentials = "aribaws" + ":" + "aribaaribaariba";
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			
			URL url = new URL(fetchUserUrl+fetchbaseId);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			//connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			connection.setRequestProperty("Content-Type","application/json");
			connection.setDoOutput(true);
			connection.setRequestProperty("Authorization",basicAuth);
			DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
			  wr.writeBytes(fetchUserPayload);		
			 
			  BufferedReader in = new BufferedReader(
			          new InputStreamReader(connection.getInputStream()));
			  String output;
			  StringBuffer response = new StringBuffer();
			 
			  while ((output = in.readLine()) != null) {
			  response.append(output);
			  }
			  in.close();			  
			 
			  //printing result from respons;
			  responseId[0] = response.toString();
			 
			  responseId[1] = connection.getHeaderField("lastBaseId");			  
			
		}catch(Exception e) {
			e.printStackTrace();
		}		
		return responseId;
	}

}

