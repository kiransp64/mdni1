package com.ariba.onemds;

import com.ariba.data.cache.MDICache;
import org.testng.annotations.DataProvider;

public class OneMdsDataProvider extends MDICacheData {
    private static Object MDICache;
    public static String IntegratedRealm = "accAcwSap";
    public static String IntegratedAnid = "AN02000580552";
    public static String BuyerRealm = "p2pTeSap-2";
    public static String BuyerAnid = "AN02000580629";
    public static String S4StandaloneRealm = "s4All";
    public static String S4StandaloneAnid = "AN02000580680";

    @DataProvider(name = "eventData")
    public static Object[][] eventData() throws Exception {
        Object data[][] = null;
        try {
            data = new Object[][]{

                    /**
                     * CompanyCode tests can't be run along with the other tests as it need devlab configuration
                     * Uncomment and run separately after changing the configuration
                     * */
//                    new Object[]{"[Integrated] CompanyCode : Create and verify", getcreateCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},//1
//                    new Object[]{"[Integrated] CompanyCode : Create, update description and verify", getcreateAndUpdateCompanyCodeCache(IntegratedRealm), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},//2
//                    new Object[]{"[Integrated] CompanyCode : Create, delete and verify", getcreateAndDeleteCompanyCodeCache(IntegratedAnid), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},//3
//                    new Object[]{"[Integrated] CompanyCode : Create multiple and verify", getcreateMultipleCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CompanyCode : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CompanyCode : Create multiple, delete all and verify", getcreateAndDeleteMultipleCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CompanyCode : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CompanyCode : Create, update, delete and verify", getcreateUpdateAndDeleteCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CompanyCode : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CompanyCode : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CompanyCode : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache(), "CompanyCode", "buyer", IntegratedRealm, IntegratedAnid},
//
//                    new Object[]{"[Buyer] CompanyCode : Create and verify", getcreateCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},//1
//                    new Object[]{"[Buyer] CompanyCode : Create, update description and verify", getcreateAndUpdateCompanyCodeCache(BuyerAnid), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},//2
//                    new Object[]{"[Buyer] CompanyCode : Create, delete and verify", getcreateAndDeleteCompanyCodeCache(BuyerAnid), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},//3
//                    new Object[]{"[Buyer] CompanyCode : Create multiple and verify", getcreateMultipleCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CompanyCode : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CompanyCode : Create multiple, delete all and verify", getcreateAndDeleteMultipleCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CompanyCode : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CompanyCode : Create, update, delete and verify", getcreateUpdateAndDeleteCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CompanyCode : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CompanyCode : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CompanyCode : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache(), "CompanyCode", "buyer", BuyerRealm, BuyerAnid},
//
//                    new Object[]{"[S4 standalone] CompanyCode : Create and verify", getcreateCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},//1
//                    new Object[]{"[S4 standalone] CompanyCode : Create, update description and verify", getcreateAndUpdateCompanyCodeCache(BuyerAnid), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},//2
//                    new Object[]{"[S4 standalone] CompanyCode : Create, delete and verify", getcreateAndDeleteCompanyCodeCache(S4StandaloneAnid), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},//3
//                    new Object[]{"[S4 standalone] CompanyCode : Create multiple and verify", getcreateMultipleCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CompanyCode : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CompanyCode : Create multiple, delete all and verify", getcreateAndDeleteMultipleCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CompanyCode : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CompanyCode : Create, update, delete and verify", getcreateUpdateAndDeleteCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CompanyCode : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CompanyCode : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CompanyCode : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache(), "CompanyCode", "s4", S4StandaloneRealm, S4StandaloneAnid},

//                    new Object[]{"[Integrated] CostCenter : Create and verify", createCostCenterWithCompanyCodePerf(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},//4

                    new Object[]{"[Integrated] CostCenter : Create and verify", getcreateCostCenterWithCompanyCodeCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},//4
                    new Object[]{"[Integrated] CostCenter : Create, update description of costCenter and verify", getcreateUpdateDescriptionOfCostCenterCache(IntegratedAnid), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},//6
                    new Object[]{"[Integrated] CostCenter : Create, delete and verify", getcreateDeleteCostCenterCache(IntegratedAnid), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},//5
                    new Object[]{"[Integrated] CostCenter : Create multiple costcenter using one companyCode and verify", getcreateMultipleCostCenterWithOneCompanyCodeCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create multiple costcenter using different companyCode everytime and verify", getcreateMultipleCostCenterWithDifferentCompanyCodeCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleCostCenterCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create multiple, delete all and verify", getcreateMultipleDeleteAllCostCenterCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteCostCenterCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create, update, delete and verify", getcreateUpdateDeleteCostCenterCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateCostCenterCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateUpdateCostCenterCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] CostCenter : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateDeleteCostCenterCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] CostCenter : Create costcenter first and let records synced and later create the companycodes and verify", getcreateCostCenterFirstThenCompanyCodeCache(), "CostCenter", "buyer", IntegratedRealm, IntegratedAnid},

                    new Object[]{"[Buyer] CostCenter : Create and verify", getcreateCostCenterWithCompanyCodeCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},//4
                    new Object[]{"[Buyer] CostCenter : Create, update description of costCenter and verify", getcreateUpdateDescriptionOfCostCenterCache(BuyerAnid), "CostCenter", "buyer", BuyerRealm, BuyerAnid},//6
                    new Object[]{"[Buyer] CostCenter : Create, delete and verify", getcreateDeleteCostCenterCache(BuyerAnid), "CostCenter", "buyer", BuyerRealm, BuyerAnid},//5
                    new Object[]{"[Buyer] CostCenter : Create multiple costcenter using one companyCode and verify", getcreateMultipleCostCenterWithOneCompanyCodeCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create multiple costcenter using different companyCode everytime and verify", getcreateMultipleCostCenterWithDifferentCompanyCodeCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleCostCenterCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create multiple, delete all and verify", getcreateMultipleDeleteAllCostCenterCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteCostCenterCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create, update, delete and verify", getcreateUpdateDeleteCostCenterCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateCostCenterCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateUpdateCostCenterCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
                    new Object[]{"[Buyer] CostCenter : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateDeleteCostCenterCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] CostCenter : Create costcenter first and let records synced and later create the companycodes and verify", getcreateCostCenterFirstThenCompanyCodeCache(), "CostCenter", "buyer", BuyerRealm, BuyerAnid},
//
                    new Object[]{"[S4 standalone] CostCenter : Create and verify", getcreateCostCenterWithCompanyCodeCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},//4
                    new Object[]{"[S4 standalone] CostCenter : Create, update description of costCenter and verify", getcreateUpdateDescriptionOfCostCenterCache(S4StandaloneAnid), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},//6
                    new Object[]{"[S4 standalone] CostCenter : Create, delete and verify", getcreateDeleteCostCenterCache(S4StandaloneAnid), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},//5
                    new Object[]{"[S4 standalone] CostCenter : Create multiple costcenter using one companyCode and verify", getcreateMultipleCostCenterWithOneCompanyCodeCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create multiple costcenter using different companyCode everytime and verify", getcreateMultipleCostCenterWithDifferentCompanyCodeCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleCostCenterCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create multiple, delete all and verify", getcreateMultipleDeleteAllCostCenterCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteCostCenterCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create, update, delete and verify", getcreateUpdateDeleteCostCenterCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateCostCenterCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateUpdateCostCenterCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] CostCenter : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateDeleteCostCenterCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] CostCenter : Create costcenter first and let records synced and later create the companycodes and verify", getcreateCostCenterFirstThenCompanyCodeCache(), "CostCenter", "s4", S4StandaloneRealm, S4StandaloneAnid},
////
//////
                    new Object[]{"[Integrated] Product : Create and verify", getcreateProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},//7
                    new Object[]{"[Integrated] Product : Create, update description and verify", getcreateAndUpdateProductCache(IntegratedAnid), "Product", "Buyer", IntegratedRealm, IntegratedAnid},//8
                    new Object[]{"[Integrated] Product : Create, update multiple times and verify", getcreateUpdateMultipleTimesProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create, delete and verify", getcreateAndDeleteProductCache(IntegratedAnid), "Product", "Buyer", IntegratedRealm, IntegratedAnid},//9
                    new Object[]{"[Integrated] Product : Create multiple and verify", getcreateMultipleProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create multiple, delete all and verify", getcreateAndDeleteMultipleProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create, update, delete and verify", getcreateUpdateDeleteProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
                    new Object[]{"[Integrated] Product : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteProductCache(), "Product", "Buyer", IntegratedRealm, IntegratedAnid},
//
                    new Object[]{"[S4 standalone] Product : Create and verify", getcreateProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},//7
                    new Object[]{"[S4 standalone] Product : Create, update description and verify", getcreateAndUpdateProductCache(S4StandaloneAnid), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},//8
                    new Object[]{"[S4 standalone] Product : Create, update multiple times and verify", getcreateUpdateMultipleTimesProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create, delete and verify", getcreateAndDeleteProductCache(S4StandaloneAnid), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},//9
                    new Object[]{"[S4 standalone] Product : Create multiple and verify", getcreateMultipleProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create multiple, delete all and verify", getcreateAndDeleteMultipleProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create, update, delete and verify", getcreateUpdateDeleteProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},
                    new Object[]{"[S4 standalone] Product : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteProductCache(), "Product", "s4", S4StandaloneRealm, S4StandaloneAnid},

/**
 * ExchangeRate tests can't be run along with the other tests as it need devlab configuration
 * Uncomment and run separately after changing the configuration
 * */

//                    new Object[]{"[Integrated] ExchangeRate : Create and verify", getcreateExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},//1
//                    new Object[]{"[Integrated] ExchangeRate : Create, update description and verify", getcreateAndUpdateExchangeRateCache(IntegratedAnid), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},//2
//                    new Object[]{"[Integrated] ExchangeRate : Create, delete and verify", getcreateAndDeleteExchangeRateCache(IntegratedAnid), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},//3
//                    new Object[]{"[Integrated] ExchangeRate : Create multiple and verify", getcreateMultipleExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] ExchangeRate : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] ExchangeRate : Create multiple, delete all and verify", getcreateAndDeleteMultipleExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] ExchangeRate : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] ExchangeRate : Create, update, delete and verify", getcreateUpdateAndDeleteExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] ExchangeRate : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] ExchangeRate : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//                    new Object[]{"[Integrated] ExchangeRate : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteExchangeRateCache(), "ExchangeRate", "buyer", IntegratedRealm, IntegratedAnid},
//
//                    new Object[]{"[Buyer] ExchangeRate : Create and verify", getcreateExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},//1
//                    new Object[]{"[Buyer] ExchangeRate : Create, update description and verify", getcreateAndUpdateExchangeRateCache(BuyerAnid), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},//2
//                    new Object[]{"[Buyer] ExchangeRate : Create, delete and verify", getcreateAndDeleteExchangeRateCache(BuyerAnid), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},//3
//                    new Object[]{"[Buyer] ExchangeRate : Create multiple and verify", getcreateMultipleExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] ExchangeRate : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] ExchangeRate : Create multiple, delete all and verify", getcreateAndDeleteMultipleExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] ExchangeRate : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] ExchangeRate : Create, update, delete and verify", getcreateUpdateAndDeleteExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] ExchangeRate : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] ExchangeRate : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},
//                    new Object[]{"[Buyer] ExchangeRate : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteExchangeRateCache(), "ExchangeRate", "buyer", BuyerRealm, BuyerAnid},

                    /**
                     * ExchangeRate not working for S4 standalone ticket logged : PL-38196
                    * */
//                    new Object[]{"[S4 standalone] ExchangeRate : Create and verify", getcreateExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},//1
//                    new Object[]{"[S4 standalone] ExchangeRate : Create, update description and verify", getcreateAndUpdateExchangeRateCache(S4StandaloneAnid), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},//2
//                    new Object[]{"[S4 standalone] ExchangeRate : Create, delete and verify", getcreateAndDeleteExchangeRateCache(S4StandaloneAnid), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},//3
//                    new Object[]{"[S4 standalone] ExchangeRate : Create multiple and verify", getcreateMultipleExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] ExchangeRate : Create multiple, update multiple times and verify", getcreateMultipleAndUpdateMultipleExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] ExchangeRate : Create multiple, delete all and verify", getcreateAndDeleteMultipleExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] ExchangeRate : Create, update multiple, delete and verify", getcreateUpdateMultipleTimesAndDeleteExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] ExchangeRate : Create, update, delete and verify", getcreateUpdateAndDeleteExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] ExchangeRate : Create, update, delete, Create same instance again verify", getcreateUpdateDeleteAndCreateExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] ExchangeRate : Create, update, delete, Create same instance again then Update verify", getcreateUpdateDeleteCreateAndUpdateExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},
//                    new Object[]{"[S4 standalone] ExchangeRate : Create, update, delete, Create same instance, Update, delete verify", getcreateUpdateDeleteCreateUpdateAndDeleteExchangeRateCache(), "ExchangeRate", "s4", S4StandaloneRealm, S4StandaloneAnid},


                    new Object[]{"Wait for the task to complete : ", startMdiProcess(), "", "", "", ""},//10

/**
 * After discussion found that below test cases are not a valid scenarios hence commenting out.
* */

//                    new Object[Integrated] []{"CostCenter : Create costcenter first then companycode and verify", createCostCenterFirstThenCompanyCode(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},
//                    new Object[Integrated] []{"CostCenter : Create CostCenter with CompanyCode that does Not Exist and verify", createCostCenterWithCompanyCodeNotExist(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},// CostCenter created with company code as null
//                    new Object[Integrated] []{"CostCenter : Create CostCenter WithOut CompanyCode and verify", createCostCenterWithOutCompanyCode(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},//Invalid scenario
//                    new Object[Integrated] []{"CostCenter : Create And Delete CompanyCode and Create Costcenter With Deleted CompanyCode and verify", createCostcenterWithDeletedCompanyCode(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},// Able to create costcenter with deleted company code (invalid scenario cost center cannot exist without company code)
//                    new Object[Integrated] []{"CostCenter : Create CostCenter With CompanyCode Then Delete that CompanyCode and verify", createCostCenterWithOneCompanyCodeThenDeleteCompanyCode(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},// Invalid scenario
//                    new Object[Integrated] []{"CostCenter : Create, update, delete and verify", createUpdateDeleteCostCenter(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},
//                    new Object[Integrated] []{"CostCenter : Create, update, delete and verify", createUpdateDeleteCostCenter(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},
//                    new Object[Integrated] []{"CostCenter : Create, update referential association after creating new (companycode) and verify", createUpdateCompanyCodeOfCostCenter1(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},//Invalid scenario we cannot update the companycode of costcenter
//                    new Object[Integrated] []{"CostCenter : Create, update referential association after creating new (multiple times) and verify", createUpdateCompanyCodeOfCostCenter2(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},//Invalid scenario
//                    new Object[Integrated] []{"CostCenter : Create costcenter then go and update the entity companycode and verify", createUpdateCompanyCodeOfCostCenter3(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},//Invalid scenario
//                    new Object[Integrated] []{"CostCenter : Create cost center with one company code and then update the company code with some company code that does not exist", createUpdateCompanyCodeOfCostCenterNegative(), "CostCenter", "buyer", "accAcwSap", "AN02000580552"},//Invalid scenario
//                    TBD : Create costcenter first with companyCode that does not exist wait for it to be processed then create that companycode and wait for it to processed

            };
        } catch (Error e) {
            e.printStackTrace();
            return new Object[][]{
                    new Object[]{"Error while executing data provider", MDICache, "", "", "", ""}
            };
        } catch (Exception e) {
            e.printStackTrace();
            return new Object[][]{
                    new Object[]{"Exception while executing data provider", MDICache, "", "", "", ""}
            };
        }
        return data;
    }

}
