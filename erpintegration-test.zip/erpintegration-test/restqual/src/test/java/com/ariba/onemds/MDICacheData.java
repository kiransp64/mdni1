package com.ariba.onemds;

import com.ariba.data.cache.MDICache;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileNotFoundException;

public class MDICacheData extends DataExecuter {
    private static Logger logger = LogManager.getLogger(MDICacheData.class);

    static MDICache createCompanyCodeCache = null;
    static MDICache createAndUpdateCompanyCodeCache = null;
    static MDICache createAndDeleteCompanyCodeCache = null;
    static MDICache createMultipleCompanyCodeCache = null;
    static MDICache createMultipleAndUpdateMultipleCompanyCodeCache = null;
    static MDICache createAndDeleteMultipleCompanyCodeCache = null;
    static MDICache createUpdateMultipleTimesAndDeleteCompanyCodeCache = null;
    static MDICache createUpdateAndDeleteCompanyCodeCache = null;
    static MDICache createUpdateDeleteAndCreateCompanyCodeCache = null;
    static MDICache createUpdateDeleteCreateAndUpdateCompanyCodeCache = null;
    static MDICache createUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache = null;

    static MDICache createCostCenterWithCompanyCodeCache = null;
    static MDICache createUpdateDescriptionOfCostCenterCache = null;
    static MDICache createDeleteCostCenterCache = null;
    static MDICache createMultipleCostCenterWithOneCompanyCodeCache = null;
    static MDICache createMultipleCostCenterWithDifferentCompanyCodeCache = null;
    static MDICache createMultipleAndUpdateMultipleCostCenterCache = null;
    static MDICache createMultipleDeleteAllCostCenterCache = null;
    static MDICache createUpdateMultipleTimesAndDeleteCostCenterCache = null;
    static MDICache createUpdateDeleteCostCenterCache = null;
    static MDICache createUpdateDeleteAndCreateCostCenterCache = null;
    static MDICache createUpdateDeleteCreateUpdateCostCenterCache = null;
    static MDICache createUpdateDeleteCreateUpdateDeleteCostCenterCache = null;
    static MDICache createCostCenterFirstThenCompanyCodeCache = null;

    static MDICache createProductCache = null;
    static MDICache createAndUpdateProductCache = null;
    static MDICache createUpdateMultipleTimesProductCache = null;
    static MDICache createAndDeleteProductCache = null;
    static MDICache createMultipleProductCache = null;
    static MDICache createMultipleAndUpdateMultipleProductCache = null;
    static MDICache createAndDeleteMultipleProductCache = null;
    static MDICache createUpdateMultipleTimesAndDeleteProductCache = null;
    static MDICache createUpdateDeleteProductCache = null;
    static MDICache createUpdateDeleteAndCreateProductCache = null;
    static MDICache createUpdateDeleteCreateAndUpdateProductCache = null;
    static MDICache createUpdateDeleteCreateUpdateAndDeleteProductCache = null;

    static MDICache createExchangeRateCache = null;
    static MDICache createAndUpdateExchangeRateCache = null;
    static MDICache createAndDeleteExchangeRateCache = null;
    static MDICache createMultipleExchangeRateCache = null;
    static MDICache createMultipleAndUpdateMultipleExchangeRateCache = null;
    static MDICache createAndDeleteMultipleExchangeRateCache = null;
    static MDICache createUpdateMultipleTimesAndDeleteExchangeRateCache = null;
    static MDICache createUpdateAndDeleteExchangeRateCache = null;
    static MDICache createUpdateDeleteAndCreateExchangeRateCache = null;
    static MDICache createUpdateDeleteCreateAndUpdateExchangeRateCache = null;
    static MDICache createUpdateDeleteCreateUpdateAndDeleteExchangeRateCache = null;

    protected static MDICache getcreateCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createCompanyCodeCache == null) {
            logger.info("first hit createCompanyCodeCache");
            createCompanyCodeCache = createCompanyCode();
        }
        return createCompanyCodeCache;
    }

    protected static MDICache getcreateAndUpdateCompanyCodeCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createAndUpdateCompanyCodeCache == null) {
            createAndUpdateCompanyCodeCache = createAndUpdateCompanyCode(anid);
        }
        return createAndUpdateCompanyCodeCache;
    }

    protected static MDICache getcreateAndDeleteCompanyCodeCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createAndDeleteCompanyCodeCache == null) {
            createAndDeleteCompanyCodeCache = createAndDeleteCompanyCode(anid);
        }
        return createAndDeleteCompanyCodeCache;
    }

    protected static MDICache getcreateMultipleCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleCompanyCodeCache == null) {
            createMultipleCompanyCodeCache = createMultipleCompanyCode();
        }
        return createMultipleCompanyCodeCache;
    }

    protected static MDICache getcreateMultipleAndUpdateMultipleCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleAndUpdateMultipleCompanyCodeCache == null) {
            createMultipleAndUpdateMultipleCompanyCodeCache = createMultipleAndUpdateMultipleCompanyCode();
        }
        return createMultipleAndUpdateMultipleCompanyCodeCache;
    }

    protected static MDICache getcreateAndDeleteMultipleCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createAndDeleteMultipleCompanyCodeCache == null) {
            createAndDeleteMultipleCompanyCodeCache = createAndDeleteMultipleCompanyCode();
        }
        return createAndDeleteMultipleCompanyCodeCache;
    }

    protected static MDICache getcreateUpdateMultipleTimesAndDeleteCompanyCodeCache() throws Exception {
        if (createUpdateMultipleTimesAndDeleteCompanyCodeCache == null) {
            createUpdateMultipleTimesAndDeleteCompanyCodeCache = createUpdateMultipleTimesAndDeleteCompanyCode();
        }
        return createUpdateMultipleTimesAndDeleteCompanyCodeCache;
    }

    protected static MDICache getcreateUpdateAndDeleteCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateAndDeleteCompanyCodeCache == null) {
            createUpdateAndDeleteCompanyCodeCache = createUpdateAndDeleteCompanyCode();
        }
        return createUpdateAndDeleteCompanyCodeCache;
    }

    protected static MDICache getcreateUpdateDeleteAndCreateCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteAndCreateCompanyCodeCache == null) {
            createUpdateDeleteAndCreateCompanyCodeCache = createUpdateDeleteAndCreateCompanyCode();
        }
        return createUpdateDeleteAndCreateCompanyCodeCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateAndUpdateCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateAndUpdateCompanyCodeCache == null) {
            createUpdateDeleteCreateAndUpdateCompanyCodeCache = createUpdateDeleteCreateAndUpdateCompanyCode();
        }
        return createUpdateDeleteCreateAndUpdateCompanyCodeCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache == null) {
            createUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache = createUpdateDeleteCreateUpdateAndDeleteCompanyCode();
        }
        return createUpdateDeleteCreateUpdateAndDeleteCompanyCodeCache;
    }


    protected static MDICache getcreateCostCenterWithCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createCostCenterWithCompanyCodeCache == null) {
            logger.info("first hit createCostCenterWithCompanyCodeCache");
            createCostCenterWithCompanyCodeCache = createCostCenterWithCompanyCode();
        }
        return createCostCenterWithCompanyCodeCache;
    }

    protected static MDICache getcreateUpdateDescriptionOfCostCenterCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createUpdateDescriptionOfCostCenterCache == null) {
            logger.info("first hit createUpdateDescriptionOfCostCenterCache");
            createUpdateDescriptionOfCostCenterCache = createUpdateDescriptionOfCostCenter(anid);
        }
        return createUpdateDescriptionOfCostCenterCache;
    }

    protected static MDICache getcreateDeleteCostCenterCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createDeleteCostCenterCache == null) {
            logger.info("first hit createDeleteCostCenterCache");
            createDeleteCostCenterCache = createDeleteCostCenter(anid);
        }
        return createDeleteCostCenterCache;
    }

    protected static MDICache getcreateMultipleCostCenterWithOneCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleCostCenterWithOneCompanyCodeCache == null) {
            logger.info("first hit createMultipleCostCenterWithOneCompanyCodeCache");
            createMultipleCostCenterWithOneCompanyCodeCache = createMultipleCostCenterWithOneCompanyCode();
        }
        return createMultipleCostCenterWithOneCompanyCodeCache;
    }

    protected static MDICache getcreateMultipleCostCenterWithDifferentCompanyCodeCache() throws Exception {
        if (createMultipleCostCenterWithDifferentCompanyCodeCache == null) {
            logger.info("first hit createMultipleCostCenterWithDifferentCompanyCodeCache");
            createMultipleCostCenterWithDifferentCompanyCodeCache = createMultipleCostCenterWithDifferentCompanyCode();
        }
        return createMultipleCostCenterWithDifferentCompanyCodeCache;
    }

    protected static MDICache getcreateMultipleAndUpdateMultipleCostCenterCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleAndUpdateMultipleCostCenterCache == null) {
            logger.info("first hit createMultipleAndUpdateMultipleCostCenterCache");
            createMultipleAndUpdateMultipleCostCenterCache = createMultipleAndUpdateMultipleCostCenter();
        }
        return createMultipleAndUpdateMultipleCostCenterCache;
    }

    protected static MDICache getcreateMultipleDeleteAllCostCenterCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleDeleteAllCostCenterCache == null) {
            logger.info("first hit createMultipleDeleteAllCostCenterCache");
            createMultipleDeleteAllCostCenterCache = createMultipleDeleteAllCostCenter();
        }
        return createMultipleDeleteAllCostCenterCache;
    }

    protected static MDICache getcreateUpdateMultipleTimesAndDeleteCostCenterCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateMultipleTimesAndDeleteCostCenterCache == null) {
            logger.info("first hit createUpdateMultipleTimesAndDeleteCostCenterCache");
            createUpdateMultipleTimesAndDeleteCostCenterCache = createUpdateMultipleTimesAndDeleteCostCenter();
        }
        return createUpdateMultipleTimesAndDeleteCostCenterCache;
    }

    protected static MDICache getcreateUpdateDeleteCostCenterCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCostCenterCache == null) {
            logger.info("first hit createUpdateDeleteCostCenterCache");
            createUpdateDeleteCostCenterCache = createUpdateDeleteCostCenter();
        }
        return createUpdateDeleteCostCenterCache;
    }

    protected static MDICache getcreateUpdateDeleteAndCreateCostCenterCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteAndCreateCostCenterCache == null) {
            logger.info("first hit createUpdateDeleteAndCreateCostCenterCache");
            createUpdateDeleteAndCreateCostCenterCache = createUpdateDeleteAndCreateCostCenter();
        }
        return createUpdateDeleteAndCreateCostCenterCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateUpdateCostCenterCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateUpdateCostCenterCache == null) {
            logger.info("first hit createUpdateDeleteCreateUpdateCostCenterCache");
            createUpdateDeleteCreateUpdateCostCenterCache = createUpdateDeleteCreateUpdateCostCenter();
        }
        return createUpdateDeleteCreateUpdateCostCenterCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateUpdateDeleteCostCenterCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateUpdateDeleteCostCenterCache == null) {
            logger.info("first hit createUpdateDeleteCreateUpdateDeleteCostCenterCache");
            createUpdateDeleteCreateUpdateDeleteCostCenterCache = createUpdateDeleteCreateUpdateDeleteCostCenter();
        }
        return createUpdateDeleteCreateUpdateDeleteCostCenterCache;
    }

    protected static MDICache getcreateCostCenterFirstThenCompanyCodeCache() throws FileNotFoundException, InterruptedException {
        if (createCostCenterFirstThenCompanyCodeCache == null) {
            logger.info("first hit createCostCenterFirstThenCompanyCodeCache");
            createCostCenterFirstThenCompanyCodeCache = createCostCenterFirstThenCompanyCode();
        }
        return createCostCenterFirstThenCompanyCodeCache;
    }

    protected static MDICache getcreateProductCache() throws FileNotFoundException, InterruptedException {
        if (createProductCache == null) {
            logger.info("first hit createProductCache");
            createProductCache = createProduct();
        }
        return createProductCache;
    }

    protected static MDICache getcreateAndUpdateProductCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createAndUpdateProductCache == null) {
            logger.info("first hit createAndUpdateProductCache");
            createAndUpdateProductCache = createAndUpdateProduct(anid);
        }
        return createAndUpdateProductCache;
    }

    protected static MDICache getcreateUpdateMultipleTimesProductCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateMultipleTimesProductCache == null) {
            logger.info("first hit createUpdateMultipleTimesProductCache");
            createUpdateMultipleTimesProductCache = createUpdateMultipleTimesProduct();
        }
        return createUpdateMultipleTimesProductCache;
    }

    protected static MDICache getcreateAndDeleteProductCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createAndDeleteProductCache == null) {
            logger.info("first hit createAndDeleteProductCache");
            createAndDeleteProductCache = createAndDeleteProduct(anid);
        }
        return createAndDeleteProductCache;
    }

    protected static MDICache getcreateMultipleProductCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleProductCache == null) {
            logger.info("first hit createMultipleProductCache");
            createMultipleProductCache = createMultipleProduct();
        }
        return createMultipleProductCache;
    }

    protected static MDICache getcreateMultipleAndUpdateMultipleProductCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleAndUpdateMultipleProductCache == null) {
            logger.info("first hit createMultipleAndUpdateMultipleProductCache");
            createMultipleAndUpdateMultipleProductCache = createMultipleAndUpdateMultipleProduct();
        }
        return createMultipleAndUpdateMultipleProductCache;
    }

    protected static MDICache getcreateAndDeleteMultipleProductCache() throws FileNotFoundException, InterruptedException {
        if (createAndDeleteMultipleProductCache == null) {
            logger.info("first hit createAndDeleteMultipleProductCache");
            createAndDeleteMultipleProductCache = createAndDeleteMultipleProduct();
        }
        return createAndDeleteMultipleProductCache;
    }

    protected static MDICache getcreateUpdateMultipleTimesAndDeleteProductCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateMultipleTimesAndDeleteProductCache == null) {
            logger.info("first hit createUpdateMultipleTimesAndDeleteProductCache");
            createUpdateMultipleTimesAndDeleteProductCache = createUpdateMultipleTimesAndDeleteProduct();
        }
        return createUpdateMultipleTimesAndDeleteProductCache;
    }

    protected static MDICache getcreateUpdateDeleteProductCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteProductCache == null) {
            logger.info("first hit createUpdateDeleteProductCache");
            createUpdateDeleteProductCache = createUpdateDeleteProduct();
        }
        return createUpdateDeleteProductCache;
    }

    protected static MDICache getcreateUpdateDeleteAndCreateProductCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteAndCreateProductCache == null) {
            logger.info("first hit createUpdateDeleteAndCreateProductCache");
            createUpdateDeleteAndCreateProductCache = createUpdateDeleteAndCreateProduct();
        }
        return createUpdateDeleteAndCreateProductCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateAndUpdateProductCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateAndUpdateProductCache == null) {
            logger.info("first hit createUpdateDeleteCreateAndUpdateProductCache");
            createUpdateDeleteCreateAndUpdateProductCache = createUpdateDeleteCreateAndUpdateProduct();
        }
        return createUpdateDeleteCreateAndUpdateProductCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateUpdateAndDeleteProductCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateUpdateAndDeleteProductCache == null) {
            logger.info("first hit createUpdateDeleteCreateUpdateAndDeleteProductCache");
            createUpdateDeleteCreateUpdateAndDeleteProductCache = createUpdateDeleteCreateUpdateAndDeleteProduct();
        }
        return createUpdateDeleteCreateUpdateAndDeleteProductCache;
    }

    protected static MDICache getcreateExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createExchangeRateCache == null) {
            logger.info("first hit getcreateExchangeRateCache");
            createExchangeRateCache = createExchangeRate();
        }
        return createExchangeRateCache;
    }

    protected static MDICache getcreateAndUpdateExchangeRateCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createAndUpdateExchangeRateCache == null) {
            logger.info("first hit getcreateAndUpdateExchangeRateCache");
            createAndUpdateExchangeRateCache = createAndUpdateExchangeRate(anid);
        }
        return createAndUpdateExchangeRateCache;
    }

    protected static MDICache getcreateAndDeleteExchangeRateCache(String anid) throws FileNotFoundException, InterruptedException {
        if (createAndDeleteExchangeRateCache == null) {
            logger.info("first hit getcreateAndDeleteExchangeRateCache");
            createAndDeleteExchangeRateCache = createAndDeleteExchangeRate(anid);
        }
        return createAndDeleteExchangeRateCache;
    }

    protected static MDICache getcreateMultipleExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleExchangeRateCache == null) {
            logger.info("first hit getcreateMultipleExchangeRateCache");
            createMultipleExchangeRateCache = createMultipleExchangeRate();
        }
        return createMultipleExchangeRateCache;
    }

    protected static MDICache getcreateMultipleAndUpdateMultipleExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createMultipleAndUpdateMultipleExchangeRateCache == null) {
            logger.info("first hit getcreateMultipleAndUpdateMultipleExchangeRateCache");
            createMultipleAndUpdateMultipleExchangeRateCache = createMultipleAndUpdateMultipleExchangeRate();
        }
        return createMultipleAndUpdateMultipleExchangeRateCache;
    }

    protected static MDICache getcreateAndDeleteMultipleExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createAndDeleteMultipleExchangeRateCache == null) {
            logger.info("first hit getcreateAndDeleteMultipleExchangeRateCache");
            createAndDeleteMultipleExchangeRateCache = createAndDeleteMultipleExchangeRate();
        }
        return createAndDeleteMultipleExchangeRateCache;
    }

    protected static MDICache getcreateUpdateMultipleTimesAndDeleteExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateMultipleTimesAndDeleteExchangeRateCache == null) {
            logger.info("first hit getcreateUpdateMultipleTimesAndDeleteExchangeRateCache");
            createUpdateMultipleTimesAndDeleteExchangeRateCache = createUpdateMultipleTimesAndDeleteExchangeRate();
        }
        return createUpdateMultipleTimesAndDeleteExchangeRateCache;
    }

    protected static MDICache getcreateUpdateAndDeleteExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateAndDeleteExchangeRateCache == null) {
            logger.info("first hit getcreateUpdateAndDeleteExchangeRateCache");
            createUpdateAndDeleteExchangeRateCache = createUpdateAndDeleteExchangeRate();
        }
        return createUpdateAndDeleteExchangeRateCache;
    }

    protected static MDICache getcreateUpdateDeleteAndCreateExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteAndCreateExchangeRateCache == null) {
            logger.info("first hit getcreateUpdateDeleteAndCreateExchangeRateCache");
            createUpdateDeleteAndCreateExchangeRateCache = createUpdateDeleteAndCreateExchangeRate();
        }
        return createUpdateDeleteAndCreateExchangeRateCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateAndUpdateExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateAndUpdateExchangeRateCache == null) {
            logger.info("first hit getcreateUpdateDeleteCreateAndUpdateExchangeRateCache");
            createUpdateDeleteCreateAndUpdateExchangeRateCache = createUpdateDeleteCreateAndUpdateExchangeRate();
        }
        return createUpdateDeleteCreateAndUpdateExchangeRateCache;
    }

    protected static MDICache getcreateUpdateDeleteCreateUpdateAndDeleteExchangeRateCache() throws FileNotFoundException, InterruptedException {
        if (createUpdateDeleteCreateUpdateAndDeleteExchangeRateCache == null) {
            logger.info("first hit getcreateUpdateDeleteCreateUpdateAndDeleteExchangeRateCache");
            createUpdateDeleteCreateUpdateAndDeleteExchangeRateCache = createUpdateDeleteCreateUpdateAndDeleteExchangeRate();
        }
        return createUpdateDeleteCreateUpdateAndDeleteExchangeRateCache;
    }
}
