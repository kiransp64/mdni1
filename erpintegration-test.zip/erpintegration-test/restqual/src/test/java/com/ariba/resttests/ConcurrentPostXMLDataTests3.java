package com.ariba.resttests;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.PostXMLDataHelper;
import com.ariba.pojos.RestResponse;

public class ConcurrentPostXMLDataTests3 {

	PostXMLDataHelper pHelper = new PostXMLDataHelper();
	String rootDir = System.getProperty("user.dir");

	@Test(invocationCount = 20, threadPoolSize = 20)
	public void concurrentThreads() throws Exception {
		long tnum = Thread.currentThread().getId();
		System.out.println("Current Thread ID -------------" + tnum);

		switch ((int) tnum % 10) {
		case 1:
		case 2:
			String incoTermsData2 = getStringFromXML("/resources/datafiles/incoTerms.txt");
			incoTermsData2 = incoTermsData2.replace("$$$", tnum + "");
			UUID uuid = UUID.randomUUID();
			incoTermsData2 = incoTermsData2.replace("###", uuid.toString());
			System.err.println(incoTermsData2);
			RestResponse incoTerms2 = pHelper.postIncoTerms("AN71000002054", incoTermsData2, "aribaws", "aribaws12345");
			System.err.println(incoTerms2.getCode());
			Assert.assertEquals(incoTerms2.getCode(), BaseHelper.HTTP_200);
			break;

		case 3:
		case 4:
			String pgData2 = getStringFromXML("/resources/datafiles/purchaseGroup.txt");
			pgData2 = pgData2.replace("$$$", "PG" + tnum);
			System.err.println(pgData2);
			RestResponse pgResponse2 = pHelper.postPurchaseGroup("AN71000002054", pgData2, "aribaws", "aribaws12345");
			System.err.println(pgResponse2.getCode());
			Assert.assertEquals(pgResponse2.getCode(), BaseHelper.HTTP_200);
			break;

		case 5:
		case 6:
			String wbsData2 = getStringFromXML("/resources/datafiles/wbsElement.txt");
			wbsData2 = wbsData2.replace("$$$", "WB" + tnum);
			System.out.println(wbsData2);
			RestResponse wbsResponse2 = pHelper.postWbsElement("AN71000002054", wbsData2, "aribaws", "aribaws12345");
			System.err.println(wbsResponse2.getCode());
			Assert.assertEquals(wbsResponse2.getCode(), BaseHelper.HTTP_200);
			break;

		case 7:
		case 8:
			String poData2 = getStringFromXML("/resources/datafiles/purchaseOrg.txt");
			poData2 = poData2.replace("$$$", "PO" + tnum);
			System.out.println(poData2);
			RestResponse poResponse2 = pHelper.postPurchaseOrg("AN71000002054", poData2, "aribaws", "aribaws12345");
			System.err.println(poResponse2.getCode());
			Assert.assertEquals(poResponse2.getCode(), BaseHelper.HTTP_200);
			break;

		case 9:
		default:
			String ccrData2 = getStringFromXML("/resources/datafiles/currencyConversion.txt");
			ccrData2 = ccrData2.replace("$$$", "C" + tnum);
			System.out.println(ccrData2);
			RestResponse ccrresponse2 = pHelper.postCurrencyConversionRate("AN71000002054", ccrData2, "aribaws",
					"aribaws12345");
			System.err.println(ccrresponse2.getCode());
			Assert.assertEquals(ccrresponse2.getCode(), BaseHelper.HTTP_200);
			break;
		}
	}

	public String getStringFromXML(String filePath) throws FileNotFoundException {

		String rootDir = System.getProperty("user.dir");
		Scanner scanner = new Scanner(new File(rootDir + filePath));
		String xmlString = scanner.useDelimiter("\\A").next();
		scanner.close();
		return xmlString;
	}
}
