package com.ariba.utilities;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateFormatter {

	static final String DefaultDateFormatPatterns = "EEE MMM d HH:mm:ss z yyyy";

	public static String getTomorrowDate() {
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR, 1);
		Date tomorrow = cal.getTime();

		return getDateInFormat(tomorrow, DefaultDateFormatPatterns);
	}

	public static String getTodayDate() {
		Date today = new Date();
		Calendar cal = Calendar.getInstance();
		today = cal.getTime();

		return getDateInFormat(today, DefaultDateFormatPatterns);

	}

	public static String getCustomDate(int days) {
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR, days);
		Date cusDate = cal.getTime();

		return getDateInFormat(cusDate, DefaultDateFormatPatterns);
	}

	public static String getBaseDate() {

		return getDateInFormat(new Date(0), DefaultDateFormatPatterns);
	}

	public static String getDateInFormat(Date date, String format) {

		if (date == null) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		String strDate = sdf.format(date);
		return strDate;
	}

}