package com.ariba.scimpatchtests;


import com.ariba.helpers.BaseHelper;
import org.apache.http.HttpStatus;
import org.testng.annotations.DataProvider;

import java.io.FileNotFoundException;

public class PatchDataProvider {
    @DataProvider(name = "getPatchPayloadsForActiveAtribute")
    public static Object[][] getPatchPayloadsForActiveAtribute() {
        Object[][] data = new Object[0][];
        try {
            data = new Object[][]{
                    new Object[]{"Verify - Replace operation on active ", PatchUsersTest.userPatchPayloads.get("ReplaceMakeInactive").getAsJsonObject()},
            };
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
    @DataProvider(name = "getPatchPayloads")
    public static Object[][] getPatchPayloads() {
        Object[][] data = new Object[0][];
        try {
            data = new Object[][]{
                    new Object[]{"Verify - Remove and Add operation on User Email Address", PatchUsersTest.userPatchPayloads.get("RemoveAddOnEmail").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on User Email Address", PatchUsersTest.userPatchPayloads.get("ReplaceOnEmail").getAsJsonObject()},
                    new Object[]{"Verify - Remove on User Email Address", PatchUsersTest.userPatchPayloads.get("RemoveOnEmail").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on User Email Address with Primary as false", PatchUsersTest.userPatchPayloads.get("ReplaceWithBothPriaryASFalseOnEmail").getAsJsonObject()},

                    new Object[]{"Verify - Remove and Add operation on User displayName", PatchUsersTest.userPatchPayloads.get("RemoveAndAddDisplayname").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on User displayName", PatchUsersTest.userPatchPayloads.get("ReplaceDisplayname").getAsJsonObject()},
                    new Object[]{"Verify - Replace with blank User displayName", PatchUsersTest.userPatchPayloads.get("ReplaceWithBlankDisplayname").getAsJsonObject()},
                    new Object[]{"Verify - Remove User displayName", PatchUsersTest.userPatchPayloads.get("RemoveDisplayname").getAsJsonObject()},

                    new Object[]{"Verify - Remove and Add operation on timezone", PatchUsersTest.userPatchPayloads.get("RemoveAndAddTimezone").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on timezone", PatchUsersTest.userPatchPayloads.get("ReplaceTimezone").getAsJsonObject()},
                    new Object[]{"Verify - Remove on User timezone", PatchUsersTest.userPatchPayloads.get("RemoveTimezone").getAsJsonObject()},
                    new Object[]{"Verify - Add on User timezone", PatchUsersTest.userPatchPayloads.get("AddTimezone").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on User Timezone As Blank", PatchUsersTest.userPatchPayloads.get("UpdateTimeZoneToBlankUsingReplace").getAsJsonObject()},

                    new Object[]{"Verify - Add on User active", PatchUsersTest.userPatchPayloads.get("AddActive").getAsJsonObject()},

                    new Object[]{"Verify - Remove and Add operation on locale", PatchUsersTest.userPatchPayloads.get("RemoveAndAddLocale").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on locale", PatchUsersTest.userPatchPayloads.get("ReplaceLocale").getAsJsonObject()},
                    new Object[]{"Verify - Remove on User locale", PatchUsersTest.userPatchPayloads.get("RemoveLocale").getAsJsonObject()},
                    new Object[]{"Verify - Add on User locale", PatchUsersTest.userPatchPayloads.get("AddLocale").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on User Locale As Blank", PatchUsersTest.userPatchPayloads.get("UpdateLocaleToBlankUsingReplace").getAsJsonObject()},

                    new Object[]{"Verify - Remove and Add operation on phonenumbers", PatchUsersTest.userPatchPayloads.get("RemoveAndAddPhoneNumbers").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on phonenumbers", PatchUsersTest.userPatchPayloads.get("ReplacePhoneNumbers").getAsJsonObject()},
                    new Object[]{"Verify - Remove on phonenumbers", PatchUsersTest.userPatchPayloads.get("RemovePhoneNumbers").getAsJsonObject()},
                    new Object[]{"Verify - Remove specific phonenumber", PatchUsersTest.userPatchPayloads.get("RemoveSpecificPhoneNumber").getAsJsonObject()},

                    new Object[]{"Verify - Remove and Add operation on useruuid", PatchUsersTest.userPatchPayloads.get("RemoveAndAddUUID").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on useruuid", PatchUsersTest.userPatchPayloads.get("ReplaceUUID").getAsJsonObject()},
                    new Object[]{"Verify - Remove on useruuid", PatchUsersTest.userPatchPayloads.get("RemoveUUID").getAsJsonObject()},

                    new Object[]{"Verify - Remove and Add operation on alternativeDisplayName", PatchUsersTest.userPatchPayloads.get("RemoveAddAlternativeDisplayName").getAsJsonObject()},
                    new Object[]{"Verify - Add operation on alternativeDisplayName", PatchUsersTest.userPatchPayloads.get("AddAlternativeDisplayName").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on alternativeDisplayName", PatchUsersTest.userPatchPayloads.get("ReplaceAlternativeDisplayName").getAsJsonObject()},
                    new Object[]{"Verify - Remove on alternativeDisplayName", PatchUsersTest.userPatchPayloads.get("RemoveAlternativeDisplayName").getAsJsonObject()},
                    new Object[]{"Verify - Replace with blank alternativeDisplayName", PatchUsersTest.userPatchPayloads.get("ReplaceAlternativeDisplayNameBlank").getAsJsonObject()},
                    new Object[]{"Verify - Replace with null alternativeDisplayName", PatchUsersTest.userPatchPayloads.get("ReplaceAlternativeDisplayNameNull").getAsJsonObject()},

                    new Object[]{"Verify - Add operation on User Supervisor(already existing)", PatchUsersTest.userPatchPayloads.get("ReplaceManagerUsingAdd").getAsJsonObject()},
                    new Object[]{"Verify - Remove and Add operation on User Supervisor", PatchUsersTest.userPatchPayloads.get("RemoveAddManager").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on User Supervisor As Null", PatchUsersTest.userPatchPayloads.get("ReplaceManagerAsNull").getAsJsonObject()},
                    new Object[]{"Verify - Replace operation on User Supervisor As blank", PatchUsersTest.userPatchPayloads.get("ReplaceManagerAsBlank").getAsJsonObject()},
                    new Object[]{"Verify - Remove manager attribute from user", PatchUsersTest.userPatchPayloads.get("RemoveManager").getAsJsonObject()},
                    new Object[] {"Verify - Add new User Email Address to a multi-valued attribute", PatchUsersTest.userPatchPayloads.get("AddNewEmailAddressUsingAdd").getAsJsonObject()},

                    /*
                    //not supported
                    new Object[] {"Update User With Removing Uuid In Buyer and verify",PatchUsersTest.userPatchPayloads.get("ReplacePhoneNumbers").getAsJsonObject()},
                    new Object[] {"Update User With Removing Uuid In S4 and verify",PatchUsersTest.userPatchPayloads.get("ReplacePhoneNumbers").getAsJsonObject()},
                    new Object[] {"Update User With Uuid Same As Other User and verify",PatchUsersTest.userPatchPayloads.get("ReplacePhoneNumbers").getAsJsonObject()},
                    new Object[] {"Verify - Remove operation on single member from a multi-valued attribute",PatchUsersTest.userPatchPayloads.get("RemoveSingleMemberFromGroup").getAsJsonObject()},//not supported
                    new Object[] {"Verify - Remove operation by removing value from a complex multi-valued attribute",PatchUsersTest.userPatchPayloads.get("removeValueFromComplexAttribute").getAsJsonObject()},//not supported
                    new Object[] {"Verify - Replace operation by giving path(target location) that does not exist", PatchUsersTest.userPatchPayloads.get("ReplaceAttributeDoesNotExist").getAsJsonObject()},//not supported
                    new Object[] {"Verify - Add operation without giving path (Remove email and display name then add without giving path)", PatchUsersTest.userPatchPayloads.get("RemoveEmailDisplayNameAndAddEmailDisplayName").getAsJsonObject()},//not supported

                     */
            };
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    @DataProvider(name = "getNegativeUserPatchPayloads")
    public static Object[][] getNegativeUserPatchPayloads() throws FileNotFoundException {
        Object[][] data = new Object[0][];
        try {
            data = new Object[][]{
                    new Object[]{"Negative - Replace operation on User Display Name Without Sending its value", PatchUsersTest.userPatchPayloads.get("patchWithoutValue").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Value cannot be null for Add or Replace operations"},
                    new Object[]{"Verify - Replace with null User displayName", PatchUsersTest.userPatchPayloads.get("ReplaceWithNullDisplayname").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Value cannot be null for Add or Replace operations"},//TBD
                    new Object[]{"Negative - Replace operation on User Locale sending invalid locale", PatchUsersTest.userPatchPayloads.get("UpdateLocaleToInvalidUsingReplace").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Invalid locale en-US"},
                    new Object[]{"Negative - Replace operation on User Locale As Null", PatchUsersTest.userPatchPayloads.get("UpdateLocaleToNullUsingReplace").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Value cannot be null for Add or Replace operations"},//"detail": "Value cannot be null for Add or Replace operations"
                    new Object[]{"Negative - Replace operation on User Timezone sending Invalid timezone", PatchUsersTest.userPatchPayloads.get("UpdateTimeZoneToInvalidUsingReplace").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Invalid Timezone US/Centra"},
                    new Object[]{"Negative - Replace operation on User Timezone As Null", PatchUsersTest.userPatchPayloads.get("UpdateTimeZoneToNullUsingReplace").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Value cannot be null for Add or Replace operations"},//"detail": "Value cannot be null for Add or Replace operations"
                    new Object[]{"Negative - Replace operation on User With Supervisor that does not exist", PatchUsersTest.userPatchPayloads.get("UpdateWithNonExistingSupervisorUsingAdd").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Given supervisor doesn't exist"},
                    new Object[]{"Negative -  Replace With In-Active Supervisor and verify", PatchUsersTest.userPatchPayloads.get("UpdateWithInActiveSupervisorUsingAdd").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Given supervisor doesn't exist"},//check with vinay how to get inactive supervisor 1. create one user and make him inactive 2. create user with inactive user as his supervisor
                    new Object[]{"Negative - Add operation on User Uuid (invalid uuid)", PatchUsersTest.userPatchPayloads.get("UpdateUuidAsInvalid").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "userUUID needs to meet RFC 4122 format for - invalid"},
                    new Object[]{"Negative - Replace operation on User Uuid As Blank", PatchUsersTest.userPatchPayloads.get("UpdateUuidAsBlank").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "userUUID needs to meet RFC 4122 format for - "},//vinay "userUUID needs to meet RFC 4122 format for - ",
                    new Object[]{"Negative - Replace operation on User Uuid As Invalid", PatchUsersTest.userPatchPayloads.get("UpdateUuidAsInvalid").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "userUUID needs to meet RFC 4122 format for - invalid"},//pass "userUUID needs to meet RFC 4122 format for - invalid",
                    new Object[]{"Verify - Replace operation on User Uuid As Null", PatchUsersTest.userPatchPayloads.get("UpdateUuidAsNull").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Value cannot be null for Add or Replace operations"},
                    new Object[]{"Negative - Replace operation on User email with invalid email address", PatchUsersTest.userPatchPayloads.get("RemoveAndAddIvalidEmailAddress").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Email is not valid - com.sap.scimono.entity.Email [value=work123test.com, type=, primary=true, operation=null, ]"},
                    new Object[]{"Negative - Remove and Replace operation on User Email Address(first remove and then try to replace)", PatchUsersTest.userPatchPayloads.get("UpdateUserWithoutEmailAddress").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "no such path in target JSON document"},//"no such path in target JSON document"
                    new Object[]{"Negative - Replace operation on User Make Primary Email Address Null", PatchUsersTest.userPatchPayloads.get("UpdateEmailAddressToNull").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Email is not valid - com.sap.scimono.entity.Email [value=null, type=, primary=true, operation=null, ]"},
                    new Object[]{"Negative - Replace operation on User Make Primary Email Address Blank", PatchUsersTest.userPatchPayloads.get("UpdateEmailAddressToBlank").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Email is not valid - com.sap.scimono.entity.Email [value=, type=, primary=true, operation=null, ]"},
                    new Object[]{"Negative - Replace operation on User Email Address  with non Primary as Null", PatchUsersTest.userPatchPayloads.get("UpdateNonPrimaryEmailAddressToNull").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Email is not valid - com.sap.scimono.entity.Email [value=null, type=, primary=false, operation=null, ]"},
                    new Object[]{"Negative - Remove active attribute from user", PatchUsersTest.userPatchPayloads.get("RemoveactiveAttribute").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Active Flag is mandatory"},
                    new Object[]{"Negative - Replace operation on User active As Blank", PatchUsersTest.userPatchPayloads.get("ReplaceactiveBlank").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Active Flag is mandatory"},
                    new Object[]{"Negative - Replace operation on User active As Null", PatchUsersTest.userPatchPayloads.get("ReplaceactiveNull").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Active Flag is mandatory"},
                    new Object[]{"Negative - Remove username  attribute from user", PatchUsersTest.userPatchPayloads.get("RemoveUserNameAttribute").getAsJsonObject(), HttpStatus.SC_OK, "NA"},//pass "userUUID needs to meet RFC 4122 format for - invalid",
                    new Object[]{"Negative - Patch request without urn:ietf:params:scim:api:messages:2.0:PatchOp", PatchUsersTest.userPatchPayloads.get("patchWithoutSchema").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Patch operation must contain schema urn:ietf:params:scim:api:messages:2.0:PatchOp"},
                    new Object[]{"Negative - Try to replace without giving path", PatchUsersTest.userPatchPayloads.get("replaceWithoutPath").getAsJsonObject(), HttpStatus.SC_NO_CONTENT, ""},
                    new Object[]{"Negative - Try to add without giving path", PatchUsersTest.userPatchPayloads.get("addWithoutPath").getAsJsonObject(), HttpStatus.SC_NO_CONTENT, ""},
                    new Object[]{"Negative - Try removing when path is unspecified(path is blank)", PatchUsersTest.userPatchPayloads.get("addWithoutPathSpecified").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Invalid user attribute: "},
                    new Object[]{"Negative - Replace operation on User giving path which does not exist", PatchUsersTest.userPatchPayloads.get("addGivingInvalidPath").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Invalid user attribute: invalid"},//first remove and then try to replace // 400 "detail": "no such path in target JSON document",
                    new Object[]{"Negative - One success and one failed should restore the value", PatchUsersTest.userPatchPayloads.get("2pass1failoperation").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Invalid user attribute: "},
//                    new Object[]{"Negative - Try updating with same value modify timestamp should not be changed", PatchUsersTest.userPatchPayloads.get("ReplaceWithSameValue").getAsJsonObject(), HttpStatus.SC_OK, "error message"},//Not supported PL-33936
                    new Object[]{"Negative - Replace operation on phoneNumbers User Make Phone As Null", PatchUsersTest.userPatchPayloads.get("UpdatePhoneAndFaxAsNull").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Phone Number cannot be blank or null. Invalid Phone Number - com.sap.scimono.entity.PhoneNumber [value=null, type=work, primary=false, operation=null, ]"},//pass     "detail": "Phone Number cannot be blank or null. Invalid Phone Number - com.sap.scimono.entity.PhoneNumber [value=null, type=work, primary=false, operation=null, ]",
                    new Object[]{"Negative - Remove and replace operation on phoneNumbers", PatchUsersTest.userPatchPayloads.get("UpdateUserwithoutPhoneAndFax").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "no such path in target JSON document"},//pass "no such path in target JSON document", not supported
                    new Object[]{"Negative - Replace operation on phoneNumbers of User by Making Phone And Fax As Blank", PatchUsersTest.userPatchPayloads.get("UpdatePhoneAndFaxAsBlank").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Phone Number cannot be blank or null. Invalid Phone Number - com.sap.scimono.entity.PhoneNumber [value=, type=work, primary=false, operation=null, ]"},//400  Vinay   "detail": "Phone Number cannot be blank or null. Invalid Phone Number - com.sap.scimono.entity.PhoneNumber [value=, type=work, primary=false, operation=null, ]",
                    new Object[]{"Negative - Add operation on username", PatchUsersTest.userPatchPayloads.get("AddUsername").getAsJsonObject(), HttpStatus.SC_OK, ""},//TBD
                    new Object[]{"Negative - Replace operation on username", PatchUsersTest.userPatchPayloads.get("ReplaceUsername").getAsJsonObject(), HttpStatus.SC_OK, ""},//TBD
                    new Object[]{"Negative - Replace operation on User Which Does Not Exists", PatchUsersTest.userPatchPayloads.get("ReplacePhoneNumbersNegative").getAsJsonObject(), HttpStatus.SC_NOT_FOUND, "Resource with given user doesn't exist"},
                    new Object[]{"Negative - Update User Supervisor As Same User and verify", PatchUsersTest.userPatchPayloads.get("UpdateSupervisorSameAsUserUsingAdd").getAsJsonObject(), HttpStatus.SC_BAD_REQUEST, "Cyclic depedency detected on supervisor"},//TBD
            };
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;

    }


    @DataProvider(name = "getGroupPatchPayloads")
    public static Object[][] getGroupPatchPayloads() throws FileNotFoundException {
        Object[][] data = new Object[0][];
        try {
            data = new Object[][]{
//                    new Object[]{"Verify - Remove and replace operation on DisplayName", PatchUsersTest.groupPatchPayloads.get("TBD").getAsJsonObject(), BaseHelper.SAP_ANID},//TBD
//                    new Object[]{"Verify - Remove and add operation on DisplayName", PatchUsersTest.groupPatchPayloads.get("TBD").getAsJsonObject(), BaseHelper.SAP_ANID},//TBD
//
                    new Object[]{"Verify - Remove and add on alternativeDisplayNames", PatchUsersTest.groupPatchPayloads.get("RemoveAddAlternativeDisplayName").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Replace on alternativeDisplayNames", PatchUsersTest.groupPatchPayloads.get("ReplaceAlternativeDisplayName").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Replace operation on alternativeDisplayNames As Null", PatchUsersTest.groupPatchPayloads.get("ReplaceAlternativeDisplayNameNull").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Replace operation on alternativeDisplayNames As Blank", PatchUsersTest.groupPatchPayloads.get("ReplaceAlternativeDisplayNameBlank").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Add operation on alternativeDisplayNames", PatchUsersTest.groupPatchPayloads.get("AddAlternativeDisplayName").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Remove operation on alternativeDisplayNames As Blank", PatchUsersTest.groupPatchPayloads.get("RemoveAlternativeDisplayName").getAsJsonObject(), BaseHelper.SAP_ANID},

                    new Object[]{"Verify - Replace operation on members-user and group with valid", PatchUsersTest.groupPatchPayloads.get("replaceMemberUserAndGroupValid").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Replace operation on members-user with valid User member", PatchUsersTest.groupPatchPayloads.get("updateMemberUserValid").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Replace operation on members-group with valid Group member", PatchUsersTest.groupPatchPayloads.get("updateMemberGroupValid").getAsJsonObject(), BaseHelper.SAP_ANID},

                    new Object[]{"Verify - Replace operation on members-group with its own group", PatchUsersTest.groupPatchPayloads.get("RemoveAddAlternativeDisplayName").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Remove and Add operation on members with valid member", PatchUsersTest.groupPatchPayloads.get("RemoveAddMembers").getAsJsonObject(), BaseHelper.SAP_ANID},
                    new Object[]{"Verify - Replace operation on specific members", PatchUsersTest.groupPatchPayloads.get("ReplaceSpecificMembers").getAsJsonObject(), BaseHelper.SAP_ANID}

//                new Object[] {"createAndUpdateGroupForSG","createAndUpdateGroupForSG", BaseHelper.SAP_ANID},
//                new Object[] {"createAndUpdateGroupForPSOFT","createAndUpdateGroupForPSOFT", BaseHelper.SAP_ANID},
//                new Object[] {"createAndUpdateGroupForMerpParent","createAndUpdateGroupForMerpParent", BaseHelper.SAP_ANID},
//                new Object[] {"createAndUpdateGroupForMerpChild","createAndUpdateGroupForMerpChild", BaseHelper.SAP_ANID},
//                new Object[] {"createAndUpdateGroupForIntegrated","createAndUpdateGroupForIntegrated", BaseHelper.SAP_ANID},
//                new Object[] {"createAndUpdateGroupForMultiDestinations","createAndUpdateGroupForMultiDestinations", BaseHelper.SAP_ANID},
//                new Object[] {"createAndUpdateGroupForS4","createAndUpdateGroupForS4", BaseHelper.SAP_ANID},
            };
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    @DataProvider(name = "getNegativeGroupPatchPayloads")
    public static Object[][] getNegativeGroupPatchPayloads() throws FileNotFoundException {
        Object[][] data = new Object[0][];
        try {
            data = new Object[][]{
                    new Object[]{"Negative - Patch operation on Group that does not exists", PatchUsersTest.groupPatchPayloads.get("updateMemberUserNull").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_NOT_FOUND, "Resource with given group doesn't exist"},
                    new Object[]{"Negative - Replace operation on members-user with null User member", PatchUsersTest.groupPatchPayloads.get("updateMemberUserNull").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_BAD_REQUEST, "Invalid input for User : [null]"},
                    new Object[]{"Negative - Replace operation on members-user with blank User member", PatchUsersTest.groupPatchPayloads.get("updateMemberUserBlank").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_BAD_REQUEST, "Invalid input for User : []"},
                    new Object[]{"Negative - Replace operation on members-user with invalid User member", PatchUsersTest.groupPatchPayloads.get("updateMemberUserInvalid").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_BAD_REQUEST, "Invalid input for User : [Invalid]"},
                    new Object[]{"Negative - Replace operation on members-group with null User member", PatchUsersTest.groupPatchPayloads.get("updateMemberGroupNull").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_BAD_REQUEST, "Invalid input for Group : [null]"},
                    new Object[]{"Negative - Replace operation on members-group with blank User member", PatchUsersTest.groupPatchPayloads.get("updateMemberGroupBlank").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_BAD_REQUEST, "Invalid input for Group : []"},
                    new Object[]{"Negative - Replace operation on members-group with invalid Group member", PatchUsersTest.groupPatchPayloads.get("updateMemberGroupInvalid").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_BAD_REQUEST, "Invalid input for Group : [Invalid]"},
                    new Object[]{"Negative - Remove operation on DisplayName", PatchUsersTest.groupPatchPayloads.get("removeDisplayName").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_OK, "Display Name is mandatory"},
                    new Object[]{"Negative - Replace operation on DisplayName giving display name which doesn't exist", PatchUsersTest.groupPatchPayloads.get("updatedisplayName").getAsJsonObject(), BaseHelper.SAP_ANID, HttpStatus.SC_OK, "Resource with given group doesn't exist"},
            };
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
}
