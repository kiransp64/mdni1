package com.ariba.onemds;


import com.ariba.data.cache.MDICache;
import com.ariba.data.companycode.CompanyCode;
import com.ariba.data.costcenter.ChangeRequest;
import com.ariba.data.costcenter.CostCenter;
import com.ariba.data.costcenter.Name;
import com.ariba.data.delete.DeleteEntity;
import com.ariba.data.exchangeRate.ExchangeRate;
import com.ariba.data.nextDeltaToken.NextDeltaToken;
import com.ariba.data.product.Product;
import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.Constants;
import com.ariba.helpers.SCIMHelper;
import com.ariba.services.AQL;
import com.ariba.services.MDNI;
import com.ariba.services.MDS;
import com.ariba.services.OneMds;
import com.ariba.utilities.DateFormatter;
import com.google.gson.*;
import io.restassured.response.Response;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.asserts.SoftAssert;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

import static com.ariba.helpers.CombinationGenerator.getCombinations;

public class OneMDSHelper {
    static String freshDeltaTokenCostCenter;
    static String freshDeltaTokenCompanyCode;
    static String freshDeltaTokenProduct;
    static String freshDeltaTokenExchangeRate;

    static String nextDeltaTokenCompanyCode;
    static String nextDeltaTokenCostCenter;
    static String nextDeltaTokenProduct;
    static String nextDeltaTokenExchangeRate;

    static String access_token;
    //    static int companyCodeSequence = 6063;
//    static int costCenterSequence = 7063;
    static int productSequence = 4;
    public static Response response;
    static List<DeleteEntity> masterDeleteEntityList = new ArrayList<>();
    Response aqlPullResponse;
    Response mdsOpenApiResponse;
    Response mdsAdvancedSearchApiResponse;

    static String companyCodeForCostCenter = null;
    AQL aql = new AQL();
    MDS mds = new MDS();
    SCIMHelper scimHelper = new SCIMHelper();
    private static JsonParser jsonParser = new JsonParser();

    private static Logger logger = LogManager.getLogger(OneMDSHelper.class);

    private static String currencyList[] = {"HUF","IDR","ETB","FJD","GMD","GHC","GYD","GTQ","HNL","HKD","AED","AFN","ALL","ANG","AUD","BBD","BGN","BHD","BDT","BND","USD"};
    static Stack currencyCombinationPool = getCombinations(currencyList);
    static DecimalFormat df = new DecimalFormat("#.###");
//    maintain the list of costcenters and companycode created

    public static List<CompanyCode> createCompanyCodePayloads(int numberOfCompanyCode, String operation) throws FileNotFoundException {
        List<CompanyCode> companyCodeList = new ArrayList<>();
        for (int i = 1; i <= numberOfCompanyCode; i++) {
            CompanyCode companyCode = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/CompanyCode.json")).getAsJsonObject(), CompanyCode.class);
            List<com.ariba.data.companycode.ChangeRequest> changeRequestList = new ArrayList<>();
            com.ariba.data.companycode.ChangeRequest changeRequest = companyCode.getChangeRequests().get(0);
            changeRequest.setOperation(operation);
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.getInstance().setDisplayId(RandomStringUtils.randomAlphanumeric(4));
            changeRequest.getInstance().setId(UUID.randomUUID().toString());
//            changeRequest.getInstance().setName("test CCode " + System.currentTimeMillis());
            changeRequestList.add(changeRequest);
            companyCode.setChangeRequests(changeRequestList);
            companyCodeList.add(companyCode);
//            companyCodeSequence++;
        }
        return companyCodeList;
    }

    public static List<ExchangeRate> createExchangeRatePayloads(int numberOfExchangeRate, String operation) throws FileNotFoundException {
        List<ExchangeRate> exchangeRateList = new ArrayList<>();
        for (int i = 1; i <= numberOfExchangeRate; i++) {
            String fromToCurrency = currencyCombinationPool.pop().toString();
            ExchangeRate exchangeRate = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/ExchangeRate.json")).getAsJsonObject(), ExchangeRate.class);
            List<com.ariba.data.exchangeRate.ChangeRequest> changeRequestList = new ArrayList<>();
            com.ariba.data.exchangeRate.ChangeRequest changeRequest = exchangeRate.getChangeRequests().get(0);
            changeRequest.setOperation(operation);
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.getInstance().setId("MDS/"+UUID.randomUUID().toString());
            changeRequest.getInstance().getFromCurrency().setCode(fromToCurrency.split("_")[0]);
            changeRequest.getInstance().getToCurrency().setCode(fromToCurrency.split("_")[1]);
            double rate = Double.valueOf(RandomStringUtils.randomNumeric(2))+0.274;
            changeRequest.getInstance().setRate(Double.parseDouble(df.format(rate)));
            changeRequestList.add(changeRequest);
            exchangeRate.setChangeRequests(changeRequestList);
            exchangeRateList.add(exchangeRate);
        }
        logger.info("Items remaining in currency combination pool is : "+currencyCombinationPool.size());
        return exchangeRateList;
    }

    public static String getCompanyCodeForCostCenter() throws InterruptedException, FileNotFoundException {
        if (companyCodeForCostCenter==null)
        {
            String DefaultDateFormatPatterns = "yyyy-MM-dd'T'HH:mm:ss.SS'Z'";
            String date = DateFormatter.getDateInFormat(new Date(), DefaultDateFormatPatterns);
            String xmlString = BaseHelper.getStringFromXML("/resources/mdiPayloads/companyCode.txt");
            String companyCode = RandomStringUtils.randomAlphanumeric(4);
            xmlString = xmlString.replace("@@@",date);
            xmlString = xmlString.replace("@UniqueName",companyCode);
            xmlString = xmlString.replace("###",UUID.randomUUID().toString());
            createCompanyCodeForCostCenter(OneMdsDataProvider.IntegratedAnid,"CompanyCode",xmlString);
            createCompanyCodeForCostCenter(OneMdsDataProvider.BuyerAnid,"CompanyCode",xmlString);
            createCompanyCodeForCostCenter(OneMdsDataProvider.S4StandaloneAnid,"CompanyCode",xmlString);
            companyCodeForCostCenter = companyCode;
        }
        return companyCodeForCostCenter;
    }
    public static void createCompanyCodeForCostCenter(String tenantId, String objectName, String payload) throws InterruptedException {
        MDNI mdni = new MDNI();
        String jobId = mdni.uploadXMLData(tenantId,objectName,payload);
        Response jobResponse = mdni.getJobStatus(tenantId,jobId);
        int recordsInserted = jobResponse.jsonPath().getInt("RecordsInserted");
        if (recordsInserted!=1){
            Assert.fail("Failed to create company code using xl upload");
        }
    }
    public static MDICache instanceToResponseMapper(MDICache mdiCache, Response response) {
        JsonObject jsonObject = new JsonParser().parse(response.asString()).getAsJsonObject();
        JsonArray jsonArray = jsonObject.getAsJsonArray("log");
        for (JsonElement element : jsonArray) {
            if (!element.getAsJsonObject().get("event").getAsString().toLowerCase().equalsIgnoreCase("deleted")) {
                mdiCache.getInstanceResponseMap().put(element.getAsJsonObject().get("instance").getAsJsonObject().get("id").getAsString(), element.getAsJsonObject());
            }
        }
        return mdiCache;
    }

    public static MDICache updateMDICache(MDICache mdiCache, Response response, String entity) {
        mdiCache = instanceToResponseMapper(mdiCache, response);
        mdiCache = createDeletePayloads(mdiCache, response);
        mdiCache = createDeletedEntityList(mdiCache, response);

        switch (entity.toLowerCase()) {
            case "costcenter":
                nextDeltaTokenCostCenter = response.jsonPath().getString("nextDeltaToken");
                break;
            case "companycode":
                nextDeltaTokenCompanyCode = response.jsonPath().getString("nextDeltaToken");
                break;
            case "product":
                nextDeltaTokenProduct = response.jsonPath().getString("nextDeltaToken");
                break;
            case "exchangerate":
                nextDeltaTokenExchangeRate = response.jsonPath().getString("nextDeltaToken");
                break;
            default:
                throw new IllegalStateException("Unexpected value inside method updateMDICache: " + entity.toLowerCase());
        }
        return mdiCache;
    }

    public static void dataCleanUp() throws InterruptedException {
        logger.info("Do the data cleanup");
        Response response = OneMds.getCompanyCode(access_token);
        MDICache mdiCache = createDeletePayloadsForDataCleanup(new MDICache(), response);
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);

        response = OneMds.getCostCenter(access_token);
        mdiCache = createDeletePayloads(new MDICache(), response);
        OneMds.deleteEntity("costcenter", mdiCache.getDeleteEntityMap(), access_token);
    }

    public static void postTestDataCleanUp() throws InterruptedException {
        logger.info("Cleaning data post test");
        Response response = OneMds.getCompanyCode(access_token, freshDeltaTokenCompanyCode);
        MDICache mdiCache = createDeletePayloads(new MDICache(), response);
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);

        response = OneMds.getCostCenter(access_token, freshDeltaTokenCostCenter);
        mdiCache = createDeletePayloads(new MDICache(), response);
        OneMds.deleteEntity("costcenter", mdiCache.getDeleteEntityMap(), access_token);

        response = OneMds.getProduct(access_token, freshDeltaTokenCostCenter);
        mdiCache = createDeletePayloads(new MDICache(), response);
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);

        response = OneMds.getExchangeRate(access_token, freshDeltaTokenCostCenter);
        mdiCache = createDeletePayloads(new MDICache(), response);
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
    }

    public static List<CompanyCode> updateCompanyCodePayload(MDICache mdiCache) throws FileNotFoundException {
        List<CompanyCode> companyCodeList = new ArrayList<>();
        for (Map.Entry<String, JsonObject> entry : mdiCache.getInstanceResponseMap().entrySet()) {
            CompanyCode companyCode = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/CompanyCode.json")).getAsJsonObject(), CompanyCode.class);
            List<com.ariba.data.companycode.ChangeRequest> changeRequestList = new ArrayList<>();
            com.ariba.data.companycode.ChangeRequest changeRequest = companyCode.getChangeRequests().get(0);
            changeRequest.setOperation("update");
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.setPreviousVersionId(entry.getValue().get("versionId").getAsString());
            changeRequest.getInstance().setId(entry.getValue().get("instance").getAsJsonObject().get("id").getAsString());
            changeRequest.getInstance().setDisplayId(entry.getValue().get("instance").getAsJsonObject().get("displayId").getAsString());
            changeRequest.getInstance().getName().get(0).getContent().setName("test CCode " + RandomStringUtils.randomAlphanumeric(6));
            changeRequestList.add(changeRequest);
            companyCode.setChangeRequests(changeRequestList);
            companyCodeList.add(companyCode);
        }
        return companyCodeList;
    }

    public static List<ExchangeRate> updateExchangeRatePayloads(MDICache mdiCache) throws FileNotFoundException {
        List<ExchangeRate> exchangeRateList = new ArrayList<>();
        for (Map.Entry<String, JsonObject> entry : mdiCache.getInstanceResponseMap().entrySet()) {
            ExchangeRate exchangeRate = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/ExchangeRate.json")).getAsJsonObject(), ExchangeRate.class);
            List<com.ariba.data.exchangeRate.ChangeRequest> changeRequestList = new ArrayList<>();
            com.ariba.data.exchangeRate.ChangeRequest changeRequest = exchangeRate.getChangeRequests().get(0);
            changeRequest.setOperation("update");
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.setPreviousVersionId(entry.getValue().get("versionId").getAsString());
            changeRequest.getInstance().setId(entry.getValue().get("instance").getAsJsonObject().get("id").getAsString());
            changeRequest.getInstance().getFromCurrency().setCode(entry.getValue().get("instance").getAsJsonObject().get("fromCurrency").getAsJsonObject().get("code").getAsString());
            changeRequest.getInstance().getToCurrency().setCode(entry.getValue().get("instance").getAsJsonObject().get("toCurrency").getAsJsonObject().get("code").getAsString());
            double rate = Double.valueOf(RandomStringUtils.randomNumeric(2))+0.275;
            changeRequest.getInstance().setRate(Double.parseDouble(df.format(rate)));
            changeRequestList.add(changeRequest);
            exchangeRate.setChangeRequests(changeRequestList);
            exchangeRateList.add(exchangeRate);
        }
        return exchangeRateList;
    }

    public static List<CostCenter> createCostCenterPayloads(int numberOfCostCenter, String operation, String companyCode) throws FileNotFoundException {
        List<CostCenter> costCenterList = new ArrayList<>();
        List<ChangeRequest> changeRequestList = new ArrayList<>();
        CostCenter costCenter = new CostCenter();
        for (int i = 1; i <= numberOfCostCenter; i++) {
            costCenter = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/CostCenter.json")).getAsJsonObject(), CostCenter.class);
//            ChangeRequest changeRequest = new ChangeRequest();
            ChangeRequest changeRequest = costCenter.getChangeRequests().get(0);
            changeRequest.setOperation(operation);
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.getInstance().setDisplayName("test CCenter " + RandomStringUtils.randomAlphanumeric(6));
            changeRequest.getInstance().getLocalIdS4().setCompanyCode(companyCode);
            changeRequest.getInstance().getLocalIdS4().setCostCenterId("1720-" + RandomStringUtils.randomAlphanumeric(4));
            changeRequestList.add(changeRequest);
        }
        costCenter.setChangeRequests(changeRequestList);
        costCenterList.add(costCenter);
        return costCenterList;
    }

    public static List<CostCenter> updateCostCenterPayloads(MDICache mdiCache, String companyCode) throws FileNotFoundException {
        List<CostCenter> costCenterList = new ArrayList<>();
        for (Map.Entry<String, JsonObject> entry : mdiCache.getInstanceResponseMap().entrySet()) {
            CostCenter costCenter = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/CostCenter.json")).getAsJsonObject(), CostCenter.class);
            List<ChangeRequest> changeRequestList = new ArrayList<>();
            ChangeRequest changeRequest = costCenter.getChangeRequests().get(0);
            changeRequest.setOperation("update");
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.setPreviousVersionId(entry.getValue().get("versionId").getAsString());
            changeRequest.getInstance().setId(entry.getValue().get("instance").getAsJsonObject().get("id").getAsString());
            List<Name> names = changeRequest.getInstance().getAttributes().get(0).getContent().getName();
            names.get(0);
            for (Name name : names) {
                if (name.getLang().equalsIgnoreCase("en")) {
                    name.setContent("My CostCenter_" + RandomStringUtils.randomAlphanumeric(6));
                }
            }
            changeRequest.getInstance().setDisplayName(entry.getValue().get("instance").getAsJsonObject().get("displayName").getAsString());
            changeRequest.getInstance().getLocalIdS4().setCompanyCode(companyCode);
            changeRequest.getInstance().getLocalIdS4().setCostCenterId(entry.getValue().get("instance").getAsJsonObject().get("localIdS4").getAsJsonObject().get("costCenterId").getAsString());
            changeRequestList.add(changeRequest);
            costCenter.setChangeRequests(changeRequestList);
            costCenterList.add(costCenter);
        }
        return costCenterList;
    }

    public static MDICache createDeletePayloads(MDICache mdiCache, Response response) {
        JsonObject jsonObject = new JsonParser().parse(response.asString()).getAsJsonObject();
        JsonArray jsonArray = jsonObject.getAsJsonArray("log");
        for (JsonElement element : jsonArray) {
            if (!element.getAsJsonObject().get("event").getAsString().toLowerCase().equalsIgnoreCase("deleted")) {
                DeleteEntity deleteEntity = new DeleteEntity();
                deleteEntity.setOperation("delete");
                deleteEntity.setInstanceId(element.getAsJsonObject().get("instance").getAsJsonObject().get("id").getAsString());
                deleteEntity.setChangeToken(UUID.randomUUID().toString());
                deleteEntity.setPreviousVersionId(element.getAsJsonObject().get("versionId").getAsString());
                mdiCache.getDeleteEntityMap().put(element.getAsJsonObject().get("instance").getAsJsonObject().get("id").getAsString(), deleteEntity);
                masterDeleteEntityList.add(deleteEntity);
            }
        }
        return mdiCache;
    }
    public static MDICache createDeletePayloadsForDataCleanup(MDICache mdiCache, Response response) {
        JsonObject jsonObject = new JsonParser().parse(response.asString()).getAsJsonObject();
        JsonArray jsonArray = jsonObject.getAsJsonArray("log");
        JsonObject deleteJsonObject = new JsonObject();
        JsonArray deletejsonArray = new JsonArray();
        int count=0;
        for (JsonElement element : jsonArray) {
            if (!element.getAsJsonObject().get("event").getAsString().toLowerCase().equalsIgnoreCase("deleted") && !element.getAsJsonObject().get("event").getAsString().toLowerCase().equalsIgnoreCase("rejected")) {
                JsonObject object = new JsonObject();
                object.addProperty("operation","delete");
                object.addProperty("changeToken",UUID.randomUUID().toString());
                object.addProperty("previousVersionId",element.getAsJsonObject().get("versionId").getAsString());
                object.addProperty("instanceId",element.getAsJsonObject().get("instance").getAsJsonObject().get("id").getAsString());
                deletejsonArray.add(object);
                if (count >1005){
                    deleteJsonObject.addProperty("changeRequests", String.valueOf(deletejsonArray));
                    logger.info("delete payload till 1005: "+deleteJsonObject.toString().replace("\\","").replace("\"[","[").replace("]\"","]"));
                    OneMds.deleteCompanyCodeCleanUP(access_token,deleteJsonObject.toString().replace("\\","").replace("\"[","[").replace("]\"","]"));
                    deletejsonArray = new JsonArray();
                    count=0;
                }
            }
            count++;
        }
        deleteJsonObject.addProperty("changeRequests", String.valueOf(deletejsonArray));
        logger.info("delete payload after 1005: "+deleteJsonObject.toString().replace("\\","").replace("\"[","[").replace("]\"","]"));
        OneMds.deleteCompanyCodeCleanUP(access_token,deleteJsonObject.toString().replace("\\","").replace("\"[","[").replace("]\"","]"));
        return mdiCache;
    }


    public static List<Product> createProductPayloads(int numberOfProduct, String operation) throws FileNotFoundException {
        List<Product> productList = new ArrayList<>();
        for (int i = 1; i <= numberOfProduct; i++) {
            Product product = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/Product.json")).getAsJsonObject(), Product.class);
            List<com.ariba.data.product.ChangeRequest> changeRequestList = new ArrayList<>();
            com.ariba.data.product.ChangeRequest changeRequest = product.getChangeRequests().get(0);
            changeRequest.setOperation(operation);
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.getInstance().setDisplayId("test Product " + System.nanoTime());
            changeRequest.getInstance().setProductGroupLocalIdS4(RandomStringUtils.randomNumeric(4));
            changeRequestList.add(changeRequest);
            product.setChangeRequests(changeRequestList);
            productList.add(product);
            productSequence++;
        }
        return productList;
    }

    public static List<Product> updateProductPayloads(MDICache mdiCache) throws FileNotFoundException {
        List<Product> productList = new ArrayList<>();
        for (Map.Entry<String, JsonObject> entry : mdiCache.getInstanceResponseMap().entrySet()) {
            Product product = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/Product.json")).getAsJsonObject(), Product.class);
            List<com.ariba.data.product.ChangeRequest> changeRequestList = new ArrayList<>();
            com.ariba.data.product.ChangeRequest changeRequest = product.getChangeRequests().get(0);
            changeRequest.setOperation("update");
            changeRequest.setChangeToken(UUID.randomUUID().toString());
            changeRequest.setPreviousVersionId(entry.getValue().get("versionId").getAsString());
            changeRequest.getInstance().setId(entry.getValue().get("instance").getAsJsonObject().get("id").getAsString());
            changeRequest.getInstance().setDisplayId(entry.getValue().get("instance").getAsJsonObject().get("displayId").getAsString());
            changeRequest.getInstance().getName().get(0).setContent("Updated name_" + RandomStringUtils.randomAlphabetic(5));
            changeRequestList.add(changeRequest);
            product.setChangeRequests(changeRequestList);
            productList.add(product);
            productSequence++;
        }
        return productList;
    }

    public static MDICache createDeletedEntityList(MDICache mdiCache, Response response) {
        JsonObject jsonObject = new JsonParser().parse(response.asString()).getAsJsonObject();
        JsonArray jsonArray = jsonObject.getAsJsonArray("log");
        for (JsonElement element : jsonArray) {
            if (element.getAsJsonObject().get("event").getAsString().toLowerCase().equalsIgnoreCase("deleted")) {
                String instanceId = element.getAsJsonObject().get("instanceId").getAsString();
                mdiCache.getDeletedEnties().add(instanceId);
                mdiCache.getDeletedInstanceResponseMap().put(instanceId, mdiCache.getInstanceResponseMap().get(instanceId));
                mdiCache.getInstanceResponseMap().remove(instanceId);
            }
        }
        return mdiCache;
    }

    protected void getLog(String entity) {
        NextDeltaToken nextDeltaToken = null;
        try {
            nextDeltaToken = new Gson().fromJson(jsonParser.parse(new FileReader("./resources/mdiPayloads/NextDeltaTokenMap.json")).getAsJsonObject(), NextDeltaToken.class);
        } catch (FileNotFoundException e) {
            Assert.fail("NextDeltaTokenMap.json not found");
            e.printStackTrace();
        }
        switch (entity.toLowerCase()) {
            case "costcenter":
                response = OneMds.getCostCenter(access_token, nextDeltaToken.getNextDeltaTokenCostCenter());
                break;
            case "companycode":
                response = OneMds.getCompanyCode(access_token, nextDeltaToken.getNextDeltaTokenCompanyCode());
                break;
            case "product":
                response = OneMds.getProduct(access_token, nextDeltaToken.getNextDeltaTokenProduct());
                break;
            case "exchangerate":
                response = OneMds.getExchangeRate(access_token, nextDeltaToken.getNextDeltaTokenExchangeRate());
                break;
            default:
                throw new IllegalStateException("Unexpected value inside method getLog: " + entity.toLowerCase());
        }
    }

    protected void saveLatestDeltaTokens() {
        NextDeltaToken nextDeltaToken = new NextDeltaToken();
        nextDeltaToken.setNextDeltaTokenCompanyCode(nextDeltaTokenCompanyCode);
        nextDeltaToken.setNextDeltaTokenCostCenter(nextDeltaTokenCostCenter);
        nextDeltaToken.setNextDeltaTokenProduct(nextDeltaTokenProduct);
        Gson gson = new Gson();
        String json = gson.toJson(nextDeltaToken);
        try {
            FileWriter writer = new FileWriter("./resources/mdiPayloads/NextDeltaTokenMap.json");
            try {
                writer.write(json);
            } catch (IOException e) {
                Assert.fail("failed to write to file NextDeltaTokenMap.json");
                e.printStackTrace();
            }
            writer.close();

        } catch (IOException e) {
            Assert.fail("failed to write to file NextDeltaTokenMap.json");
            e.printStackTrace();
        }
    }

    protected void getLog(String entity, String nextDeltaToken) {
        switch (entity.toLowerCase()) {
            case "costcenter":
                response = OneMds.getCostCenter(access_token, nextDeltaToken);
                break;
            case "companycode":
                response = OneMds.getCompanyCode(access_token, nextDeltaToken);
                break;
            case "product":
                response = OneMds.getProduct(access_token, nextDeltaToken);
                break;
            case "exchangerate":
                response = OneMds.getExchangeRate(access_token, nextDeltaToken);
                break;
            default:
                throw new IllegalStateException("Unexpected value inside method getLog: " + entity.toLowerCase());
        }
    }

    protected String getFreshDeltaToken(String entity) {
        boolean hasMoreEvents = true;
        getLog(entity);
        hasMoreEvents = response.jsonPath().getBoolean("hasMoreEvents");
        String nextDeltaToken = response.jsonPath().getString("nextDeltaToken");
        while (hasMoreEvents) {
            getLog(entity, nextDeltaToken);
            nextDeltaToken = response.jsonPath().getString("nextDeltaToken");
            hasMoreEvents = response.jsonPath().getBoolean("hasMoreEvents");
        }
        return nextDeltaToken;
    }

    protected static Set<String> getCreatedEntityList(MDICache mdiCache) {
        Set<String> createdList = mdiCache.getInstanceResponseMap().keySet();
        for (String id : mdiCache.getDeletedEnties()) {
            createdList.remove(id);
        }
        return createdList;
    }

    protected void verifyEvents(MDICache mdiCache, String entity, String system, String realm, String anid) throws Exception {
        for (Map.Entry<String, JsonObject> entry : mdiCache.getInstanceResponseMap().entrySet()) {
            verifyCreatedUpdatedEvents(entry.getValue(), entity, system, realm, anid);
        }
        if (mdiCache.getInstanceResponseMap().size() == 0) {
            for (Map.Entry<String, JsonObject> entry : mdiCache.getDeletedInstanceResponseMap().entrySet()) {
                verifyDeletedEvents(entry.getValue(), entity, system, realm, anid);
            }
        }
    }

    protected void verifyDeletedEvents(JsonObject instance, String entity, String system, String realm, String anid) throws Exception {
        switch (entity.toLowerCase()) {
            case "costcenter":
                verifyDeletedCostCenter(instance, system, realm, anid);
                break;
            case "companycode":
                verifyDeletedCompanyCode(instance, system, realm, anid);
                break;
            case "product":
                verifyDeletedProduct(instance, system, realm, anid);
                break;
            case "exchangerate":
                verifyDeletedExchangeRate(instance, system, realm, anid);
                break;
            default:
                throw new IllegalStateException("Unexpected value inside method verifyDeletedEvents: " + entity.toLowerCase());
        }
    }

    protected void verifyCreatedUpdatedEvents(JsonObject object, String entity, String system, String realm, String anid) throws Exception {
        switch (entity.toLowerCase()) {
            case "costcenter":
                verifyUpdatedCostCenter(object, system, realm, anid);
                break;
            case "companycode":
                verifyUpdatedCompanyCode(object, system, realm, anid);
                break;
            case "product":
                verifyUpdatedProduct(object, system, realm, anid);
                break;
            case "exchangerate":
                verifyUpdatedExchangeRate(object, system, realm, anid);
                break;
            default:
                throw new IllegalStateException("Unexpected value inside method verifyCreatedUpdatedEvents: " + entity.toLowerCase());
        }
    }

    private void verifyUpdatedCostCenter(JsonObject instance, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting created/updated costcenter verification for anid " + anid + " ==================================================");
        SoftAssert softAssertion = new SoftAssert();
        String keys = "UniqueName,CostCenterDescription,CompanyCode,SenderBusinessSystemId,this.CompanyCode.UniqueName,this.CompanyCode.Description,PartitionNumber";
        String expectedDisplayName = instance.get("instance").getAsJsonObject().get("displayName").getAsString();
        String expectedDescription = instance.get("instance").getAsJsonObject().get("attributes").getAsJsonArray().get(0).getAsJsonObject().get("content").getAsJsonObject().get("name").getAsJsonArray().get(0).getAsJsonObject().get("content").getAsString();
        String expectedCompanyCode = instance.get("instance").getAsJsonObject().get("localIdS4").getAsJsonObject().get("companyCode").getAsString();
        int index = 0;
        if (system.equalsIgnoreCase("buyer")) {
            String query = scimHelper.constructQuery(keys, "ariba.core.CostCenter", "UniqueName='" + expectedDisplayName + "'", Boolean.FALSE);
            logger.info("Fetching result from s4/buyer : " + query);
            aqlPullResponse = aql.buyerPull(query, realm, anid, "en_US");
            JSONArray buyerDataArray = scimHelper.getResultsAsJson(keys, aqlPullResponse.getBody().asString().replace("\n", "").trim());
            logger.info("Cost center Buyer pull response : " + buyerDataArray);
            JsonArray buyerResponseArray = new JsonParser().parse(buyerDataArray.toString()).getAsJsonArray();
            if (buyerDataArray.length() == 2) {
                if (buyerResponseArray.get(index).getAsJsonObject().get("this.CompanyCode.UniqueName").getAsString().equalsIgnoreCase("")) {
                    index = 1;
                }
            } else {
                Assert.assertEquals(buyerResponseArray.size(), 1, expectedDisplayName + " - not found in " + system);
            }
            String buyerDisplayName = buyerResponseArray.get(index).getAsJsonObject().get("UniqueName").getAsString();
            String buyerDescription = buyerResponseArray.get(index).getAsJsonObject().get("CostCenterDescription").getAsString();
            String buyerCompanyCode = buyerResponseArray.get(index).getAsJsonObject().get("this.CompanyCode.UniqueName").getAsString();
            softAssertion.assertEquals(buyerDisplayName, expectedDisplayName, "Costcenter : Name mismatch in " + system + " Expected : [" + expectedDisplayName + "] Actual : [" + buyerDisplayName + "]");
            softAssertion.assertEquals(buyerDescription, expectedDescription, "CostCenter : Description mismatch in " + system + " Expected : [" + expectedDescription + "] Actual : [" + buyerDescription + "]");
            softAssertion.assertEquals(buyerCompanyCode, expectedCompanyCode, "CostCenter : companycode mismatch in " + system + " Expected : [" + expectedCompanyCode + "] Actual : [" + buyerCompanyCode + "]");
        }
        index = 0;
        logger.info("Fetching result from MDS hana");
        mdsOpenApiResponse = mds.openApiSearch(system, system, realm, anid, Constants.MDS_SEARCH_COSTCENTER, "UniqueName eq '" + expectedDisplayName + "'");
        JsonArray mdsResponseArray = new JsonParser().parse(mdsOpenApiResponse.asString()).getAsJsonArray();
        logger.info("Cost center MDS search response : " + mdsResponseArray);
        if (mdsResponseArray.size() == 2) {
            if (mdsResponseArray.get(index).getAsJsonObject().get("CompanyCode").getAsString().equalsIgnoreCase("NULL")) {
                index = 1;
            }
        } else {
            Assert.assertEquals(mdsResponseArray.size(), 1, expectedDisplayName + " - not found in MDS hana ");
        }
        String mdsDisplayName = mdsResponseArray.get(index).getAsJsonObject().get("UniqueName").getAsString();
        String mdsDescription = mdsResponseArray.get(0).getAsJsonObject().get("CostCenterDescription_en").getAsString();
        String mdsCompanyCode = mdsResponseArray.get(index).getAsJsonObject().get("CompanyCode").getAsString();
        softAssertion.assertEquals(mdsDisplayName, expectedDisplayName, "Costcenter : unique name mismatch in MDS hana" + " Expected : [" + expectedDisplayName + "] Actual : [" + mdsDisplayName + "]");
        Assert.assertTrue(mdsResponseArray.get(0).getAsJsonObject().has("CostCenterDescription_en"), "CostCenterDescription is NULL in Hana");
        softAssertion.assertEquals(mdsDescription, expectedDescription, "Costcenter : description mismatch in MDS hana" + " Expected : [" + expectedDescription + "] Actual : [" + mdsDescription + "]");
        softAssertion.assertEquals(mdsCompanyCode, expectedCompanyCode, "Costcenter : company code mismatch in MDS hana" + " Expected : [" + expectedCompanyCode + "] Actual : [" + mdsCompanyCode + "]");
        softAssertion.assertAll();
        logger.info("============================ completed costcenter verification of : " + expectedDisplayName + " for anid " + anid + " ==================================================");
    }


    private void verifyUpdatedCompanyCode(JsonObject object, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting created/updated ComapnyCode verification for anid " + anid + " ==================================================");
        SoftAssert softAssertion = new SoftAssert();
        String name = object.get("instance").getAsJsonObject().get("displayId").getAsString();
        String expectedUniqueName = name;
        String expectedDescription = object.get("instance").getAsJsonObject().get("name").getAsString();
        if (system.equalsIgnoreCase("buyer")) {
            String query = scimHelper.constructQuery("UniqueName,Description,PartitionNumber", "ariba.core.CompanyCode", "UniqueName='" + name + "'", Boolean.FALSE);
            logger.info("Fetching result from buyer : " + query);
            aqlPullResponse = aql.buyerPull(query, realm, anid, "en_US");
            JSONArray buyerDataArray = scimHelper.getResultsAsJson("UniqueName,Description,PartitionNumber", aqlPullResponse.getBody().asString().replace("\n", "").trim());
            logger.info("Comapny code Buyer pull response : " + buyerDataArray);
            JsonArray buyerResponseArray = new JsonParser().parse(buyerDataArray.toString()).getAsJsonArray();
            Assert.assertEquals(buyerResponseArray.size(), 1, "Companycode : " + name + " count mismatch in buyer/s4");
            String buyerUniqueName = buyerResponseArray.get(0).getAsJsonObject().get("UniqueName").getAsString();
            String buyerDescription = buyerResponseArray.get(0).getAsJsonObject().get("Description").getAsString();
            Assert.assertEquals(buyerResponseArray.size(), 1, "Records not found in " + system);
            softAssertion.assertEquals(buyerUniqueName, expectedUniqueName, "Name mismatch in " + system + " Expected : [" + expectedUniqueName + "] Actual : [" + buyerUniqueName + "]");
            softAssertion.assertEquals(buyerDescription, expectedDescription, "Description mismatch in " + system + " Expected : " + expectedDescription + "] Actual : [" + buyerDescription + "]");
        }
        logger.info("Fetching result from MDS hana");
        mdsOpenApiResponse = mds.openApiSearch(system, system, realm, anid, Constants.COMPANY_CODE, "UniqueName eq '" + name + "'");
        JsonArray mdsResponseArray = new JsonParser().parse(mdsOpenApiResponse.asString()).getAsJsonArray();
        Assert.assertEquals(mdsResponseArray.size(), 1, "Records not found in MDS hana");
        String mdsUniqueName = mdsResponseArray.get(0).getAsJsonObject().get("UniqueName").getAsString();
        String mdsDescription = mdsResponseArray.get(0).getAsJsonObject().get("Description").getAsString();
        Assert.assertEquals(mdsResponseArray.size(), 1, "Records not found in MDS hana");
        softAssertion.assertEquals(mdsUniqueName, expectedUniqueName, "Name mismatch in MDS hana" + " Expected : " + expectedUniqueName + "] Actual : [" + mdsUniqueName + "]");
        softAssertion.assertEquals(mdsDescription, expectedDescription, "Description mismatch in MDS hana" + " Expected : " + expectedUniqueName + "] Actual : [" + mdsDescription + "]");
        softAssertion.assertAll();
        logger.info("============================ completed CompanyCode verification of : " + name + " for anid " + anid + " ==================================================");
    }

    private void verifyUpdatedExchangeRate(JsonObject object, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting created/updated ExchangeRate verification for anid " + anid + " ==================================================");
        String keys = "UniqueName,Rate,this.FromCurrency.UniqueName,this.ToCurrency.UniqueName,PartitionNumber";
        SoftAssert softAssertion = new SoftAssert();
        String expectedFromCurrency = object.get("instance").getAsJsonObject().get("fromCurrency").getAsJsonObject().get("code").getAsString();
        String expectedToCurrency = object.get("instance").getAsJsonObject().get("toCurrency").getAsJsonObject().get("code").getAsString();
        String date = object.get("instance").getAsJsonObject().get("effectiveDate").getAsString();
        String UniqueName = expectedFromCurrency+":"+expectedToCurrency;
        double expectedExchangeRate = object.get("instance").getAsJsonObject().get("exchangeRate").getAsDouble();
        String query = scimHelper.constructQuery(keys, "ariba.basic.core.CurrencyConversionRate", "UniqueName='" + UniqueName + "'"+" and CurrencyConversionRate.Date = date('"+date+" 00:00:00 PDT')", Boolean.FALSE);
        logger.info("Fetching result from buyer : " + query);
        if (system.equalsIgnoreCase("buyer")) {
            aqlPullResponse = aql.buyerPull(query, realm, anid, "en_US");
        } else {
            aqlPullResponse = aql.sourcingPull(query, realm, anid, "en_US");
        }
        JSONArray buyerDataArray = scimHelper.getResultsAsJson(keys, aqlPullResponse.getBody().asString().replace("\n", "").trim());
        JsonArray buyerResponseArray = new JsonParser().parse(buyerDataArray.toString()).getAsJsonArray();
        logger.info("ExchangeRate Buyer/s4 pull response : " + buyerResponseArray);
        Assert.assertEquals(buyerResponseArray.size(), 1, "ExchangeRate : " + UniqueName + " count mismatch in buyer/s4");
        String buyerFromCurrency = buyerResponseArray.get(0).getAsJsonObject().get("this.FromCurrency.UniqueName").getAsString();
        String buyerToCurrency = buyerResponseArray.get(0).getAsJsonObject().get("this.ToCurrency.UniqueName").getAsString();

        String buyerExchangeRate = buyerResponseArray.get(0).getAsJsonObject().get("Rate").getAsString();
        double buyerRate = Double.valueOf(buyerExchangeRate);
        buyerRate = Double.parseDouble(df.format(buyerRate));

        softAssertion.assertEquals(buyerFromCurrency, expectedFromCurrency, "FromCurrency mismatch in " + system + " Expected : [" + expectedFromCurrency + "] Actual : [" + buyerFromCurrency + "]");
        softAssertion.assertEquals(buyerToCurrency, expectedToCurrency, "ToCurrency mismatch in " + system + " Expected : [" + expectedToCurrency + "] Actual : [" + buyerToCurrency + "]");
        softAssertion.assertEquals(buyerRate, expectedExchangeRate, "ExchangeRate mismatch in " + system + " Expected : [" + expectedExchangeRate + "] Actual : [" + buyerRate + "]");
        logger.info("Fetching result from MDS hana");
        mdsOpenApiResponse = mds.advancedApiSearchUsingUniqueName(system, system, realm, anid, Constants.EXCHANGE_RATE_ADV, UniqueName);
        JsonArray mdsResponseArray = new JsonParser().parse(mdsOpenApiResponse.asString()).getAsJsonArray();
        logger.info("ExchangeRate MDS hana pull response : " + mdsResponseArray);
        Assert.assertEquals(mdsResponseArray.size(), 1, "Records not found in MDS hana");
        String mdsFromCurrency = mdsResponseArray.get(0).getAsJsonObject().get("FromCurrency_UniqueName").getAsString();
        String mdsToCurrency = mdsResponseArray.get(0).getAsJsonObject().get("ToCurrency_UniqueName").getAsString();
        String mdsExchangeRate = mdsResponseArray.get(0).getAsJsonObject().get("Rate").getAsString();
        double mdsRate = Double.valueOf(mdsExchangeRate);
        mdsRate = Double.parseDouble(df.format(mdsRate));
        Assert.assertEquals(mdsResponseArray.size(), 1, "Records not found in MDS hana");
        softAssertion.assertEquals(mdsFromCurrency, expectedFromCurrency, "FromCurrency mismatch in " + system + " Expected : [" + expectedFromCurrency + "] Actual : [" + mdsFromCurrency + "]");
        softAssertion.assertEquals(mdsToCurrency, expectedToCurrency, "ToCurrency mismatch in " + system + " Expected : [" + expectedToCurrency + "] Actual : [" + mdsToCurrency + "]");
        softAssertion.assertEquals(mdsRate, expectedExchangeRate, "ExchangeRate mismatch in " + system + " Expected : [" + expectedExchangeRate + "] Actual : [" + mdsRate + "]");
        softAssertion.assertAll();
        logger.info("============================ completed CompanyCode verification of : " + UniqueName + " for anid " + anid + " ==================================================");
    }

    public static void main(String[] args) throws Exception {
        OneMDSHelper oneMDSHelper = new OneMDSHelper();
        oneMDSHelper.verifyUpdatedExchangeRate(new JsonObject(), "buyer", "accAcwSap", "AN02000580552");
    }

    private void verifyUpdatedProduct(JsonObject object, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting created/updated Product verification for anid " + anid + " ==================================================");

        SoftAssert softAssertion = new SoftAssert();
        String name = object.get("instance").getAsJsonObject().get("displayId").getAsString();
        logger.info("Fetching result from MDS hana");
        mdsAdvancedSearchApiResponse = mds.mdsAdvancedSearchApiResponse(system, realm, anid, Constants.PRODUCTS, "", "ItemMasterKey.ProductInternalID='" + name + "'", "PlantMapAssociation", "zh_CN");

        JsonArray mdsResponseArray = new JsonParser().parse(mdsAdvancedSearchApiResponse.asString()).getAsJsonArray();
        String expectedProductInternalID = name;
//        String expectedSenderBusinessSystemId = object.get("instance").getAsJsonObject().get("name").getAsString();
        String expectedDescription = object.get("instance").getAsJsonObject().get("name").getAsJsonArray().get(0).getAsJsonObject().get("content").getAsString();
        String expectedProductTypeCode = object.get("instance").getAsJsonObject().get("type").getAsJsonObject().get("code").getAsString();
        String expectedProductGroupInternalID = object.get("instance").getAsJsonObject().get("productGroupLocalIdS4").getAsString();
        String expectedBaseMeasureUnitCode = object.get("instance").getAsJsonObject().get("baseUnitOfMeasure").getAsJsonObject().get("code").getAsString();
        String expectedOrderUnit = object.get("instance").getAsJsonObject().get("procurementAspect").getAsJsonObject().get("orderUnit").getAsJsonObject().get("code").getAsString();
        List<String> expectedPlantIdList = new ArrayList<>();
        for (JsonElement element : object.get("instance").getAsJsonObject().get("plants").getAsJsonArray()) {
            expectedPlantIdList.add(element.getAsJsonObject().get("id").getAsString());
        }
        Assert.assertEquals(mdsResponseArray.size(), 1, "Records not found in MDS hana");
        String mdsProductInternalID = mdsResponseArray.get(0).getAsJsonObject().get("ItemMasterKey.ProductInternalID").getAsString();
//        String mdsSenderBusinessSystemId = mdsResponseArray.get(0).getAsJsonObject().get("ItemMasterKey.SenderBusinessSystemId").getAsString();//TBD
        String mdsDescription = mdsResponseArray.get(0).getAsJsonObject().get("ItemMasterLangAssociation").getAsJsonArray().get(0).getAsJsonObject().get("Description").getAsString();
        String mdsProductTypeCode = mdsResponseArray.get(0).getAsJsonObject().get("ProductTypeCode").getAsString();
        String mdsProductGroupInternalID = mdsResponseArray.get(0).getAsJsonObject().get("ProductGroupInternalID").getAsString();
        String mdsBaseMeasureUnitCode = mdsResponseArray.get(0).getAsJsonObject().get("BaseMeasureUnitCode").getAsString();
        String mdsOrderUnit = mdsResponseArray.get(0).getAsJsonObject().get("OrderUnit").getAsString();
        List<String> mdsProductPlantIDList = new ArrayList<>();
        for (JsonElement element : mdsResponseArray.get(0).getAsJsonObject().get("PlantMapAssociation").getAsJsonArray()) {
            mdsProductPlantIDList.add(element.getAsJsonObject().get("CommonAddressKey.UniqueName").getAsString());
        }


        Assert.assertEquals(mdsResponseArray.size(), 1, "Records not found in MDS hana");
        softAssertion.assertEquals(mdsProductInternalID, expectedProductInternalID, "ProductInternalID mismatch in MDS hana" + " Expected : " + expectedProductInternalID + "] Actual : [" + mdsProductInternalID + "]");
//        softAssertion.assertEquals(mdsSenderBusinessSystemId, expectedSenderBusinessSystemId, "Description mismatch in MDS hana" + " Expected : " + expectedUniqueName + "] Actual : [" + mdsDescription + "]");
        softAssertion.assertEquals(mdsDescription, expectedDescription, "Description mismatch in MDS hana" + " Expected : " + expectedDescription + "] Actual : [" + mdsDescription + "]");
        softAssertion.assertEquals(mdsProductTypeCode, expectedProductTypeCode, "ProductTypeCode mismatch in MDS hana" + " Expected : " + expectedProductTypeCode + "] Actual : [" + mdsProductTypeCode + "]");
        softAssertion.assertEquals(mdsProductGroupInternalID, expectedProductGroupInternalID, "ProductGroupInternalID mismatch in MDS hana" + " Expected : " + expectedProductGroupInternalID + "] Actual : [" + mdsProductGroupInternalID + "]");
        softAssertion.assertEquals(mdsBaseMeasureUnitCode, expectedBaseMeasureUnitCode, "BaseMeasureUnitCode mismatch in MDS hana" + " Expected : " + expectedBaseMeasureUnitCode + "] Actual : [" + mdsBaseMeasureUnitCode + "]");
        softAssertion.assertEquals(mdsProductPlantIDList.size(), expectedPlantIdList.size(), "ProductPlantID count mismatch in MDS hana" + " Expected : " + expectedPlantIdList.size() + "] Actual : [" + mdsProductPlantIDList.size() + "]");
        for (String plantID : expectedPlantIdList) {
            softAssertion.assertTrue(mdsProductPlantIDList.contains(plantID), "Plant ID not found in MDS hana : " + plantID);
        }
        softAssertion.assertEquals(mdsOrderUnit, expectedOrderUnit, "OrderUnit mismatch in MDS hana" + " Expected : " + expectedOrderUnit + "] Actual : [" + mdsOrderUnit + "]");
        softAssertion.assertAll();
        logger.info("============================ completed Product/ItemMaster verification of : " + name + " for anid " + anid + " ==================================================");
    }

    private void verifyUpdatedProductUsingOpenApi(JsonObject object, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting created/updated Product verification for anid " + anid + " ==================================================");

        SoftAssert softAssertion = new SoftAssert();
        String name = object.get("instance").getAsJsonObject().get("displayId").getAsString();
        logger.info("Fetching result from MDS hana");
        mdsOpenApiResponse = mds.openApiSearch(system, "mdni", realm, anid, Constants.MDS_OPEN_API_ITEM_MASTER, "ProductInternalID eq '" + name + "'");

        JsonArray mdsResponseArray = new JsonParser().parse(mdsOpenApiResponse.asString()).getAsJsonArray();
        String expectedProductInternalID = name;
//        String expectedSenderBusinessSystemId = object.get("instance").getAsJsonObject().get("name").getAsString();
        String expectedDescription = object.get("instance").getAsJsonObject().get("name").getAsJsonArray().get(0).getAsJsonObject().get("content").getAsString();
        String expectedProductTypeCode = object.get("instance").getAsJsonObject().get("type").getAsJsonObject().get("code").getAsString();
        String expectedProductGroupInternalID = object.get("instance").getAsJsonObject().get("productGroupLocalIdS4").getAsString();
        String expectedBaseMeasureUnitCode = object.get("instance").getAsJsonObject().get("baseUnitOfMeasure").getAsJsonObject().get("code").getAsString();
//        String expectedProductPlantID = object.get("instance").getAsJsonObject().get("plants").getAsJsonObject().get("ProductPlant").getAsJsonObject().get("id").getAsString();
        String expectedOrderUnit = object.get("instance").getAsJsonObject().get("procurementAspect").getAsJsonObject().get("orderUnit").getAsJsonObject().get("code").getAsString();


        String mdsProductInternalID = mdsResponseArray.get(0).getAsJsonObject().get("ProductInternalID").getAsString();
//        String mdsSenderBusinessSystemId = mdsResponseArray.get(0).getAsJsonObject().get("SenderBusinessSystemId").getAsString();//TBD
        String mdsDescription = mdsResponseArray.get(0).getAsJsonObject().get("Description_en").getAsString();
        String mdsProductTypeCode = mdsResponseArray.get(0).getAsJsonObject().get("ProductTypeCode").getAsString();
        String mdsProductGroupInternalID = mdsResponseArray.get(0).getAsJsonObject().get("ProductGroupInternalID").getAsString();
        String mdsBaseMeasureUnitCode = mdsResponseArray.get(0).getAsJsonObject().get("BaseMeasureUnitCode").getAsString();
//        String mdsProductPlantID = mdsResponseArray.get(0).getAsJsonObject().get("UniqueName").getAsString();//TBD
//        String mdsOrderUnit = mdsResponseArray.get(0).getAsJsonObject().get("OrderUnit").getAsString();


        Assert.assertEquals(mdsResponseArray.size(), 1, "Records not found in MDS hana");
        softAssertion.assertEquals(mdsProductInternalID, expectedProductInternalID, "ProductInternalID mismatch in MDS hana" + " Expected : " + expectedProductInternalID + "] Actual : [" + mdsProductInternalID + "]");
//        softAssertion.assertEquals(mdsSenderBusinessSystemId, expectedSenderBusinessSystemId, "Description mismatch in MDS hana" + " Expected : " + expectedUniqueName + "] Actual : [" + mdsDescription + "]");
        softAssertion.assertEquals(mdsDescription, expectedDescription, "Description mismatch in MDS hana" + " Expected : " + expectedDescription + "] Actual : [" + mdsDescription + "]");
        softAssertion.assertEquals(mdsProductTypeCode, expectedProductTypeCode, "ProductTypeCode mismatch in MDS hana" + " Expected : " + expectedProductTypeCode + "] Actual : [" + mdsProductTypeCode + "]");
        softAssertion.assertEquals(mdsProductGroupInternalID, expectedProductGroupInternalID, "ProductGroupInternalID mismatch in MDS hana" + " Expected : " + expectedProductGroupInternalID + "] Actual : [" + mdsProductGroupInternalID + "]");
        softAssertion.assertEquals(mdsBaseMeasureUnitCode, expectedBaseMeasureUnitCode, "BaseMeasureUnitCode mismatch in MDS hana" + " Expected : " + expectedBaseMeasureUnitCode + "] Actual : [" + mdsBaseMeasureUnitCode + "]");
//        softAssertion.assertEquals(mdsProductPlantID, expectedProductPlantID, "ProductPlantID mismatch in MDS hana" + " Expected : " + expectedProductPlantID + "] Actual : [" + mdsProductPlantID + "]");
//        softAssertion.assertEquals(mdsOrderUnit, expectedOrderUnit, "OrderUnit mismatch in MDS hana" + " Expected : " + expectedOrderUnit + "] Actual : [" + mdsOrderUnit + "]");
        softAssertion.assertAll();
        logger.info("============================ completed Product/ItemMaster verification of : " + name + " for anid " + anid + " ==================================================");
    }

    private void verifyDeletedCompanyCode(JsonObject object, String system, String realm, String anid) throws Exception {
        SoftAssert softAssertion = new SoftAssert();
        String name = object.get("instance").getAsJsonObject().get("displayId").getAsString();
        String query = scimHelper.constructQuery("UniqueName,Description,PartitionNumber", "ariba.core.CompanyCode", "UniqueName='" + name + "'", Boolean.FALSE);
        if (system.equalsIgnoreCase("buyer")) {
            logger.info("Fetching result from s4/buyer : " + query);
            aqlPullResponse = aql.buyerPull(query, realm, anid, "en_US");
            JSONArray buyerDataArray = scimHelper.getResultsAsJson("UniqueName,Description,PartitionNumber", aqlPullResponse.getBody().asString().replace("\n", "").trim());
            JsonArray buyerResponseArray = new JsonParser().parse(buyerDataArray.toString()).getAsJsonArray();
            logger.info("Comapny code Buyer pull response in case of delete : " + buyerDataArray);
            softAssertion.assertEquals(buyerResponseArray.size(), 0, "CompanyCode with unique name " + name + " not deleted in s4/buyer");
        }

        logger.info("Fetching result from MDS hana");
        mdsOpenApiResponse = mds.openApiSearch(system, system, realm, anid, Constants.COMPANY_CODE, "UniqueName eq '" + name + "'");
        JsonArray mdsResponseArray = new JsonParser().parse(mdsOpenApiResponse.asString()).getAsJsonArray();
        logger.info("Comapany Code MDS search response : " + mdsResponseArray);
        softAssertion.assertEquals(mdsResponseArray.size(), 0, "CompanyCode with unique name " + name + " not deleted in mds hana");
        softAssertion.assertAll();
        logger.info("============================ completed CompanyCode verification of : " + name + " for anid " + anid + " ==================================================");
    }

    private void verifyDeletedCostCenter(JsonObject instance, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting Deleted costcenter verification for anid " + anid + " ==================================================");
        SoftAssert softAssertion = new SoftAssert();
        String keys = "UniqueName,CostCenterDescription,CompanyCode,SenderBusinessSystemId,this.CompanyCode.UniqueName,this.CompanyCode.Description,PartitionNumber";
        String expectedDisplayName = instance.get("instance").getAsJsonObject().get("displayName").getAsString();
        if (system.equalsIgnoreCase("buyer")) {
            String query = scimHelper.constructQuery(keys, "ariba.core.CostCenter", "UniqueName='" + expectedDisplayName + "'", Boolean.FALSE);
            logger.info("Fetching result from s4/buyer : " + query);
            aqlPullResponse = aql.buyerPull(query, realm, anid, "en_US");
            JSONArray buyerDataArray = scimHelper.getResultsAsJson(keys, aqlPullResponse.getBody().asString().replace("\n", "").trim());
            logger.info("Cost center Buyer pull response : " + buyerDataArray);
            JsonArray buyerResponseArray = new JsonParser().parse(buyerDataArray.toString()).getAsJsonArray();
            Assert.assertEquals(buyerResponseArray.size(), 0, "CostCenter with unique name " + expectedDisplayName + " not deleted in s4/buyer");
        }
        logger.info("Fetching result from MDS hana");
        mdsOpenApiResponse = mds.openApiSearch(system, system, realm, anid, Constants.MDS_SEARCH_COSTCENTER, "UniqueName eq '" + expectedDisplayName + "'");
        JsonArray mdsResponseArray = new JsonParser().parse(mdsOpenApiResponse.asString()).getAsJsonArray();
        logger.info("Cost center MDS search response : " + mdsResponseArray);
        Assert.assertEquals(mdsResponseArray.size(), 0, "CostCenter with unique name " + expectedDisplayName + " not deleted in mds hana");
        softAssertion.assertAll();
        logger.info("============================ completed deleted costcenter verification of : " + expectedDisplayName + " for anid " + anid + " ==================================================");
    }

    private void verifyDeletedProduct(JsonObject object, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting Deleted Product verification for anid " + anid + " ==================================================");
        SoftAssert softAssertion = new SoftAssert();
        String name = object.get("instance").getAsJsonObject().get("displayId").getAsString();
        logger.info("Fetching result from MDS hana");
        mdsAdvancedSearchApiResponse = mds.mdsAdvancedSearchApiResponse(system, realm, anid, Constants.PRODUCTS, "", "ItemMasterKey.ProductInternalID='" + name + "'", "PlantMapAssociation", "zh_CN");
        JsonArray mdsResponseArray = new JsonParser().parse(mdsAdvancedSearchApiResponse.asString()).getAsJsonArray();
        softAssertion.assertEquals(mdsResponseArray.size(), 0, "Product with unique name " + name + " not deleted in mds hana");
        softAssertion.assertAll();
        logger.info("============================ completed deleted Product/ItemMaster verification of : " + name + " for anid " + anid + " ==================================================");
    }

    private void verifyDeletedExchangeRate(JsonObject object, String system, String realm, String anid) throws Exception {
        logger.info("============================ Starting created/updated ExchangeRate verification for anid " + anid + " ==================================================");
        String keys = "UniqueName,Rate,this.FromCurrency.UniqueName,this.ToCurrency.UniqueName,PartitionNumber";
        SoftAssert softAssertion = new SoftAssert();
        String expectedFromCurrency = object.get("instance").getAsJsonObject().get("fromCurrency").getAsJsonObject().get("code").getAsString();
        String expectedToCurrency = object.get("instance").getAsJsonObject().get("toCurrency").getAsJsonObject().get("code").getAsString();
        String date = object.get("instance").getAsJsonObject().get("effectiveDate").getAsString();
        String UniqueName = expectedFromCurrency+":"+expectedToCurrency;
        String query = scimHelper.constructQuery(keys, "ariba.basic.core.CurrencyConversionRate", "UniqueName='" + UniqueName + "'"+" and CurrencyConversionRate.Date = date('"+date+" 00:00:00 PDT')", Boolean.FALSE);
        logger.info("Fetching result from buyer : " + query);
        if (system.equalsIgnoreCase("buyer")) {
            aqlPullResponse = aql.buyerPull(query, realm, anid, "en_US");
        } else {
            aqlPullResponse = aql.sourcingPull(query, realm, anid, "en_US");
        }
        JSONArray buyerDataArray = scimHelper.getResultsAsJson(keys, aqlPullResponse.getBody().asString().replace("\n", "").trim());
        logger.info("ExchangeRate Buyer/s4 pull response : " + buyerDataArray);
        JsonArray buyerResponseArray = new JsonParser().parse(buyerDataArray.toString()).getAsJsonArray();
        softAssertion.assertEquals(buyerResponseArray.size(), 0, "ExchangeRate with unique name " + UniqueName + " not deleted in s4/buyer");
        logger.info("Fetching result from MDS hana");
        mdsOpenApiResponse = mds.advancedApiSearchUsingUniqueName(system, system, realm, anid, Constants.EXCHANGE_RATE_ADV, UniqueName);
        JsonArray mdsResponseArray = new JsonParser().parse(mdsOpenApiResponse.asString()).getAsJsonArray();
        softAssertion.assertEquals(mdsResponseArray.size(), 0, "ExchangeRate with unique name " + UniqueName + " not deleted in mds hana");
        softAssertion.assertAll();
        logger.info("============================ [Deleted] completed ExchangeRate verification of : " + UniqueName + " for anid " + anid + " ==================================================");
    }

}
