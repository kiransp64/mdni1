package com.ariba.scimpatchtests;

import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import com.ariba.helpers.*;
import com.ariba.pojos.RestResponse;
import com.ariba.services.MDNI;
import com.ariba.services.MDS;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.UUID;

import static com.ariba.scim.SCIMGroups.GROUPNAME_EN;

public class PatchGroupsTest extends SCIMHelper {
    OAuthHelper oauthHelper = new OAuthHelper();
    SCIMHelper scimHelper = new SCIMHelper();
    MDSSearchHelper searchHelper = new MDSSearchHelper();


    String token;
    String displayName;
    Response createGroupResponse;
    private static JsonObject groupPatchPayloads;
    public static String KEYS = "UniqueName,Users.UniqueName,ChildGroups.UniqueName,Name,this,PartitionNumber";


    private void loadPayloads() {
        String JSON_PATH = "./resources/patchpayloads/PatchGroupPayload.json";
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(JSON_PATH));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        JsonParser parser = new JsonParser();
        groupPatchPayloads = parser.parse(br).getAsJsonObject();
    }

    public void createGroup() throws Exception {
        loadPayloads();
        UUID uuid = UUID.randomUUID();
        displayName = GROUPNAME_EN + uuid.toString();
        JsonObject groupPayload = groupPatchPayloads.get("group").getAsJsonObject();
        groupPayload.addProperty("displayName", displayName);
        token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
        MDNI mdni = new MDNI();
        createGroupResponse = mdni.createGroup(SAP_ANID, token, groupPayload.toString());
    }

    @Test(dataProvider = "getGroupPatchPayloads", dataProviderClass = PatchDataProvider.class)
    public void verifyScimPatchTests(String description, JsonObject patchPayload, String anid) throws Exception {
        createGroup();
        MDNI mdni = new MDNI();
        JsonParser parser = new JsonParser();
        System.out.println("Patch payload : " + patchPayload.get("patch").toString());
        Response getGroupResponseBeforePatch = mdni.getGroup(anid, token, displayName);
        JsonObject groupBeforePatch = parser.parse(getGroupResponseBeforePatch.asString()).getAsJsonObject();
        Response patchGroupResponse = mdni.patchGroup(anid, token, patchPayload.get("patch").toString(), displayName);
        Response getGroupResponseAfterPatch = mdni.getGroup(anid, token, displayName);
        JsonObject groupAfterPatch = parser.parse(getGroupResponseAfterPatch.asString()).getAsJsonObject();
        JSONObject groupUpdated = (JSONObject) jsonObject(groupAfterPatch.toString());
        JSONArray buyerGroupUpdated = getGroupFromBuyer(anid, displayName, token);
        JSONObject hanaGroupUpdated = getGroupUsingMdsSearch(displayName, token);

        validatePatchOperation(groupBeforePatch, groupAfterPatch, patchPayload);
        groupAfterPatch = parser.parse(getGroupResponseAfterPatch.asString()).getAsJsonObject();
        validatePatchOperation(groupAfterPatch, patchPayload);
        JSONArray issues = comparePayloadsForGroup(groupUpdated, hanaGroupUpdated, buyerGroupUpdated, Constants.LANG_EN);
        Assert.assertTrue(issues.length() == 0, "Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
    }

    @Test()
    public void defaultMemberResolveToUserTest() throws Exception {
        loadPayloads();
        UUID uuid = UUID.randomUUID();
        displayName = GROUPNAME_EN + uuid.toString();
        JsonObject groupPayload = groupPatchPayloads.get("groupWithoutMemberType").getAsJsonObject();
        groupPayload.addProperty("displayName", displayName);
        token = oauthHelper.getAccessToken(SAP_REALM, SAP_USERNAME, SAP_ANID, ORIGIN_SYS);
        MDNI mdni = new MDNI();
        createGroupResponse = mdni.createGroup(SAP_ANID, token, groupPayload.toString());
        Response getGroupResponse = mdni.getGroup(SAP_ANID, token, displayName);
        Assert.assertEquals(getGroupResponse.jsonPath().getString("members"), "[[value:Budget Approver, type:Group], [value:adavis, type:User]]");
    }

    @Test
    public void apeerRealmGroupTest() throws Exception {
        String s4Realm = PEER_REALM;
        String anid = PEER_REALM_ANID;
        String s4Token = oauthHelper.getAccessToken(s4Realm, SAP_USERNAME, anid, "s4");
        String buyerToken = oauthHelper.getAccessToken(s4Realm, SAP_USERNAME, anid, "buyer");
        enableFeatureSettings(buyerToken, anid);
        Thread.sleep(10000);//waiting for for some time for feature settings to take affect
        loadPayloads();
        UUID uuid = UUID.randomUUID();
        displayName = GROUPNAME_EN + uuid.toString();
        JsonObject groupPayload = groupPatchPayloads.get("group").getAsJsonObject();
        groupPayload.addProperty("displayName", displayName);
        MDS mds = new MDS();
        MDNI mdni = new MDNI();
        createGroupResponse = mdni.createGroup(anid, s4Token, groupPayload.toString());
        Response response = mds.mdsSearchWithToken(SEARCHBASEURL, Constants.MDS_SEARCH_GROUPS+"?$filter=GroupKey.UniqueName='" + displayName + "'", buyerToken);
        JsonArray jsonArray = new JsonParser().parse(response.asString()).getAsJsonArray();
        Assert.assertEquals(jsonArray.size(), 1, "Search could not find the user created with buyer context : " + displayName);
        int buyerPartitionNumber = jsonArray.get(0).getAsJsonObject().get("GroupKey.PartitionNumber").getAsInt();
        response = mds.mdsSearchWithToken(SEARCHBASEURL, Constants.MDS_SEARCH_GROUPS+"?$filter=GroupKey.UniqueName='" + displayName + "'", s4Token);
        jsonArray = new JsonParser().parse(response.asString()).getAsJsonArray();
        Assert.assertEquals(jsonArray.size(), 1, "Search could not find the user created with s4 context : " + displayName);
        int S4PartitionNumber = jsonArray.get(0).getAsJsonObject().get("GroupKey.PartitionNumber").getAsInt();
        Assert.assertTrue(S4PartitionNumber!=buyerPartitionNumber, "S4 and Buyer partition number should be different");

        JsonParser parser = new JsonParser();
        JsonObject patchPayload = PatchUsersTest.groupPatchPayloads.get("RemoveAddAlternativeDisplayName").getAsJsonObject();
        Response getGroupResponseBeforePatch = mdni.getGroup(anid, s4Token, displayName);
        JsonObject groupBeforePatch = parser.parse(getGroupResponseBeforePatch.asString()).getAsJsonObject();
        Response patchGroupResponse = mdni.patchGroup(anid, s4Token, patchPayload.get("patch").toString(), displayName);
        Response getGroupResponseAfterPatch = mdni.getGroup(anid, s4Token, displayName);
        JsonObject groupAfterPatch = parser.parse(getGroupResponseAfterPatch.asString()).getAsJsonObject();
        JSONObject groupUpdated = (JSONObject) jsonObject(groupAfterPatch.toString());
        JSONArray buyerGroupUpdated = getGroupFromBuyer(anid, displayName, buyerToken);
        JSONArray s4GroupUpdated = getGroupFromS4(anid, displayName, s4Token);
        JSONObject hanaGroupUpdated = getGroupUsingMdsSearch(displayName, s4Token);

        validatePatchOperation(groupBeforePatch, groupAfterPatch, patchPayload);
        groupAfterPatch = parser.parse(getGroupResponseAfterPatch.asString()).getAsJsonObject();
        validatePatchOperation(groupAfterPatch, patchPayload);
        JSONArray issues = comparePayloadsForGroup(groupUpdated, hanaGroupUpdated, buyerGroupUpdated, Constants.LANG_EN);
        Assert.assertTrue(issues.length() == 0, "Issues when compared payload with Group created in HANA and Buyer. Issues - " + issues);
        issues = comparePayloadsForGroup(groupUpdated, hanaGroupUpdated, s4GroupUpdated, Constants.LANG_EN);
        Assert.assertTrue(issues.length() == 0, "Issues when compared payload with Group created in HANA and S4. Issues - " + issues);
    }


    @Test(dataProvider = "getNegativeGroupPatchPayloads", dataProviderClass = PatchDataProvider.class)
    public void verifyScimPatchNegativeGroupTests(String description, JsonObject patchPayload, String anid, int responseCode, String msg) throws Exception {
        createGroup();
        MDNI mdni = new MDNI();
        JsonParser parser = new JsonParser();
        System.out.println("Patch payload : " + patchPayload);
        Response getGroupResponseBeforePatch = mdni.getGroup(anid, token, displayName);
        JsonObject groupBeforePatch = parser.parse(getGroupResponseBeforePatch.asString()).getAsJsonObject();
        Response patchGroupResponse;
        if (description.contains("Group that does not exists")) {
            patchGroupResponse = mdni.patchGroup(anid, token, patchPayload.get("patch").toString(), "InvalidDisplayName");

        } else {
            patchGroupResponse = mdni.patchGroup(anid, token, patchPayload.get("patch").toString(), displayName);
        }
        Assert.assertEquals(patchGroupResponse.getStatusCode(), responseCode);
        if (responseCode != 200) {
            Assert.assertEquals(patchGroupResponse.jsonPath().getString("detail"), msg, "Mismatch in the failure message");
        }
        Response getGroupResponseAfterPatch = mdni.getGroup(anid, token, displayName);
        JsonObject getUserAfterPatch = parser.parse(getGroupResponseAfterPatch.asString()).getAsJsonObject();
        Assert.assertEquals(groupBeforePatch, getUserAfterPatch, "Mismatch");
    }

    private JSONObject getGroupUsingMdsSearch(String displayName, String token) throws Exception {
        String url = "groups?$filter=GroupKey.UniqueName='" + displayName
                + "'&$expand=UsersMapAssociation,ChildGroupsMapAssociation&$locale=" + Constants.LANG_EN;
        RestResponse res = searchHelper.searchEntity(token, url);
        String content = res.getContent();
        Assert.assertNotNull(content, "Null response obtained");
        Assert.assertEquals(200, res.getCode(), "Response code is not matching");
        JSONArray hanaArray_ja = new JSONArray(content);
        Assert.assertEquals(hanaArray_ja.length(), 1,
                "Group with groupname " + displayName + " not found in MDS Search");
        JSONObject hanaGroup_ja = hanaArray_ja.getJSONObject(0);
        System.err.println(hanaGroup_ja);
        Assert.assertEquals(hanaGroup_ja.getJSONArray(Constants.HANA_GROUP_LANG_ASSOCIATION).getJSONObject(0)
                .getString(Constants.NAME), displayName, "Group Name in JA locale is not matching in HANA and Payload");

        return hanaGroup_ja;
    }

    private JSONArray getGroupFromBuyer(String anid, String displayName, String token) throws Exception {
        String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
                Boolean.TRUE);
        RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.BUYER, query, anid, Constants.LANG_EN);
        JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
        System.err.println(buyerDataArray);
        Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + displayName + " not found in buyer");
        Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), displayName,
                "Name is not matching in buyer");
        return buyerDataArray;
    }

    private JSONArray getGroupFromS4(String anid, String displayName, String token) throws Exception {
        String query = scimHelper.constructQuery(KEYS, "ariba.user.core.Group", "UniqueName='" + displayName + "'",
                Boolean.TRUE);
        RestResponse aqlRes = scimHelper.runAQLPull(token, Constants.SOURCING, query, anid, Constants.LANG_EN);
        JSONArray buyerDataArray = scimHelper.getResultsAsJson(KEYS, aqlRes.getContent());
        System.err.println(buyerDataArray);
        Assert.assertTrue(buyerDataArray.length() > 0, "Group with uniquename " + displayName + " not found in buyer");
        Assert.assertEquals(buyerDataArray.getJSONObject(0).getString(Constants.NAME), displayName,
                "Name is not matching in buyer");
        return buyerDataArray;
    }

    private void validatePatchOperation(JsonObject groupAfterPatch, JsonObject patchPayload) {
        JsonArray patchOperations = patchPayload.get("expectedAfterPatch").getAsJsonArray();
        JSONObject jo1 = new JSONObject(groupAfterPatch.toString());
        JSONObject jo2 = new JSONObject(patchPayload.toString());
        for (int i = 0; i < patchOperations.size(); i++) {
            String path = patchOperations.get(i).getAsJsonObject().get("path").getAsString();
            if (patchOperations.get(i).getAsJsonObject().get("value") instanceof JsonObject) {
                System.out.println("comparing" + "\n" + jo1.getJSONObject(path).toString() + "\n" + new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONObject("value"));
                JSONAssert.assertEquals(jo1.getJSONObject(path), new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONObject("value"), JSONCompareMode.LENIENT);
            } else if (patchOperations.get(i).getAsJsonObject().get("value") instanceof JsonArray) {
                System.out.println("comparing" + "\n" + jo1.getJSONArray(path).toString() + "\n" + new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONArray("value"));
                JSONAssert.assertEquals(jo1.getJSONArray(path), new JSONObject(jo2.getJSONArray("expectedAfterPatch").get(i).toString()).getJSONArray("value"), JSONCompareMode.LENIENT);

            } else {
                System.out.println("comparing" + "\n" + groupAfterPatch.get(path) + "\n" + patchPayload.get("expectedAfterPatch").getAsJsonArray().get(i).getAsJsonObject().get("value"));
                Assert.assertEquals(groupAfterPatch.get(path), patchPayload.get("expectedAfterPatch").getAsJsonArray().get(i).getAsJsonObject().get("value"), "Mismatch in expected patch value");
            }
        }
    }

    private void validatePatchOperation(JsonObject groupBeforePatch, JsonObject groupAfterPatch, JsonObject patchPayload) {
        JsonArray patchOperations = patchPayload.get("patch").getAsJsonObject().get("Operations").getAsJsonArray();
        for (int i = 0; i < patchOperations.size(); i++) {
            String key = patchOperations.get(i).getAsJsonObject().get("path").getAsString();
            groupBeforePatch.remove(key);
            groupAfterPatch.remove(key);
        }
        groupBeforePatch.get("meta").getAsJsonObject().remove("lastModified");
        groupBeforePatch.get("meta").getAsJsonObject().remove("version");
        groupAfterPatch.get("meta").getAsJsonObject().remove("lastModified");
        groupAfterPatch.get("meta").getAsJsonObject().remove("version");
        Assert.assertEquals(groupBeforePatch, groupAfterPatch, "Patch operation modified the attribute which was not in patch payload");
    }
}
