package com.ariba.onemds;

import com.ariba.data.cache.MDICache;
import com.ariba.data.companycode.CompanyCode;
import com.ariba.data.costcenter.CostCenter;
import com.ariba.data.exchangeRate.ExchangeRate;
import com.ariba.data.product.Product;
import com.ariba.services.MDNI;
import com.ariba.services.OneMds;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.FileNotFoundException;
import java.util.*;

public class DataExecuter extends OneMDSHelper {
    private static Logger logger = LogManager.getLogger(DataExecuter.class);
    static MDICache MDICompanyCode = new MDICache();
    static MDICache MDICostCenter = new MDICache();
    static MDICache MDIProduct = new MDICache();
    private static String mdiProcessToken = null;
    static MDNI mdni = new MDNI();



    protected static MDICache createCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 1;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        MDICompanyCode = mdiCache;
        return mdiCache;
    }

    protected static MDICache createProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        List<Product> productList = createProductPayloads(1, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createMultipleProduct() throws InterruptedException, FileNotFoundException {
        int numberOfProduct = 5;
        MDICache mdiCache = new MDICache();
        List<Product> productList = createProductPayloads(numberOfProduct, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createAndUpdateProduct(String anid) throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        List<Product> productList = createProductPayloads(1, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "Product");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"Product", StartDate);
        productList = updateProductPayloads(mdiCache);
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    private static Response waitForEventPopulatedInMDI(String entity, int count) throws InterruptedException {
        Response response;
        JsonObject jsonObject;
        JsonArray jsonArray;
        int triedCount = 1;
        int maxRetries = 20;
        while (true) {
            switch (entity.toLowerCase()) {
                case "costcenter":
                    response = OneMds.getCostCenter(access_token, nextDeltaTokenCostCenter);
                    break;
                case "companycode":
                    response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
                    break;
                case "product":
                    response = OneMds.getProduct(access_token, nextDeltaTokenProduct);
                    break;
                case "exchangerate":
                    response = OneMds.getExchangeRate(access_token, nextDeltaTokenExchangeRate);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value inside method waitForEventPopulatedInMDI: " + entity.toLowerCase());
            }
            jsonObject = new JsonParser().parse(response.asString()).getAsJsonObject();
            jsonArray = jsonObject.getAsJsonArray("log");
            if (jsonArray.size() >= count || triedCount > maxRetries) {
                break;
            } else {
                logger.info("waiting for " + entity + " to be populated. Current count is : " + jsonArray.size() + " expected count is : " + count);
                triedCount++;
                Thread.sleep(triedCount * 10000);
            }
        }
        Assert.assertTrue(triedCount < maxRetries);
        return response;
    }

    private static Response waitForCostCenterStatusChangeToNeedsReprocessing() throws InterruptedException {
        Response response = MDNI.getJobStatusOfObject(OneMdsDataProvider.IntegratedAnid, "CostCentre");
        logger.info("Final response when tried costcenter with company code that does not exist : " + response.asString());
        Assert.assertEquals(response.jsonPath().getString("Status"), "Needs Re-Processing", "CostCenter creation status should be 3 when company code doesn't exist");
        return response;
    }

    protected static MDICache createMultipleCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 10;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        return mdiCache;
    }

    protected static MDICache createAndUpdateCompanyCode(String anid) throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "CompanyCode");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"CompanyCode", StartDate);
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            companyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, companyCodeList);
            OneMDSHelper.response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, OneMDSHelper.response, "companycode");
        }
        logger.info("Final instance response map : " + mdiCache.getInstanceResponseMap());
        return mdiCache;
    }

    protected static MDICache createMultipleAndUpdateMultipleCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 2;
        int numberOfTimesUpdated = 2;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            companyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, companyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        logger.info("Final instance response map : " + mdiCache.getInstanceResponseMap());
        return mdiCache;

    }

    protected static MDICache createUpdateMultipleTimesProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 1;
        int numberOfTimesUpdated = 20;
        List<Product> productList = createProductPayloads(numberOfProduct, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            productList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, productList);
            response = waitForEventPopulatedInMDI("product", numberOfProduct);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        return mdiCache;
    }

    protected static MDICache createMultipleAndUpdateMultipleProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 2;
        int numberOfTimesUpdated = 2;
        List<Product> productList = createProductPayloads(numberOfProduct, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            productList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, productList);
            response = waitForEventPopulatedInMDI("product", numberOfProduct);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        return mdiCache;
    }

    protected static MDICache createAndDeleteCompanyCode(String anid) throws InterruptedException, FileNotFoundException {
        int numberOfCompanyCode = 1;
        MDICache mdiCache = new MDICache();
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "CompanyCode");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"CompanyCode", StartDate);
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        logger.info("Final instance response map : " + mdiCache.getInstanceResponseMap());
        logger.info("Final delete entity list : " + mdiCache.getDeleteEntityMap());
        return mdiCache;
    }

    protected static MDICache createAndDeleteMultipleCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 2;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        return mdiCache;
    }

    protected static MDICache createUpdateAndDeleteCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            companyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, companyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteAndCreateCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        List<CompanyCode> createCompanyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        List<CompanyCode> updateCompanyCodeList;
        OneMds.postCompanyCode(access_token, createCompanyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateCompanyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, updateCompanyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        logger.info("Final instance response map : " + mdiCache.getInstanceResponseMap());
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        OneMds.postCompanyCode(access_token, createCompanyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteCreateAndUpdateCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        List<CompanyCode> createCompanyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        List<CompanyCode> updateCompanyCodeList;
        OneMds.postCompanyCode(access_token, createCompanyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateCompanyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, updateCompanyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        logger.info("Final instance response map : " + mdiCache.getInstanceResponseMap());
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        OneMds.postCompanyCode(access_token, createCompanyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            createCompanyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, createCompanyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteCreateUpdateAndDeleteCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 2;
        int numberOfTimesUpdated = 10;
        List<CompanyCode> createCompanyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        List<CompanyCode> updateCompanyCodeList;
        OneMds.postCompanyCode(access_token, createCompanyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateCompanyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, updateCompanyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        OneMds.postCompanyCode(access_token, createCompanyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            createCompanyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, createCompanyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteAndCreateProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 1;
        int numberOfTimesUpdated = 1;
        List<Product> createProductList = createProductPayloads(numberOfProduct, "create");
        List<Product> updateProductList;
        OneMds.postProduct(access_token, createProductList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateProductList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, updateProductList);
            response = waitForEventPopulatedInMDI("product", 1);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        OneMds.postProduct(access_token, createProductList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteCreateAndUpdateProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 1;
        int numberOfTimesUpdated = 1;
        List<Product> createProductList = createProductPayloads(numberOfProduct, "create");
        List<Product> updateProductList;
        OneMds.postProduct(access_token, createProductList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateProductList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, updateProductList);
            response = waitForEventPopulatedInMDI("product", 1);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        OneMds.postProduct(access_token, createProductList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateProductList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, updateProductList);
            response = waitForEventPopulatedInMDI("product", 1);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteCreateUpdateAndDeleteProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 1;
        int numberOfTimesUpdated = 1;
        List<Product> createProductList = createProductPayloads(numberOfProduct, "create");
        List<Product> updateProductList;
        OneMds.postProduct(access_token, createProductList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateProductList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, updateProductList);
            response = waitForEventPopulatedInMDI("product", 1);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        OneMds.postProduct(access_token, createProductList);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateProductList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, updateProductList);
            response = waitForEventPopulatedInMDI("product", 1);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", 1);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createUpdateMultipleTimesAndDeleteCompanyCode() throws Exception {
        MDICache mdiCache = new MDICache();
        int numberOfCompanyCode = 3;
        int numberOfTimesUpdated = 3;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            companyCodeList = updateCompanyCodePayload(mdiCache);
            OneMds.postCompanyCode(access_token, companyCodeList);
            response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
            mdiCache = updateMDICache(mdiCache, response, "companycode");
        }
        logger.info("Final instance response map : " + mdiCache.getInstanceResponseMap());
        OneMds.deleteEntity("companycode", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCache = updateMDICache(mdiCache, response, "companycode");
        logger.info("Final instance response map : " + mdiCache.getInstanceResponseMap());
        logger.info("Final delete entity list : " + mdiCache.getDeleteEntityMap());
        return mdiCache;
    }

    protected static MDICache createAndDeleteProduct(String anid) throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 1;
        List<Product> productList = createProductPayloads(numberOfProduct, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "Product");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"Product", StartDate);
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 1;
        int numberOfTimesUpdated = 1;
        List<Product> productList = createProductPayloads(numberOfProduct, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            productList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, productList);
            response = waitForEventPopulatedInMDI("product", numberOfProduct);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createUpdateMultipleTimesAndDeleteProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 1;
        int numberOfTimesUpdated = 20;
        List<Product> productList = createProductPayloads(numberOfProduct, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            productList = updateProductPayloads(mdiCache);
            OneMds.postProduct(access_token, productList);
            response = waitForEventPopulatedInMDI("product", numberOfProduct);
            mdiCache = updateMDICache(mdiCache, response, "product");
        }
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createAndDeleteMultipleProduct() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfProduct = 3;
        List<Product> productList = createProductPayloads(numberOfProduct, "create");
        OneMds.postProduct(access_token, productList);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        OneMds.deleteEntity("product", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("product", numberOfProduct);
        mdiCache = updateMDICache(mdiCache, response, "product");
        return mdiCache;
    }

    protected static MDICache createCostCenterWithCompanyCode() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create and verify");
        int numberOfCostCenter = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        Set<String> createdCompanyCodes = getCreatedEntityList(MDICompanyCode);
//        for (String instance : createdCompanyCodes) {
//            String companyCode = MDICompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        String companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(numberOfCostCenter, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenter);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
        MDICostCenter = mdiCacheCostCenter;
        return mdiCacheCostCenter;
    }

    protected static MDICache createCostCenterWithCompanyCodePerf() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create and verify");
        for (int i = 0; i < 25; i++) {
            int numberOfCostCenter = 200;
            MDICache mdiCacheCostCenter = new MDICache();
            Set<String> createdCompanyCodes = getCreatedEntityList(MDICompanyCode);
            String companyCode = getCompanyCodeForCostCenter();
            List<CostCenter> costCenterList = createCostCenterPayloads(numberOfCostCenter, "create", companyCode);
            OneMds.postCostCenter(access_token, costCenterList);
//            response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenter);
//            mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
            logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
//            MDICostCenter = mdiCacheCostCenter;
        }
            return new MDICache();
    }

    protected static MDICache createMultipleCostCenterWithOneCompanyCode() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create multiple costcenter using one companyCode and verify");
        int numberOfCostCenter = 2;
        MDICache mdiCacheCostCenter = new MDICache();
        Set<String> createdCompanyCodes = getCreatedEntityList(MDICompanyCode);
//        for (String instance : createdCompanyCodes) {
//            String companyCode = MDICompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        String companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(numberOfCostCenter, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenter);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;
    }

    protected static MDICache createMultipleCostCenterWithDifferentCompanyCode() throws Exception {
        logger.info("CostCenter : Create multiple costcenter using different companyCode everytime and verify");
        int numberOfCompanyCode = 2;
        int numberOfCostCenterWithEachCompanyCode = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            String companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        String companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
//        logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;
    }

    protected static MDICache createCostCenterFirstThenCompanyCode() throws InterruptedException, FileNotFoundException {
        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
        for (CompanyCode instance : companyCodeList) {
            String companyCode = instance.getChangeRequests().get(0).getInstance().getDisplayId();
            List<CostCenter> costCenterList = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
            OneMds.postCostCenter(access_token, costCenterList);
            response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
            mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        }
        waitForCostCenterStatusChangeToNeedsReprocessing();
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        return mdiCacheCostCenter;
    }

    protected static MDICache createCostCenterWithCompanyCodeNotExist() throws InterruptedException, FileNotFoundException {
        MDICache mdiCacheCostCenter = new MDICache();
        String companyCode = "7777";
        List<CostCenter> costCenterList = createCostCenterPayloads(1, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", 1);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;

    }

    protected static MDICache createCostCenterWithOutCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCacheCostCenter = new MDICache();
        String companyCode = "";
        List<CostCenter> costCenterList = createCostCenterPayloads(1, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", 1);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;
    }

    protected static MDICache createCostcenterWithDeletedCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(1, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        OneMds.deleteEntity("companycode", mdiCacheCompanyCode.getDeleteEntityMap(), access_token);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        logger.info("Final instance response map : " + mdiCacheCompanyCode.getInstanceResponseMap());
        logger.info("Final delete entity list : " + mdiCacheCompanyCode.getDeleteEntityMap());
        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            String companyCode = MDICompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        String companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(1, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
//            response = OneMds.getCostCenter(access_token, nextDeltaTokenCostCenter);
        response = waitForEventPopulatedInMDI("costcenter", 1);

        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;
    }

    protected static MDICache createCostCenterWithOneCompanyCodeThenDeleteCompanyCode() throws InterruptedException, FileNotFoundException {
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(1, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            String companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        String companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(1, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
//            response = OneMds.getCostCenter(access_token, nextDeltaTokenCostCenter);
        response = waitForEventPopulatedInMDI("costcenter", 1);

        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        OneMds.deleteEntity("companycode", mdiCacheCompanyCode.getDeleteEntityMap(), access_token);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");

        logger.info("Final instance response map : " + mdiCacheCompanyCode.getInstanceResponseMap());
        logger.info("Final delete entity list : " + mdiCacheCompanyCode.getDeleteEntityMap());
        logger.info("Final instance response map : " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateDescriptionOfCostCenter(String anid) throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create, update description of costCenter and verify");
        int numberOfCostCenter = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        Set<String> createdCompanyCodes = getCreatedEntityList(MDICompanyCode);
        String companyCode = null;
//        for (String instance : createdCompanyCodes) {
//            companyCode = MDICompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList1 = createCostCenterPayloads(numberOfCostCenter, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList1);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenter);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "CostCentre");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"CostCentre", StartDate);
        List<CostCenter> costCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenter);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        logger.info("Final instance response map of cost center: " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;
    }

    protected static MDICache createDeleteCostCenter(String anid) throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create, delete and verify");
        int numberOfCostCenter = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCostCenter, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = waitForEventPopulatedInMDI("companycode", numberOfCostCenter);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(numberOfCostCenter, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenter);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "CostCentre");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"CostCentre", StartDate);
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenter);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateDeleteCostCenter() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create, update, delete and verify");
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
//        List<CostCenter> costCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        costCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        logger.info("Final instance response map of comapany code: " + mdiCacheCompanyCode.getInstanceResponseMap());
//        logger.info("Final delete entity list : " + mdiCacheCompanyCode.getDeleteEntityMap());
//        logger.info("Final instance response map of cost center: " + mdiCacheCostCenter.getInstanceResponseMap());
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateDeleteAndCreateCostCenter() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create, update, delete, Create same instance again verify");
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
        List<CostCenter> createCostCenterList = new ArrayList<>();
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        createCostCenterList = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, createCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        List<CostCenter> updateCostCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, updateCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        for (CostCenter c : createCostCenterList) {
            c.getChangeRequests().get(0).setChangeToken(UUID.randomUUID().toString());
        }
        OneMds.postCostCenter(access_token, createCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateDeleteCreateUpdateCostCenter() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create, update, delete, Create same instance again then Update verify");
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
        List<CostCenter> createCostCenterList = new ArrayList<>();
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        createCostCenterList = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, createCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        List<CostCenter> updateCostCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, updateCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        for (CostCenter c : createCostCenterList) {
            c.getChangeRequests().get(0).setChangeToken(UUID.randomUUID().toString());
        }
        OneMds.postCostCenter(access_token, createCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        for (CostCenter c : createCostCenterList) {
            c.getChangeRequests().get(0).setChangeToken(UUID.randomUUID().toString());
        }
        updateCostCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, updateCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateDeleteUpdateCostCenter() throws InterruptedException, FileNotFoundException {
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
        List<CostCenter> createCostCenterList = new ArrayList<>();
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        createCostCenterList = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, createCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        List<CostCenter> updateCostCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, updateCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        updateCostCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, updateCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateDeleteCreateUpdateDeleteCostCenter() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create, update, delete, Create same instance, Update, delete verify");
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 1;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
        List<CostCenter> createCostCenterList = new ArrayList<>();
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        createCostCenterList = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, createCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        List<CostCenter> updateCostCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, updateCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        for (CostCenter c : createCostCenterList) {
            c.getChangeRequests().get(0).setChangeToken(UUID.randomUUID().toString());
        }
        OneMds.postCostCenter(access_token, createCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        updateCostCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, updateCostCenterList);
        response = waitForEventPopulatedInMDI("costcenter", numberOfTimesUpdated);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }
    // create the refretials only once rather than creating in every test

    protected static MDICache createUpdateCompanyCodeOfCostCenter1() throws InterruptedException, FileNotFoundException {
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(1, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList1 = createCostCenterPayloads(1, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList1);
        response = waitForEventPopulatedInMDI("costcenter", 1);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        companyCodeList = createCompanyCodePayloads(1, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        JsonObject jsonObject = new JsonParser().parse(response.asString()).getAsJsonObject();
        JsonArray jsonArray = jsonObject.getAsJsonArray("log");
        companyCode = jsonArray.get(0).getAsJsonObject().get("instance").getAsJsonObject().get("displayId").getAsString();
        List<CostCenter> costCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
        response = waitForEventPopulatedInMDI("costcenter", 1);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateCompanyCodeOfCostCenter2() {
        MDICache mdiCacheCostCenter = new MDICache();
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateCompanyCodeOfCostCenter3() throws InterruptedException, FileNotFoundException {
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
        List<CompanyCode> companyCodeList = createCompanyCodePayloads(1, "create");
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList = createCostCenterPayloads(1, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList);
//            response = OneMds.getCostCenter(access_token, nextDeltaTokenCostCenter);
        response = waitForEventPopulatedInMDI("costcenter", 1);

        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        companyCodeList = updateCompanyCodePayload(mdiCacheCompanyCode);
        OneMds.postCompanyCode(access_token, companyCodeList);
        response = OneMds.getCompanyCode(access_token, nextDeltaTokenCompanyCode);
        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        return mdiCacheCostCenter;
    }

    protected static MDICache createMultipleDeleteAllCostCenter() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create multiple, delete all and verify");
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 2;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList1 = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList1);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            List<CostCenter> costCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
            OneMds.postCostCenter(access_token, costCenterList);
            response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
            mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        }
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }

    protected static MDICache createUpdateMultipleTimesAndDeleteCostCenter() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create, update multiple, delete and verify");
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 2;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
//        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList1 = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList1);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            List<CostCenter> costCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
            OneMds.postCostCenter(access_token, costCenterList);
            response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
            mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        }
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }

    protected static MDICache createMultipleAndUpdateMultipleCostCenter() throws InterruptedException, FileNotFoundException {
        logger.info("CostCenter : Create multiple, update multiple times and verify");
//        int numberOfCompanyCode = 1;
        int numberOfCostCenterWithEachCompanyCode = 1;
        int numberOfTimesUpdated = 2;
        MDICache mdiCacheCostCenter = new MDICache();
        MDICache mdiCacheCompanyCode = new MDICache();
        String companyCode = null;
//        List<CompanyCode> companyCodeList = createCompanyCodePayloads(numberOfCompanyCode, "create");
//        OneMds.postCompanyCode(access_token, companyCodeList);
//        response = waitForEventPopulatedInMDI("companycode", numberOfCompanyCode);
//        mdiCacheCompanyCode = updateMDICache(mdiCacheCompanyCode, response, "companycode");
        Set<String> createdCompanyCodes = getCreatedEntityList(mdiCacheCompanyCode);
//        for (String instance : createdCompanyCodes) {
//            companyCode = mdiCacheCompanyCode.getInstanceResponseMap().get(instance).get("instance").getAsJsonObject().get("displayId").getAsString();
        companyCode = getCompanyCodeForCostCenter();
        List<CostCenter> costCenterList1 = createCostCenterPayloads(numberOfCostCenterWithEachCompanyCode, "create", companyCode);
        OneMds.postCostCenter(access_token, costCenterList1);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
//        }
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            List<CostCenter> costCenterList = updateCostCenterPayloads(mdiCacheCostCenter, companyCode);
            OneMds.postCostCenter(access_token, costCenterList);
            response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
            mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        }
        OneMds.deleteEntity("costcenter", mdiCacheCostCenter.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("costcenter", numberOfCostCenterWithEachCompanyCode);
        mdiCacheCostCenter = updateMDICache(mdiCacheCostCenter, response, "costcenter");
        return mdiCacheCostCenter;
    }


    protected static MDICache createExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    protected static MDICache createAndUpdateExchangeRate(String anid) throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        int numberOfTimesUpdated = 1;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "ExchangeRate");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"ExchangeRate", StartDate);
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        return mdiCache;
    }

    protected static MDICache createAndDeleteExchangeRate(String anid) throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        Response mdniStatusResponse = mdni.getStatusWithObjectName(anid, "ExchangeRate");
        String StartDate = mdniStatusResponse.jsonPath().getString("StartDate");
        waitForNewEntityToBeCreated(anid,"ExchangeRate", StartDate);
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    private static Response waitForNewEntityToBeCreated(String anid, String objectName, String StartDate) throws InterruptedException {
        Response response = MDNI.waitForNewInstanceOfObjectCreated(anid, objectName, StartDate);
        logger.info("Final response when tried creating new  : "+objectName+" \n" + response.asString());
        Assert.assertNotEquals(response.jsonPath().getString("StartDate"), StartDate, "New record for entity "+objectName+" is not created");
        return response;
    }

    protected static MDICache createMultipleExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 3;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    protected static MDICache createMultipleAndUpdateMultipleExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 3;
        int numberOfTimesUpdated = 3;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        return mdiCache;
    }

    protected static MDICache createAndDeleteMultipleExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 3;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", numberOfExchangeRate);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    protected static MDICache createUpdateMultipleTimesAndDeleteExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        int numberOfTimesUpdated = 3;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    protected static MDICache createUpdateAndDeleteExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        int numberOfTimesUpdated = 1;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteAndCreateExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        int numberOfTimesUpdated = 1;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        OneMds.postExchangeRate(access_token, updateExchaneRateID(createExchangeRateList));
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    private static List<ExchangeRate> updateExchaneRateID(List<ExchangeRate> createExchangeRateList) {
        List<ExchangeRate> updatedCreateExchangeRateList = new ArrayList<>();
        for (ExchangeRate exchangeRate : createExchangeRateList) {
            exchangeRate.getChangeRequests().get(0).getInstance().setId("MDS/" + UUID.randomUUID().toString());
            updatedCreateExchangeRateList.add(exchangeRate);
        }
        return updatedCreateExchangeRateList;
    }

    protected static MDICache createUpdateDeleteCreateAndUpdateExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        int numberOfTimesUpdated = 1;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        OneMds.postExchangeRate(access_token, updateExchaneRateID(createExchangeRateList));
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        return mdiCache;
    }

    protected static MDICache createUpdateDeleteCreateUpdateAndDeleteExchangeRate() throws InterruptedException, FileNotFoundException {
        MDICache mdiCache = new MDICache();
        int numberOfExchangeRate = 1;
        int numberOfTimesUpdated = 1;
        List<ExchangeRate> createExchangeRateList = createExchangeRatePayloads(numberOfExchangeRate, "create");
        List<ExchangeRate> updateExchangeRatetList;
        OneMds.postExchangeRate(access_token, createExchangeRateList);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        OneMds.postExchangeRate(access_token, updateExchaneRateID(createExchangeRateList));
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        for (int i = 0; i < numberOfTimesUpdated; i++) {
            updateExchangeRatetList = updateExchangeRatePayloads(mdiCache);
            OneMds.postExchangeRate(access_token, updateExchangeRatetList);
            response = waitForEventPopulatedInMDI("exchangerate", 1);
            mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        }
        OneMds.deleteEntity("exchangerate", mdiCache.getDeleteEntityMap(), access_token);
        response = waitForEventPopulatedInMDI("exchangerate", 1);
        mdiCache = updateMDICache(mdiCache, response, "exchangerate");
        return mdiCache;
    }

    protected static MDICache startMdiProcess() throws InterruptedException {
//        if (mdiProcessToken == null) {
//            mdiProcessToken = OneMds.getOauthForMdiProcess();
//        }
//        MDNI mdni = new MDNI();
//        for (int i = 0; i < 13; i++) {
//            mdni.mdiProcess("AN02002584301", mdiProcessToken);
//            Thread.sleep(5000);
//        }
        logger.info("20 mins wait for mdni to pick the jobid and process it");
        Thread.sleep(60000);
        return new MDICache();
    }
}
