package com.ariba.resttests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ariba.helpers.OAuthHelper;

public class OAuthTests {

	@Test
	public void testOAuth() throws Exception {

		OAuthHelper oAuthHelper = new OAuthHelper();
		String token = oAuthHelper.getAccessToken("AN02001565601");
		System.err.println("Token is---------" + token);
		Assert.assertNotNull(token, "Token is null");
	}

}
