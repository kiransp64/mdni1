package com.ariba.spendvisibility;

public class AQLQueries {
    public static String costCenter = "select UniqueName,CostCenterDescription,PartitionNumber from ariba.core.CostCenter where CostCenter.UniqueName='@UniqueName'";
    public static String generalLedger = "select UniqueName,CompanyCode,GeneralLedgerDescription,PartitionNumber from ariba.core.GeneralLedger where GeneralLedger.UniqueName='@UniqueName'";
    public static String commodityCode = "select UniqueName,Name,PartitionNumber from ariba.common.core.PartitionedCommodityCode where PartitionedCommodityCode.UniqueName='@UniqueName'";
    public static String address = "select UniqueName,Name,PostalAddress.City,PostalAddress.State,PostalAddress.PostalCode,PartitionNumber from ariba.common.core.Address where Address.UniqueName='@UniqueName'";
    public static String itemMaster = "select * from ariba.basic.core.ItemMaster where UniqueName='@UniqueName'";
    public static String companyCode = "";

}
