 
package com.ariba.cig;
 
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
 
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
 
import com.ariba.helpers.BaseHelper;
import com.ariba.helpers.ConfigHelper;
import com.ariba.helpers.GetDataHelper;
import com.ariba.helpers.OAuthHelper;
import com.ariba.helpers.PostXMLDataHelper;
import com.ariba.httpcore.HttpRequests;
import com.ariba.pojos.RestResponse;
import com.ariba.utilities.DateFormatter;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
 
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
 
 
public class CIGTest {
 
       String endPointURLFalse = "https://devfarm.cobalt.ariba.com/mdni/erpintegration/api/uploadXMLData?tenantId=AN71000502099&objectName=Incoterms&cigSource=false";
       String endPointURLTrue = "https://devfarm.cobalt.ariba.com/mdni/erpintegration/api/uploadXMLData?tenantId=AN71000502099&objectName=Incoterms&cigSource=true";
       static CloseableHttpClient client;
      
      
       @Test
       public void request_cigSourceFalse() throws Exception {
             
              String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode01");
              
              System.out.println("=====CigSouce False=====");
               
              RestResponse response = retrieveStatusFromAPI(
                           endPointURLFalse,
            IncoTermBodyPayload);
              Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same Expected 200 and Actual "+response.getCode());
 
        
       }
      
       @Test
       public void request_cigSourceTrue_WithoutCertificate() throws Exception {
             
              String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode01");
              
              System.out.println("=====Without Certificate=====");             
               
              RestResponse response = retrieveStatusFromAPI(
                           endPointURLTrue,
            IncoTermBodyPayload);
              Assert.assertEquals(response.getCode(), BaseHelper.HTTP_500, "Response message is not same Expected 200 and Actual "+response.getCode());
 
        
       }
      
       @Test
       public void request_cigSourceTrue_WithCorrectCertificate() throws Exception {
             
              String IncoTermBodyPayload = getData("testMDNIIncotermsWithActionCode01");
              
              System.out.println("=====With Certificate=====");
             
               
              RestResponse response = retrieveStatusFromAPIWithCert(
                           endPointURLTrue,
            IncoTermBodyPayload);
              Assert.assertEquals(response.getCode(), BaseHelper.HTTP_200, "Response message is not same Expected 200 and Actual "+response.getCode());
 
        
       }
       public String getData(String dataType) throws InvalidFormatException, IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {                                       
              
               HashMap<String, String> masterData = new HashMap<String, String>();
              
               InputStream file = new FileInputStream("/Users/i514914/Downloads/mdniPayload.xlsx");
               //File file = new File("/Users/i330270/Downloads/mdniPayload1.xlsx");
              
               XSSFWorkbook wb = new XSSFWorkbook(file);
               XSSFSheet sheet = wb.getSheet("PayLoad");
               int rowCount = sheet.getLastRowNum();
                   for(int i=1;i<=rowCount;i++) {     
                       String key = sheet.getRow(i).getCell(0).getStringCellValue();
                       String value = sheet.getRow(i).getCell(1).getStringCellValue();
                       masterData.put(key, value);
                       }
                   //wb.close();
             return masterData.get(dataType);
           }
          
       private RestResponse retrieveStatusFromAPIWithCert (String endPointURL,
             
             String body)
                     {
                    
                     RestResponse response = null;
                    
                     try {
                     String userCredentials = "aribaws" + ":" + "go2aribago2ariba";
                     String basicAuth = "Basic "+ new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                    
                     SSLConnectionSocketFactory sslSf =  keyToolAuth();
                     //client = HttpClients.custom().setSSLSocketFactory(sslSf).build();
                    
                     HttpRequests connection = new HttpRequests();
                     //response = connection.httpPost(endPointURL, basicAuth, body);
                     response = connection.httpPostWithCert(endPointURL, basicAuth, body, sslSf);
                    
                    
                    
                    
                     // Writing the post data to the HTTP request body
                    
                    
                    
                     } catch (Exception ioe) {
                     ioe.printStackTrace();
                    
                     }
                    
                    
                     return response;
              }
        
        
        
       private RestResponse retrieveStatusFromAPI (String endPointURL,
             
             String body)
                     {
                    
                     RestResponse response = null;
                    
                     try {
                     String userCredentials = "aribaws" + ":" + "go2aribago2ariba";
                     String basicAuth = "Basic "+ new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                    
                     /*SSLSocketFactory sslSf =  keyToolAuth();
                     client = HttpClients.custom().setSSLSocketFactory((LayeredConnectionSocketFactory) sslSf).build();*/
                    
                     HttpRequests connection = new HttpRequests();
                     response = connection.httpPost(endPointURL, basicAuth, body);
                     //response = connection.httpPostWithCert(endPointURL, basicAuth, body, client);
                    
                    
                    
                    
                     // Writing the post data to the HTTP request body
                    
                    
                    
                     } catch (Exception ioe) {
                     ioe.printStackTrace();
                    
                     }
                    
                    
                     return response;
              }
        
        
       private String getHttpResponse (HttpURLConnection connection) throws IOException
           {
               BufferedReader in = null;
               StringBuffer response = new StringBuffer();
               try {
                   if (connection.getResponseCode() != HttpURLConnection.HTTP_OK
                       && connection.getErrorStream() != null) {
                       in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                   }
                   else {
                       in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                   }
                   String inputLine;
                   while ((inputLine = in.readLine()) != null) {
                       response.append(inputLine);
                   }
               } finally {
                   if (in != null) in.close();
               }
        
               return response.toString();
           }
        
 
           public String verifySuccessResponse (String response)
           {
               String responsepattern = "JobId .*";
               Pattern pattern = Pattern.compile(responsepattern, Pattern.CASE_INSENSITIVE);
               Matcher matcher = pattern.matcher(response);
               String jobID = response.replace("JobId ", "");
              
               boolean matches = matcher.matches();
               Assert.assertEquals("jobID does not match", matches == true);
               // Verify the status to be Processed
              
               return jobID;
        
           }
      
        
       public SSLConnectionSocketFactory  keyToolAuth() throws Exception {
              
               KeyStore clientStore = KeyStore.getInstance("JKS");
               InputStream inputStream = new FileInputStream("/Users/i514914/Downloads/dummy1.jks");
               clientStore.load(inputStream, "keypass".toCharArray());
               KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
               kmf.init(clientStore, "keypass".toCharArray());
               KeyManager[] kms = kmf.getKeyManagers();
               SSLContext sslcontext = SSLContexts.custom()
                       .loadKeyMaterial(clientStore, "keypass".toCharArray()).build();
   
               
                    SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
                       sslcontext,
                       new String[] { "TLSv1" },
                       null,
                       SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER); //TODO
          
            
             return sslsf;
           } 
        
 
 
}
 