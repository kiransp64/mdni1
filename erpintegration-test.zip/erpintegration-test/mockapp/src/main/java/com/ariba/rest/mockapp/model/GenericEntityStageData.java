package com.ariba.rest.mockapp.dao;


import java.util.Date;

import javax.persistence.*;

import org.json.simple.JSONObject;


@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@DiscriminatorColumn(name = "itemType", discriminatorType = DiscriminatorType.STRING)
public abstract class GenericEntityStageData {
    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "TENANT_ID")
    private long tenantId;

    @Column(name = "IS_ACTIVE")
    private int isActive;

    @Column(name = "DATE_CREATED")
    private Date dateCreated;

    @Column(name = "DATE_UPDATED")
    private Date dateUpdated;

    @Column(name = "STATUS")
    private int status = 1;

    @Column(name = "DATA_PATH")
    private String dataPath;

    @Version
    @Column(name = "VERSION")
    private Integer version;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getTenantId() {
        return tenantId;
    }

    public void setTenantId(long tenantId) {
        this.tenantId = tenantId;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDataPath() {
        return dataPath;
    }

    public void setDataPath(String dataPath) {
        this.dataPath = dataPath;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public abstract void setSpecialFields(JSONObject jsonObject);

}

