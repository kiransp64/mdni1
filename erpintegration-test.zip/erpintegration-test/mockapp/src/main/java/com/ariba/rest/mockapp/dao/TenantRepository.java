package com.ariba.rest.mockapp.dao;

import com.ariba.rest.mockapp.model.Tenant;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;


@Component("TenantRepositoryComponent")
public interface TenantRepository  extends PagingAndSortingRepository<Tenant, Long> {

    @Query("select t.tenantId from Tenant t where t.anId = :anId")
    public long findTenandId(@Param("anId") String anId);
}

