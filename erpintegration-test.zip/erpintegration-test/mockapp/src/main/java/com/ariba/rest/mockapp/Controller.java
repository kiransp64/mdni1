package com.ariba.rest.mockapp;

import java.util.List;

import com.ariba.rest.mockapp.dao.TenantRepository;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ariba.rest.mockapp.dao.StagedDataRepository;
import com.ariba.rest.mockapp.model.StagedData;

@RestController
@Configuration
@PropertySource("classpath:application.properties")
public class Controller {

	@Autowired
	StagedDataRepository stagedDataRepository;

	@Autowired
	TenantRepository tenantRepository;

	@Value("${warning.realms.list}")
	private String warningRealms;

	@Value("${fatalerror.realms.list}")
	private String fatalErrorRealms;

	@Value("${retry.realms.list}")
	private String retryRealms;

	@RequestMapping(value = "/getConfig/NativeIntegrationDirectAction", method = RequestMethod.GET)
	public String getConfig(@RequestParam(value = "realm", defaultValue = "none") String realm) {
		if (warningRealms.contains(realm) || fatalErrorRealms.contains(realm)){
			System.out.println("Realm ----"+ realm);
			return "{\"HttpAuthUniqueName\": \"aribaws\",\"HttpAuthPassword\": \"aribaws\"}";
		}
		else {
			return "{\"HttpAuthUniqueName\": \"aribaws\",\"HttpAuthPassword\": \"aribaws12345\"}";
		}
	}

	@RequestMapping(value = "/publishMasterData/NativeIntegrationDirectAction", method = RequestMethod.POST)
	public String publishMasterData(@RequestParam(value = "realm", defaultValue = "none") String realm,
									@RequestParam(value = "operation", defaultValue = "none") String operation,
									@RequestParam(value = "object", defaultValue = "none") String object, @RequestBody String data) {
		System.out.println("Data is -----------" + data);
		if (retryRealms.contains(realm)) {
			if (object.equalsIgnoreCase("CompanyCode") || object.equalsIgnoreCase("Incoterms"))
				return "{\"RecordsCreated\":1, \"FatalErrors\":[], \"WarningMessages\":[], \"RecordsDeleted\":0, \"NonFatalExceptions\":[], \"RecordsUpdated\":0}";
			else
				return "{\"RecordsCreated\":0, \"FatalErrors\":[], \"WarningMessages\":[{\"WarningRowNumber\":1,\"WarningMessage\":\"Referenced data of type CompanyCode\"}], \"RecordsDeleted\":0, \"NonFatalExceptions\":[], \"RecordsUpdated\":0}";
		}
		if (warningRealms.contains(realm)) {
			return "{\"RecordsCreated\":0, \"FatalErrors\":[], \"WarningMessages\":[{\"WarningRowNumber\":1,\"WarningMessage\":\"Warning message String 1\"},{\"WarningRowNumber\":2,\"WarningMessage\":\"Warning message String 2\"}], \"RecordsDeleted\":0, \"NonFatalExceptions\":[], \"RecordsUpdated\":0}";
		} else if (fatalErrorRealms.contains(realm)) {
			return "{\"RecordsCreated\":0, \"FatalErrors\":[{\"ErrorMessage\":\"Error message string 1\"},{\"ErrorMessage\":\"Error message string 2\"}], \"WarningMessages\":[], \"RecordsDeleted\":0, \"NonFatalExceptions\":[], \"RecordsUpdated\":0}";
		} else {

			JSONParser parser = new JSONParser();
			int rowsCreated = 0;
			try {
				JSONArray dataArr = (JSONArray) parser.parse(data);
				rowsCreated = dataArr.size();
				System.out.println("JSON Arr---" + dataArr.size());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "{\"RecordsCreated\":" + rowsCreated
					+ ", \"FatalErrors\":[], \"WarningMessages\":[], \"RecordsDeleted\":0, \"NonFatalExceptions\":[], \"RecordsUpdated\":0}";
		}
	}

	@RequestMapping(value = "/getGroups/NativeIntegrationDirectAction", method = RequestMethod.GET)
	public String getGroups(@RequestParam(value = "realm", defaultValue = "none") String realm) {
		return "[{\"UniqueName\":\"Procurement Manager\", \"Name\":\"Procurement Manager\"},{\"UniqueName\":\"Contract Agent\", \"Name\":\"Contract Agent\"}]";
	}

	@RequestMapping(value = "/getProcurementUnits/NativeIntegrationDirectAction", method = RequestMethod.GET)
	public String getProcurementUnits(@RequestParam(value = "realm", defaultValue = "none") String realm) {
		return "[{\"UniqueName\":\"BUY01\", \"Name\":\"BUY01\", \"LogoFileName\":\"\", \"Level\":\"\", \"Description\":\"BUY01 Description\", \"Parent\":\"All\"},{\"UniqueName\":\"BUY02\", \"Name\":\"BUY02\", \"LogoFileName\":\"\", \"Level\":\"\", \"Description\":\"BUY02 Description\", \"Parent\":\"All\"}]";
	}

	@RequestMapping(value = "/getUsers/NativeIntegrationDirectAction", method = RequestMethod.GET)
	public String getUsers(@RequestParam(value = "realm", defaultValue = "none") String realm) {
		return "[{\"Account\":null, \"WBSElement\":null, \"Organization\":\"[Buyer]\", \"timeZoneID\":\"Asia/Kolkata\", \"ApprovalLimit\":null, \"ActionCode\":\"01\", \"LastLoginDate\":null, \"Name\":[{\"languageCode\":\"EN\", \"value\":\"Test User\"}], \"BillingAddress\":\"3000\", \"SAPSerialNumber\":null, \"ExpenseApprovalLimit\":null, \"EmployeeSupplierID\":null, \"Phone\":null, \"Groups\":null, \"SAPLimitSplitValue\":null, \"Supervisor\":null, \"DeliverTo\":\"testuser\", \"NetworkKey\":null, \"PCardsList\":null, \"CostCenterKey\":null, \"DefaultCurrency\":\"USD\", \"LoginDate\":null, \"PersistedAlternateEmailAddressesList\":null, \"TimezoneID\":\"Asia/Kolkata\", \"PurchaseOrg\":null, \"InternalOrder\":null, \"EmailAddress\":\"nobody@ansmtp.ariba.com\", \"GLAccountKey\":null, \"ProcurementUnit\":\"US100\", \"AssetKey\":null, \"ActivityNumberKey\":null, \"ShipTo\":null, \"PurchaseGroup\":null, \"Fax\":null, \"LocaleIDUniqueName\":\"en_US\", \"user\":{\"PasswordAdapter\":\"PasswordAdapter1\", \"UniqueName\":\"testuser\"}, \"CompanyCode\":null}]";
	}

	@RequestMapping(value = "/getEncryptionInfo/NativeIntegrationDirectAction", method = RequestMethod.GET)
	public String getEncryptionInfo(@RequestParam(value = "realm", defaultValue = "none") String realm) {
		return "{\"CurrentVersion\": \"2\",\"EncryptionAlgorithms\": { \"2\": \"AES/CBC/PKCS5Padding\"},\"EncryptionKeys\":{\"1\": \"{DESede}2HWApPVqkq3voqoiLlO3q+n/EdA/dbPA\", \"2\": \"{DESede}5iqZexbW4mSAVmX//vty2ce9g9trIzJJ\"}}";
	}

	@RequestMapping(value = "/configs", method = RequestMethod.POST)
	public String configs(@RequestBody String realm) {
		return "hello post" + realm;
	}

	@RequestMapping(value = "/getStagedStatusAll", method = RequestMethod.GET)
	public List<StagedData> getStagedStatusAll() {

		System.out.println("getStagedStatus method start");
		List<StagedData> list = stagedDataRepository.findAllRecords();
		System.out.println("getStagedStatus method Done!");
		return list;
	}

	@RequestMapping(value = "/getStagedStatus", method = RequestMethod.GET)
	public StagedData getStagedStatus(@RequestParam(value = "anid", defaultValue = "none") String anid,
										@RequestParam(value = "uuid", defaultValue = "none") String uuid) {

		System.out.println("getStagedStatus method start");
		long tenant = tenantRepository.findTenandId(anid);
		List<StagedData> stagedDataList = stagedDataRepository.findStatusByUUID(tenant, "%" + uuid + "%");
		System.out.println("getStagedStatus method Done!");
		return stagedDataList .get(0);
	}
}
