package com.ariba.rest.mockapp.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TENANT_TAB")
public class Tenant implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String objectType = "Tenant";

    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "TENANT_ID")
    @GeneratedValue(generator = "tenant_id_sequence", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "tenant_id_sequence", sequenceName = "tenant_id_sequence", allocationSize = 1)
    private long tenantId;

    @Column(name = "IS_ACTIVE")
    private int isActive;

    @Column(name = "DATE_CREATED")
    private Date dateCreated;

    @Column(name = "DATE_UPDATED")
    private Date dateUpdated;

    @Column(name = "STATUS")
    private int status = 1;

    @Column(name = "AN_ID")
    private String anId;

    @Column(name = "PARENT_AN_ID")
    private String parentAnId;

    @Column(name = "REALM_NAME")
    private String realmName;

    @Column(name = "WEIGHT")
    private Double weight;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public long getTenantId ()
    {
        return tenantId;
    }

    public void setTenantId (long tenantId)
    {
        this.tenantId = tenantId;
    }

    public int getIsActive ()
    {
        return isActive;
    }

    public void setIsActive (int isActive)
    {
        this.isActive = isActive;
    }

    public Date getDateCreated ()
    {
        return dateCreated;
    }

    public void setDateCreated (Date dateCreated)
    {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated ()
    {
        return dateUpdated;
    }

    public void setDateUpdated (Date dateUpdated)
    {
        this.dateUpdated = dateUpdated;
    }

    public int getStatus ()
    {
        return status;
    }

    public void setStatus (int status)
    {
        this.status = status;
    }

    public String getAnId ()
    {
        return anId;
    }

    public void setAnId (String anId)
    {
        this.anId = anId;
    }

    public String getObjectType ()
    {
        return objectType;
    }

    public String getParentAnId ()
    {
        return parentAnId;
    }

    public void setParentAnId (String parentAnId)
    {
        this.parentAnId = parentAnId;
    }

    public String getRealmName ()
    {
        return realmName;
    }

    public void setRealmName (String realmName)
    {
        this.realmName = realmName;
    }

    public Double getWeight ()
    {
        return weight;
    }

    public void setWeight (Double weight)
    {
        this.weight = weight;
    }

    @Override
    public String toString ()
    {
        return "Tenant [id=" + id + ", tenantId=" + tenantId + ", isActive=" + isActive
                + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
                + ", status=" + status + ", anId=" + anId + ", parentAnId=" + parentAnId
                + ", realmName=" + realmName + ", weight=" + weight + "]";
    }
}
