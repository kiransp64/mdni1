package com.ariba.rest.mockapp.dao;

import com.ariba.rest.mockapp.model.StagedData;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("StageXMLDataRepositoryComponent")
public interface StagedDataRepository  extends PagingAndSortingRepository<StagedData, Long> {

	@Query("select s from StagedData s where s.tenantId = 1")
	public List<StagedData> findAllRecords();

	@Query("select s from StagedData s where s.tenantId = :tenantId and s.dataPath like :uuid")
	public List<StagedData> findStatusByUUID(@Param("tenantId") long tenantId,@Param("uuid") String uuid);
}

